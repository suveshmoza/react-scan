var __defProp=Object.defineProperty;var __name=(target,value)=>__defProp(target,"name",{value,configurable:!0});(function(){var __commonJSMin=__name((cb,mod)=>()=>(mod||(cb((mod={exports:{}}).exports,mod),cb=null),mod.exports),"__commonJSMin"),e$4="0.5.39",t$4=`bippy-${e$4}`,n$4=Object.defineProperty,r$6=Object.prototype.hasOwnProperty,i$6=__name(()=>{},"i$6"),a$5=__name(e2=>{try{Function.prototype.toString.call(e2).indexOf("^_^")>-1&&setTimeout(()=>{throw Error("React is running in production mode, but dead code elimination has not been applied. Read how to correctly configure React for production: https://reactjs.org/link/perf-use-production-build")})}catch{}},"a$5"),o$6=__name((e2=globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__)=>!!(e2&&"getFiberRoots"in e2),"o$6"),s$5=!1,c$5,l$6=__name((e2=globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__)=>s$5?!0:(e2&&typeof e2.inject=="function"&&(c$5=e2.inject.toString()),!!c$5?.includes("(injected)")),"l$6"),u$6=new Set,d$7=new Set,f$7=__name(e2=>{let r2=new Map,o2=0,s2={_instrumentationIsActive:!1,_instrumentationSource:t$4,checkDCE:a$5,hasUnsupportedRendererAttached:!1,inject(e3){let t2=++o2;return r2.set(t2,e3),d$7.add(e3),s2._instrumentationIsActive||(s2._instrumentationIsActive=!0,u$6.forEach(e4=>e4())),t2},on:i$6,onCommitFiberRoot:i$6,onCommitFiberUnmount:i$6,onPostCommitFiberRoot:i$6,renderers:r2,supportsFiber:!0,supportsFlight:!0};try{n$4(globalThis,"__REACT_DEVTOOLS_GLOBAL_HOOK__",{configurable:!0,enumerable:!0,get(){return s2},set(t3){if(t3&&typeof t3=="object"){let n2=s2.renderers;s2=t3,n2.size>0&&(n2.forEach((e3,n3)=>{d$7.add(e3),t3.renderers.set(n3,e3)}),p$7(e2))}}});let t2=window.hasOwnProperty,r3=!1;n$4(window,"hasOwnProperty",{configurable:!0,value:__name(function(...e3){try{if(!r3&&e3[0]==="__REACT_DEVTOOLS_GLOBAL_HOOK__")return globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__=void 0,r3=!0,-0}catch{}return t2.apply(this,e3)},"value"),writable:!0})}catch{p$7(e2)}return s2},"f$7"),p$7=__name(e2=>{e2&&u$6.add(e2);try{let n2=globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!n2)return;if(!n2._instrumentationSource){n2.checkDCE=a$5,n2.supportsFiber=!0,n2.supportsFlight=!0,n2.hasUnsupportedRendererAttached=!1,n2._instrumentationSource=t$4,n2._instrumentationIsActive=!1;let e3=o$6(n2);if(e3||(n2.on=i$6),n2.renderers.size){n2._instrumentationIsActive=!0,u$6.forEach(e4=>e4());return}let r2=n2.inject,c2=l$6(n2);c2&&!e3&&(s$5=!0,n2.inject({scheduleRefresh(){}})&&(n2._instrumentationIsActive=!0)),n2.inject=e4=>{let t2=r2(e4);return d$7.add(e4),c2&&n2.renderers.set(t2,e4),n2._instrumentationIsActive=!0,u$6.forEach(e5=>e5()),t2}}(n2.renderers.size||n2._instrumentationIsActive||l$6())&&e2?.()}catch{}},"p$7"),m$7=__name(()=>r$6.call(globalThis,"__REACT_DEVTOOLS_GLOBAL_HOOK__"),"m$7"),h$7=__name(e2=>m$7()?(p$7(e2),globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__):f$7(e2),"h$7"),g$7=__name(()=>!!(typeof window<"u"&&(window.document?.createElement||window.navigator?.product==="ReactNative")),"g$7"),_$7=__name(()=>{try{g$7()&&h$7()}catch{}},"_$7");_$7();var d$6=0,ee$1=1,te$1=3,ne$1=5,re$1=6,ie$1=7,f$6=9,p$6=11,m$6=13,h$6=14,g$6=15,ae$1=16,oe$1=18,se$1=19,ce$1=22,le$1=23,ue$1=26,de$1=27,fe$1=28,pe$1=30,_$6=60111,me$1="Symbol(react.element)",he$1="Symbol(react.transitional.element)",v$5="Symbol(react.concurrent_mode)",y$7="Symbol(react.async_mode)",b$6=13366,ge$1=__name(e2=>typeof e2=="object"&&!!e2&&"$$typeof"in e2&&["Symbol(react.element)","Symbol(react.transitional.element)"].includes(String(e2.$$typeof)),"ge$1"),_e$1=__name(e2=>typeof e2=="object"&&!!e2&&"tag"in e2&&"stateNode"in e2&&"return"in e2&&"child"in e2&&"sibling"in e2&&"flags"in e2,"_e$1"),x$7=__name(e2=>{switch(e2.tag){case 5:case 26:case 27:return!0;default:return typeof e2.type=="string"}},"x$7"),ve$1=__name(e2=>{switch(e2.tag){case 1:case 11:case 0:case 14:case 15:return!0;default:return!1}},"ve$1"),ye$1=__name(e2=>!e2||typeof e2!="object"?!1:"pendingProps"in e2&&!("containerInfo"in e2),"ye$1"),be$1=__name((e2,t2)=>e2===t2||e2.alternate===t2||t2.alternate===e2,"be$1"),xe$1=__name((e2,t2)=>{try{let n2=e2.dependencies,r2=e2.alternate?.dependencies;if(!n2||!r2||typeof n2!="object"||!("firstContext"in n2)||typeof r2!="object"||!("firstContext"in r2))return!1;let i2=n2.firstContext,a2=r2.firstContext;for(;i2&&typeof i2=="object"&&"memoizedValue"in i2||a2&&typeof a2=="object"&&"memoizedValue"in a2;){if(t2(i2,a2)===!0)return!0;i2=i2?.next,a2=a2?.next}}catch{}return!1},"xe$1"),S$5=__name((e2,t2)=>{try{let n2=e2.memoizedState,r2=e2.alternate?.memoizedState;for(;n2||r2;){if(t2(n2,r2)===!0)return!0;n2=n2?.next,r2=r2?.next}}catch{}return!1},"S$5"),C$6=__name((e2,t2)=>{try{let n2=e2.memoizedProps,r2=e2.alternate?.memoizedProps||{},i2=new Set([...Object.keys(n2),...Object.keys(r2)]);for(let e3 of i2){let i3=r2?.[e3],a2=n2?.[e3];if(t2(e3,a2,i3)===!0)return!0}}catch{}return!1},"C$6"),w$7=__name(e2=>{let t2=e2.memoizedProps,n2=e2.alternate?.memoizedProps||{},r2=e2.flags??e2.effectTag??0;switch(e2.tag){case 1:case 9:case 11:case 0:case 14:case 15:return(r2&1)==1;default:return e2.alternate?n2!==t2||e2.alternate.memoizedState!==e2.memoizedState||e2.alternate.ref!==e2.ref:!0}},"w$7"),T$7=__name(e2=>!!(e2.flags&(b$6|8)||e2.subtreeFlags&(b$6|8)),"T$7"),E$6=__name(e2=>{let t2=[],n2=[e2];for(;n2.length;){let e3=n2.pop();e3&&(x$7(e3)&&T$7(e3)&&w$7(e3)&&t2.push(e3),e3.child&&n2.push(e3.child),e3.sibling&&n2.push(e3.sibling))}return t2},"E$6"),D$5=__name(e2=>{let t2=[],n2=e2;for(;n2.return;)t2.push(n2),n2=n2.return;return t2},"D$5"),O$4=__name(e2=>{switch(e2.tag){case 18:return!0;case 7:case 6:case 23:case 22:return!0;case 3:return!1;default:{let t2=typeof e2.type=="object"&&e2.type!==null?e2.type.$$typeof:e2.type;switch(typeof t2=="symbol"?t2.toString():t2){case _$6:case v$5:case y$7:return!0;default:return!1}}}},"O$4"),k$5=__name((e2,t2=!1)=>{let n2=j$5(e2,x$7,t2);return n2||=j$5(e2,x$7,!t2),n2},"k$5"),A$5=__name(e2=>{let t2=[],n2=[];for(x$7(e2)?t2.push(e2):e2.child&&n2.push(e2.child);n2.length;){let e3=n2.pop();if(!e3)break;x$7(e3)?t2.push(e3):e3.child&&n2.push(e3.child),e3.sibling&&n2.push(e3.sibling)}return t2},"A$5");function j$5(e2,t2,n2=!1){if(!e2)return null;let r2=t2(e2);if(r2 instanceof Promise)return(async()=>{if(await r2===!0)return e2;let i3=n2?e2.return:e2.child;for(;i3;){let e3=await N$3(i3,t2,n2);if(e3)return e3;i3=n2?null:i3.sibling}return null})();if(r2===!0)return e2;let i2=n2?e2.return:e2.child;for(;i2;){let e3=M$2(i2,t2,n2);if(e3)return e3;i2=n2?null:i2.sibling}return null}__name(j$5,"j$5");var M$2=__name((e2,t2,n2=!1)=>{if(!e2)return null;if(t2(e2)===!0)return e2;let r2=n2?e2.return:e2.child;for(;r2;){let e3=M$2(r2,t2,n2);if(e3)return e3;r2=n2?null:r2.sibling}return null},"M$2"),N$3=__name(async(e2,t2,n2=!1)=>{if(!e2)return null;if(await t2(e2)===!0)return e2;let r2=n2?e2.return:e2.child;for(;r2;){let e3=await N$3(r2,t2,n2);if(e3)return e3;r2=n2?null:r2.sibling}return null},"N$3"),Se$1=__name(e2=>{let t2=e2?.actualDuration??0,n2=t2,r2=e2?.child??null;for(;t2>0&&r2!=null;)n2-=r2.actualDuration??0,r2=r2.sibling;return{selfTime:n2,totalTime:t2}},"Se$1"),Ce$1=__name(e2=>!!e2.updateQueue?.memoCache,"Ce$1"),P$3=__name(e2=>{let t2=e2;return typeof t2=="function"?t2:typeof t2=="object"&&t2?P$3(t2.type||t2.render):null},"P$3"),we$1=__name(e2=>{let t2=e2;if(typeof t2=="string")return t2;if(typeof t2!="function"&&!(typeof t2=="object"&&t2))return null;let n2=t2.displayName||t2.name||null;if(n2)return n2;let r2=P$3(t2);return r2&&(r2.displayName||r2.name)||null},"we$1"),F$4=__name(e2=>{try{if(typeof e2.version=="string"&&e2.bundleType>0)return"development"}catch{}return"production"},"F$4"),Te$1=__name(()=>{let e2=globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__;return!!e2?._instrumentationIsActive||o$6(e2)||l$6(e2)},"Te$1"),Ee$1=__name(e2=>{let t2=e2.alternate;if(!t2)return e2;if(t2.actualStartTime&&e2.actualStartTime)return t2.actualStartTime>e2.actualStartTime?t2:e2;for(let t3 of $$2){let n2=j$5(t3.current,t4=>{if(t4===e2)return!0});if(n2)return n2}return e2},"Ee$1"),I$2=0,L$2=new WeakMap,R$2=__name((e2,t2=I$2++)=>{L$2.set(e2,t2)},"R$2"),z$2=__name(e2=>{let t2=L$2.get(e2);return!t2&&e2.alternate&&(t2=L$2.get(e2.alternate)),t2||(t2=I$2++,R$2(e2,t2)),t2},"z$2"),B$4=__name((e2,t2,n2)=>{let r2=t2;for(;r2!=null;){if(L$2.has(r2)||z$2(r2),!O$4(r2)&&w$7(r2)&&e2(r2,"mount"),r2.tag===13)if(r2.memoizedState!==null){let t3=r2.child,n3=t3?t3.sibling:null;if(n3){let t4=n3.child;t4!==null&&B$4(e2,t4,!1)}}else{let t3=null;r2.child!==null&&(t3=r2.child.child),t3!==null&&B$4(e2,t3,!1)}else r2.child!=null&&B$4(e2,r2.child,!0);r2=n2?r2.sibling:null}},"B$4"),V$3=__name((e2,t2,n2,r2)=>{if(L$2.has(t2)||z$2(t2),!n2)return;L$2.has(n2)||z$2(n2);let i2=t2.tag===13,a2=!O$4(t2);a2&&w$7(t2)&&e2(t2,"update");let o2=i2&&n2.memoizedState!==null,s2=i2&&t2.memoizedState!==null;if(o2&&s2){let r3=t2.child?.sibling??null,i3=n2.child?.sibling??null;r3!==null&&i3!==null&&V$3(e2,r3,i3,t2)}else if(o2&&!s2){let n3=t2.child;n3!==null&&B$4(e2,n3,!0)}else if(!o2&&s2){U$2(e2,n2);let r3=t2.child?.sibling??null;r3!==null&&B$4(e2,r3,!0)}else if(t2.child!==n2.child){let n3=t2.child;for(;n3;){if(n3.alternate){let i3=n3.alternate;V$3(e2,n3,i3,a2?t2:r2)}else B$4(e2,n3,!1);n3=n3.sibling}}},"V$3"),H$3=__name((e2,t2)=>{(t2.tag===3||!O$4(t2))&&e2(t2,"unmount")},"H$3"),U$2=__name((e2,t2)=>{let n2=t2.tag===13&&t2.memoizedState!==null,r2=t2.child;for(n2&&(r2=(t2.child?.sibling??null)?.child??null);r2!==null;)r2.return!==null&&(H$3(e2,r2),U$2(e2,r2)),r2=r2.sibling},"U$2"),De$1=0,W$1=new WeakMap,Oe$1=__name((e2,t2)=>{let n2="current"in e2?e2.current:e2,r2=W$1.get(e2);r2||(r2={id:De$1++,prevFiber:null},W$1.set(e2,r2));let{prevFiber:i2}=r2;if(!n2)H$3(t2,n2);else if(i2!==null){let e3=i2&&i2.memoizedState!=null&&i2.memoizedState.element!=null&&i2.memoizedState.isDehydrated!==!0,r3=n2.memoizedState!=null&&n2.memoizedState.element!=null&&n2.memoizedState.isDehydrated!==!0;!e3&&r3?B$4(t2,n2,!1):e3&&r3?V$3(t2,n2,n2.alternate,null):e3&&!r3&&H$3(t2,n2)}else B$4(t2,n2,!0);r2.prevFiber=n2},"Oe$1"),G$2=null,K$2=null,q$4=null,J$2=__name(()=>{if(!m$7())return null;let e2=h$7();if(!e2?.renderers)return null;if(G$2||K$2||q$4)return{overrideContext:q$4,overrideHookState:K$2,overrideProps:G$2};for(let[,t2]of Array.from(e2.renderers))try{if(K$2){let e3=K$2;K$2=__name((n2,r2,i2,a2)=>{let o2=n2.memoizedState;for(let e4=0;e4<Number(r2)&&o2?.next;e4++)o2=o2.next;if(o2?.queue){let e4=o2.queue;if(Y$1(e4)&&"dispatch"in e4){let t3=e4.dispatch;t3(a2);return}}e3(n2,r2,i2,a2),t2.overrideHookState?.(n2,r2,i2,a2)},"K$2")}else t2.overrideHookState&&(K$2=t2.overrideHookState);if(G$2){let e3=G$2;G$2=__name((n2,r2,i2)=>{e3(n2,r2,i2),t2.overrideProps?.(n2,r2,i2)},"G$2")}else t2.overrideProps&&(G$2=t2.overrideProps);q$4=__name((e3,t3,n2,r2)=>{let i2=e3;for(;i2;){let e4=i2.type;if(e4===t3||e4?.Provider===t3){G$2&&(G$2(i2,["value",...n2],r2),i2.alternate&&G$2(i2.alternate,["value",...n2],r2));break}i2=i2.return}},"q$4")}catch{}},"J$2"),Y$1=__name(e2=>Object.prototype.toString.call(e2)==="[object Object]"&&(Object.getPrototypeOf(e2)===Object.prototype||Object.getPrototypeOf(e2)===null),"Y$1"),X$2=__name((e2,t2=[])=>{if(!Y$1(e2))return[{path:t2,value:e2}];let n2=[];for(let r2 in e2){let i2=e2[r2],a2=t2.concat(r2);Y$1(i2)?n2.push(...X$2(i2,a2)):n2.push({path:a2,value:i2})}return n2},"X$2"),ke$1=__name((e2,t2)=>{J$2();let n2=X$2(t2);for(let{path:t3,value:r2}of n2)try{G$2?.(e2,t3,r2)}catch{}},"ke$1"),Ae$1=__name((e2,t2,n2)=>{J$2();let r2=String(t2);if(Y$1(n2)){let t3=X$2(n2);for(let{path:n3,value:i2}of t3)try{K$2?.(e2,r2,n3,i2)}catch{}}else try{K$2?.(e2,r2,[],n2)}catch{}},"Ae$1"),je$1=__name((e2,t2,n2)=>{if(J$2(),Y$1(n2)){let r2=X$2(n2);for(let{path:n3,value:i2}of r2)try{q$4?.(e2,t2,n3,i2)}catch{}}else try{q$4?.(e2,t2,[],n2)}catch{}},"je$1"),Me$1=__name(e2=>{let t2=h$7(e2.onActive);t2._instrumentationSource=e2.name??t$4;let n2=t2.onCommitFiberRoot;if(e2.onCommitFiberRoot){let r3=__name((t3,i3,a2)=>{n2!==r3&&(n2?.(t3,i3,a2),e2.onCommitFiberRoot?.(t3,i3,a2))},"r");t2.onCommitFiberRoot=r3}let r2=t2.onCommitFiberUnmount;if(e2.onCommitFiberUnmount){let n3=__name((i3,a2)=>{t2.onCommitFiberUnmount===n3&&(r2?.(i3,a2),e2.onCommitFiberUnmount?.(i3,a2))},"n");t2.onCommitFiberUnmount=n3}let i2=t2.onPostCommitFiberRoot;if(e2.onPostCommitFiberRoot){let n3=__name((r3,a2)=>{t2.onPostCommitFiberRoot===n3&&(i2?.(r3,a2),e2.onPostCommitFiberRoot?.(r3,a2))},"n");t2.onPostCommitFiberRoot=n3}return t2},"Me$1"),Z$1=__name(e2=>{let t2=globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__;if(t2?.renderers)for(let n2 of t2.renderers.values())try{let t3=n2.findFiberByHostInstance?.(e2);if(t3)return t3}catch{}if(typeof e2=="object"&&e2){if("_reactRootContainer"in e2)return e2._reactRootContainer?._internalRoot?.current?.child;for(let t3 in e2)if(t3.startsWith("__reactContainer$")||t3.startsWith("__reactInternalInstance$")||t3.startsWith("__reactFiber"))return e2[t3]||null}return null},"Z$1"),Q$2=Error(),$$2=new Set,Ne$1=__name((e2,n2={})=>{let i2=e2.onActive,a2=m$7(),o2=o$6(),l2=l$6(),u2,d2=!n2.isProduction;return e2.onActive=()=>{clearTimeout(u2);let t2=!0;try{let e3=h$7();for(let r2 of e3.renderers.values()){let[e4]=r2.version.split(".");Number(e4)<(n2.minReactMajorVersion??17)&&(t2=!1),F$4(r2)==="development"?d2=!0:n2.dangerouslyRunInProduction||(t2=!1)}}catch(e3){n2.onError?.(e3)}if(!t2){e2.onCommitFiberRoot=void 0,e2.onCommitFiberUnmount=void 0,e2.onPostCommitFiberRoot=void 0,e2.onActive=void 0;return}i2?.();try{let t3=e2.onCommitFiberRoot;t3&&(e2.onCommitFiberRoot=(e3,r3,i4)=>{$$2.has(r3)||$$2.add(r3);try{t3(e3,r3,i4)}catch(e4){n2.onError?.(e4)}});let r2=e2.onCommitFiberUnmount;r2&&(e2.onCommitFiberUnmount=(e3,t4)=>{try{r2(e3,t4)}catch(e4){n2.onError?.(e4)}});let i3=e2.onPostCommitFiberRoot;i3&&(e2.onPostCommitFiberRoot=(e3,t4)=>{try{i3(e3,t4)}catch(e4){n2.onError?.(e4)}})}catch(e3){n2.onError?.(e3)}},!a2&&!o2&&!l2&&(u2=setTimeout(()=>{d2&&n2.onError?.(Q$2),stop()},n2.installCheckTimeout??100)),e2},"Ne$1"),n$3,l$5,u$5,t$3,i$5,r$5,o$5,e$3,f$5,c$4,s$4,a$4,h$5,p$5,v$4,y$6,d$5={},w$6=[],_$5=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,g$5=Array.isArray;function m$5(n2,l2){for(var u2 in l2)n2[u2]=l2[u2];return n2}__name(m$5,"m$5");function b$5(n2){n2&&n2.parentNode&&n2.parentNode.removeChild(n2)}__name(b$5,"b$5");function k$4(l2,u2,t2){var i2,r2,o2,e2={};for(o2 in u2)o2=="key"?i2=u2[o2]:o2=="ref"?r2=u2[o2]:e2[o2]=u2[o2];if(arguments.length>2&&(e2.children=arguments.length>3?n$3.call(arguments,2):t2),typeof l2=="function"&&l2.defaultProps!=null)for(o2 in l2.defaultProps)e2[o2]===void 0&&(e2[o2]=l2.defaultProps[o2]);return x$6(l2,e2,i2,r2,null)}__name(k$4,"k$4");function x$6(n2,t2,i2,r2,o2){var e2={type:n2,props:t2,key:i2,ref:r2,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o2??++u$5,__i:-1,__u:0};return o2==null&&l$5.vnode!=null&&l$5.vnode(e2),e2}__name(x$6,"x$6");function S$4(n2){return n2.children}__name(S$4,"S$4");function C$5(n2,l2){this.props=n2,this.context=l2}__name(C$5,"C$5");function $$1(n2,l2){if(l2==null)return n2.__?$$1(n2.__,n2.__i+1):null;for(var u2;l2<n2.__k.length;l2++)if((u2=n2.__k[l2])!=null&&u2.__e!=null)return u2.__e;return typeof n2.type=="function"?$$1(n2):null}__name($$1,"$$1");function I$1(n2){if(n2.__P&&n2.__d){var u2=n2.__v,t2=u2.__e,i2=[],r2=[],o2=m$5({},u2);o2.__v=u2.__v+1,l$5.vnode&&l$5.vnode(o2),q$3(n2.__P,o2,u2,n2.__n,n2.__P.namespaceURI,32&u2.__u?[t2]:null,i2,t2??$$1(u2),!!(32&u2.__u),r2),o2.__v=u2.__v,o2.__.__k[o2.__i]=o2,D$4(i2,o2,r2),u2.__e=u2.__=null,o2.__e!=t2&&P$2(o2)}}__name(I$1,"I$1");function P$2(n2){if((n2=n2.__)!=null&&n2.__c!=null)return n2.__e=n2.__c.base=null,n2.__k.some(function(l2){if(l2!=null&&l2.__e!=null)return n2.__e=n2.__c.base=l2.__e}),P$2(n2)}__name(P$2,"P$2");function A$4(n2){(!n2.__d&&(n2.__d=!0)&&i$5.push(n2)&&!H$2.__r++||r$5!=l$5.debounceRendering)&&((r$5=l$5.debounceRendering)||o$5)(H$2)}__name(A$4,"A$4");function H$2(){try{for(var n2,l2=1;i$5.length;)i$5.length>l2&&i$5.sort(e$3),n2=i$5.shift(),l2=i$5.length,I$1(n2)}finally{i$5.length=H$2.__r=0}}__name(H$2,"H$2");function L$1(n2,l2,u2,t2,i2,r2,o2,e2,f2,c2,s2){var a2,h2,p2,v2,y2,_2,g2,m2=t2&&t2.__k||w$6,b2=l2.length;for(f2=T$6(u2,l2,m2,f2,b2),a2=0;a2<b2;a2++)(p2=u2.__k[a2])!=null&&(h2=p2.__i!=-1&&m2[p2.__i]||d$5,p2.__i=a2,_2=q$3(n2,p2,h2,i2,r2,o2,e2,f2,c2,s2),v2=p2.__e,p2.ref&&h2.ref!=p2.ref&&(h2.ref&&J$1(h2.ref,null,p2),s2.push(p2.ref,p2.__c||v2,p2)),y2==null&&v2!=null&&(y2=v2),(g2=!!(4&p2.__u))||h2.__k===p2.__k?(f2=j$4(p2,f2,n2,g2),g2&&h2.__e&&(h2.__e=null)):typeof p2.type=="function"&&_2!==void 0?f2=_2:v2&&(f2=v2.nextSibling),p2.__u&=-7);return u2.__e=y2,f2}__name(L$1,"L$1");function T$6(n2,l2,u2,t2,i2){var r2,o2,e2,f2,c2,s2=u2.length,a2=s2,h2=0;for(n2.__k=new Array(i2),r2=0;r2<i2;r2++)(o2=l2[r2])!=null&&typeof o2!="boolean"&&typeof o2!="function"?(typeof o2=="string"||typeof o2=="number"||typeof o2=="bigint"||o2.constructor==String?o2=n2.__k[r2]=x$6(null,o2,null,null,null):g$5(o2)?o2=n2.__k[r2]=x$6(S$4,{children:o2},null,null,null):o2.constructor===void 0&&o2.__b>0?o2=n2.__k[r2]=x$6(o2.type,o2.props,o2.key,o2.ref?o2.ref:null,o2.__v):n2.__k[r2]=o2,f2=r2+h2,o2.__=n2,o2.__b=n2.__b+1,e2=null,(c2=o2.__i=O$3(o2,u2,f2,a2))!=-1&&(a2--,(e2=u2[c2])&&(e2.__u|=2)),e2==null||e2.__v==null?(c2==-1&&(i2>s2?h2--:i2<s2&&h2++),typeof o2.type!="function"&&(o2.__u|=4)):c2!=f2&&(c2==f2-1?h2--:c2==f2+1?h2++:(c2>f2?h2--:h2++,o2.__u|=4))):n2.__k[r2]=null;if(a2)for(r2=0;r2<s2;r2++)(e2=u2[r2])!=null&&(2&e2.__u)==0&&(e2.__e==t2&&(t2=$$1(e2)),K$1(e2,e2));return t2}__name(T$6,"T$6");function j$4(n2,l2,u2,t2){var i2,r2;if(typeof n2.type=="function"){for(i2=n2.__k,r2=0;i2&&r2<i2.length;r2++)i2[r2]&&(i2[r2].__=n2,l2=j$4(i2[r2],l2,u2,t2));return l2}n2.__e!=l2&&(t2&&(l2&&n2.type&&!l2.parentNode&&(l2=$$1(n2)),u2.insertBefore(n2.__e,l2||null)),l2=n2.__e);do l2=l2&&l2.nextSibling;while(l2!=null&&l2.nodeType==8);return l2}__name(j$4,"j$4");function F$3(n2,l2){return l2=l2||[],n2==null||typeof n2=="boolean"||(g$5(n2)?n2.some(function(n3){F$3(n3,l2)}):l2.push(n2)),l2}__name(F$3,"F$3");function O$3(n2,l2,u2,t2){var i2,r2,o2,e2=n2.key,f2=n2.type,c2=l2[u2],s2=c2!=null&&(2&c2.__u)==0;if(c2===null&&e2==null||s2&&e2==c2.key&&f2==c2.type)return u2;if(t2>(s2?1:0)){for(i2=u2-1,r2=u2+1;i2>=0||r2<l2.length;)if((c2=l2[o2=i2>=0?i2--:r2++])!=null&&(2&c2.__u)==0&&e2==c2.key&&f2==c2.type)return o2}return-1}__name(O$3,"O$3");function z$1(n2,l2,u2){l2[0]=="-"?n2.setProperty(l2,u2??""):n2[l2]=u2==null?"":typeof u2!="number"||_$5.test(l2)?u2:u2+"px"}__name(z$1,"z$1");function N$2(n2,l2,u2,t2,i2){var r2,o2;n:if(l2=="style")if(typeof u2=="string")n2.style.cssText=u2;else{if(typeof t2=="string"&&(n2.style.cssText=t2=""),t2)for(l2 in t2)u2&&l2 in u2||z$1(n2.style,l2,"");if(u2)for(l2 in u2)t2&&u2[l2]==t2[l2]||z$1(n2.style,l2,u2[l2])}else if(l2[0]=="o"&&l2[1]=="n")r2=l2!=(l2=l2.replace(a$4,"$1")),o2=l2.toLowerCase(),l2=o2 in n2||l2=="onFocusOut"||l2=="onFocusIn"?o2.slice(2):l2.slice(2),n2.l||(n2.l={}),n2.l[l2+r2]=u2,u2?t2?u2[s$4]=t2[s$4]:(u2[s$4]=h$5,n2.addEventListener(l2,r2?v$4:p$5,r2)):n2.removeEventListener(l2,r2?v$4:p$5,r2);else{if(i2=="http://www.w3.org/2000/svg")l2=l2.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(l2!="width"&&l2!="height"&&l2!="href"&&l2!="list"&&l2!="form"&&l2!="tabIndex"&&l2!="download"&&l2!="rowSpan"&&l2!="colSpan"&&l2!="role"&&l2!="popover"&&l2 in n2)try{n2[l2]=u2??"";break n}catch{}typeof u2=="function"||(u2==null||u2===!1&&l2[4]!="-"?n2.removeAttribute(l2):n2.setAttribute(l2,l2=="popover"&&u2==1?"":u2))}}__name(N$2,"N$2");function V$2(n2){return function(u2){if(this.l){var t2=this.l[u2.type+n2];if(u2[c$4]==null)u2[c$4]=h$5++;else if(u2[c$4]<t2[s$4])return;return t2(l$5.event?l$5.event(u2):u2)}}}__name(V$2,"V$2");function q$3(n2,u2,t2,i2,r2,o2,e2,f2,c2,s2){var a2,h2,p2,v2,y2,d2,_2,k2,x2,M2,$2,I2,P2,A2,H2,T2=u2.type;if(u2.constructor!==void 0)return null;128&t2.__u&&(c2=!!(32&t2.__u),o2=[f2=u2.__e=t2.__e]),(a2=l$5.__b)&&a2(u2);n:if(typeof T2=="function")try{if(k2=u2.props,x2=T2.prototype&&T2.prototype.render,M2=(a2=T2.contextType)&&i2[a2.__c],$2=a2?M2?M2.props.value:a2.__:i2,t2.__c?_2=(h2=u2.__c=t2.__c).__=h2.__E:(x2?u2.__c=h2=new T2(k2,$2):(u2.__c=h2=new C$5(k2,$2),h2.constructor=T2,h2.render=Q$1),M2&&M2.sub(h2),h2.state||(h2.state={}),h2.__n=i2,p2=h2.__d=!0,h2.__h=[],h2._sb=[]),x2&&h2.__s==null&&(h2.__s=h2.state),x2&&T2.getDerivedStateFromProps!=null&&(h2.__s==h2.state&&(h2.__s=m$5({},h2.__s)),m$5(h2.__s,T2.getDerivedStateFromProps(k2,h2.__s))),v2=h2.props,y2=h2.state,h2.__v=u2,p2)x2&&T2.getDerivedStateFromProps==null&&h2.componentWillMount!=null&&h2.componentWillMount(),x2&&h2.componentDidMount!=null&&h2.__h.push(h2.componentDidMount);else{if(x2&&T2.getDerivedStateFromProps==null&&k2!==v2&&h2.componentWillReceiveProps!=null&&h2.componentWillReceiveProps(k2,$2),u2.__v==t2.__v||!h2.__e&&h2.shouldComponentUpdate!=null&&h2.shouldComponentUpdate(k2,h2.__s,$2)===!1){u2.__v!=t2.__v&&(h2.props=k2,h2.state=h2.__s,h2.__d=!1),u2.__e=t2.__e,u2.__k=t2.__k,u2.__k.some(function(n3){n3&&(n3.__=u2)}),w$6.push.apply(h2.__h,h2._sb),h2._sb=[],h2.__h.length&&e2.push(h2);break n}h2.componentWillUpdate!=null&&h2.componentWillUpdate(k2,h2.__s,$2),x2&&h2.componentDidUpdate!=null&&h2.__h.push(function(){h2.componentDidUpdate(v2,y2,d2)})}if(h2.context=$2,h2.props=k2,h2.__P=n2,h2.__e=!1,I2=l$5.__r,P2=0,x2)h2.state=h2.__s,h2.__d=!1,I2&&I2(u2),a2=h2.render(h2.props,h2.state,h2.context),w$6.push.apply(h2.__h,h2._sb),h2._sb=[];else do h2.__d=!1,I2&&I2(u2),a2=h2.render(h2.props,h2.state,h2.context),h2.state=h2.__s;while(h2.__d&&++P2<25);h2.state=h2.__s,h2.getChildContext!=null&&(i2=m$5(m$5({},i2),h2.getChildContext())),x2&&!p2&&h2.getSnapshotBeforeUpdate!=null&&(d2=h2.getSnapshotBeforeUpdate(v2,y2)),A2=a2!=null&&a2.type===S$4&&a2.key==null?E$5(a2.props.children):a2,f2=L$1(n2,g$5(A2)?A2:[A2],u2,t2,i2,r2,o2,e2,f2,c2,s2),h2.base=u2.__e,u2.__u&=-161,h2.__h.length&&e2.push(h2),_2&&(h2.__E=h2.__=null)}catch(n3){if(u2.__v=null,c2||o2!=null)if(n3.then){for(u2.__u|=c2?160:128;f2&&f2.nodeType==8&&f2.nextSibling;)f2=f2.nextSibling;o2[o2.indexOf(f2)]=null,u2.__e=f2}else{for(H2=o2.length;H2--;)b$5(o2[H2]);B$3(u2)}else u2.__e=t2.__e,u2.__k=t2.__k,n3.then||B$3(u2);l$5.__e(n3,u2,t2)}else o2==null&&u2.__v==t2.__v?(u2.__k=t2.__k,u2.__e=t2.__e):f2=u2.__e=G$1(t2.__e,u2,t2,i2,r2,o2,e2,c2,s2);return(a2=l$5.diffed)&&a2(u2),128&u2.__u?void 0:f2}__name(q$3,"q$3");function B$3(n2){n2&&(n2.__c&&(n2.__c.__e=!0),n2.__k&&n2.__k.some(B$3))}__name(B$3,"B$3");function D$4(n2,u2,t2){for(var i2=0;i2<t2.length;i2++)J$1(t2[i2],t2[++i2],t2[++i2]);l$5.__c&&l$5.__c(u2,n2),n2.some(function(u3){try{n2=u3.__h,u3.__h=[],n2.some(function(n3){n3.call(u3)})}catch(n3){l$5.__e(n3,u3.__v)}})}__name(D$4,"D$4");function E$5(n2){return typeof n2!="object"||n2==null||n2.__b>0?n2:g$5(n2)?n2.map(E$5):m$5({},n2)}__name(E$5,"E$5");function G$1(u2,t2,i2,r2,o2,e2,f2,c2,s2){var a2,h2,p2,v2,y2,w2,_2,m2=i2.props||d$5,k2=t2.props,x2=t2.type;if(x2=="svg"?o2="http://www.w3.org/2000/svg":x2=="math"?o2="http://www.w3.org/1998/Math/MathML":o2||(o2="http://www.w3.org/1999/xhtml"),e2!=null){for(a2=0;a2<e2.length;a2++)if((y2=e2[a2])&&"setAttribute"in y2==!!x2&&(x2?y2.localName==x2:y2.nodeType==3)){u2=y2,e2[a2]=null;break}}if(u2==null){if(x2==null)return document.createTextNode(k2);u2=document.createElementNS(o2,x2,k2.is&&k2),c2&&(l$5.__m&&l$5.__m(t2,e2),c2=!1),e2=null}if(x2==null)m2===k2||c2&&u2.data==k2||(u2.data=k2);else{if(e2=e2&&n$3.call(u2.childNodes),!c2&&e2!=null)for(m2={},a2=0;a2<u2.attributes.length;a2++)m2[(y2=u2.attributes[a2]).name]=y2.value;for(a2 in m2)y2=m2[a2],a2=="dangerouslySetInnerHTML"?p2=y2:a2=="children"||a2 in k2||a2=="value"&&"defaultValue"in k2||a2=="checked"&&"defaultChecked"in k2||N$2(u2,a2,null,y2,o2);for(a2 in k2)y2=k2[a2],a2=="children"?v2=y2:a2=="dangerouslySetInnerHTML"?h2=y2:a2=="value"?w2=y2:a2=="checked"?_2=y2:c2&&typeof y2!="function"||m2[a2]===y2||N$2(u2,a2,y2,m2[a2],o2);if(h2)c2||p2&&(h2.__html==p2.__html||h2.__html==u2.innerHTML)||(u2.innerHTML=h2.__html),t2.__k=[];else if(p2&&(u2.innerHTML=""),L$1(t2.type=="template"?u2.content:u2,g$5(v2)?v2:[v2],t2,i2,r2,x2=="foreignObject"?"http://www.w3.org/1999/xhtml":o2,e2,f2,e2?e2[0]:i2.__k&&$$1(i2,0),c2,s2),e2!=null)for(a2=e2.length;a2--;)b$5(e2[a2]);c2||(a2="value",x2=="progress"&&w2==null?u2.removeAttribute("value"):w2!=null&&(w2!==u2[a2]||x2=="progress"&&!w2||x2=="option"&&w2!=m2[a2])&&N$2(u2,a2,w2,m2[a2],o2),a2="checked",_2!=null&&_2!=u2[a2]&&N$2(u2,a2,_2,m2[a2],o2))}return u2}__name(G$1,"G$1");function J$1(n2,u2,t2){try{if(typeof n2=="function"){var i2=typeof n2.__u=="function";i2&&n2.__u(),i2&&u2==null||(n2.__u=n2(u2))}else n2.current=u2}catch(n3){l$5.__e(n3,t2)}}__name(J$1,"J$1");function K$1(n2,u2,t2){var i2,r2;if(l$5.unmount&&l$5.unmount(n2),(i2=n2.ref)&&(i2.current&&i2.current!=n2.__e||J$1(i2,null,u2)),(i2=n2.__c)!=null){if(i2.componentWillUnmount)try{i2.componentWillUnmount()}catch(n3){l$5.__e(n3,u2)}i2.base=i2.__P=null}if(i2=n2.__k)for(r2=0;r2<i2.length;r2++)i2[r2]&&K$1(i2[r2],u2,t2||typeof n2.type!="function");t2||b$5(n2.__e),n2.__c=n2.__=n2.__e=void 0}__name(K$1,"K$1");function Q$1(n2,l2,u2){return this.constructor(n2,u2)}__name(Q$1,"Q$1");function R$1(u2,t2,i2){var r2,o2,e2,f2;t2==document&&(t2=document.documentElement),l$5.__&&l$5.__(u2,t2),o2=(r2=typeof i2=="function")?null:i2&&i2.__k||t2.__k,e2=[],f2=[],q$3(t2,u2=(!r2&&i2||t2).__k=k$4(S$4,null,[u2]),o2||d$5,d$5,t2.namespaceURI,!r2&&i2?[i2]:o2?null:t2.firstChild?n$3.call(t2.childNodes):null,e2,!r2&&i2?i2:o2?o2.__e:t2.firstChild,r2,f2),D$4(e2,u2,f2)}__name(R$1,"R$1");function X$1(n2){function l2(n3){var u2,t2;return this.getChildContext||(u2=new Set,(t2={})[l2.__c]=this,this.getChildContext=function(){return t2},this.componentWillUnmount=function(){u2=null},this.shouldComponentUpdate=function(n4){this.props.value!=n4.value&&u2.forEach(function(n5){n5.__e=!0,A$4(n5)})},this.sub=function(n4){u2.add(n4);var l3=n4.componentWillUnmount;n4.componentWillUnmount=function(){u2&&u2.delete(n4),l3&&l3.call(n4)}}),n3.children}return __name(l2,"l"),l2.__c="__cC"+y$6++,l2.__=n2,l2.Provider=l2.__l=(l2.Consumer=function(n3,l3){return n3.children(l3)}).contextType=l2,l2}__name(X$1,"X$1"),n$3=w$6.slice,l$5={__e:__name(function(n2,l2,u2,t2){for(var i2,r2,o2;l2=l2.__;)if((i2=l2.__c)&&!i2.__)try{if((r2=i2.constructor)&&r2.getDerivedStateFromError!=null&&(i2.setState(r2.getDerivedStateFromError(n2)),o2=i2.__d),i2.componentDidCatch!=null&&(i2.componentDidCatch(n2,t2||{}),o2=i2.__d),o2)return i2.__E=i2}catch(l3){n2=l3}throw n2},"__e")},u$5=0,t$3=__name(function(n2){return n2!=null&&n2.constructor===void 0},"t$3"),C$5.prototype.setState=function(n2,l2){var u2=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=m$5({},this.state);typeof n2=="function"&&(n2=n2(m$5({},u2),this.props)),n2&&m$5(u2,n2),n2!=null&&this.__v&&(l2&&this._sb.push(l2),A$4(this))},C$5.prototype.forceUpdate=function(n2){this.__v&&(this.__e=!0,n2&&this.__h.push(n2),A$4(this))},C$5.prototype.render=S$4,i$5=[],o$5=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,e$3=__name(function(n2,l2){return n2.__v.__b-l2.__v.__b},"e$3"),H$2.__r=0,f$5=Math.random().toString(8),c$4="__d"+f$5,s$4="__a"+f$5,a$4=/(PointerCapture)$|Capture$/i,h$5=0,p$5=V$2(!1),v$4=V$2(!0),y$6=0;var t$2,r$4,u$4,i$4,o$4=0,f$4=[],c$3=l$5,e$2=c$3.__b,a$3=c$3.__r,v$3=c$3.diffed,l$4=c$3.__c,m$4=c$3.unmount,s$3=c$3.__;function p$4(n2,t2){c$3.__h&&c$3.__h(r$4,n2,o$4||t2),o$4=0;var u2=r$4.__H||(r$4.__H={__:[],__h:[]});return n2>=u2.__.length&&u2.__.push({}),u2.__[n2]}__name(p$4,"p$4");function d$4(n2){return o$4=1,h$4(D$3,n2)}__name(d$4,"d$4");function h$4(n2,u2,i2){var o2=p$4(t$2++,2);if(o2.t=n2,!o2.__c&&(o2.__=[i2?i2(u2):D$3(void 0,u2),function(n3){var t2=o2.__N?o2.__N[0]:o2.__[0],r2=o2.t(t2,n3);t2!==r2&&(o2.__N=[r2,o2.__[1]],o2.__c.setState({}))}],o2.__c=r$4,!r$4.__f)){var f2=__name(function(n3,t2,r2){if(!o2.__c.__H)return!0;var u3=o2.__c.__H.__.filter(function(n4){return n4.__c});if(u3.every(function(n4){return!n4.__N}))return!c2||c2.call(this,n3,t2,r2);var i3=o2.__c.props!==n3;return u3.some(function(n4){if(n4.__N){var t3=n4.__[0];n4.__=n4.__N,n4.__N=void 0,t3!==n4.__[0]&&(i3=!0)}}),c2&&c2.call(this,n3,t2,r2)||i3},"f");r$4.__f=!0;var c2=r$4.shouldComponentUpdate,e2=r$4.componentWillUpdate;r$4.componentWillUpdate=function(n3,t2,r2){if(this.__e){var u3=c2;c2=void 0,f2(n3,t2,r2),c2=u3}e2&&e2.call(this,n3,t2,r2)},r$4.shouldComponentUpdate=f2}return o2.__N||o2.__}__name(h$4,"h$4");function y$5(n2,u2){var i2=p$4(t$2++,3);!c$3.__s&&C$4(i2.__H,u2)&&(i2.__=n2,i2.u=u2,r$4.__H.__h.push(i2))}__name(y$5,"y$5");function _$4(n2,u2){var i2=p$4(t$2++,4);!c$3.__s&&C$4(i2.__H,u2)&&(i2.__=n2,i2.u=u2,r$4.__h.push(i2))}__name(_$4,"_$4");function A$3(n2){return o$4=5,T$5(function(){return{current:n2}},[])}__name(A$3,"A$3");function T$5(n2,r2){var u2=p$4(t$2++,7);return C$4(u2.__H,r2)&&(u2.__=n2(),u2.__H=r2,u2.__h=n2),u2.__}__name(T$5,"T$5");function q$2(n2,t2){return o$4=8,T$5(function(){return n2},t2)}__name(q$2,"q$2");function x$5(n2){var u2=r$4.context[n2.__c],i2=p$4(t$2++,9);return i2.c=n2,u2?(i2.__??(i2.__=!0,u2.sub(r$4)),u2.props.value):n2.__}__name(x$5,"x$5");function j$3(){for(var n2;n2=f$4.shift();){var t2=n2.__H;if(n2.__P&&t2)try{t2.__h.some(z),t2.__h.some(B$2),t2.__h=[]}catch(r2){t2.__h=[],c$3.__e(r2,n2.__v)}}}__name(j$3,"j$3"),c$3.__b=function(n2){r$4=null,e$2&&e$2(n2)},c$3.__=function(n2,t2){n2&&t2.__k&&t2.__k.__m&&(n2.__m=t2.__k.__m),s$3&&s$3(n2,t2)},c$3.__r=function(n2){a$3&&a$3(n2),t$2=0;var i2=(r$4=n2.__c).__H;i2&&(u$4===r$4?(i2.__h=[],r$4.__h=[],i2.__.some(function(n3){n3.__N&&(n3.__=n3.__N),n3.u=n3.__N=void 0})):(i2.__h.some(z),i2.__h.some(B$2),i2.__h=[],t$2=0)),u$4=r$4},c$3.diffed=function(n2){v$3&&v$3(n2);var t2=n2.__c;t2&&t2.__H&&(t2.__H.__h.length&&(f$4.push(t2)!==1&&i$4===c$3.requestAnimationFrame||((i$4=c$3.requestAnimationFrame)||w$5)(j$3)),t2.__H.__.some(function(n3){n3.u&&(n3.__H=n3.u),n3.u=void 0})),u$4=r$4=null},c$3.__c=function(n2,t2){t2.some(function(n3){try{n3.__h.some(z),n3.__h=n3.__h.filter(function(n4){return!n4.__||B$2(n4)})}catch(r2){t2.some(function(n4){n4.__h&&(n4.__h=[])}),t2=[],c$3.__e(r2,n3.__v)}}),l$4&&l$4(n2,t2)},c$3.unmount=function(n2){m$4&&m$4(n2);var t2,r2=n2.__c;r2&&r2.__H&&(r2.__H.__.some(function(n3){try{z(n3)}catch(n4){t2=n4}}),r2.__H=void 0,t2&&c$3.__e(t2,r2.__v))};var k$3=typeof requestAnimationFrame=="function";function w$5(n2){var t2,r2=__name(function(){clearTimeout(u2),k$3&&cancelAnimationFrame(t2),setTimeout(n2)},"r"),u2=setTimeout(r2,35);k$3&&(t2=requestAnimationFrame(r2))}__name(w$5,"w$5");function z(n2){var t2=r$4,u2=n2.__c;typeof u2=="function"&&(n2.__c=void 0,u2()),r$4=t2}__name(z,"z");function B$2(n2){var t2=r$4;n2.__c=n2.__(),r$4=t2}__name(B$2,"B$2");function C$4(n2,t2){return!n2||n2.length!==t2.length||t2.some(function(t3,r2){return t3!==n2[r2]})}__name(C$4,"C$4");function D$3(n2,t2){return typeof t2=="function"?t2(n2):t2}__name(D$3,"D$3");var i$3=Symbol.for("preact-signals");function t$1(){if(s$2>1)s$2--;else{var i2,t2=!1;for((function(){var i3=c$2;for(c$2=void 0;i3!==void 0;)i3.S.v===i3.v&&(i3.S.i=i3.i),i3=i3.o})();h$3!==void 0;){var n2=h$3;for(h$3=void 0,v$2++;n2!==void 0;){var r2=n2.u;if(n2.u=void 0,n2.f&=-3,!(8&n2.f)&&w$4(n2))try{n2.c()}catch(n3){t2||(i2=n3,t2=!0)}n2=r2}}if(v$2=0,s$2--,t2)throw i2}}__name(t$1,"t$1");function n$2(i2){if(s$2>0)return i2();e$1=++u$3,s$2++;try{return i2()}finally{t$1()}}__name(n$2,"n$2");var r$3=void 0;function o$3(i2){var t2=r$3;r$3=void 0;try{return i2()}finally{r$3=t2}}__name(o$3,"o$3");var f$3,h$3=void 0,s$2=0,v$2=0,u$3=0,e$1=0,c$2=void 0,d$3=0;function a$2(i2){if(r$3!==void 0){var t2=i2.n;if(t2===void 0||t2.t!==r$3)return t2={i:0,S:i2,p:r$3.s,n:void 0,t:r$3,e:void 0,x:void 0,r:t2},r$3.s!==void 0&&(r$3.s.n=t2),r$3.s=t2,i2.n=t2,32&r$3.f&&i2.S(t2),t2;if(t2.i===-1)return t2.i=0,t2.n!==void 0&&(t2.n.p=t2.p,t2.p!==void 0&&(t2.p.n=t2.n),t2.p=r$3.s,t2.n=void 0,r$3.s.n=t2,r$3.s=t2),t2}}__name(a$2,"a$2");function l$3(i2,t2){this.v=i2,this.i=0,this.n=void 0,this.t=void 0,this.l=0,this.W=t2?.watched,this.Z=t2?.unwatched,this.name=t2?.name}__name(l$3,"l$3"),l$3.prototype.brand=i$3,l$3.prototype.h=function(){return!0},l$3.prototype.S=function(i2){var t2=this,n2=this.t;n2!==i2&&i2.e===void 0&&(i2.x=n2,this.t=i2,n2!==void 0?n2.e=i2:o$3(function(){var i3;(i3=t2.W)==null||i3.call(t2)}))},l$3.prototype.U=function(i2){var t2=this;if(this.t!==void 0){var n2=i2.e,r2=i2.x;n2!==void 0&&(n2.x=r2,i2.e=void 0),r2!==void 0&&(r2.e=n2,i2.x=void 0),i2===this.t&&(this.t=r2,r2===void 0&&o$3(function(){var i3;(i3=t2.Z)==null||i3.call(t2)}))}},l$3.prototype.subscribe=function(i2){var t2=this;return j$2(function(){var n2=t2.value,o2=r$3;r$3=void 0;try{i2(n2)}finally{r$3=o2}},{name:"sub"})},l$3.prototype.valueOf=function(){return this.value},l$3.prototype.toString=function(){return this.value+""},l$3.prototype.toJSON=function(){return this.value},l$3.prototype.peek=function(){var i2=r$3;r$3=void 0;try{return this.value}finally{r$3=i2}},Object.defineProperty(l$3.prototype,"value",{get:__name(function(){var i2=a$2(this);return i2!==void 0&&(i2.i=this.i),this.v},"get"),set:__name(function(i2){if(i2!==this.v){if(v$2>100)throw new Error("Cycle detected");(function(i3){s$2!==0&&v$2===0&&i3.l!==e$1&&(i3.l=e$1,c$2={S:i3,v:i3.v,i:i3.i,o:c$2})})(this),this.v=i2,this.i++,d$3++,s$2++;try{for(var n2=this.t;n2!==void 0;n2=n2.x)n2.t.N()}finally{t$1()}}},"set")});function y$4(i2,t2){return new l$3(i2,t2)}__name(y$4,"y$4");function w$4(i2){for(var t2=i2.s;t2!==void 0;t2=t2.n)if(t2.S.i!==t2.i||!t2.S.h()||t2.S.i!==t2.i)return!0;return!1}__name(w$4,"w$4");function _$3(i2){for(var t2=i2.s;t2!==void 0;t2=t2.n){var n2=t2.S.n;if(n2!==void 0&&(t2.r=n2),t2.S.n=t2,t2.i=-1,t2.n===void 0){i2.s=t2;break}}}__name(_$3,"_$3");function b$4(i2){for(var t2=i2.s,n2=void 0;t2!==void 0;){var r2=t2.p;t2.i===-1?(t2.S.U(t2),r2!==void 0&&(r2.n=t2.n),t2.n!==void 0&&(t2.n.p=r2)):n2=t2,t2.S.n=t2.r,t2.r!==void 0&&(t2.r=void 0),t2=r2}i2.s=n2}__name(b$4,"b$4");function p$3(i2,t2){l$3.call(this,void 0),this.x=i2,this.s=void 0,this.g=d$3-1,this.f=4,this.W=t2?.watched,this.Z=t2?.unwatched,this.name=t2?.name}__name(p$3,"p$3"),p$3.prototype=new l$3,p$3.prototype.h=function(){if(this.f&=-3,1&this.f)return!1;if((36&this.f)==32||(this.f&=-5,this.g===d$3))return!0;if(this.g=d$3,this.f|=1,this.i>0&&!w$4(this))return this.f&=-2,!0;var i2=r$3;try{_$3(this),r$3=this;var t2=this.x();(16&this.f||this.v!==t2||this.i===0)&&(this.v=t2,this.f&=-17,this.i++)}catch(i3){this.v=i3,this.f|=16,this.i++}return r$3=i2,b$4(this),this.f&=-2,!0},p$3.prototype.S=function(i2){if(this.t===void 0){this.f|=36;for(var t2=this.s;t2!==void 0;t2=t2.n)t2.S.S(t2)}l$3.prototype.S.call(this,i2)},p$3.prototype.U=function(i2){if(this.t!==void 0&&(l$3.prototype.U.call(this,i2),this.t===void 0)){this.f&=-33;for(var t2=this.s;t2!==void 0;t2=t2.n)t2.S.U(t2)}},p$3.prototype.N=function(){if(!(2&this.f)){this.f|=6;for(var i2=this.t;i2!==void 0;i2=i2.x)i2.t.N()}},Object.defineProperty(p$3.prototype,"value",{get:__name(function(){if(1&this.f)throw new Error("Cycle detected");var i2=a$2(this);if(this.h(),i2!==void 0&&(i2.i=this.i),16&this.f)throw this.v;return this.v},"get")});function g$4(i2,t2){return new p$3(i2,t2)}__name(g$4,"g$4");function S$3(i2){var n2=i2.m;if(i2.m=void 0,typeof n2=="function"){s$2++;var o2=r$3;r$3=void 0;try{n2()}catch(t2){throw i2.f&=-2,i2.f|=8,m$3(i2),t2}finally{r$3=o2,t$1()}}}__name(S$3,"S$3");function m$3(i2){for(var t2=i2.s;t2!==void 0;t2=t2.n)t2.S.U(t2);i2.x=void 0,i2.s=void 0,S$3(i2)}__name(m$3,"m$3");function x$4(i2){if(r$3!==this)throw new Error("Out-of-order effect");b$4(this),r$3=i2,this.f&=-2,8&this.f&&m$3(this),t$1()}__name(x$4,"x$4");function E$4(i2,t2){this.x=i2,this.m=void 0,this.s=void 0,this.u=void 0,this.f=32,this.name=t2?.name,f$3&&f$3.push(this)}__name(E$4,"E$4"),E$4.prototype.c=function(){var i2=this.S();try{if(8&this.f||this.x===void 0)return;var t2=this.x();typeof t2=="function"&&(this.m=t2)}finally{i2()}},E$4.prototype.S=function(){if(1&this.f)throw new Error("Cycle detected");this.f|=1,this.f&=-9,S$3(this),_$3(this),s$2++;var i2=r$3;return r$3=this,x$4.bind(this,i2)},E$4.prototype.N=function(){2&this.f||(this.f|=2,this.u=h$3,h$3=this)},E$4.prototype.d=function(){this.f|=8,1&this.f||m$3(this)},E$4.prototype.dispose=function(){this.d()};function j$2(i2,t2){var n2=new E$4(i2,t2);try{n2.c()}catch(i3){throw n2.d(),i3}var r2=n2.d.bind(n2);return r2[Symbol.dispose]=r2,r2}__name(j$2,"j$2");var l$2,d$2,h$2,p$2=typeof window<"u"&&!!window.__PREACT_SIGNALS_DEVTOOLS__,m$2=[],_$2=[];j$2(function(){l$2=this.N})();function g$3(i2,r2){l$5[i2]=r2.bind(null,l$5[i2]||function(){})}__name(g$3,"g$3");function b$3(i2){if(h$2){var n2=h$2;h$2=void 0,n2()}h$2=i2&&i2.S()}__name(b$3,"b$3");function y$3(i2){var n2=this,t2=i2.data,e2=useSignal(t2);e2.value=t2;var f2=T$5(function(){for(var i3=n2,t3=n2.__v;t3=t3.__;)if(t3.__c){t3.__c.__$f|=4;break}var o2=g$4(function(){var i4=e2.value.value;return i4===0?0:i4===!0?"":i4||""}),f3=g$4(function(){return!Array.isArray(o2.value)&&!t$3(o2.value)}),a3=j$2(function(){if(this.N=F$2,f3.value){var n3=o2.value;i3.__v&&i3.__v.__e&&i3.__v.__e.nodeType===3&&(i3.__v.__e.data=n3)}}),v3=n2.__$u.d;return n2.__$u.d=function(){a3(),v3.call(this)},[f3,o2]},[]),a2=f2[0],v2=f2[1];return a2.value?v2.peek():v2.value}__name(y$3,"y$3"),y$3.displayName="ReactiveTextNode",Object.defineProperties(l$3.prototype,{constructor:{configurable:!0,value:void 0},type:{configurable:!0,value:y$3},props:{configurable:!0,get:__name(function(){var i2=this;return{data:{get value(){return i2.value}}}},"get")},__b:{configurable:!0,value:1}}),g$3("__b",function(i2,n2){if(typeof n2.type=="string"){var r2,t2=n2.props;for(var o2 in t2)if(o2!=="children"){var e2=t2[o2];e2 instanceof l$3&&(r2||(n2.__np=r2={}),r2[o2]=e2,t2[o2]=e2.peek())}}i2(n2)}),g$3("__r",function(i2,n2){if(i2(n2),n2.type!==S$4){b$3();var r2,o2=n2.__c;o2&&(o2.__$f&=-2,(r2=o2.__$u)===void 0&&(o2.__$u=r2=(function(i3,n3){var r3;return j$2(function(){r3=this},{name:n3}),r3.c=i3,r3})(function(){var i3;p$2&&((i3=r2.y)==null||i3.call(r2)),o2.__$f|=1,o2.setState({})},typeof n2.type=="function"?n2.type.displayName||n2.type.name:""))),d$2=o2,b$3(r2)}}),g$3("__e",function(i2,n2,r2,t2){b$3(),d$2=void 0,i2(n2,r2,t2)}),g$3("diffed",function(i2,n2){b$3(),d$2=void 0;var r2;if(typeof n2.type=="string"&&(r2=n2.__e)){var t2=n2.__np,o2=n2.props;if(t2){var e2=r2.U;if(e2)for(var f2 in e2){var u2=e2[f2];u2!==void 0&&!(f2 in t2)&&(u2.d(),e2[f2]=void 0)}else e2={},r2.U=e2;for(var a2 in t2){var c2=e2[a2],v2=t2[a2];c2===void 0?(c2=w$3(r2,a2,v2),e2[a2]=c2):c2.o(v2,o2)}for(var s2 in t2)o2[s2]=t2[s2]}}i2(n2)});function w$3(i2,n2,r2,t2){var o2=n2 in i2&&i2.ownerSVGElement===void 0,e2=y$4(r2),f2=r2.peek();return{o:__name(function(i3,n3){e2.value=i3,f2=i3.peek()},"o"),d:j$2(function(){this.N=F$2;var r3=e2.value.value;f2!==r3?(f2=void 0,o2?i2[n2]=r3:r3!=null&&(r3!==!1||n2[4]==="-")?i2.setAttribute(n2,r3):i2.removeAttribute(n2)):f2=void 0})}}__name(w$3,"w$3"),g$3("unmount",function(i2,n2){if(typeof n2.type=="string"){var r2=n2.__e;if(r2){var t2=r2.U;if(t2){r2.U=void 0;for(var o2 in t2){var e2=t2[o2];e2&&e2.d()}}}n2.__np=void 0}else{var f2=n2.__c;if(f2){var u2=f2.__$u;u2&&(f2.__$u=void 0,u2.d())}}i2(n2)}),g$3("__h",function(i2,n2,r2,t2){(t2<3||t2===9)&&(n2.__$f|=2),i2(n2,r2,t2)}),C$5.prototype.shouldComponentUpdate=function(i2,n2){if(this.__R)return!0;var r2=this.__$u,t2=r2&&r2.s!==void 0;for(var o2 in n2)return!0;if(this.__f||typeof this.u=="boolean"&&this.u===!0){var e2=2&this.__$f;if(!(t2||e2||4&this.__$f)||1&this.__$f)return!0}else if(!(t2||4&this.__$f)||3&this.__$f)return!0;for(var f2 in i2)if(f2!=="__source"&&i2[f2]!==this.props[f2])return!0;for(var u2 in this.props)if(!(u2 in i2))return!0;return!1};function useSignal(i2,n2){return T$5(function(){return y$4(i2,n2)},[])}__name(useSignal,"useSignal");var k$2=typeof requestAnimationFrame>"u"?setTimeout:function(i2){var n2=__name(function(){clearTimeout(r2),cancelAnimationFrame(t2),i2()},"n"),r2=setTimeout(n2,35),t2=requestAnimationFrame(n2)},q$1=__name(function(i2){queueMicrotask(function(){queueMicrotask(i2)})},"q$1");function A$2(){n$2(function(){for(var i2;i2=m$2.shift();)l$2.call(i2)})}__name(A$2,"A$2");function T$4(){m$2.push(this)===1&&(l$5.requestAnimationFrame||k$2)(A$2)}__name(T$4,"T$4");function x$3(){n$2(function(){for(var i2;i2=_$2.shift();)l$2.call(i2)})}__name(x$3,"x$3");function F$2(){_$2.push(this)===1&&(l$5.requestAnimationFrame||q$1)(x$3)}__name(F$2,"F$2");function useSignalEffect(i2,n2){var r2=A$3(i2);r2.current=i2,y$5(function(){return j$2(function(){return this.N=T$4,r2.current()},n2)},[])}__name(useSignalEffect,"useSignalEffect");function g$2(n2,t2){for(var e2 in t2)n2[e2]=t2[e2];return n2}__name(g$2,"g$2");function E$3(n2,t2){for(var e2 in n2)if(e2!=="__source"&&!(e2 in t2))return!0;for(var r2 in t2)if(r2!=="__source"&&n2[r2]!==t2[r2])return!0;return!1}__name(E$3,"E$3");function C$3(n2,t2){var e2=t2(),r2=d$4({t:{__:e2,u:t2}}),u2=r2[0].t,o2=r2[1];return _$4(function(){u2.__=e2,u2.u=t2,R(u2)&&o2({t:u2})},[n2,e2,t2]),y$5(function(){return R(u2)&&o2({t:u2}),n2(function(){R(u2)&&o2({t:u2})})},[n2]),e2}__name(C$3,"C$3");function R(n2){try{return!((t2=n2.__)===(e2=n2.u())&&(t2!==0||1/t2==1/e2)||t2!=t2&&e2!=e2)}catch{return!0}var t2,e2}__name(R,"R");function M$1(n2,t2){this.props=n2,this.context=t2}__name(M$1,"M$1");function N$1(n2,e2){function r2(n3){var t2=this.props.ref;return t2!=n3.ref&&t2&&(typeof t2=="function"?t2(null):t2.current=null),e2?!e2(this.props,n3)||t2!=n3.ref:E$3(this.props,n3)}__name(r2,"r");function u2(e3){return this.shouldComponentUpdate=r2,k$4(n2,e3)}return __name(u2,"u"),u2.displayName="Memo("+(n2.displayName||n2.name)+")",u2.__f=u2.prototype.isReactComponent=!0,u2.type=n2,u2}__name(N$1,"N$1"),(M$1.prototype=new C$5).isPureReactComponent=!0,M$1.prototype.shouldComponentUpdate=function(n2,t2){return E$3(this.props,n2)||E$3(this.state,t2)};var T$3=l$5.__b;l$5.__b=function(n2){n2.type&&n2.type.__f&&n2.ref&&(n2.props.ref=n2.ref,n2.ref=null),T$3&&T$3(n2)};var A$1=typeof Symbol<"u"&&Symbol.for&&Symbol.for("react.forward_ref")||3911;function D$2(n2){function t2(t3){var e2=g$2({},t3);return delete e2.ref,n2(e2,t3.ref||null)}return __name(t2,"t"),t2.$$typeof=A$1,t2.render=n2,t2.prototype.isReactComponent=t2.__f=!0,t2.displayName="ForwardRef("+(n2.displayName||n2.name)+")",t2}__name(D$2,"D$2");var F$1=__name(function(n2,t2){return n2==null?null:F$3(F$3(n2).map(t2))},"F$1"),L={map:F$1,forEach:F$1,count:__name(function(n2){return n2?F$3(n2).length:0},"count"),only:__name(function(n2){var t2=F$3(n2);if(t2.length!==1)throw"Children.only";return t2[0]},"only"),toArray:F$3},O$2=l$5.__e;l$5.__e=function(n2,t2,e2,r2){if(n2.then){for(var u2,o2=t2;o2=o2.__;)if((u2=o2.__c)&&u2.__c)return t2.__e??(t2.__e=e2.__e,t2.__k=e2.__k),u2.__c(n2,t2)}O$2(n2,t2,e2,r2)};var U$1=l$5.unmount;function V$1(n2,t2,e2){return n2&&(n2.__c&&n2.__c.__H&&(n2.__c.__H.__.forEach(function(n3){typeof n3.__c=="function"&&n3.__c()}),n2.__c.__H=null),(n2=g$2({},n2)).__c!=null&&(n2.__c.__P===e2&&(n2.__c.__P=t2),n2.__c.__e=!0,n2.__c=null),n2.__k=n2.__k&&n2.__k.map(function(n3){return V$1(n3,t2,e2)})),n2}__name(V$1,"V$1");function W(n2,t2,e2){return n2&&e2&&(n2.__v=null,n2.__k=n2.__k&&n2.__k.map(function(n3){return W(n3,t2,e2)}),n2.__c&&n2.__c.__P===t2&&(n2.__e&&e2.appendChild(n2.__e),n2.__c.__e=!0,n2.__c.__P=e2)),n2}__name(W,"W");function P$1(){this.__u=0,this.o=null,this.__b=null}__name(P$1,"P$1");function j$1(n2){var t2=n2.__&&n2.__.__c;return t2&&t2.__a&&t2.__a(n2)}__name(j$1,"j$1");function B$1(){this.i=null,this.l=null}__name(B$1,"B$1"),l$5.unmount=function(n2){var t2=n2.__c;t2&&(t2.__z=!0),t2&&t2.__R&&t2.__R(),t2&&32&n2.__u&&(n2.type=null),U$1&&U$1(n2)},(P$1.prototype=new C$5).__c=function(n2,t2){var e2=t2.__c,r2=this;r2.o??=[],r2.o.push(e2);var u2=j$1(r2.__v),o2=!1,i2=__name(function(){o2||r2.__z||(o2=!0,e2.__R=null,u2?u2(c2):c2())},"i");e2.__R=i2;var l2=e2.__P;e2.__P=null;var c2=__name(function(){if(!--r2.__u){if(r2.state.__a){var n3=r2.state.__a;r2.__v.__k[0]=W(n3,n3.__c.__P,n3.__c.__O)}var t3;for(r2.setState({__a:r2.__b=null});t3=r2.o.pop();)t3.__P=l2,t3.forceUpdate()}},"c");r2.__u++||32&t2.__u||r2.setState({__a:r2.__b=r2.__v.__k[0]}),n2.then(i2,i2)},P$1.prototype.componentWillUnmount=function(){this.o=[]},P$1.prototype.render=function(n2,e2){if(this.__b){if(this.__v.__k){var r2=document.createElement("div"),o2=this.__v.__k[0].__c;this.__v.__k[0]=V$1(this.__b,r2,o2.__O=o2.__P)}this.__b=null}var i2=e2.__a&&k$4(S$4,null,n2.fallback);return i2&&(i2.__u&=-33),[k$4(S$4,null,e2.__a?null:n2.children),i2]};var H$1=__name(function(n2,t2,e2){if(++e2[1]===e2[0]&&n2.l.delete(t2),n2.props.revealOrder&&(n2.props.revealOrder[0]!=="t"||!n2.l.size))for(e2=n2.i;e2;){for(;e2.length>3;)e2.pop()();if(e2[1]<e2[0])break;n2.i=e2=e2[2]}},"H$1");function Z(n2){return this.getChildContext=function(){return n2.context},n2.children}__name(Z,"Z");function Y(n2){var e2=this,r2=n2.h;if(e2.componentWillUnmount=function(){R$1(null,e2.v),e2.v=null,e2.h=null},e2.h&&e2.h!==r2&&e2.componentWillUnmount(),!e2.v){for(var u2=e2.__v;u2!==null&&!u2.__m&&u2.__!==null;)u2=u2.__;e2.h=r2,e2.v={nodeType:1,parentNode:r2,childNodes:[],__k:{__m:u2.__m},contains:__name(function(){return!0},"contains"),namespaceURI:r2.namespaceURI,insertBefore:__name(function(n3,t2){this.childNodes.push(n3),e2.h.insertBefore(n3,t2)},"insertBefore"),removeChild:__name(function(n3){this.childNodes.splice(this.childNodes.indexOf(n3)>>>1,1),e2.h.removeChild(n3)},"removeChild")}}R$1(k$4(Z,{context:e2.context},n2.__v),e2.v)}__name(Y,"Y");function $(n2,e2){var r2=k$4(Y,{__v:n2,h:e2});return r2.containerInfo=e2,r2}__name($,"$"),(B$1.prototype=new C$5).__a=function(n2){var t2=this,e2=j$1(t2.__v),r2=t2.l.get(n2);return r2[0]++,function(u2){var o2=__name(function(){t2.props.revealOrder?(r2.push(u2),H$1(t2,n2,r2)):u2()},"o");e2?e2(o2):o2()}},B$1.prototype.render=function(n2){this.i=null,this.l=new Map;var t2=F$3(n2.children);n2.revealOrder&&n2.revealOrder[0]==="b"&&t2.reverse();for(var e2=t2.length;e2--;)this.l.set(t2[e2],this.i=[1,0,this.i]);return n2.children},B$1.prototype.componentDidUpdate=B$1.prototype.componentDidMount=function(){var n2=this;this.l.forEach(function(t2,e2){H$1(n2,e2,t2)})};var q=typeof Symbol<"u"&&Symbol.for&&Symbol.for("react.element")||60103,G=/^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,J=/^on(Ani|Tra|Tou|BeforeInp|Compo)/,K=/[A-Z0-9]/g,Q=typeof document<"u",X=__name(function(n2){return(typeof Symbol<"u"&&typeof Symbol()=="symbol"?/fil|che|rad/:/fil|che|ra/).test(n2)},"X");C$5.prototype.isReactComponent=!0,["componentWillMount","componentWillReceiveProps","componentWillUpdate"].forEach(function(t2){Object.defineProperty(C$5.prototype,t2,{configurable:!0,get:__name(function(){return this["UNSAFE_"+t2]},"get"),set:__name(function(n2){Object.defineProperty(this,t2,{configurable:!0,writable:!0,value:n2})},"set")})});var en$1=l$5.event;l$5.event=function(n2){return en$1&&(n2=en$1(n2)),n2.persist=function(){},n2.isPropagationStopped=function(){return this.cancelBubble},n2.isDefaultPrevented=function(){return this.defaultPrevented},n2.nativeEvent=n2};var rn$1,un$1={configurable:!0,get:__name(function(){return this.class},"get")},on$1=l$5.vnode;l$5.vnode=function(n2){typeof n2.type=="string"&&(function(n3){var t2=n3.props,e2=n3.type,u2={},o2=e2.indexOf("-")==-1;for(var i2 in t2){var l2=t2[i2];if(!(i2==="value"&&"defaultValue"in t2&&l2==null||Q&&i2==="children"&&e2==="noscript"||i2==="class"||i2==="className")){var c2=i2.toLowerCase();i2==="defaultValue"&&"value"in t2&&t2.value==null?i2="value":i2==="download"&&l2===!0?l2="":c2==="translate"&&l2==="no"?l2=!1:c2[0]==="o"&&c2[1]==="n"?c2==="ondoubleclick"?i2="ondblclick":c2!=="onchange"||e2!=="input"&&e2!=="textarea"||X(t2.type)?c2==="onfocus"?i2="onfocusin":c2==="onblur"?i2="onfocusout":J.test(i2)&&(i2=c2):c2=i2="oninput":o2&&G.test(i2)?i2=i2.replace(K,"-$&").toLowerCase():l2===null&&(l2=void 0),c2==="oninput"&&u2[i2=c2]&&(i2="oninputCapture"),u2[i2]=l2}}e2=="select"&&(u2.multiple&&Array.isArray(u2.value)&&(u2.value=F$3(t2.children).forEach(function(n4){n4.props.selected=u2.value.indexOf(n4.props.value)!=-1})),u2.defaultValue!=null&&(u2.value=F$3(t2.children).forEach(function(n4){n4.props.selected=u2.multiple?u2.defaultValue.indexOf(n4.props.value)!=-1:u2.defaultValue==n4.props.value}))),t2.class&&!t2.className?(u2.class=t2.class,Object.defineProperty(u2,"className",un$1)):t2.className&&(u2.class=u2.className=t2.className),n3.props=u2})(n2),n2.$$typeof=q,on$1&&on$1(n2)};var ln$1=l$5.__r;l$5.__r=function(n2){ln$1&&ln$1(n2),rn$1=n2.__c};var cn$2=l$5.diffed;l$5.diffed=function(n2){cn$2&&cn$2(n2);var t2=n2.props,e2=n2.__e;e2!=null&&n2.type==="textarea"&&"value"in t2&&t2.value!==e2.value&&(e2.value=t2.value==null?"":t2.value),rn$1=null};var o$2=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,f$2=0,i$2=Array.isArray;function u$2(e2,t2,n2,o2,i2,u2){t2||(t2={});var a2,c2,p2=t2;if("ref"in p2)for(c2 in p2={},t2)c2=="ref"?a2=t2[c2]:p2[c2]=t2[c2];var l2={type:e2,props:p2,key:n2,ref:a2,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:--f$2,__i:-1,__u:0,__source:i2,__self:u2};if(typeof e2=="function"&&(a2=e2.defaultProps))for(c2 in a2)p2[c2]===void 0&&(p2[c2]=a2[c2]);return l$5.vnode&&l$5.vnode(l2),l2}__name(u$2,"u$2");var e=null,t=__name(()=>{if(e!==null)return e;try{e=window.matchMedia("(color-gamut: p3)").matches}catch{e=!1}return e},"t"),n$1=t(),r$2=__name(e2=>n$1?`color(display-p3 0.84 0.19 0.78 / ${e2})`:`rgba(210, 57, 192, ${e2})`,"r$2"),i$1="0.1.37",a$1="var(--rg-panel-bg)",o$1="var(--rg-shadow)",s$1=-1e3,c$1=.95,l$1=1500,ee=1e4,te=2147483647,ne=2147483645,re=.7,ie=1e3/60,ae=.5,oe=.01,se=r$2(.4),ce=r$2(.05),le=r$2(.5),ue=r$2(.08),de=r$2(.15),fe=.2,pe=["id","class","aria-label","data-testid","role","name","title"],me=new Set(["id","data-testid","aria-label","href","src","alt","type","name","placeholder","role","for","action","method","title","disabled","checked","readonly","required","selected","open"]),he=["Meta","Control","Shift","Alt"],ge=new Set(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"]),u$1="data-react-grab-frozen",_e=.5,ve="comment",ye=.75,be=.01,xe=1e3,Se=2*1024*1024,Ce={left:-9999,top:-9999},we={left:"left center",right:"right center",top:"center top",bottom:"center bottom"},Te=1e3,Ee=-9999,De=new Set("display.position.top.right.bottom.left.z-index.overflow.overflow-x.overflow-y.width.height.min-width.min-height.max-width.max-height.margin-top.margin-right.margin-bottom.margin-left.padding-top.padding-right.padding-bottom.padding-left.flex-direction.flex-wrap.justify-content.align-items.align-self.align-content.flex-grow.flex-shrink.flex-basis.order.gap.row-gap.column-gap.grid-template-columns.grid-template-rows.grid-template-areas.font-family.font-size.font-weight.font-style.line-height.letter-spacing.text-align.text-decoration-line.text-decoration-style.text-transform.text-overflow.text-shadow.white-space.word-break.overflow-wrap.vertical-align.color.background-color.background-image.background-position.background-size.background-repeat.border-top-width.border-right-width.border-bottom-width.border-left-width.border-top-style.border-right-style.border-bottom-style.border-left-style.border-top-color.border-right-color.border-bottom-color.border-left-color.border-top-left-radius.border-top-right-radius.border-bottom-left-radius.border-bottom-right-radius.box-shadow.opacity.transform.filter.backdrop-filter.object-fit.object-position".split(".")),d$1=__name(e2=>(e2.tagName||"").toLowerCase(),"d$1"),Oe,ke=__name(()=>{if(Oe!==void 0)return Oe;let e2=document.querySelector("script[nonce], style[nonce]"),t2=e2?.nonce||e2?.getAttribute("nonce")||null;return t2&&(Oe=t2),t2},"ke"),Ae=[["data-rr-block",""],["data-rr-ignore",""],["data-rr-mask",""],["data-sentry-block",""],["data-sentry-ignore",""],["data-sentry-mask",""],["data-dd-privacy","hidden"],["data-fs-exclude",""],["data-lr-exclude",""],["data-hj-suppress",""],["data-recording-disable",""],["data-clarity-mask","true"],["data-heap-redact-text",""]],je=__name(e2=>{for(let[t2,n2]of Ae)e2.setAttribute(t2,n2);e2.setAttribute("data-testid","react-grab-overlay"),e2.classList.add("ph-no-capture")},"je"),Me=typeof window<"u",Ne=__name(e2=>0,"Ne"),Pe=__name(e2=>{},"Pe"),f$1=Me?(Object.getOwnPropertyDescriptor(Window.prototype,"requestAnimationFrame")?.value??window.requestAnimationFrame).bind(window):Ne,p$1=Me?(Object.getOwnPropertyDescriptor(Window.prototype,"cancelAnimationFrame")?.value??window.cancelAnimationFrame).bind(window):Pe,Fe=__name(()=>Me?new Promise(e2=>f$1(()=>e2())):Promise.resolve(),"Fe"),Ie="bippy-0.5.41",Le=Object.defineProperty,Re=Object.prototype.hasOwnProperty,m$1=__name(()=>{},"m$1"),ze=__name(e2=>{try{Function.prototype.toString.call(e2).indexOf("^_^")>-1&&setTimeout(()=>{throw Error("React is running in production mode, but dead code elimination has not been applied. Read how to correctly configure React for production: https://reactjs.org/link/perf-use-production-build")})}catch{}},"ze"),Be=__name((e2=globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__)=>!!(e2&&"getFiberRoots"in e2),"Be"),Ve=!1,He,Ue=__name((e2=globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__)=>Ve?!0:(e2&&typeof e2.inject=="function"&&(He=e2.inject.toString()),!!He?.includes("(injected)")),"Ue"),h$1=new Set,g$1=new Set,We=__name(e2=>{let t2=new Map,n2=0,r2={_instrumentationIsActive:!1,_instrumentationSource:Ie,checkDCE:ze,hasUnsupportedRendererAttached:!1,inject(e3){let i2=++n2;return t2.set(i2,e3),g$1.add(e3),r2._instrumentationIsActive||(r2._instrumentationIsActive=!0,h$1.forEach(e4=>e4())),i2},on:m$1,onCommitFiberRoot:m$1,onCommitFiberUnmount:m$1,onPostCommitFiberRoot:m$1,renderers:t2,supportsFiber:!0,supportsFlight:!0};try{Le(globalThis,"__REACT_DEVTOOLS_GLOBAL_HOOK__",{configurable:!0,enumerable:!0,get(){return r2},set(t4){if(t4&&typeof t4=="object"){let n4=r2.renderers;r2=t4,n4.size>0&&(n4.forEach((e3,n5)=>{g$1.add(e3),t4.renderers.set(n5,e3)}),Ge(e2))}}});let t3=window.hasOwnProperty,n3=!1;Le(window,"hasOwnProperty",{configurable:!0,value:__name(function(...e3){try{if(!n3&&e3[0]==="__REACT_DEVTOOLS_GLOBAL_HOOK__")return globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__=void 0,n3=!0,-0}catch{}return t3.apply(this,e3)},"value"),writable:!0})}catch{Ge(e2)}return r2},"We"),Ge=__name(e2=>{e2&&h$1.add(e2);try{let t2=globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!t2)return;if(!t2._instrumentationSource){t2.checkDCE=ze,t2.supportsFiber=!0,t2.supportsFlight=!0,t2.hasUnsupportedRendererAttached=!1,t2._instrumentationSource=Ie,t2._instrumentationIsActive=!1;let e3=Be(t2);if(e3||(t2.on=m$1),t2.renderers.size){t2._instrumentationIsActive=!0,h$1.forEach(e4=>e4());return}let n2=t2.inject,r2=Ue(t2);r2&&!e3&&(Ve=!0,t2.inject({scheduleRefresh(){}})&&(t2._instrumentationIsActive=!0)),t2.inject=e4=>{let i2=n2(e4);return g$1.add(e4),r2&&t2.renderers.set(i2,e4),t2._instrumentationIsActive=!0,h$1.forEach(e5=>e5()),i2}}(t2.renderers.size||t2._instrumentationIsActive||Ue())&&e2?.()}catch{}},"Ge"),Ke=__name(()=>Re.call(globalThis,"__REACT_DEVTOOLS_GLOBAL_HOOK__"),"Ke"),_$1=__name(e2=>Ke()?(Ge(e2),globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__):We(e2),"_$1"),qe=__name(()=>!!(typeof window<"u"&&(window.document?.createElement||window.navigator?.product==="ReactNative")),"qe"),Je=__name(()=>{try{qe()&&_$1()}catch{}},"Je"),Ye=__name(e2=>{switch(e2.tag){case 1:case 11:case 0:case 14:case 15:return!0;default:return!1}},"Ye");function Xe(e2,t2,n2=!1){if(!e2)return null;let r2=t2(e2);if(r2 instanceof Promise)return(async()=>{if(await r2===!0)return e2;let i3=n2?e2.return:e2.child;for(;i3;){let e3=await Qe(i3,t2,n2);if(e3)return e3;i3=n2?null:i3.sibling}return null})();if(r2===!0)return e2;let i2=n2?e2.return:e2.child;for(;i2;){let e3=Ze(i2,t2,n2);if(e3)return e3;i2=n2?null:i2.sibling}return null}__name(Xe,"Xe");var Ze=__name((e2,t2,n2=!1)=>{if(!e2)return null;if(t2(e2)===!0)return e2;let r2=n2?e2.return:e2.child;for(;r2;){let e3=Ze(r2,t2,n2);if(e3)return e3;r2=n2?null:r2.sibling}return null},"Ze"),Qe=__name(async(e2,t2,n2=!1)=>{if(!e2)return null;if(await t2(e2)===!0)return e2;let r2=n2?e2.return:e2.child;for(;r2;){let e3=await Qe(r2,t2,n2);if(e3)return e3;r2=n2?null:r2.sibling}return null},"Qe"),$e=__name(e2=>{let t2=e2;return typeof t2=="function"?t2:typeof t2=="object"&&t2?$e(t2.type||t2.render):null},"$e"),v$1=__name(e2=>{let t2=e2;if(typeof t2=="string")return t2;if(typeof t2!="function"&&!(typeof t2=="object"&&t2))return null;let n2=t2.displayName||t2.name||null;if(n2)return n2;let r2=$e(t2);return r2&&(r2.displayName||r2.name)||null},"v$1"),y$2=__name(()=>{let e2=globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__;return!!e2?._instrumentationIsActive||Be(e2)||Ue(e2)},"y$2"),et=__name(e2=>Object.prototype.toString.call(e2)==="[object Object]"&&(Object.getPrototypeOf(e2)===Object.prototype||Object.getPrototypeOf(e2)===null),"et"),tt=__name((e2,t2=[])=>{if(!et(e2))return[{path:t2,value:e2}];let n2=[];for(let r2 in e2){let i2=e2[r2],a2=t2.concat(r2);et(i2)?n2.push(...tt(i2,a2)):n2.push({path:a2,value:i2})}return n2},"tt"),b$2=__name(e2=>{let t2=globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__;if(t2?.renderers)for(let n2 of t2.renderers.values())try{let t3=n2.findFiberByHostInstance?.(e2);if(t3)return t3}catch{}if(typeof e2=="object"&&e2){if("_reactRootContainer"in e2)return e2._reactRootContainer?._internalRoot?.current?.child;for(let t3 in e2)if(t3.startsWith("__reactContainer$")||t3.startsWith("__reactInternalInstance$")||t3.startsWith("__reactFiber"))return e2[t3]||null}return null},"b$2"),nt=new Set,rt=/^[a-zA-Z][a-zA-Z\d+\-.]*:/,it=["rsc://","file:///","webpack-internal://","webpack://","node:","turbopack://","metro://","/app-pages-browser/","/(app-pages-browser)/"],at=["<anonymous>","eval",""],ot=/\.(jsx|tsx|ts|js)$/,st=/(\.min|bundle|chunk|vendor|vendors|runtime|polyfill|polyfills)\.(js|mjs|cjs)$|(chunk|bundle|vendor|vendors|runtime|polyfill|polyfills|framework|app|main|index)[-_.][A-Za-z0-9_-]{4,}\.(js|mjs|cjs)$|[\da-f]{8,}\.(js|mjs|cjs)$|[-_.][\da-f]{20,}\.(js|mjs|cjs)$|\/dist\/|\/build\/|\/.next\/|\/out\/|\/node_modules\/|\.webpack\.|\.vite\.|\.turbopack\./i,ct=/^\?[\w~.-]+(?:=[^&#]*)?(?:&[\w~.-]+(?:=[^&#]*)?)*$/,lt=/\(at [^)]+\)$/,ut=/(^|@)\S+:\d+/,dt=/^\s*at .*(\S+:\d+|\(native\))/m,ft=/^(eval@)?(\[native code\])?$/,pt=__name((e2,t2)=>{if(t2?.includeInElement!==!1){let n2=e2.split(`
`),r2=[];for(let e3 of n2)if(/^\s*at\s+/.test(e3)){let t3=gt$1(e3,void 0)[0];t3&&r2.push(t3)}else if(/^\s*in\s+/.test(e3)){let t3=e3.replace(/^\s*in\s+/,"").replace(/\s*\(at .*\)$/,"");r2.push({functionName:t3,source:e3})}else if(e3.match(ut)){let t3=_t(e3,void 0)[0];t3&&r2.push(t3)}return ht(r2,t2)}return e2.match(dt)?gt$1(e2,t2):_t(e2,t2)},"pt"),mt=__name(e2=>{if(!e2.includes(":"))return[e2,void 0,void 0];let t2=e2.startsWith("(")&&/:\d+\)$/.test(e2)?e2.slice(1,-1):e2,n2=/(.+?)(?::(\d+))?(?::(\d+))?$/.exec(t2);return n2?[n2[1],n2[2]||void 0,n2[3]||void 0]:[t2,void 0,void 0]},"mt"),ht=__name((e2,t2)=>t2&&t2.slice!=null?Array.isArray(t2.slice)?e2.slice(t2.slice[0],t2.slice[1]):e2.slice(0,t2.slice):e2,"ht"),gt$1=__name((e2,t2)=>ht(e2.split(`
`).filter(e3=>!!e3.match(dt)),t2).map(e3=>{let t3=e3;t3.includes("(eval ")&&(t3=t3.replace(/eval code/g,"eval").replace(/(\(eval at [^()]*)|(,.*$)/g,""));let n2=t3.replace(/^\s+/,"").replace(/\(eval code/g,"(").replace(/^.*?\s+/,""),r2=n2.match(/ (\(.+\)$)/);n2=r2?n2.replace(r2[0],""):n2;let i2=mt(r2?r2[1]:n2);return{functionName:r2&&n2||void 0,fileName:["eval","<anonymous>"].includes(i2[0])?void 0:i2[0],lineNumber:i2[1]?+i2[1]:void 0,columnNumber:i2[2]?+i2[2]:void 0,source:t3}}),"gt$1"),_t=__name((e2,t2)=>ht(e2.split(`
`).filter(e3=>!e3.match(ft)),t2).map(e3=>{let t3=e3;if(t3.includes(" > eval")&&(t3=t3.replace(/ line (\d+)(?: > eval line \d+)* > eval:\d+:\d+/g,":$1")),!t3.includes("@")&&!t3.includes(":"))return{functionName:t3};{let e4=/(([^\n\r"\u2028\u2029]*".[^\n\r"\u2028\u2029]*"[^\n\r@\u2028\u2029]*(?:@[^\n\r"\u2028\u2029]*"[^\n\r@\u2028\u2029]*)*(?:[\n\r\u2028\u2029][^@]*)?)?[^@]*)@/,n2=t3.match(e4),r2=n2&&n2[1]?n2[1]:void 0,i2=mt(t3.replace(e4,""));return{functionName:r2,fileName:i2[0],lineNumber:i2[1]?+i2[1]:void 0,columnNumber:i2[2]?+i2[2]:void 0,source:t3}}}),"_t"),vt=44,yt="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",bt=new Uint8Array(64),xt=new Uint8Array(128);for(let e2=0;e2<yt.length;e2++){let t2=yt.charCodeAt(e2);bt[e2]=t2,xt[t2]=e2}function x$2(e2,t2){let n2=0,r2=0,i2=0;do i2=xt[e2.next()],n2|=(i2&31)<<r2,r2+=5;while(i2&32);let a2=n2&1;return n2>>>=1,a2&&(n2=-2147483648|-n2),t2+n2}__name(x$2,"x$2");function St(e2,t2){return e2.pos>=t2?!1:e2.peek()!==vt}__name(St,"St");var Ct=class{static{__name(this,"Ct")}constructor(e2){this.pos=0,this.buffer=e2}next(){return this.buffer.charCodeAt(this.pos++)}peek(){return this.buffer.charCodeAt(this.pos)}indexOf(e2){let{buffer:t2,pos:n2}=this,r2=t2.indexOf(e2,n2);return r2===-1?t2.length:r2}};function wt(e2){let{length:t2}=e2,n2=new Ct(e2),r2=[],i2=0,a2=0,o2=0,s2=0,c2=0;do{let e3=n2.indexOf(";"),t3=[],l2=!0,ee2=0;for(i2=0;n2.pos<e3;){let r3;i2=x$2(n2,i2),i2<ee2&&(l2=!1),ee2=i2,St(n2,e3)?(a2=x$2(n2,a2),o2=x$2(n2,o2),s2=x$2(n2,s2),St(n2,e3)?(c2=x$2(n2,c2),r3=[i2,a2,o2,s2,c2]):r3=[i2,a2,o2,s2]):r3=[i2],t3.push(r3),n2.pos++}l2||Tt(t3),r2.push(t3),n2.pos=e3+1}while(n2.pos<=t2);return r2}__name(wt,"wt");function Tt(e2){e2.sort(Et)}__name(Tt,"Tt");function Et(e2,t2){return e2[0]-t2[0]}__name(Et,"Et");var Dt=/^[a-zA-Z][a-zA-Z\d+\-.]*:/,Ot=/^data:application\/json[^,]+base64,/,kt=/(?:\/\/[@#][ \t]+sourceMappingURL=([^\s'"]+?)[ \t]*$)|(?:\/\*[@#][ \t]+sourceMappingURL=([^*]+?)[ \t]*(?:\*\/)[ \t]*$)/,S$2=new Map,C$2=new Map,At=__name((e2,t2,n2,r2)=>{if(n2<0||n2>=e2.length)return null;let i2=e2[n2];if(!i2||i2.length===0)return null;let a2=null;for(let e3 of i2)if(e3[0]<=r2)a2=e3;else break;if(!a2||a2.length<4)return null;let[,o2,s2,c2]=a2;if(o2===void 0||s2===void 0||c2===void 0)return null;let l2=t2[o2];return l2?{columnNumber:c2,fileName:l2,lineNumber:s2+1}:null},"At"),jt=__name((e2,t2,n2)=>{if(e2.sections){let r2=null;for(let i3 of e2.sections)if(t2>i3.offset.line||t2===i3.offset.line&&n2>=i3.offset.column)r2=i3;else break;if(!r2)return null;let i2=t2-r2.offset.line,a2=t2===r2.offset.line?n2-r2.offset.column:n2;return At(r2.map.mappings,r2.map.sources,i2,a2)}return At(e2.mappings,e2.sources,t2-1,n2)},"jt"),Mt=__name((e2,t2)=>{let n2=t2.split(`
`),r2;for(let e3=n2.length-1;e3>=0&&!r2;e3--){let t3=n2[e3].match(kt);t3&&(r2=t3[1]||t3[2])}if(!r2)return null;let i2=Dt.test(r2);if(!(Ot.test(r2)||i2||r2.startsWith("/"))){let t3=e2.split("/");t3[t3.length-1]=r2,r2=t3.join("/")}return r2},"Mt"),Nt=__name(e2=>({file:e2.file,mappings:wt(e2.mappings),names:e2.names,sourceRoot:e2.sourceRoot,sources:e2.sources,sourcesContent:e2.sourcesContent,version:3}),"Nt"),Pt=__name(e2=>{let t2=e2.sections.map(({map:e3,offset:t3})=>({map:{...e3,mappings:wt(e3.mappings)},offset:t3})),n2=new Set;for(let e3 of t2)for(let t3 of e3.map.sources)n2.add(t3);return{file:e2.file,mappings:[],names:[],sections:t2,sourceRoot:void 0,sources:Array.from(n2),sourcesContent:void 0,version:3}},"Pt"),Ft=__name(e2=>{if(!e2)return!1;let t2=e2.trim();if(!t2)return!1;let n2=t2.match(Dt);if(!n2)return!0;let r2=n2[0].toLowerCase();return r2==="http:"||r2==="https:"},"Ft"),It=__name(async(e2,t2=fetch)=>{if(!Ft(e2))return null;let n2;try{let r3=await t2(e2);if(!r3.ok)return null;n2=await r3.text()}catch{return null}if(!n2)return null;let r2=Mt(e2,n2);if(!r2||!Ft(r2))return null;try{let e3=await t2(r2);if(!e3.ok)return null;let n3=await e3.json();return"sections"in n3?Pt(n3):Nt(n3)}catch{return null}},"It"),Lt=__name(async(e2,t2=!0,n2)=>{if(t2&&S$2.has(e2))return S$2.get(e2)??null;if(t2&&C$2.has(e2))return C$2.get(e2);let r2=It(e2,n2);t2&&C$2.set(e2,r2);let i2=await r2;return t2&&C$2.delete(e2),t2&&(i2===null?S$2.set(e2,null):S$2.set(e2,i2)),i2},"Lt"),Rt=__name(async(e2,t2=!0,n2)=>await Promise.all(e2.map(async e3=>{if(!e3.fileName)return e3;let r2=await Lt(e3.fileName,t2,n2);if(!r2||typeof e3.lineNumber!="number"||typeof e3.columnNumber!="number")return e3;let i2=jt(r2,e3.lineNumber,e3.columnNumber);return i2?{...e3,source:i2.fileName&&e3.source?e3.source.replace(e3.fileName,i2.fileName):e3.source,fileName:i2.fileName,lineNumber:i2.lineNumber,columnNumber:i2.columnNumber,isSymbolicated:!0}:e3})),"Rt"),zt=__name(e2=>e2._debugStack instanceof Error&&typeof e2._debugStack?.stack=="string","zt"),Bt=__name(()=>{let e2=_$1();for(let t2 of[...Array.from(g$1),...Array.from(e2.renderers.values())]){let e3=t2.currentDispatcherRef;if(e3&&typeof e3=="object")return"H"in e3?e3.H:e3.current}return null},"Bt"),Vt=__name(e2=>{for(let t2 of g$1){let n2=t2.currentDispatcherRef;n2&&typeof n2=="object"&&("H"in n2?n2.H=e2:n2.current=e2)}},"Vt"),w$2=__name(e2=>`
    in ${e2}`,"w$2"),Ht=__name((e2,t2)=>{let n2=w$2(e2);return t2&&(n2+=` (at ${t2})`),n2},"Ht"),Ut=!1,Wt=__name((e2,t2)=>{if(!e2||Ut)return"";let n2=Error.prepareStackTrace;Error.prepareStackTrace=void 0,Ut=!0;let r2=Bt();Vt(null);let i2=console.error,a2=console.warn;console.error=()=>{},console.warn=()=>{};try{let n3={DetermineComponentFrameRoot(){let n4;try{if(t2){let t3=__name(function(){throw Error()},"t");if(Object.defineProperty(t3.prototype,"props",{set:__name(function(){throw Error()},"set")}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(t3,[])}catch(e3){n4=e3}Reflect.construct(e2,[],t3)}else{try{t3.call()}catch(e3){n4=e3}e2.call(t3.prototype)}}else{try{throw Error()}catch(e3){n4=e3}let t3=e2();t3&&typeof t3.catch=="function"&&t3.catch(()=>{})}}catch(e3){if(e3 instanceof Error&&n4 instanceof Error&&typeof e3.stack=="string")return[e3.stack,n4.stack]}return[null,null]}};n3.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot",Object.getOwnPropertyDescriptor(n3.DetermineComponentFrameRoot,"name")?.configurable&&Object.defineProperty(n3.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});let[r3,i3]=n3.DetermineComponentFrameRoot();if(r3&&i3){let t3=r3.split(`
`),n4=i3.split(`
`),a3=0,o3=0;for(;a3<t3.length&&!t3[a3].includes("DetermineComponentFrameRoot");)a3++;for(;o3<n4.length&&!n4[o3].includes("DetermineComponentFrameRoot");)o3++;if(a3===t3.length||o3===n4.length)for(a3=t3.length-1,o3=n4.length-1;a3>=1&&o3>=0&&t3[a3]!==n4[o3];)o3--;for(;a3>=1&&o3>=0;a3--,o3--)if(t3[a3]!==n4[o3]){if(a3!==1||o3!==1)do if(a3--,o3--,o3<0||t3[a3]!==n4[o3]){let n5=`
${t3[a3].replace(" at new "," at ")}`,r4=v$1(e2);return r4&&n5.includes("<anonymous>")&&(n5=n5.replace("<anonymous>",r4)),n5}while(a3>=1&&o3>=0);break}}}finally{Ut=!1,Error.prepareStackTrace=n2,Vt(r2),console.error=i2,console.warn=a2}let o2=e2?v$1(e2):"";return o2?w$2(o2):""},"Wt"),Gt=__name((e2,t2)=>{let n2=e2.tag,r2="";switch(n2){case 28:r2=w$2("Activity");break;case 1:r2=Wt(e2.type,!0);break;case 11:r2=Wt(e2.type.render,!1);break;case 0:case 15:r2=Wt(e2.type,!1);break;case 5:case 26:case 27:r2=w$2(e2.type);break;case 16:r2=w$2("Lazy");break;case 13:r2=e2.child!==t2&&t2!==null?w$2("Suspense Fallback"):w$2("Suspense");break;case 19:r2=w$2("SuspenseList");break;case 30:r2=w$2("ViewTransition");break;default:return""}return r2},"Gt"),Kt=__name(e2=>{try{let t2="",n2=e2,r2=null;do{t2+=Gt(n2,r2);let e3=n2._debugInfo;if(e3&&Array.isArray(e3))for(let n3=e3.length-1;n3>=0;n3--){let r3=e3[n3];typeof r3.name=="string"&&(t2+=Ht(r3.name,r3.env))}r2=n2,n2=n2.return}while(n2);return t2}catch(e3){return e3 instanceof Error?`
Error generating stack: ${e3.message}
${e3.stack}`:""}},"Kt"),qt=__name(e2=>{let t2=Error.prepareStackTrace;Error.prepareStackTrace=void 0;let n2=e2;if(!n2)return"";Error.prepareStackTrace=t2,n2.startsWith(`Error: react-stack-top-frame
`)&&(n2=n2.slice(29));let r2=n2.indexOf(`
`);if(r2!==-1&&(n2=n2.slice(r2+1)),r2=Math.max(n2.indexOf("react_stack_bottom_frame"),n2.indexOf("react-stack-bottom-frame")),r2!==-1&&(r2=n2.lastIndexOf(`
`,r2)),r2!==-1)n2=n2.slice(0,r2);else return"";return n2},"qt"),Jt=__name(e2=>!!(e2.functionName&&e2.fileName&&(e2.fileName.startsWith("rsc://")||e2.fileName.startsWith("about://React/"))),"Jt"),Yt=__name((e2,t2)=>e2.fileName===t2.fileName&&e2.lineNumber===t2.lineNumber&&e2.columnNumber===t2.columnNumber,"Yt"),Xt=__name(e2=>{let t2=new Map;for(let n2 of e2)for(let e3 of n2.stackFrames){if(!Jt(e3))continue;let n3=e3.functionName,r2=t2.get(n3)??[];r2.some(t3=>Yt(t3,e3))||(r2.push(e3),t2.set(n3,r2))}return t2},"Xt"),Zt=__name((e2,t2,n2)=>{if(!e2.functionName)return{...e2,isServer:!0};let r2=t2.get(e2.functionName);if(!r2||r2.length===0)return{...e2,isServer:!0};let i2=n2.get(e2.functionName)??0,a2=r2[i2%r2.length];return n2.set(e2.functionName,i2+1),{...e2,isServer:!0,fileName:a2.fileName,lineNumber:a2.lineNumber,columnNumber:a2.columnNumber,source:e2.source?.replace("(at Server)",`(${a2.fileName}:${a2.lineNumber}:${a2.columnNumber})`)}},"Zt"),Qt=__name(e2=>{let t2=[];return Xe(e2,e3=>{if(!zt(e3))return;let n2=typeof e3.type=="string"?e3.type:v$1(e3.type)||"<anonymous>";t2.push({componentName:n2,stackFrames:pt(qt(e3._debugStack?.stack))})},!0),t2},"Qt"),$t=__name(async(e2,t2=!0,n2)=>{let r2=Qt(e2),i2=pt(Kt(e2)),a2=Xt(r2),o2=new Map;return Rt(i2.map(e3=>(e3.source?.includes("(at Server)")??!1)||e3.source!=null&&lt.test(e3.source)?Zt(e3,a2,o2):e3).filter((e3,t3,n3)=>{if(t3===0)return!0;let r3=n3[t3-1];return e3.functionName!==r3.functionName}),t2,n2)},"$t"),en=__name(e2=>e2.split("/").filter(Boolean).length,"en"),tn=__name(e2=>e2.split("/").filter(Boolean)[0]??null,"tn"),nn=__name(e2=>{let t2=e2.indexOf("/",1);if(t2===-1||en(e2.slice(0,t2))!==1)return e2;let n2=e2.slice(t2);if(!ot.test(n2)||en(n2)<2)return e2;let r2=tn(n2);return!r2||r2.startsWith("@")||r2.length>4?e2:n2},"nn"),rn=__name(e2=>{if(!e2||at.some(t3=>t3===e2))return"";let t2=e2,n2=t2.startsWith("http://")||t2.startsWith("https://");if(n2)try{t2=new URL(t2).pathname}catch{}if(n2&&(t2=nn(t2)),t2.startsWith("about://React/")){let e3=t2.slice(14),n3=e3.indexOf("/"),r3=e3.indexOf(":");t2=n3!==-1&&(r3===-1||n3<r3)?e3.slice(n3+1):e3}let r2=!0;for(;r2;){r2=!1;for(let e3 of it)if(t2.startsWith(e3)){t2=t2.slice(e3.length),e3==="file:///"&&(t2=`/${t2.replace(/^\/+/,"")}`),r2=!0;break}}if(rt.test(t2)){let e3=t2.match(rt);e3&&(t2=t2.slice(e3[0].length))}if(t2.startsWith("//")){let e3=t2.indexOf("/",2);t2=e3===-1?"":t2.slice(e3)}let i2=t2.indexOf("?");if(i2!==-1){let e3=t2.slice(i2);ct.test(e3)&&(t2=t2.slice(0,i2))}return t2},"rn"),an=__name(e2=>{let t2=rn(e2);return!(!t2||!ot.test(t2)||st.test(t2))},"an"),on=Symbol.for("react.context"),sn=[],cn$1=null,ln=Error("Suspense Exception: This is not a real error! It's an implementation detail of `use` to interrupt the current render."),T$2=__name(()=>{let e2=cn$1;return e2!==null&&(cn$1=e2.next),e2},"T$2"),E$2=__name(e2=>e2._currentValue,"E$2"),D$1=__name((e2,t2,n2,r2=null)=>{sn.push({displayName:r2,primitive:e2,stackError:Error(),value:t2,dispatcherHookName:n2})},"D$1"),un=__name(e2=>{if(typeof e2=="object"&&e2){let t2=e2;if(typeof t2.then=="function"){let e3=t2;switch(e3.status){case"fulfilled":return D$1("Promise",e3.value,"Use"),e3.value;case"rejected":throw e3.reason}throw D$1("Unresolved",e3,"Use"),ln}if(t2.$$typeof===on&&"_currentValue"in t2){let e3=t2,n2=E$2(e3);return D$1("Context (use)",n2,"Use",e3.displayName||"Context"),n2}}throw Error("An unsupported type was passed to use(): "+String(e2))},"un"),dn=__name(e2=>{let t2=E$2(e2);return D$1("Context",t2,"Context",e2.displayName||null),t2},"dn"),fn=__name(e2=>{let t2=T$2(),n2=t2===null?typeof e2=="function"?e2():e2:t2.memoizedState;return D$1("State",n2,"State"),[n2,()=>{}]},"fn"),pn=__name((e2,t2,n2)=>{let r2=T$2(),i2=r2===null?n2===void 0?t2:n2(t2):r2.memoizedState;return D$1("Reducer",i2,"Reducer"),[i2,()=>{}]},"pn"),mn=__name(e2=>{let t2=T$2(),n2=t2===null?{current:e2}:t2.memoizedState;return D$1("Ref",n2.current,"Ref"),n2},"mn"),hn=__name(()=>{let e2=T$2();return D$1("CacheRefresh",e2===null?()=>{}:e2.memoizedState,"CacheRefresh"),()=>{}},"hn"),gn=__name(e2=>{T$2(),D$1("LayoutEffect",e2,"LayoutEffect")},"gn"),_n=__name(e2=>{T$2(),D$1("InsertionEffect",e2,"InsertionEffect")},"_n"),vn=__name(e2=>{T$2(),D$1("Effect",e2,"Effect")},"vn"),yn=__name(e2=>{T$2();let t2;typeof e2=="object"&&e2&&"current"in e2&&(t2=e2.current),D$1("ImperativeHandle",t2,"ImperativeHandle")},"yn"),bn=__name((e2,t2)=>{D$1("DebugValue",typeof t2=="function"?t2(e2):e2,"DebugValue")},"bn"),xn=__name(e2=>{let t2=T$2();return D$1("Callback",t2===null?e2:t2.memoizedState[0],"Callback"),e2},"xn"),Sn=__name(e2=>{let t2=T$2(),n2=t2===null?e2():t2.memoizedState[0];return D$1("Memo",n2,"Memo"),n2},"Sn"),Cn=__name((e2,t2)=>{let n2=T$2();T$2();let r2=n2===null?t2():n2.memoizedState;return D$1("SyncExternalStore",r2,"SyncExternalStore"),r2},"Cn"),wn=__name(()=>{let e2=T$2();T$2();let t2=e2===null?!1:e2.memoizedState;return D$1("Transition",t2,"Transition"),[t2,()=>{}]},"wn"),Tn=__name(e2=>{let t2=T$2(),n2=t2===null?e2:t2.memoizedState;return D$1("DeferredValue",n2,"DeferredValue"),n2},"Tn"),En=__name(()=>{let e2=T$2(),t2=e2===null?"":e2.memoizedState;return D$1("Id",t2,"Id"),t2},"En"),Dn=__name(e2=>[],"Dn"),On=__name(e2=>{let t2=T$2(),n2=t2===null?e2:t2.memoizedState;return D$1("Optimistic",n2,"Optimistic"),[n2,()=>{}]},"On"),kn=__name((e2,t2)=>{let n2,r2=null;if(e2!==null){let t3=e2.memoizedState;if(typeof t3=="object"&&t3&&"then"in t3&&typeof t3.then=="function"){let e3=t3;switch(e3.status){case"fulfilled":n2=e3.value;break;case"rejected":r2=e3.reason;break;default:r2=ln,n2=e3}}else n2=t3}else n2=t2;return{value:n2,error:r2}},"kn"),An=__name(e2=>(t2,n2)=>{let r2=T$2();T$2(),T$2();let i2=Error(),{value:a2,error:o2}=kn(r2,n2);if(sn.push({displayName:null,primitive:e2,stackError:i2,value:a2,dispatcherHookName:e2}),o2!==null)throw o2;return[a2,()=>{},!1]},"An"),jn=An("ActionState"),Mn={readContext:E$2,use:un,useCallback:xn,useContext:dn,useEffect:vn,useImperativeHandle:yn,useLayoutEffect:gn,useInsertionEffect:_n,useMemo:Sn,useReducer:pn,useRef:mn,useState:fn,useDebugValue:bn,useDeferredValue:Tn,useTransition:wn,useSyncExternalStore:Cn,useId:En,useHostTransitionStatus:__name(()=>{let e2=E$2({_currentValue:null});return D$1("HostTransitionStatus",e2,"HostTransitionStatus"),e2},"useHostTransitionStatus"),useFormState:An("FormState"),useActionState:jn,useOptimistic:On,useMemoCache:Dn,useCacheRefresh:hn,useEffectEvent:__name(e2=>(T$2(),D$1("EffectEvent",e2,"EffectEvent"),e2),"useEffectEvent")};typeof Proxy>"u"||new Proxy(Mn,{get(e2,t2){if(Object.prototype.hasOwnProperty.call(e2,t2))return e2[t2];let n2=Error("Missing method in Dispatcher: "+t2);throw n2.name="ReactDebugToolsUnsupportedHookError",n2}}),Je();var O$1=__name((e2,t2)=>e2.length>t2?`${e2.slice(0,t2)}...`:e2,"O$1"),k$1,Nn=__name(()=>{if(k$1!==void 0)return k$1;let e2=document.querySelector('script[src*="/_next/"]')?.src,t2=e2?new URL(e2).pathname:"",n2=t2.indexOf("/_next/");return k$1=n2>0?t2.slice(0,n2):"",k$1},"Nn"),Pn=/^(?:\.\/)?\/?\([a-z][a-z0-9-]*\)\//,A=__name(e2=>{let t2=rn(e2);return t2=t2.replace(Pn,""),t2.startsWith("./")&&(t2=t2.slice(2)),t2},"A"),Fn=__name(e2=>{try{return decodeURIComponent(e2)}catch{return e2}},"Fn"),In=/(?:^|[/\\])node_modules[/\\]/g,Ln=/[/\\]\.vite[/\\]deps[^/\\]*[/\\]/g,Rn=/\.[mc]?[jt]sx?$/i,zn=/^chunk-[A-Za-z0-9_-]+$/,Bn=/[/\\]/,Vn=/^(.+?)@v?\d/,Hn=__name(e2=>e2.split(Bn).filter(Boolean),"Hn"),Un=__name(e2=>{let[t2,n2]=Hn(e2);return!t2||t2.startsWith(".")?null:t2.startsWith("@")?n2?`${t2}/${n2}`:null:t2},"Un"),Wn=__name(e2=>{let t2=Hn(e2)[0];if(!t2)return null;let n2=t2.replace(Rn,"");if(zn.test(n2))return null;if(!n2.startsWith("@"))return n2;let r2=n2.indexOf("_");return r2===-1?null:`${n2.slice(0,r2)}/${n2.slice(r2+1)}`},"Wn"),Gn=__name((e2,t2,n2)=>{let r2=null,i2;for(;(i2=t2.exec(e2))!==null;)r2=i2;return r2?n2(e2.slice(r2.index+r2[0].length)):null},"Gn"),Kn=__name(e2=>e2?.match(Vn)?.[1]??null,"Kn"),qn=__name(e2=>{let t2;try{t2=new URL(e2)}catch{return null}if(!t2.hostname)return null;let n2=Hn(t2.pathname).map(Fn);for(let[e3,t3]of n2.entries()){if(t3.startsWith("@")){let r3=Kn(n2[e3+1]);if(r3)return`${t3}/${r3}`;continue}let r2=Kn(t3);if(r2)return r2}return null},"qn"),Jn=__name(e2=>Gn(e2,Ln,Wn)??Gn(e2,In,Un),"Jn"),Yn=__name(e2=>{if(!e2)return null;let t2=rn(e2);return t2&&(Jn(Fn(t2))||qn(e2))||null},"Yn"),Xn=__name(e2=>e2.startsWith("data-react-grab-"),"Xn"),Zn=new Set(["_","$","motion.","styled.","chakra.","ark.","Primitive.","Slot."]),Qn=new Set("AppRouter.AppRouterAnnouncer.AppDevOverlay.AppDevOverlayErrorBoundary.ClientPageRoot.ClientSegmentRoot.DevRootHTTPAccessFallbackBoundary.ErrorBoundary.ErrorBoundaryHandler.GracefulDegradeBoundary.HTTPAccessErrorFallback.HTTPAccessFallbackBoundary.HTTPAccessFallbackErrorBoundary.HandleRedirect.Head.HistoryUpdater.HotReload.InnerLayoutRouter.InnerScrollAndFocusHandler.InnerScrollAndFocusHandlerOld.InnerScrollAndMaybeFocusHandler.InnerScrollHandlerNew.LoadableComponent.LoadingBoundary.LoadingBoundaryProvider.NotAllowedRootHTTPFallbackError.OfflineProvider.OuterLayoutRouter.RedirectBoundary.RedirectErrorBoundary.RenderFromTemplateContext.RenderValidationBoundaryAtThisLevel.ReplaySsrOnlyErrors.RootErrorBoundary.RootLevelDevOverlayElement.Router.ScrollAndFocusHandler.ScrollAndMaybeFocusHandler.SegmentBoundaryTrigger.SegmentBoundaryTriggerNode.SegmentStateProvider.SegmentTrieNode.SegmentViewNode.SegmentViewStateNode.ServerRoot.body.html".split(".")),$n=new Set(["Suspense","Fragment","StrictMode","Profiler","SuspenseList"]),er=new Set(["MotionDOMComponent"]),tr=__name(e2=>{if(Qn.has(e2)||$n.has(e2)||er.has(e2))return!0;for(let t2 of Zn)if(e2.startsWith(t2))return!0;return!1},"tr"),nr=__name(e2=>!(!e2||tr(e2)||e2==="SlotClone"||e2==="Slot"),"nr"),rr,j=__name(e2=>(e2&&(rr=void 0),rr??=typeof document<"u"&&!!(document.getElementById("__NEXT_DATA__")||document.querySelector("nextjs-portal")),rr),"j"),M=__name(e2=>!(e2.length<=1||tr(e2)||e2[0]!==e2[0].toUpperCase()||e2.endsWith("Provider")||e2.endsWith("Context")),"M"),ir=["about://React/","rsc://React/"],ar=__name(e2=>ir.some(t2=>e2.startsWith(t2)),"ar"),or=__name(e2=>{for(let t2 of ir){if(!e2.startsWith(t2))continue;let n2=e2.indexOf("/",t2.length);if(n2===-1)continue;let r2=n2+1,i2=e2.lastIndexOf("?");return Fn(i2>r2?e2.slice(r2,i2):e2.slice(r2))}return e2},"or"),sr=__name(async e2=>{let t2=[],n2=[];for(let r3=0;r3<e2.length;r3++){let i3=e2[r3];!i3.isServer||!i3.fileName||(t2.push(r3),n2.push({file:or(i3.fileName),methodName:i3.functionName??"<unknown>",line1:i3.lineNumber??null,column1:i3.columnNumber??null,arguments:[]}))}if(n2.length===0)return e2;let r2=new AbortController,i2=setTimeout(()=>r2.abort(),5e3);try{let i3=await fetch(`${Nn()}/__nextjs_original-stack-frames`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({frames:n2,isServer:!0,isEdgeServer:!1,isAppDirectory:!0}),signal:r2.signal});if(!i3.ok)return e2;let a2=await i3.json(),o2=[...e2];for(let n3=0;n3<t2.length;n3++){let r3=a2[n3];if(r3?.status!=="fulfilled")continue;let i4=r3.value?.originalStackFrame;if(!i4?.file||i4.ignored)continue;let s2=t2[n3];o2[s2]={...e2[s2],fileName:i4.file,lineNumber:i4.line1??void 0,columnNumber:i4.column1??void 0,isSymbolicated:!0}}return o2}catch{return e2}finally{clearTimeout(i2)}},"sr"),cr=__name(e2=>{let t2=new Map;return Xe(e2,e3=>{if(!zt(e3))return!1;let n2=qt(e3._debugStack.stack);if(!n2)return!1;for(let e4 of pt(n2))!e4.functionName||!e4.fileName||ar(e4.fileName)&&(t2.has(e4.functionName)||t2.set(e4.functionName,{...e4,isServer:!0}));return!1},!0),t2},"cr"),lr=__name((e2,t2)=>{if(!t2.some(e3=>e3.isServer&&!e3.fileName&&e3.functionName))return t2;let n2=cr(e2);return n2.size===0?t2:t2.map(e3=>{if(!e3.isServer||e3.fileName||!e3.functionName)return e3;let t3=n2.get(e3.functionName);return t3?{...e3,fileName:t3.fileName,lineNumber:t3.lineNumber,columnNumber:t3.columnNumber}:e3})},"lr"),N=__name(e2=>{if(!y$2())return e2;let t2=e2;for(;t2;){if(b$2(t2))return t2;t2=t2.parentElement}return e2},"N"),ur=new WeakMap,dr=__name(async e2=>{try{let t2=b$2(e2);if(!t2)return null;let n2=await $t(t2);return j()?await sr(lr(t2,n2)):n2}catch{return null}},"dr"),P=__name(e2=>{if(!y$2())return Promise.resolve([]);let t2=N(e2),n2=ur.get(t2);if(n2)return n2;let r2=dr(t2);return ur.set(t2,r2),r2},"P"),fr=__name(async e2=>{if(!y$2())return null;let t2=await P(e2);if(!t2)return null;for(let e3 of t2)if(e3.functionName&&M(e3.functionName))return e3.functionName;return null},"fr"),pr=__name(async e2=>{let t2=await P(N(e2));if(!t2||t2.length===0)return null;let n2=t2.filter(e3=>e3.fileName&&an(e3.fileName)),r2=n2.find(e3=>e3.functionName&&M(e3.functionName))??n2[0];return r2?.fileName?{filePath:A(r2.fileName),lineNumber:r2.lineNumber??null,columnNumber:r2.columnNumber??null,componentName:r2.functionName&&M(r2.functionName)?r2.functionName:null}:null},"pr"),mr=__name(e2=>{if(!y$2())return null;let t2=b$2(N(e2));if(!t2)return null;let n2=t2.return;for(;n2;){if(Ye(n2)){let e3=v$1(n2.type);if(e3&&nr(e3))return e3}n2=n2.return}return null},"mr"),hr=__name(e2=>e2?e2.some(e3=>!!(e3.fileName&&an(e3.fileName)||e3.isServer&&(!e3.functionName||M(e3.functionName))||e3.functionName&&M(e3.functionName))):!1,"hr"),gr=__name((e2,t2)=>{if(!y$2())return[];let n2=b$2(e2);if(!n2)return[];let r2=[];return Xe(n2,e3=>{if(r2.length>=t2)return!0;if(Ye(e3)){let t3=v$1(e3.type);t3&&nr(t3)&&r2.push(t3)}return!1},!0),r2},"gr"),_r=__name((e2,t2,n2,r2)=>{let i2=r2&&e2.lineNumber?`${A(t2)}:${e2.lineNumber}${e2.columnNumber?`:${e2.columnNumber}`:""}`:A(t2);return n2?`
  in ${n2} (at ${i2})`:`
  in ${i2}`},"_r"),vr=__name((e2,t2={})=>{let{maxLines:n2=3}=t2,r2=j(),i2=[],a2=null,o2=__name((e3,t3)=>{i2.push(e3),a2=t3},"o");for(let t3 of e2){if(i2.length>=n2)break;let e3=t3.fileName&&an(t3.fileName)?t3.fileName:null,s2=e3?null:Yn(t3.fileName);if(s2&&s2===a2)continue;let c2=t3.functionName&&M(t3.functionName)?t3.functionName:null;if(t3.isServer&&!e3&&(c2||!t3.functionName)){let e4=s2?`${s2} at Server`:"at Server";o2(`
  in ${c2??"<anonymous>"} (${e4})`,s2);continue}if(!e3&&c2){o2(s2?`
  in ${c2} (${s2})`:`
  in ${c2}`,s2);continue}e3&&o2(_r(t3,e3,c2,r2),null)}return i2.join("")},"vr"),yr=__name(async(e2,t2={})=>{let n2=t2.maxLines??3,r2=await P(e2);if(r2&&hr(r2))return vr(r2,t2);let i2=gr(e2,n2);return i2.length>0?i2.map(e3=>`
  in ${e3}`).join(""):""},"yr"),br=__name(async(e2,t2={})=>{let n2=N(e2),r2=kr(n2),i2=await yr(n2,t2);return i2?`${r2}${i2}`:xr(n2)},"br"),xr=__name(e2=>{if(!(e2 instanceof HTMLElement))return Or(e2);let t2=d$1(e2),n2=Tr(e2),r2=O$1(Er(e2),100);return r2.length>0?`<${t2}${n2}>
  ${r2}
</${t2}>`:`<${t2}${n2} />`},"xr"),Sr=__name(e2=>O$1(e2,15),"Sr"),Cr=__name((e2,t2={})=>{let{truncate:n2=!0,maxAttrs:r2=3}=t2,i2=[];for(let t3 of pe){if(i2.length>=r2)break;let a2=e2.getAttribute(t3);if(a2){let e3=n2?Sr(a2):a2;i2.push(`${t3}="${e3}"`)}}return i2.length>0?` ${i2.join(" ")}`:""},"Cr"),wr=__name(e2=>e2==="class"||e2==="className"||e2==="style","wr"),Tr=__name(e2=>{let t2=[],n2=[],r2="";for(let{name:i2,value:a2}of e2.attributes)if(!Xn(i2)){if(wr(i2)){i2!=="style"&&a2&&(r2=` class="${Sr(a2)}"`);continue}me.has(i2)?t2.push(a2?` ${i2}="${a2}"`:` ${i2}`):a2&&n2.push(` ${i2}="${Sr(a2)}"`)}return t2.join("")+n2.join("")+r2},"Tr"),Er=__name(e2=>{let t2="";for(let n2 of e2.childNodes)if(n2.nodeType===Node.TEXT_NODE){let e3=n2.textContent?.trim()??"";e3&&(t2+=(t2?" ":"")+e3)}return t2},"Er"),Dr=__name(e2=>e2.length===0?"":e2.length<=2?e2.map(e3=>`<${d$1(e3)} ...>`).join(`
  `):`(${e2.length} elements)`,"Dr"),Or=__name(e2=>{let t2=d$1(e2);if(!(e2 instanceof HTMLElement))return`<${t2}${Cr(e2,{truncate:!1,maxAttrs:pe.length})} />`;let n2=Tr(e2),r2=O$1(Er(e2),100);return r2?`<${t2}${n2}>${r2}</${t2}>`:`<${t2}${n2} />`},"Or"),kr=__name(e2=>{let t2=d$1(e2),n2=Tr(e2),r2=Er(e2),i2=[],a2=[],o2=!1;for(let t3 of e2.childNodes)t3.nodeType!==Node.COMMENT_NODE&&(t3.nodeType===Node.TEXT_NODE?t3.textContent&&t3.textContent.trim().length>0&&(o2=!0):t3 instanceof Element&&(o2?a2.push(t3):i2.push(t3)));let s2="",c2=Dr(i2);c2&&(s2+=`
  ${c2}`),r2.length>0&&(s2+=`
  ${O$1(r2,100)}`);let l2=Dr(a2);return l2&&(s2+=`
  ${l2}`),s2.length>0?`<${t2}${n2}>${s2}
</${t2}>`:`<${t2}${n2} />`},"kr"),Ar=__name((e2,t2=window.getComputedStyle(e2))=>t2.display!=="none"&&t2.visibility!=="hidden"&&t2.opacity!=="0","Ar"),jr=__name(e2=>{let t2=d$1(e2);return t2==="html"||t2==="body"},"jr"),Mr=__name(e2=>{if(e2.hasAttribute("data-react-grab"))return!0;let t2=e2.getRootNode();return t2 instanceof ShadowRoot&&t2.host.hasAttribute("data-react-grab")},"Mr"),Nr=__name(e2=>e2.hasAttribute("data-react-grab-ignore")||e2.closest("[data-react-grab-ignore]")!==null,"Nr"),Pr=__name(e2=>{let t2=parseInt(e2.zIndex,10);return e2.pointerEvents==="none"&&e2.position==="fixed"&&!isNaN(t2)&&t2>=2147483600},"Pr"),Fr=__name(e2=>{let t2=e2.backgroundColor;return t2==="transparent"||t2==="rgba(0, 0, 0, 0)"},"Fr"),Ir=__name(e2=>{let t2=e2.position;if(t2!=="fixed"&&t2!=="absolute")return!1;if(Fr(e2)||parseFloat(e2.opacity)<.1)return!0;let n2=parseInt(e2.zIndex,10);return!isNaN(n2)&&n2>1e3},"Ir"),F=new WeakMap,Lr=__name(()=>{F=new WeakMap},"Lr"),Rr=__name(e2=>{if(jr(e2)||Mr(e2)||Nr(e2))return!1;let t2=performance.now(),n2=F.get(e2);if(n2&&t2-n2.timestamp<50)return n2.isVisible;let r2=window.getComputedStyle(e2);return Ar(e2,r2)?e2.clientWidth/window.innerWidth>=.9&&e2.clientHeight/window.innerHeight>=.9&&(Pr(r2)||Ir(r2))?!1:(F.set(e2,{isVisible:!0,timestamp:t2}),!0):(F.set(e2,{isVisible:!1,timestamp:t2}),!1)},"Rr"),zr=__name((e2,t2)=>{let n2=document.createElement("style");n2.setAttribute(e2,"");let r2=ke();return r2&&(n2.nonce=r2),je(n2),n2.textContent=t2,document.head.appendChild(n2),n2},"zr"),I=null,Br=__name(()=>I!==null,"Br"),Vr=__name(()=>{I||=zr("data-react-grab-frozen-pseudo","html { pointer-events: none !important; }")},"Vr"),Hr=__name(()=>{I?.remove(),I=null},"Hr"),Ur=__name(()=>{I&&(I.disabled=!0)},"Ur"),Wr=__name(()=>{I&&(I.disabled=!1)},"Wr"),B=!1,V=new Map,ei=-1,ti=new WeakSet,H=new Map,U=new Map,ni=__name(e2=>ti.has(e2)?!0:!B||!("gsapVersions"in window)||!(Error().stack??"").includes("_tick")?!1:(ti.add(e2),!0),"ni");typeof window<"u"&&(window.requestAnimationFrame=e2=>{if(!ni(e2))return f$1(e2);if(B){let t3=ei--;return V.set(t3,e2),t3}let t2=f$1(n2=>{if(B){let n3=ei--;V.set(n3,e2),H.set(t2,n3);return}e2(n2)});return t2},window.cancelAnimationFrame=e2=>{if(V.has(e2)){V.delete(e2);return}let t2=U.get(e2);if(t2!==void 0){p$1(t2.nativeId),U.delete(e2);return}let n2=H.get(e2);if(n2!==void 0){V.delete(n2),H.delete(e2);return}p$1(e2)});var ri=__name(()=>{if(!B){B=!0,V.clear(),H.clear();for(let[e2,{nativeId:t2,callback:n2}]of U)p$1(t2),V.set(e2,n2);U.clear()}},"ri"),ii=__name(()=>{if(B){B=!1;for(let[e2,t2]of V.entries()){let n2=f$1(n3=>{U.delete(e2),t2(n3)});U.set(e2,{nativeId:n2,callback:t2})}V.clear(),H.clear()}},"ii"),ai=`
[${u$1}],
[${u$1}] * {
  animation-play-state: paused !important;
  transition: none !important;
}
`,n=__name(e2=>e2.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"),"n"),r$1=__name((e2,r2)=>{let i2=r2?.componentName??"div",a2={version:i$1,content:e2,entries:r2?.entries??[{tagName:r2?.tagName,componentName:i2,content:e2,commentText:r2?.commentText}],timestamp:Date.now()},o2=__name(t2=>{t2.preventDefault(),t2.clipboardData?.setData("text/plain",e2),t2.clipboardData?.setData("text/html",`<meta charset='utf-8'><pre><code>${n(e2)}</code></pre>`),t2.clipboardData?.setData("application/x-react-grab",JSON.stringify(a2))},"o");document.addEventListener("copy",o2);let s2=document.createElement("textarea");s2.value=e2,s2.style.position="fixed",s2.style.left="-9999px",s2.ariaHidden="true",document.body.appendChild(s2),s2.select();try{return typeof document.execCommand=="function"?document.execCommand("copy"):!1}finally{document.removeEventListener("copy",o2),s2.remove()}},"r$1"),i=new Set(["role","name","aria-label","rel","href"]),a=__name(e2=>{if(!/^[a-z-]{3,}$/i.test(e2))return!1;let t2=e2.split(/-|[A-Z]/);for(let e3 of t2)if(e3.length<=2||/[^aeiou]{4,}/i.test(e3))return!1;return!0},"a"),o=__name((e2,t2)=>{let n2=i.has(e2)||e2.startsWith("data-")&&a(e2),r2=a(t2)&&t2.length<100||t2.startsWith("#")&&a(t2.slice(1));return n2&&r2},"o"),s=__name(e2=>{let t2=e2[0].name;for(let n2=1;n2<e2.length;n2++)t2=`${e2[n2].name} > ${t2}`;return t2},"s"),c=__name(e2=>{let t2=0;for(let n2 of e2)t2+=n2.penalty;return t2},"c"),l=__name((e2,t2)=>c(e2)-c(t2),"l"),u=__name((e2,t2)=>{let n2=e2.parentNode;if(!n2)return;let r2=n2.firstChild;if(!r2)return;let i2=0;for(;r2&&(r2.nodeType===Node.ELEMENT_NODE&&(t2===void 0||r2.tagName.toLowerCase()===t2)&&i2++,r2!==e2);)r2=r2.nextSibling;return i2},"u"),d=__name((e2,t2)=>e2==="html"?"html":`${e2}:nth-child(${t2})`,"d"),f=__name((e2,t2)=>e2==="html"?"html":`${e2}:nth-of-type(${t2})`,"f"),p=__name((e2,t2)=>{let n2=[],r2=e2.getAttribute("id"),i2=e2.tagName.toLowerCase();r2&&a(r2)&&n2.push({name:`#${CSS.escape(r2)}`,penalty:0});for(let t3 of e2.classList)a(t3)&&n2.push({name:`.${CSS.escape(t3)}`,penalty:1});for(let r3 of e2.attributes)t2(r3.name,r3.value)&&n2.push({name:`[${CSS.escape(r3.name)}="${CSS.escape(r3.value)}"]`,penalty:2});n2.push({name:i2,penalty:5});let o2=u(e2,i2);o2!==void 0&&n2.push({name:f(i2,o2),penalty:10});let s2=u(e2);return s2!==void 0&&n2.push({name:d(i2,s2),penalty:50}),n2},"p"),m=__name((t2,n2=ee,r2=[])=>{if(n2<=0)return[];if(t2.length===0)return[r2];let i2=[];for(let e2 of t2[0]){let a2=n2-i2.length;if(a2<=0)break;i2.push(...m(t2.slice(1),a2,[...r2,e2]))}return i2},"m"),h=__name((e2,t2)=>{let n2=t2.getRootNode?.();return n2 instanceof ShadowRoot?n2:e2.nodeType===Node.DOCUMENT_NODE?e2:e2.ownerDocument},"h"),g=__name((e2,t2)=>t2.querySelectorAll(s(e2)).length===1,"g"),_=__name((e2,t2)=>{let n2=e2,r2=[];for(;n2&&n2!==t2;){let e3=n2.tagName.toLowerCase(),t3=u(n2,e3);if(t3===void 0)return;r2.push({name:f(e3,t3),penalty:10}),n2=n2.parentElement}return g(r2,t2)?r2:void 0},"_"),v=__name((e2,t2,n2,r2)=>{if(e2.nodeType!==Node.ELEMENT_NODE)throw Error("Can't generate CSS selector for non-element node type.");if(e2.tagName.toLowerCase()==="html")return"html";let i2=h(t2,e2),a2=Date.now(),o2=[],c2=e2,u2=0,d2;for(;c2&&c2!==i2&&!d2;)if(o2.push(p(c2,r2)),c2=c2.parentElement,u2++,u2>=3){let t3=m(o2);t3.sort(l);for(let r3 of t3){if(Date.now()-a2>n2){let t4=_(e2,i2);if(!t4)throw Error(`Timeout: Can't find a unique selector after ${n2}ms`);return s(t4)}if(g(r3,i2)){d2=r3;break}}}if(!d2&&u2<3){let e3=m(o2);e3.sort(l);for(let t3 of e3){if(Date.now()-a2>n2)break;if(g(t3,i2)){d2=t3;break}}}if(!d2)throw Error("Selector was not found.");return s(d2)},"v"),y$1=__name(e2=>typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(e2):e2.replace(/[^a-zA-Z0-9_-]/g,e3=>`\\${e3}`),"y$1"),b$1=__name(e2=>e2.ownerDocument.body??e2.ownerDocument.documentElement,"b$1"),x$1=new Set(["data-testid","data-test-id","data-test","data-cy","data-qa","aria-label","role","name","title","alt"]),S$1=__name(e2=>e2.length>0&&e2.length<=120,"S$1"),C$1=__name((e2,t2)=>{try{let n2=e2.ownerDocument.querySelectorAll(t2);return n2.length===1&&n2[0]===e2}catch{return!1}},"C$1"),w$1=__name(e2=>{if(e2 instanceof HTMLElement&&e2.id){let t2=`#${y$1(e2.id)}`;if(C$1(e2,t2))return t2}for(let t2 of x$1){let n2=e2.getAttribute(t2);if(!n2||!S$1(n2))continue;let r2=`[${t2}=${JSON.stringify(n2)}]`;if(C$1(e2,r2))return r2;let i2=`${e2.tagName.toLowerCase()}${r2}`;if(C$1(e2,i2))return i2}return null},"w$1"),T$1=__name(e2=>{let t2=[],n2=b$1(e2),r2=e2;for(;r2;){if(r2 instanceof HTMLElement&&r2.id){t2.unshift(`#${y$1(r2.id)}`);break}let e3=r2.parentElement;if(!e3){t2.unshift(r2.tagName.toLowerCase());break}let i2=Array.from(e3.children).indexOf(r2),a2=i2>=0?i2+1:1;if(t2.unshift(`${r2.tagName.toLowerCase()}:nth-child(${a2})`),e3===n2){t2.unshift(n2.tagName.toLowerCase());break}r2=e3}return t2.join(" > ")},"T$1"),E$1=__name((e2,t2=!0)=>{let n2=w$1(e2);if(n2)return n2;if(t2)try{let t3=v(e2,b$1(e2),200,(e3,t4)=>o(e3,t4)||x$1.has(e3)&&S$1(t4));if(t3)return t3}catch{}return T$1(e2)},"E$1"),y=new Map(["top","right","bottom","left"].flatMap(e2=>[[`border-${e2}-style`,e2],[`border-${e2}-color`,e2]])),b=null,x=new Map,S=__name(()=>b||(b=document.createElement("iframe"),b.style.cssText="position:fixed;left:-9999px;width:0;height:0;border:none;visibility:hidden;",document.body.appendChild(b),b),"S"),C=__name(e2=>{let t2=x.get(e2);if(t2)return t2;let n2=S(),i2=n2.contentDocument,a2=i2.createElement(e2);i2.body.appendChild(a2);let o2=n2.contentWindow.getComputedStyle(a2),s2=new Map;for(let e3 of De){let t3=o2.getPropertyValue(e3);t3&&s2.set(e3,t3)}return a2.remove(),x.set(e2,s2),s2},"C"),w=__name((e2,t2)=>{let n2=y.get(e2);if(!n2)return!1;let r2=t2.getPropertyValue(`border-${n2}-width`);return r2==="0px"||r2==="0"},"w"),T=__name(e2=>{let t2=C(e2.tagName.toLowerCase()),n2=getComputedStyle(e2),i2=[];for(let e3 of De){let r2=n2.getPropertyValue(e3);r2&&r2!==t2.get(e3)&&(w(e3,n2)||i2.push(`${e3}: ${r2};`))}let a2=e2.getAttribute("class")?.trim(),o2=i2.join(`
`);return a2?o2?`className: ${a2}

${o2}`:`className: ${a2}`:o2},"T"),E=__name(()=>{b?.remove(),b=null,x.clear()},"E"),D=__name(async r2=>{let[a2,o2,s2]=await Promise.all([br(r2),pr(r2),P(r2).then(e2=>e2??[])]),c2=await yr(r2),l2=kr(r2),u2=mr(r2),d2=b$2(r2),f2=E$1(r2),p2=T(r2);return{element:r2,snippet:a2,htmlPreview:l2,stackString:c2,stack:s2,componentName:u2,filePath:o2?.filePath??null,lineNumber:o2?.lineNumber??null,columnNumber:o2?.columnNumber??null,fiber:d2,selector:f2,styles:p2}},"D"),O=__name((e2,t2)=>{if(!Number.isFinite(e2)||!Number.isFinite(t2))return[];Ur();let n2=document.elementsFromPoint(e2,t2);return Wr(),Array.from(n2)},"O"),k=new Set,version="0.1.37",__defProp2=Object.defineProperty,__defNormalProp=__name((obj,key,value)=>key in obj?__defProp2(obj,key,{enumerable:!0,configurable:!0,writable:!0,value}):obj[key]=value,"__defNormalProp"),__publicField=__name((obj,key,value)=>__defNormalProp(obj,typeof key!="symbol"?key+"":key,value),"__publicField");Array.prototype.toSorted||Object.defineProperty(Array.prototype,"toSorted",{value:__name(function(compareFn){return[...this].sort(compareFn)},"value"),writable:!0,configurable:!0});var IS_CLIENT$1=typeof window<"u";function descending(a2,b2){return b2-a2}__name(descending,"descending");function getComponentGroupNames(group){let result=group[0].name;const len=group.length,max=Math.min(4,len);for(let i2=1;i2<max;i2++)result+=`, ${group[i2].name}`;return result}__name(getComponentGroupNames,"getComponentGroupNames");function getComponentGroupTotalTime(group){let result=group[0].time;for(let i2=1,len=group.length;i2<len;i2++)result+=group[i2].time;return result}__name(getComponentGroupTotalTime,"getComponentGroupTotalTime");function componentGroupHasForget(group){for(let i2=0,len=group.length;i2<len;i2++)if(group[i2].forget)return!0;return!1}__name(componentGroupHasForget,"componentGroupHasForget");var getLabelText=__name(groupedAggregatedRenders=>{let labelText="";const componentsByCount=new Map;for(const aggregatedRender of groupedAggregatedRenders){const{forget,time,aggregatedCount,name}=aggregatedRender;componentsByCount.has(aggregatedCount)||componentsByCount.set(aggregatedCount,[]);const components=componentsByCount.get(aggregatedCount);components&&components.push({name,forget,time:time??0})}const sortedCounts=Array.from(componentsByCount.keys()).sort(descending),parts=[];let cumulativeTime=0;for(const count of sortedCounts){const componentGroup=componentsByCount.get(count);if(!componentGroup)continue;let text=getComponentGroupNames(componentGroup);const totalTime=getComponentGroupTotalTime(componentGroup),hasForget=componentGroupHasForget(componentGroup);cumulativeTime+=totalTime,componentGroup.length>4&&(text+="…"),count>1&&(text+=` × ${count}`),hasForget&&(text=`✨${text}`),parts.push(text)}return labelText=parts.join(", "),labelText.length?(labelText.length>40&&(labelText=`${labelText.slice(0,40)}…`),cumulativeTime>=.01&&(labelText+=` (${Number(cumulativeTime.toFixed(2))}ms)`),labelText):null},"getLabelText");function isEqual(a2,b2){return a2===b2||a2!==a2&&b2!==b2}__name(isEqual,"isEqual");var not_globally_unique_generateId=__name(()=>IS_CLIENT$1?(window.reactScanIdCounter===void 0&&(window.reactScanIdCounter=0),`${++window.reactScanIdCounter}`):"0","not_globally_unique_generateId"),playNotificationSound=__name(audioContext=>{const oscillator=audioContext.createOscillator(),gainNode=audioContext.createGain();oscillator.connect(gainNode),gainNode.connect(audioContext.destination);const options={type:"sine",freq:[392,600],duration:.3,gain:.12},frequencies=options.freq,timePerNote=options.duration/frequencies.length;frequencies.forEach((freq,i2)=>{oscillator.frequency.setValueAtTime(freq,audioContext.currentTime+i2*timePerNote)}),oscillator.type=options.type,gainNode.gain.setValueAtTime(options.gain,audioContext.currentTime),gainNode.gain.setTargetAtTime(0,audioContext.currentTime+options.duration*.7,.05),oscillator.start(),oscillator.stop(audioContext.currentTime+options.duration)},"playNotificationSound"),Icon=D$2(({size=15,name,fill="currentColor",stroke="currentColor",className,externalURL="",style},ref)=>{const width=Array.isArray(size)?size[0]:size,height=Array.isArray(size)?size[1]||size[0]:size,path=`${externalURL}#${name}`;return u$2("svg",{ref,width:`${width}px`,height:`${height}px`,fill,stroke,className,style:{...style,minWidth:`${width}px`,maxWidth:`${width}px`,minHeight:`${height}px`,maxHeight:`${height}px`},children:[u$2("title",{children:name}),u$2("use",{href:path})]})}),SAFE_AREA=24,COPY_FEEDBACK_DURATION_MS=600,MIN_SIZE={width:550,height:350,initialHeight:400},MIN_CONTAINER_WIDTH=240,LOCALSTORAGE_KEY="react-scan-widget-settings-v2",LOCALSTORAGE_COLLAPSED_KEY="react-scan-widget-collapsed-v1",LOCALSTORAGE_LAST_VIEW_KEY="react-scan-widget-last-view-v1",TOOLBAR_INTERACTIVE_SELECTOR="button, a, input, textarea, select, pre, [contenteditable], [data-react-scan-selectable]";function r(e2){var t2,f2,n2="";if(typeof e2=="string"||typeof e2=="number")n2+=e2;else if(typeof e2=="object")if(Array.isArray(e2)){var o2=e2.length;for(t2=0;t2<o2;t2++)e2[t2]&&(f2=r(e2[t2]))&&(n2&&(n2+=" "),n2+=f2)}else for(f2 in e2)e2[f2]&&(n2&&(n2+=" "),n2+=f2);return n2}__name(r,"r");function clsx(){for(var e2,t2,f2=0,n2="",o2=arguments.length;f2<o2;f2++)(e2=arguments[f2])&&(t2=r(e2))&&(n2&&(n2+=" "),n2+=t2);return n2}__name(clsx,"clsx");var concatArrays=__name((array1,array2)=>{const combinedArray=new Array(array1.length+array2.length);for(let i2=0;i2<array1.length;i2++)combinedArray[i2]=array1[i2];for(let i2=0;i2<array2.length;i2++)combinedArray[array1.length+i2]=array2[i2];return combinedArray},"concatArrays"),createClassValidatorObject=__name((classGroupId,validator)=>({classGroupId,validator}),"createClassValidatorObject"),createClassPartObject=__name((nextPart=new Map,validators=null,classGroupId)=>({nextPart,validators,classGroupId}),"createClassPartObject"),CLASS_PART_SEPARATOR="-",EMPTY_CONFLICTS=[],ARBITRARY_PROPERTY_PREFIX="arbitrary..",createClassGroupUtils=__name(config=>{const classMap=createClassMap(config),{conflictingClassGroups,conflictingClassGroupModifiers}=config;return{getClassGroupId:__name(className=>{if(className.startsWith("[")&&className.endsWith("]"))return getGroupIdForArbitraryProperty(className);const classParts=className.split(CLASS_PART_SEPARATOR);return getGroupRecursive(classParts,classParts[0]===""&&classParts.length>1?1:0,classMap)},"getClassGroupId"),getConflictingClassGroupIds:__name((classGroupId,hasPostfixModifier)=>{if(hasPostfixModifier){const modifierConflicts=conflictingClassGroupModifiers[classGroupId],baseConflicts=conflictingClassGroups[classGroupId];return modifierConflicts?baseConflicts?concatArrays(baseConflicts,modifierConflicts):modifierConflicts:baseConflicts||EMPTY_CONFLICTS}return conflictingClassGroups[classGroupId]||EMPTY_CONFLICTS},"getConflictingClassGroupIds")}},"createClassGroupUtils"),getGroupRecursive=__name((classParts,startIndex,classPartObject)=>{if(classParts.length-startIndex===0)return classPartObject.classGroupId;const currentClassPart=classParts[startIndex],nextClassPartObject=classPartObject.nextPart.get(currentClassPart);if(nextClassPartObject){const result=getGroupRecursive(classParts,startIndex+1,nextClassPartObject);if(result)return result}const validators=classPartObject.validators;if(validators===null)return;const classRest=startIndex===0?classParts.join(CLASS_PART_SEPARATOR):classParts.slice(startIndex).join(CLASS_PART_SEPARATOR),validatorsLength=validators.length;for(let i2=0;i2<validatorsLength;i2++){const validatorObj=validators[i2];if(validatorObj.validator(classRest))return validatorObj.classGroupId}},"getGroupRecursive"),getGroupIdForArbitraryProperty=__name(className=>className.slice(1,-1).indexOf(":")===-1?void 0:(()=>{const content=className.slice(1,-1),colonIndex=content.indexOf(":"),property=content.slice(0,colonIndex);return property?ARBITRARY_PROPERTY_PREFIX+property:void 0})(),"getGroupIdForArbitraryProperty"),createClassMap=__name(config=>{const{theme,classGroups}=config;return processClassGroups(classGroups,theme)},"createClassMap"),processClassGroups=__name((classGroups,theme)=>{const classMap=createClassPartObject();for(const classGroupId in classGroups){const group=classGroups[classGroupId];processClassesRecursively(group,classMap,classGroupId,theme)}return classMap},"processClassGroups"),processClassesRecursively=__name((classGroup,classPartObject,classGroupId,theme)=>{const len=classGroup.length;for(let i2=0;i2<len;i2++){const classDefinition=classGroup[i2];processClassDefinition(classDefinition,classPartObject,classGroupId,theme)}},"processClassesRecursively"),processClassDefinition=__name((classDefinition,classPartObject,classGroupId,theme)=>{if(typeof classDefinition=="string"){processStringDefinition(classDefinition,classPartObject,classGroupId);return}if(typeof classDefinition=="function"){processFunctionDefinition(classDefinition,classPartObject,classGroupId,theme);return}processObjectDefinition(classDefinition,classPartObject,classGroupId,theme)},"processClassDefinition"),processStringDefinition=__name((classDefinition,classPartObject,classGroupId)=>{const classPartObjectToEdit=classDefinition===""?classPartObject:getPart(classPartObject,classDefinition);classPartObjectToEdit.classGroupId=classGroupId},"processStringDefinition"),processFunctionDefinition=__name((classDefinition,classPartObject,classGroupId,theme)=>{if(isThemeGetter(classDefinition)){processClassesRecursively(classDefinition(theme),classPartObject,classGroupId,theme);return}classPartObject.validators===null&&(classPartObject.validators=[]),classPartObject.validators.push(createClassValidatorObject(classGroupId,classDefinition))},"processFunctionDefinition"),processObjectDefinition=__name((classDefinition,classPartObject,classGroupId,theme)=>{const entries=Object.entries(classDefinition),len=entries.length;for(let i2=0;i2<len;i2++){const[key,value]=entries[i2];processClassesRecursively(value,getPart(classPartObject,key),classGroupId,theme)}},"processObjectDefinition"),getPart=__name((classPartObject,path)=>{let current=classPartObject;const parts=path.split(CLASS_PART_SEPARATOR),len=parts.length;for(let i2=0;i2<len;i2++){const part=parts[i2];let next=current.nextPart.get(part);next||(next=createClassPartObject(),current.nextPart.set(part,next)),current=next}return current},"getPart"),isThemeGetter=__name(func=>"isThemeGetter"in func&&func.isThemeGetter===!0,"isThemeGetter"),createLruCache=__name(maxCacheSize=>{if(maxCacheSize<1)return{get:__name(()=>{},"get"),set:__name(()=>{},"set")};let cacheSize=0,cache2=Object.create(null),previousCache=Object.create(null);const update=__name((key,value)=>{cache2[key]=value,cacheSize++,cacheSize>maxCacheSize&&(cacheSize=0,previousCache=cache2,cache2=Object.create(null))},"update");return{get(key){let value=cache2[key];if(value!==void 0)return value;if((value=previousCache[key])!==void 0)return update(key,value),value},set(key,value){key in cache2?cache2[key]=value:update(key,value)}}},"createLruCache"),IMPORTANT_MODIFIER="!",MODIFIER_SEPARATOR=":",EMPTY_MODIFIERS=[],createResultObject=__name((modifiers,hasImportantModifier,baseClassName,maybePostfixModifierPosition,isExternal)=>({modifiers,hasImportantModifier,baseClassName,maybePostfixModifierPosition,isExternal}),"createResultObject"),createParseClassName=__name(config=>{const{prefix,experimentalParseClassName}=config;let parseClassName=__name(className=>{const modifiers=[];let bracketDepth=0,parenDepth=0,modifierStart=0,postfixModifierPosition;const len=className.length;for(let index=0;index<len;index++){const currentCharacter=className[index];if(bracketDepth===0&&parenDepth===0){if(currentCharacter===MODIFIER_SEPARATOR){modifiers.push(className.slice(modifierStart,index)),modifierStart=index+1;continue}if(currentCharacter==="/"){postfixModifierPosition=index;continue}}currentCharacter==="["?bracketDepth++:currentCharacter==="]"?bracketDepth--:currentCharacter==="("?parenDepth++:currentCharacter===")"&&parenDepth--}const baseClassNameWithImportantModifier=modifiers.length===0?className:className.slice(modifierStart);let baseClassName=baseClassNameWithImportantModifier,hasImportantModifier=!1;baseClassNameWithImportantModifier.endsWith(IMPORTANT_MODIFIER)?(baseClassName=baseClassNameWithImportantModifier.slice(0,-1),hasImportantModifier=!0):baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER)&&(baseClassName=baseClassNameWithImportantModifier.slice(1),hasImportantModifier=!0);const maybePostfixModifierPosition=postfixModifierPosition&&postfixModifierPosition>modifierStart?postfixModifierPosition-modifierStart:void 0;return createResultObject(modifiers,hasImportantModifier,baseClassName,maybePostfixModifierPosition)},"parseClassName");if(prefix){const fullPrefix=prefix+MODIFIER_SEPARATOR,parseClassNameOriginal=parseClassName;parseClassName=__name(className=>className.startsWith(fullPrefix)?parseClassNameOriginal(className.slice(fullPrefix.length)):createResultObject(EMPTY_MODIFIERS,!1,className,void 0,!0),"parseClassName")}if(experimentalParseClassName){const parseClassNameOriginal=parseClassName;parseClassName=__name(className=>experimentalParseClassName({className,parseClassName:parseClassNameOriginal}),"parseClassName")}return parseClassName},"createParseClassName"),createSortModifiers=__name(config=>{const modifierWeights=new Map;return config.orderSensitiveModifiers.forEach((mod,index)=>{modifierWeights.set(mod,1e6+index)}),modifiers=>{const result=[];let currentSegment=[];for(let i2=0;i2<modifiers.length;i2++){const modifier=modifiers[i2],isArbitrary=modifier[0]==="[",isOrderSensitive=modifierWeights.has(modifier);isArbitrary||isOrderSensitive?(currentSegment.length>0&&(currentSegment.sort(),result.push(...currentSegment),currentSegment=[]),result.push(modifier)):currentSegment.push(modifier)}return currentSegment.length>0&&(currentSegment.sort(),result.push(...currentSegment)),result}},"createSortModifiers"),createConfigUtils=__name(config=>({cache:createLruCache(config.cacheSize),parseClassName:createParseClassName(config),sortModifiers:createSortModifiers(config),...createClassGroupUtils(config)}),"createConfigUtils"),SPLIT_CLASSES_REGEX=/\s+/,mergeClassList=__name((classList,configUtils)=>{const{parseClassName,getClassGroupId,getConflictingClassGroupIds,sortModifiers}=configUtils,classGroupsInConflict=[],classNames=classList.trim().split(SPLIT_CLASSES_REGEX);let result="";for(let index=classNames.length-1;index>=0;index-=1){const originalClassName=classNames[index],{isExternal,modifiers,hasImportantModifier,baseClassName,maybePostfixModifierPosition}=parseClassName(originalClassName);if(isExternal){result=originalClassName+(result.length>0?" "+result:result);continue}let hasPostfixModifier=!!maybePostfixModifierPosition,classGroupId=getClassGroupId(hasPostfixModifier?baseClassName.substring(0,maybePostfixModifierPosition):baseClassName);if(!classGroupId){if(!hasPostfixModifier){result=originalClassName+(result.length>0?" "+result:result);continue}if(classGroupId=getClassGroupId(baseClassName),!classGroupId){result=originalClassName+(result.length>0?" "+result:result);continue}hasPostfixModifier=!1}const variantModifier=modifiers.length===0?"":modifiers.length===1?modifiers[0]:sortModifiers(modifiers).join(":"),modifierId=hasImportantModifier?variantModifier+IMPORTANT_MODIFIER:variantModifier,classId=modifierId+classGroupId;if(classGroupsInConflict.indexOf(classId)>-1)continue;classGroupsInConflict.push(classId);const conflictGroups=getConflictingClassGroupIds(classGroupId,hasPostfixModifier);for(let i2=0;i2<conflictGroups.length;++i2){const group=conflictGroups[i2];classGroupsInConflict.push(modifierId+group)}result=originalClassName+(result.length>0?" "+result:result)}return result},"mergeClassList"),twJoin=__name((...classLists)=>{let index=0,argument,resolvedValue,string="";for(;index<classLists.length;)(argument=classLists[index++])&&(resolvedValue=toValue(argument))&&(string&&(string+=" "),string+=resolvedValue);return string},"twJoin"),toValue=__name(mix=>{if(typeof mix=="string")return mix;let resolvedValue,string="";for(let k2=0;k2<mix.length;k2++)mix[k2]&&(resolvedValue=toValue(mix[k2]))&&(string&&(string+=" "),string+=resolvedValue);return string},"toValue"),createTailwindMerge=__name((createConfigFirst,...createConfigRest)=>{let configUtils,cacheGet,cacheSet,functionToCall;const initTailwindMerge=__name(classList=>(configUtils=createConfigUtils(createConfigRest.reduce((previousConfig,createConfigCurrent)=>createConfigCurrent(previousConfig),createConfigFirst())),cacheGet=configUtils.cache.get,cacheSet=configUtils.cache.set,functionToCall=tailwindMerge,tailwindMerge(classList)),"initTailwindMerge"),tailwindMerge=__name(classList=>{const cachedResult=cacheGet(classList);if(cachedResult)return cachedResult;const result=mergeClassList(classList,configUtils);return cacheSet(classList,result),result},"tailwindMerge");return functionToCall=initTailwindMerge,(...args)=>functionToCall(twJoin(...args))},"createTailwindMerge"),fallbackThemeArr=[],fromTheme=__name(key=>{const themeGetter=__name(theme=>theme[key]||fallbackThemeArr,"themeGetter");return themeGetter.isThemeGetter=!0,themeGetter},"fromTheme"),arbitraryValueRegex=/^\[(?:(\w[\w-]*):)?(.+)\]$/i,arbitraryVariableRegex=/^\((?:(\w[\w-]*):)?(.+)\)$/i,fractionRegex=/^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,tshirtUnitRegex=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,lengthUnitRegex=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,colorFunctionRegex=/^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,shadowRegex=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,imageRegex=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,isFraction=__name(value=>fractionRegex.test(value),"isFraction"),isNumber=__name(value=>!!value&&!Number.isNaN(Number(value)),"isNumber"),isInteger=__name(value=>!!value&&Number.isInteger(Number(value)),"isInteger"),isPercent=__name(value=>value.endsWith("%")&&isNumber(value.slice(0,-1)),"isPercent"),isTshirtSize=__name(value=>tshirtUnitRegex.test(value),"isTshirtSize"),isAny=__name(()=>!0,"isAny"),isLengthOnly=__name(value=>lengthUnitRegex.test(value)&&!colorFunctionRegex.test(value),"isLengthOnly"),isNever=__name(()=>!1,"isNever"),isShadow=__name(value=>shadowRegex.test(value),"isShadow"),isImage=__name(value=>imageRegex.test(value),"isImage"),isAnyNonArbitrary=__name(value=>!isArbitraryValue(value)&&!isArbitraryVariable(value),"isAnyNonArbitrary"),isArbitrarySize=__name(value=>getIsArbitraryValue(value,isLabelSize,isNever),"isArbitrarySize"),isArbitraryValue=__name(value=>arbitraryValueRegex.test(value),"isArbitraryValue"),isArbitraryLength=__name(value=>getIsArbitraryValue(value,isLabelLength,isLengthOnly),"isArbitraryLength"),isArbitraryNumber=__name(value=>getIsArbitraryValue(value,isLabelNumber,isNumber),"isArbitraryNumber"),isArbitraryWeight=__name(value=>getIsArbitraryValue(value,isLabelWeight,isAny),"isArbitraryWeight"),isArbitraryFamilyName=__name(value=>getIsArbitraryValue(value,isLabelFamilyName,isNever),"isArbitraryFamilyName"),isArbitraryPosition=__name(value=>getIsArbitraryValue(value,isLabelPosition,isNever),"isArbitraryPosition"),isArbitraryImage=__name(value=>getIsArbitraryValue(value,isLabelImage,isImage),"isArbitraryImage"),isArbitraryShadow=__name(value=>getIsArbitraryValue(value,isLabelShadow,isShadow),"isArbitraryShadow"),isArbitraryVariable=__name(value=>arbitraryVariableRegex.test(value),"isArbitraryVariable"),isArbitraryVariableLength=__name(value=>getIsArbitraryVariable(value,isLabelLength),"isArbitraryVariableLength"),isArbitraryVariableFamilyName=__name(value=>getIsArbitraryVariable(value,isLabelFamilyName),"isArbitraryVariableFamilyName"),isArbitraryVariablePosition=__name(value=>getIsArbitraryVariable(value,isLabelPosition),"isArbitraryVariablePosition"),isArbitraryVariableSize=__name(value=>getIsArbitraryVariable(value,isLabelSize),"isArbitraryVariableSize"),isArbitraryVariableImage=__name(value=>getIsArbitraryVariable(value,isLabelImage),"isArbitraryVariableImage"),isArbitraryVariableShadow=__name(value=>getIsArbitraryVariable(value,isLabelShadow,!0),"isArbitraryVariableShadow"),isArbitraryVariableWeight=__name(value=>getIsArbitraryVariable(value,isLabelWeight,!0),"isArbitraryVariableWeight"),getIsArbitraryValue=__name((value,testLabel,testValue)=>{const result=arbitraryValueRegex.exec(value);return result?result[1]?testLabel(result[1]):testValue(result[2]):!1},"getIsArbitraryValue"),getIsArbitraryVariable=__name((value,testLabel,shouldMatchNoLabel=!1)=>{const result=arbitraryVariableRegex.exec(value);return result?result[1]?testLabel(result[1]):shouldMatchNoLabel:!1},"getIsArbitraryVariable"),isLabelPosition=__name(label=>label==="position"||label==="percentage","isLabelPosition"),isLabelImage=__name(label=>label==="image"||label==="url","isLabelImage"),isLabelSize=__name(label=>label==="length"||label==="size"||label==="bg-size","isLabelSize"),isLabelLength=__name(label=>label==="length","isLabelLength"),isLabelNumber=__name(label=>label==="number","isLabelNumber"),isLabelFamilyName=__name(label=>label==="family-name","isLabelFamilyName"),isLabelWeight=__name(label=>label==="number"||label==="weight","isLabelWeight"),isLabelShadow=__name(label=>label==="shadow","isLabelShadow"),getDefaultConfig=__name(()=>{const themeColor=fromTheme("color"),themeFont=fromTheme("font"),themeText=fromTheme("text"),themeFontWeight=fromTheme("font-weight"),themeTracking=fromTheme("tracking"),themeLeading=fromTheme("leading"),themeBreakpoint=fromTheme("breakpoint"),themeContainer=fromTheme("container"),themeSpacing=fromTheme("spacing"),themeRadius=fromTheme("radius"),themeShadow=fromTheme("shadow"),themeInsetShadow=fromTheme("inset-shadow"),themeTextShadow=fromTheme("text-shadow"),themeDropShadow=fromTheme("drop-shadow"),themeBlur=fromTheme("blur"),themePerspective=fromTheme("perspective"),themeAspect=fromTheme("aspect"),themeEase=fromTheme("ease"),themeAnimate=fromTheme("animate"),scaleBreak=__name(()=>["auto","avoid","all","avoid-page","page","left","right","column"],"scaleBreak"),scalePosition=__name(()=>["center","top","bottom","left","right","top-left","left-top","top-right","right-top","bottom-right","right-bottom","bottom-left","left-bottom"],"scalePosition"),scalePositionWithArbitrary=__name(()=>[...scalePosition(),isArbitraryVariable,isArbitraryValue],"scalePositionWithArbitrary"),scaleOverflow=__name(()=>["auto","hidden","clip","visible","scroll"],"scaleOverflow"),scaleOverscroll=__name(()=>["auto","contain","none"],"scaleOverscroll"),scaleUnambiguousSpacing=__name(()=>[isArbitraryVariable,isArbitraryValue,themeSpacing],"scaleUnambiguousSpacing"),scaleInset=__name(()=>[isFraction,"full","auto",...scaleUnambiguousSpacing()],"scaleInset"),scaleGridTemplateColsRows=__name(()=>[isInteger,"none","subgrid",isArbitraryVariable,isArbitraryValue],"scaleGridTemplateColsRows"),scaleGridColRowStartAndEnd=__name(()=>["auto",{span:["full",isInteger,isArbitraryVariable,isArbitraryValue]},isInteger,isArbitraryVariable,isArbitraryValue],"scaleGridColRowStartAndEnd"),scaleGridColRowStartOrEnd=__name(()=>[isInteger,"auto",isArbitraryVariable,isArbitraryValue],"scaleGridColRowStartOrEnd"),scaleGridAutoColsRows=__name(()=>["auto","min","max","fr",isArbitraryVariable,isArbitraryValue],"scaleGridAutoColsRows"),scaleAlignPrimaryAxis=__name(()=>["start","end","center","between","around","evenly","stretch","baseline","center-safe","end-safe"],"scaleAlignPrimaryAxis"),scaleAlignSecondaryAxis=__name(()=>["start","end","center","stretch","center-safe","end-safe"],"scaleAlignSecondaryAxis"),scaleMargin=__name(()=>["auto",...scaleUnambiguousSpacing()],"scaleMargin"),scaleSizing=__name(()=>[isFraction,"auto","full","dvw","dvh","lvw","lvh","svw","svh","min","max","fit",...scaleUnambiguousSpacing()],"scaleSizing"),scaleSizingInline=__name(()=>[isFraction,"screen","full","dvw","lvw","svw","min","max","fit",...scaleUnambiguousSpacing()],"scaleSizingInline"),scaleSizingBlock=__name(()=>[isFraction,"screen","full","lh","dvh","lvh","svh","min","max","fit",...scaleUnambiguousSpacing()],"scaleSizingBlock"),scaleColor=__name(()=>[themeColor,isArbitraryVariable,isArbitraryValue],"scaleColor"),scaleBgPosition=__name(()=>[...scalePosition(),isArbitraryVariablePosition,isArbitraryPosition,{position:[isArbitraryVariable,isArbitraryValue]}],"scaleBgPosition"),scaleBgRepeat=__name(()=>["no-repeat",{repeat:["","x","y","space","round"]}],"scaleBgRepeat"),scaleBgSize=__name(()=>["auto","cover","contain",isArbitraryVariableSize,isArbitrarySize,{size:[isArbitraryVariable,isArbitraryValue]}],"scaleBgSize"),scaleGradientStopPosition=__name(()=>[isPercent,isArbitraryVariableLength,isArbitraryLength],"scaleGradientStopPosition"),scaleRadius=__name(()=>["","none","full",themeRadius,isArbitraryVariable,isArbitraryValue],"scaleRadius"),scaleBorderWidth=__name(()=>["",isNumber,isArbitraryVariableLength,isArbitraryLength],"scaleBorderWidth"),scaleLineStyle=__name(()=>["solid","dashed","dotted","double"],"scaleLineStyle"),scaleBlendMode=__name(()=>["normal","multiply","screen","overlay","darken","lighten","color-dodge","color-burn","hard-light","soft-light","difference","exclusion","hue","saturation","color","luminosity"],"scaleBlendMode"),scaleMaskImagePosition=__name(()=>[isNumber,isPercent,isArbitraryVariablePosition,isArbitraryPosition],"scaleMaskImagePosition"),scaleBlur=__name(()=>["","none",themeBlur,isArbitraryVariable,isArbitraryValue],"scaleBlur"),scaleRotate=__name(()=>["none",isNumber,isArbitraryVariable,isArbitraryValue],"scaleRotate"),scaleScale=__name(()=>["none",isNumber,isArbitraryVariable,isArbitraryValue],"scaleScale"),scaleSkew=__name(()=>[isNumber,isArbitraryVariable,isArbitraryValue],"scaleSkew"),scaleTranslate=__name(()=>[isFraction,"full",...scaleUnambiguousSpacing()],"scaleTranslate");return{cacheSize:500,theme:{animate:["spin","ping","pulse","bounce"],aspect:["video"],blur:[isTshirtSize],breakpoint:[isTshirtSize],color:[isAny],container:[isTshirtSize],"drop-shadow":[isTshirtSize],ease:["in","out","in-out"],font:[isAnyNonArbitrary],"font-weight":["thin","extralight","light","normal","medium","semibold","bold","extrabold","black"],"inset-shadow":[isTshirtSize],leading:["none","tight","snug","normal","relaxed","loose"],perspective:["dramatic","near","normal","midrange","distant","none"],radius:[isTshirtSize],shadow:[isTshirtSize],spacing:["px",isNumber],text:[isTshirtSize],"text-shadow":[isTshirtSize],tracking:["tighter","tight","normal","wide","wider","widest"]},classGroups:{aspect:[{aspect:["auto","square",isFraction,isArbitraryValue,isArbitraryVariable,themeAspect]}],container:["container"],columns:[{columns:[isNumber,isArbitraryValue,isArbitraryVariable,themeContainer]}],"break-after":[{"break-after":scaleBreak()}],"break-before":[{"break-before":scaleBreak()}],"break-inside":[{"break-inside":["auto","avoid","avoid-page","avoid-column"]}],"box-decoration":[{"box-decoration":["slice","clone"]}],box:[{box:["border","content"]}],display:["block","inline-block","inline","flex","inline-flex","table","inline-table","table-caption","table-cell","table-column","table-column-group","table-footer-group","table-header-group","table-row-group","table-row","flow-root","grid","inline-grid","contents","list-item","hidden"],sr:["sr-only","not-sr-only"],float:[{float:["right","left","none","start","end"]}],clear:[{clear:["left","right","both","none","start","end"]}],isolation:["isolate","isolation-auto"],"object-fit":[{object:["contain","cover","fill","none","scale-down"]}],"object-position":[{object:scalePositionWithArbitrary()}],overflow:[{overflow:scaleOverflow()}],"overflow-x":[{"overflow-x":scaleOverflow()}],"overflow-y":[{"overflow-y":scaleOverflow()}],overscroll:[{overscroll:scaleOverscroll()}],"overscroll-x":[{"overscroll-x":scaleOverscroll()}],"overscroll-y":[{"overscroll-y":scaleOverscroll()}],position:["static","fixed","absolute","relative","sticky"],inset:[{inset:scaleInset()}],"inset-x":[{"inset-x":scaleInset()}],"inset-y":[{"inset-y":scaleInset()}],start:[{"inset-s":scaleInset(),start:scaleInset()}],end:[{"inset-e":scaleInset(),end:scaleInset()}],"inset-bs":[{"inset-bs":scaleInset()}],"inset-be":[{"inset-be":scaleInset()}],top:[{top:scaleInset()}],right:[{right:scaleInset()}],bottom:[{bottom:scaleInset()}],left:[{left:scaleInset()}],visibility:["visible","invisible","collapse"],z:[{z:[isInteger,"auto",isArbitraryVariable,isArbitraryValue]}],basis:[{basis:[isFraction,"full","auto",themeContainer,...scaleUnambiguousSpacing()]}],"flex-direction":[{flex:["row","row-reverse","col","col-reverse"]}],"flex-wrap":[{flex:["nowrap","wrap","wrap-reverse"]}],flex:[{flex:[isNumber,isFraction,"auto","initial","none",isArbitraryValue]}],grow:[{grow:["",isNumber,isArbitraryVariable,isArbitraryValue]}],shrink:[{shrink:["",isNumber,isArbitraryVariable,isArbitraryValue]}],order:[{order:[isInteger,"first","last","none",isArbitraryVariable,isArbitraryValue]}],"grid-cols":[{"grid-cols":scaleGridTemplateColsRows()}],"col-start-end":[{col:scaleGridColRowStartAndEnd()}],"col-start":[{"col-start":scaleGridColRowStartOrEnd()}],"col-end":[{"col-end":scaleGridColRowStartOrEnd()}],"grid-rows":[{"grid-rows":scaleGridTemplateColsRows()}],"row-start-end":[{row:scaleGridColRowStartAndEnd()}],"row-start":[{"row-start":scaleGridColRowStartOrEnd()}],"row-end":[{"row-end":scaleGridColRowStartOrEnd()}],"grid-flow":[{"grid-flow":["row","col","dense","row-dense","col-dense"]}],"auto-cols":[{"auto-cols":scaleGridAutoColsRows()}],"auto-rows":[{"auto-rows":scaleGridAutoColsRows()}],gap:[{gap:scaleUnambiguousSpacing()}],"gap-x":[{"gap-x":scaleUnambiguousSpacing()}],"gap-y":[{"gap-y":scaleUnambiguousSpacing()}],"justify-content":[{justify:[...scaleAlignPrimaryAxis(),"normal"]}],"justify-items":[{"justify-items":[...scaleAlignSecondaryAxis(),"normal"]}],"justify-self":[{"justify-self":["auto",...scaleAlignSecondaryAxis()]}],"align-content":[{content:["normal",...scaleAlignPrimaryAxis()]}],"align-items":[{items:[...scaleAlignSecondaryAxis(),{baseline:["","last"]}]}],"align-self":[{self:["auto",...scaleAlignSecondaryAxis(),{baseline:["","last"]}]}],"place-content":[{"place-content":scaleAlignPrimaryAxis()}],"place-items":[{"place-items":[...scaleAlignSecondaryAxis(),"baseline"]}],"place-self":[{"place-self":["auto",...scaleAlignSecondaryAxis()]}],p:[{p:scaleUnambiguousSpacing()}],px:[{px:scaleUnambiguousSpacing()}],py:[{py:scaleUnambiguousSpacing()}],ps:[{ps:scaleUnambiguousSpacing()}],pe:[{pe:scaleUnambiguousSpacing()}],pbs:[{pbs:scaleUnambiguousSpacing()}],pbe:[{pbe:scaleUnambiguousSpacing()}],pt:[{pt:scaleUnambiguousSpacing()}],pr:[{pr:scaleUnambiguousSpacing()}],pb:[{pb:scaleUnambiguousSpacing()}],pl:[{pl:scaleUnambiguousSpacing()}],m:[{m:scaleMargin()}],mx:[{mx:scaleMargin()}],my:[{my:scaleMargin()}],ms:[{ms:scaleMargin()}],me:[{me:scaleMargin()}],mbs:[{mbs:scaleMargin()}],mbe:[{mbe:scaleMargin()}],mt:[{mt:scaleMargin()}],mr:[{mr:scaleMargin()}],mb:[{mb:scaleMargin()}],ml:[{ml:scaleMargin()}],"space-x":[{"space-x":scaleUnambiguousSpacing()}],"space-x-reverse":["space-x-reverse"],"space-y":[{"space-y":scaleUnambiguousSpacing()}],"space-y-reverse":["space-y-reverse"],size:[{size:scaleSizing()}],"inline-size":[{inline:["auto",...scaleSizingInline()]}],"min-inline-size":[{"min-inline":["auto",...scaleSizingInline()]}],"max-inline-size":[{"max-inline":["none",...scaleSizingInline()]}],"block-size":[{block:["auto",...scaleSizingBlock()]}],"min-block-size":[{"min-block":["auto",...scaleSizingBlock()]}],"max-block-size":[{"max-block":["none",...scaleSizingBlock()]}],w:[{w:[themeContainer,"screen",...scaleSizing()]}],"min-w":[{"min-w":[themeContainer,"screen","none",...scaleSizing()]}],"max-w":[{"max-w":[themeContainer,"screen","none","prose",{screen:[themeBreakpoint]},...scaleSizing()]}],h:[{h:["screen","lh",...scaleSizing()]}],"min-h":[{"min-h":["screen","lh","none",...scaleSizing()]}],"max-h":[{"max-h":["screen","lh",...scaleSizing()]}],"font-size":[{text:["base",themeText,isArbitraryVariableLength,isArbitraryLength]}],"font-smoothing":["antialiased","subpixel-antialiased"],"font-style":["italic","not-italic"],"font-weight":[{font:[themeFontWeight,isArbitraryVariableWeight,isArbitraryWeight]}],"font-stretch":[{"font-stretch":["ultra-condensed","extra-condensed","condensed","semi-condensed","normal","semi-expanded","expanded","extra-expanded","ultra-expanded",isPercent,isArbitraryValue]}],"font-family":[{font:[isArbitraryVariableFamilyName,isArbitraryFamilyName,themeFont]}],"font-features":[{"font-features":[isArbitraryValue]}],"fvn-normal":["normal-nums"],"fvn-ordinal":["ordinal"],"fvn-slashed-zero":["slashed-zero"],"fvn-figure":["lining-nums","oldstyle-nums"],"fvn-spacing":["proportional-nums","tabular-nums"],"fvn-fraction":["diagonal-fractions","stacked-fractions"],tracking:[{tracking:[themeTracking,isArbitraryVariable,isArbitraryValue]}],"line-clamp":[{"line-clamp":[isNumber,"none",isArbitraryVariable,isArbitraryNumber]}],leading:[{leading:[themeLeading,...scaleUnambiguousSpacing()]}],"list-image":[{"list-image":["none",isArbitraryVariable,isArbitraryValue]}],"list-style-position":[{list:["inside","outside"]}],"list-style-type":[{list:["disc","decimal","none",isArbitraryVariable,isArbitraryValue]}],"text-alignment":[{text:["left","center","right","justify","start","end"]}],"placeholder-color":[{placeholder:scaleColor()}],"text-color":[{text:scaleColor()}],"text-decoration":["underline","overline","line-through","no-underline"],"text-decoration-style":[{decoration:[...scaleLineStyle(),"wavy"]}],"text-decoration-thickness":[{decoration:[isNumber,"from-font","auto",isArbitraryVariable,isArbitraryLength]}],"text-decoration-color":[{decoration:scaleColor()}],"underline-offset":[{"underline-offset":[isNumber,"auto",isArbitraryVariable,isArbitraryValue]}],"text-transform":["uppercase","lowercase","capitalize","normal-case"],"text-overflow":["truncate","text-ellipsis","text-clip"],"text-wrap":[{text:["wrap","nowrap","balance","pretty"]}],indent:[{indent:scaleUnambiguousSpacing()}],"vertical-align":[{align:["baseline","top","middle","bottom","text-top","text-bottom","sub","super",isArbitraryVariable,isArbitraryValue]}],whitespace:[{whitespace:["normal","nowrap","pre","pre-line","pre-wrap","break-spaces"]}],break:[{break:["normal","words","all","keep"]}],wrap:[{wrap:["break-word","anywhere","normal"]}],hyphens:[{hyphens:["none","manual","auto"]}],content:[{content:["none",isArbitraryVariable,isArbitraryValue]}],"bg-attachment":[{bg:["fixed","local","scroll"]}],"bg-clip":[{"bg-clip":["border","padding","content","text"]}],"bg-origin":[{"bg-origin":["border","padding","content"]}],"bg-position":[{bg:scaleBgPosition()}],"bg-repeat":[{bg:scaleBgRepeat()}],"bg-size":[{bg:scaleBgSize()}],"bg-image":[{bg:["none",{linear:[{to:["t","tr","r","br","b","bl","l","tl"]},isInteger,isArbitraryVariable,isArbitraryValue],radial:["",isArbitraryVariable,isArbitraryValue],conic:[isInteger,isArbitraryVariable,isArbitraryValue]},isArbitraryVariableImage,isArbitraryImage]}],"bg-color":[{bg:scaleColor()}],"gradient-from-pos":[{from:scaleGradientStopPosition()}],"gradient-via-pos":[{via:scaleGradientStopPosition()}],"gradient-to-pos":[{to:scaleGradientStopPosition()}],"gradient-from":[{from:scaleColor()}],"gradient-via":[{via:scaleColor()}],"gradient-to":[{to:scaleColor()}],rounded:[{rounded:scaleRadius()}],"rounded-s":[{"rounded-s":scaleRadius()}],"rounded-e":[{"rounded-e":scaleRadius()}],"rounded-t":[{"rounded-t":scaleRadius()}],"rounded-r":[{"rounded-r":scaleRadius()}],"rounded-b":[{"rounded-b":scaleRadius()}],"rounded-l":[{"rounded-l":scaleRadius()}],"rounded-ss":[{"rounded-ss":scaleRadius()}],"rounded-se":[{"rounded-se":scaleRadius()}],"rounded-ee":[{"rounded-ee":scaleRadius()}],"rounded-es":[{"rounded-es":scaleRadius()}],"rounded-tl":[{"rounded-tl":scaleRadius()}],"rounded-tr":[{"rounded-tr":scaleRadius()}],"rounded-br":[{"rounded-br":scaleRadius()}],"rounded-bl":[{"rounded-bl":scaleRadius()}],"border-w":[{border:scaleBorderWidth()}],"border-w-x":[{"border-x":scaleBorderWidth()}],"border-w-y":[{"border-y":scaleBorderWidth()}],"border-w-s":[{"border-s":scaleBorderWidth()}],"border-w-e":[{"border-e":scaleBorderWidth()}],"border-w-bs":[{"border-bs":scaleBorderWidth()}],"border-w-be":[{"border-be":scaleBorderWidth()}],"border-w-t":[{"border-t":scaleBorderWidth()}],"border-w-r":[{"border-r":scaleBorderWidth()}],"border-w-b":[{"border-b":scaleBorderWidth()}],"border-w-l":[{"border-l":scaleBorderWidth()}],"divide-x":[{"divide-x":scaleBorderWidth()}],"divide-x-reverse":["divide-x-reverse"],"divide-y":[{"divide-y":scaleBorderWidth()}],"divide-y-reverse":["divide-y-reverse"],"border-style":[{border:[...scaleLineStyle(),"hidden","none"]}],"divide-style":[{divide:[...scaleLineStyle(),"hidden","none"]}],"border-color":[{border:scaleColor()}],"border-color-x":[{"border-x":scaleColor()}],"border-color-y":[{"border-y":scaleColor()}],"border-color-s":[{"border-s":scaleColor()}],"border-color-e":[{"border-e":scaleColor()}],"border-color-bs":[{"border-bs":scaleColor()}],"border-color-be":[{"border-be":scaleColor()}],"border-color-t":[{"border-t":scaleColor()}],"border-color-r":[{"border-r":scaleColor()}],"border-color-b":[{"border-b":scaleColor()}],"border-color-l":[{"border-l":scaleColor()}],"divide-color":[{divide:scaleColor()}],"outline-style":[{outline:[...scaleLineStyle(),"none","hidden"]}],"outline-offset":[{"outline-offset":[isNumber,isArbitraryVariable,isArbitraryValue]}],"outline-w":[{outline:["",isNumber,isArbitraryVariableLength,isArbitraryLength]}],"outline-color":[{outline:scaleColor()}],shadow:[{shadow:["","none",themeShadow,isArbitraryVariableShadow,isArbitraryShadow]}],"shadow-color":[{shadow:scaleColor()}],"inset-shadow":[{"inset-shadow":["none",themeInsetShadow,isArbitraryVariableShadow,isArbitraryShadow]}],"inset-shadow-color":[{"inset-shadow":scaleColor()}],"ring-w":[{ring:scaleBorderWidth()}],"ring-w-inset":["ring-inset"],"ring-color":[{ring:scaleColor()}],"ring-offset-w":[{"ring-offset":[isNumber,isArbitraryLength]}],"ring-offset-color":[{"ring-offset":scaleColor()}],"inset-ring-w":[{"inset-ring":scaleBorderWidth()}],"inset-ring-color":[{"inset-ring":scaleColor()}],"text-shadow":[{"text-shadow":["none",themeTextShadow,isArbitraryVariableShadow,isArbitraryShadow]}],"text-shadow-color":[{"text-shadow":scaleColor()}],opacity:[{opacity:[isNumber,isArbitraryVariable,isArbitraryValue]}],"mix-blend":[{"mix-blend":[...scaleBlendMode(),"plus-darker","plus-lighter"]}],"bg-blend":[{"bg-blend":scaleBlendMode()}],"mask-clip":[{"mask-clip":["border","padding","content","fill","stroke","view"]},"mask-no-clip"],"mask-composite":[{mask:["add","subtract","intersect","exclude"]}],"mask-image-linear-pos":[{"mask-linear":[isNumber]}],"mask-image-linear-from-pos":[{"mask-linear-from":scaleMaskImagePosition()}],"mask-image-linear-to-pos":[{"mask-linear-to":scaleMaskImagePosition()}],"mask-image-linear-from-color":[{"mask-linear-from":scaleColor()}],"mask-image-linear-to-color":[{"mask-linear-to":scaleColor()}],"mask-image-t-from-pos":[{"mask-t-from":scaleMaskImagePosition()}],"mask-image-t-to-pos":[{"mask-t-to":scaleMaskImagePosition()}],"mask-image-t-from-color":[{"mask-t-from":scaleColor()}],"mask-image-t-to-color":[{"mask-t-to":scaleColor()}],"mask-image-r-from-pos":[{"mask-r-from":scaleMaskImagePosition()}],"mask-image-r-to-pos":[{"mask-r-to":scaleMaskImagePosition()}],"mask-image-r-from-color":[{"mask-r-from":scaleColor()}],"mask-image-r-to-color":[{"mask-r-to":scaleColor()}],"mask-image-b-from-pos":[{"mask-b-from":scaleMaskImagePosition()}],"mask-image-b-to-pos":[{"mask-b-to":scaleMaskImagePosition()}],"mask-image-b-from-color":[{"mask-b-from":scaleColor()}],"mask-image-b-to-color":[{"mask-b-to":scaleColor()}],"mask-image-l-from-pos":[{"mask-l-from":scaleMaskImagePosition()}],"mask-image-l-to-pos":[{"mask-l-to":scaleMaskImagePosition()}],"mask-image-l-from-color":[{"mask-l-from":scaleColor()}],"mask-image-l-to-color":[{"mask-l-to":scaleColor()}],"mask-image-x-from-pos":[{"mask-x-from":scaleMaskImagePosition()}],"mask-image-x-to-pos":[{"mask-x-to":scaleMaskImagePosition()}],"mask-image-x-from-color":[{"mask-x-from":scaleColor()}],"mask-image-x-to-color":[{"mask-x-to":scaleColor()}],"mask-image-y-from-pos":[{"mask-y-from":scaleMaskImagePosition()}],"mask-image-y-to-pos":[{"mask-y-to":scaleMaskImagePosition()}],"mask-image-y-from-color":[{"mask-y-from":scaleColor()}],"mask-image-y-to-color":[{"mask-y-to":scaleColor()}],"mask-image-radial":[{"mask-radial":[isArbitraryVariable,isArbitraryValue]}],"mask-image-radial-from-pos":[{"mask-radial-from":scaleMaskImagePosition()}],"mask-image-radial-to-pos":[{"mask-radial-to":scaleMaskImagePosition()}],"mask-image-radial-from-color":[{"mask-radial-from":scaleColor()}],"mask-image-radial-to-color":[{"mask-radial-to":scaleColor()}],"mask-image-radial-shape":[{"mask-radial":["circle","ellipse"]}],"mask-image-radial-size":[{"mask-radial":[{closest:["side","corner"],farthest:["side","corner"]}]}],"mask-image-radial-pos":[{"mask-radial-at":scalePosition()}],"mask-image-conic-pos":[{"mask-conic":[isNumber]}],"mask-image-conic-from-pos":[{"mask-conic-from":scaleMaskImagePosition()}],"mask-image-conic-to-pos":[{"mask-conic-to":scaleMaskImagePosition()}],"mask-image-conic-from-color":[{"mask-conic-from":scaleColor()}],"mask-image-conic-to-color":[{"mask-conic-to":scaleColor()}],"mask-mode":[{mask:["alpha","luminance","match"]}],"mask-origin":[{"mask-origin":["border","padding","content","fill","stroke","view"]}],"mask-position":[{mask:scaleBgPosition()}],"mask-repeat":[{mask:scaleBgRepeat()}],"mask-size":[{mask:scaleBgSize()}],"mask-type":[{"mask-type":["alpha","luminance"]}],"mask-image":[{mask:["none",isArbitraryVariable,isArbitraryValue]}],filter:[{filter:["","none",isArbitraryVariable,isArbitraryValue]}],blur:[{blur:scaleBlur()}],brightness:[{brightness:[isNumber,isArbitraryVariable,isArbitraryValue]}],contrast:[{contrast:[isNumber,isArbitraryVariable,isArbitraryValue]}],"drop-shadow":[{"drop-shadow":["","none",themeDropShadow,isArbitraryVariableShadow,isArbitraryShadow]}],"drop-shadow-color":[{"drop-shadow":scaleColor()}],grayscale:[{grayscale:["",isNumber,isArbitraryVariable,isArbitraryValue]}],"hue-rotate":[{"hue-rotate":[isNumber,isArbitraryVariable,isArbitraryValue]}],invert:[{invert:["",isNumber,isArbitraryVariable,isArbitraryValue]}],saturate:[{saturate:[isNumber,isArbitraryVariable,isArbitraryValue]}],sepia:[{sepia:["",isNumber,isArbitraryVariable,isArbitraryValue]}],"backdrop-filter":[{"backdrop-filter":["","none",isArbitraryVariable,isArbitraryValue]}],"backdrop-blur":[{"backdrop-blur":scaleBlur()}],"backdrop-brightness":[{"backdrop-brightness":[isNumber,isArbitraryVariable,isArbitraryValue]}],"backdrop-contrast":[{"backdrop-contrast":[isNumber,isArbitraryVariable,isArbitraryValue]}],"backdrop-grayscale":[{"backdrop-grayscale":["",isNumber,isArbitraryVariable,isArbitraryValue]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[isNumber,isArbitraryVariable,isArbitraryValue]}],"backdrop-invert":[{"backdrop-invert":["",isNumber,isArbitraryVariable,isArbitraryValue]}],"backdrop-opacity":[{"backdrop-opacity":[isNumber,isArbitraryVariable,isArbitraryValue]}],"backdrop-saturate":[{"backdrop-saturate":[isNumber,isArbitraryVariable,isArbitraryValue]}],"backdrop-sepia":[{"backdrop-sepia":["",isNumber,isArbitraryVariable,isArbitraryValue]}],"border-collapse":[{border:["collapse","separate"]}],"border-spacing":[{"border-spacing":scaleUnambiguousSpacing()}],"border-spacing-x":[{"border-spacing-x":scaleUnambiguousSpacing()}],"border-spacing-y":[{"border-spacing-y":scaleUnambiguousSpacing()}],"table-layout":[{table:["auto","fixed"]}],caption:[{caption:["top","bottom"]}],transition:[{transition:["","all","colors","opacity","shadow","transform","none",isArbitraryVariable,isArbitraryValue]}],"transition-behavior":[{transition:["normal","discrete"]}],duration:[{duration:[isNumber,"initial",isArbitraryVariable,isArbitraryValue]}],ease:[{ease:["linear","initial",themeEase,isArbitraryVariable,isArbitraryValue]}],delay:[{delay:[isNumber,isArbitraryVariable,isArbitraryValue]}],animate:[{animate:["none",themeAnimate,isArbitraryVariable,isArbitraryValue]}],backface:[{backface:["hidden","visible"]}],perspective:[{perspective:[themePerspective,isArbitraryVariable,isArbitraryValue]}],"perspective-origin":[{"perspective-origin":scalePositionWithArbitrary()}],rotate:[{rotate:scaleRotate()}],"rotate-x":[{"rotate-x":scaleRotate()}],"rotate-y":[{"rotate-y":scaleRotate()}],"rotate-z":[{"rotate-z":scaleRotate()}],scale:[{scale:scaleScale()}],"scale-x":[{"scale-x":scaleScale()}],"scale-y":[{"scale-y":scaleScale()}],"scale-z":[{"scale-z":scaleScale()}],"scale-3d":["scale-3d"],skew:[{skew:scaleSkew()}],"skew-x":[{"skew-x":scaleSkew()}],"skew-y":[{"skew-y":scaleSkew()}],transform:[{transform:[isArbitraryVariable,isArbitraryValue,"","none","gpu","cpu"]}],"transform-origin":[{origin:scalePositionWithArbitrary()}],"transform-style":[{transform:["3d","flat"]}],translate:[{translate:scaleTranslate()}],"translate-x":[{"translate-x":scaleTranslate()}],"translate-y":[{"translate-y":scaleTranslate()}],"translate-z":[{"translate-z":scaleTranslate()}],"translate-none":["translate-none"],accent:[{accent:scaleColor()}],appearance:[{appearance:["none","auto"]}],"caret-color":[{caret:scaleColor()}],"color-scheme":[{scheme:["normal","dark","light","light-dark","only-dark","only-light"]}],cursor:[{cursor:["auto","default","pointer","wait","text","move","help","not-allowed","none","context-menu","progress","cell","crosshair","vertical-text","alias","copy","no-drop","grab","grabbing","all-scroll","col-resize","row-resize","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","ew-resize","ns-resize","nesw-resize","nwse-resize","zoom-in","zoom-out",isArbitraryVariable,isArbitraryValue]}],"field-sizing":[{"field-sizing":["fixed","content"]}],"pointer-events":[{"pointer-events":["auto","none"]}],resize:[{resize:["none","","y","x"]}],"scroll-behavior":[{scroll:["auto","smooth"]}],"scroll-m":[{"scroll-m":scaleUnambiguousSpacing()}],"scroll-mx":[{"scroll-mx":scaleUnambiguousSpacing()}],"scroll-my":[{"scroll-my":scaleUnambiguousSpacing()}],"scroll-ms":[{"scroll-ms":scaleUnambiguousSpacing()}],"scroll-me":[{"scroll-me":scaleUnambiguousSpacing()}],"scroll-mbs":[{"scroll-mbs":scaleUnambiguousSpacing()}],"scroll-mbe":[{"scroll-mbe":scaleUnambiguousSpacing()}],"scroll-mt":[{"scroll-mt":scaleUnambiguousSpacing()}],"scroll-mr":[{"scroll-mr":scaleUnambiguousSpacing()}],"scroll-mb":[{"scroll-mb":scaleUnambiguousSpacing()}],"scroll-ml":[{"scroll-ml":scaleUnambiguousSpacing()}],"scroll-p":[{"scroll-p":scaleUnambiguousSpacing()}],"scroll-px":[{"scroll-px":scaleUnambiguousSpacing()}],"scroll-py":[{"scroll-py":scaleUnambiguousSpacing()}],"scroll-ps":[{"scroll-ps":scaleUnambiguousSpacing()}],"scroll-pe":[{"scroll-pe":scaleUnambiguousSpacing()}],"scroll-pbs":[{"scroll-pbs":scaleUnambiguousSpacing()}],"scroll-pbe":[{"scroll-pbe":scaleUnambiguousSpacing()}],"scroll-pt":[{"scroll-pt":scaleUnambiguousSpacing()}],"scroll-pr":[{"scroll-pr":scaleUnambiguousSpacing()}],"scroll-pb":[{"scroll-pb":scaleUnambiguousSpacing()}],"scroll-pl":[{"scroll-pl":scaleUnambiguousSpacing()}],"snap-align":[{snap:["start","end","center","align-none"]}],"snap-stop":[{snap:["normal","always"]}],"snap-type":[{snap:["none","x","y","both"]}],"snap-strictness":[{snap:["mandatory","proximity"]}],touch:[{touch:["auto","none","manipulation"]}],"touch-x":[{"touch-pan":["x","left","right"]}],"touch-y":[{"touch-pan":["y","up","down"]}],"touch-pz":["touch-pinch-zoom"],select:[{select:["none","text","all","auto"]}],"will-change":[{"will-change":["auto","scroll","contents","transform",isArbitraryVariable,isArbitraryValue]}],fill:[{fill:["none",...scaleColor()]}],"stroke-w":[{stroke:[isNumber,isArbitraryVariableLength,isArbitraryLength,isArbitraryNumber]}],stroke:[{stroke:["none",...scaleColor()]}],"forced-color-adjust":[{"forced-color-adjust":["auto","none"]}]},conflictingClassGroups:{overflow:["overflow-x","overflow-y"],overscroll:["overscroll-x","overscroll-y"],inset:["inset-x","inset-y","inset-bs","inset-be","start","end","top","right","bottom","left"],"inset-x":["right","left"],"inset-y":["top","bottom"],flex:["basis","grow","shrink"],gap:["gap-x","gap-y"],p:["px","py","ps","pe","pbs","pbe","pt","pr","pb","pl"],px:["pr","pl"],py:["pt","pb"],m:["mx","my","ms","me","mbs","mbe","mt","mr","mb","ml"],mx:["mr","ml"],my:["mt","mb"],size:["w","h"],"font-size":["leading"],"fvn-normal":["fvn-ordinal","fvn-slashed-zero","fvn-figure","fvn-spacing","fvn-fraction"],"fvn-ordinal":["fvn-normal"],"fvn-slashed-zero":["fvn-normal"],"fvn-figure":["fvn-normal"],"fvn-spacing":["fvn-normal"],"fvn-fraction":["fvn-normal"],"line-clamp":["display","overflow"],rounded:["rounded-s","rounded-e","rounded-t","rounded-r","rounded-b","rounded-l","rounded-ss","rounded-se","rounded-ee","rounded-es","rounded-tl","rounded-tr","rounded-br","rounded-bl"],"rounded-s":["rounded-ss","rounded-es"],"rounded-e":["rounded-se","rounded-ee"],"rounded-t":["rounded-tl","rounded-tr"],"rounded-r":["rounded-tr","rounded-br"],"rounded-b":["rounded-br","rounded-bl"],"rounded-l":["rounded-tl","rounded-bl"],"border-spacing":["border-spacing-x","border-spacing-y"],"border-w":["border-w-x","border-w-y","border-w-s","border-w-e","border-w-bs","border-w-be","border-w-t","border-w-r","border-w-b","border-w-l"],"border-w-x":["border-w-r","border-w-l"],"border-w-y":["border-w-t","border-w-b"],"border-color":["border-color-x","border-color-y","border-color-s","border-color-e","border-color-bs","border-color-be","border-color-t","border-color-r","border-color-b","border-color-l"],"border-color-x":["border-color-r","border-color-l"],"border-color-y":["border-color-t","border-color-b"],translate:["translate-x","translate-y","translate-none"],"translate-none":["translate","translate-x","translate-y","translate-z"],"scroll-m":["scroll-mx","scroll-my","scroll-ms","scroll-me","scroll-mbs","scroll-mbe","scroll-mt","scroll-mr","scroll-mb","scroll-ml"],"scroll-mx":["scroll-mr","scroll-ml"],"scroll-my":["scroll-mt","scroll-mb"],"scroll-p":["scroll-px","scroll-py","scroll-ps","scroll-pe","scroll-pbs","scroll-pbe","scroll-pt","scroll-pr","scroll-pb","scroll-pl"],"scroll-px":["scroll-pr","scroll-pl"],"scroll-py":["scroll-pt","scroll-pb"],touch:["touch-x","touch-y","touch-pz"],"touch-x":["touch"],"touch-y":["touch"],"touch-pz":["touch"]},conflictingClassGroupModifiers:{"font-size":["leading"]},orderSensitiveModifiers:["*","**","after","backdrop","before","details-content","file","first-letter","first-line","marker","placeholder","selection"]}},"getDefaultConfig"),twMerge=createTailwindMerge(getDefaultConfig),cn=__name((...inputs)=>twMerge(clsx(inputs)),"cn"),throttle=__name((callback,delay)=>{let lastCall=0;return e2=>{const now=Date.now();if(now-lastCall>=delay)return lastCall=now,callback(e2)}},"throttle"),readLocalStorage$1=__name(storageKey=>{if(!IS_CLIENT$1)return null;try{const stored=localStorage.getItem(storageKey);return stored?JSON.parse(stored):null}catch{return null}},"readLocalStorage$1"),saveLocalStorage$1=__name((storageKey,state)=>{if(IS_CLIENT$1)try{window.localStorage.setItem(storageKey,JSON.stringify(state))}catch{}},"saveLocalStorage$1"),removeLocalStorage=__name(storageKey=>{if(IS_CLIENT$1)try{window.localStorage.removeItem(storageKey)}catch{}},"removeLocalStorage"),LazyComponentTag=24,ProfilerTag=12,getExtendedDisplayName=__name(fiber=>{if(!fiber)return{name:"Unknown",wrappers:[],wrapperTypes:[]};const{tag,type,elementType}=fiber;let name=we$1(type);const wrappers=[],wrapperTypes=[];if(Ce$1(fiber)||tag===15||tag===14||type?.$$typeof===Symbol.for("react.memo")||elementType?.$$typeof===Symbol.for("react.memo")){const compiler=Ce$1(fiber);wrapperTypes.push({type:"memo",title:compiler?"This component has been auto-memoized by the React Compiler.":"Memoized component that skips re-renders if props are the same",compiler})}if(tag===LazyComponentTag&&wrapperTypes.push({type:"lazy",title:"Lazily loaded component that supports code splitting"}),tag===13&&wrapperTypes.push({type:"suspense",title:"Component that can suspend while content is loading"}),tag===ProfilerTag&&wrapperTypes.push({type:"profiler",title:"Component that measures rendering performance"}),typeof name=="string"){const wrapperRegex=/^(\w+)\((.*)\)$/;let currentName=name;for(;wrapperRegex.test(currentName);){const match=currentName.match(wrapperRegex);if(match?.[1]&&match?.[2])wrappers.unshift(match[1]),currentName=match[2];else break}name=currentName}return{name:name||"Unknown",wrappers,wrapperTypes}},"getExtendedDisplayName"),isFiniteNonNegative=__name(value=>typeof value=="number"&&Number.isFinite(value)&&value>=0,"isFiniteNonNegative"),isPlainObject=__name(value=>!!value&&typeof value=="object"&&!Array.isArray(value),"isPlainObject"),getSafeArea=__name(()=>{const value=ReactScanInternals.options.value.safeArea;if(isFiniteNonNegative(value))return{top:value,right:value,bottom:value,left:value};if(isPlainObject(value)){const top=value.top,right=value.right,bottom=value.bottom,left=value.left;return{top:isFiniteNonNegative(top)?top:SAFE_AREA,right:isFiniteNonNegative(right)?right:SAFE_AREA,bottom:isFiniteNonNegative(bottom)?bottom:SAFE_AREA,left:isFiniteNonNegative(left)?left:SAFE_AREA}}return{top:SAFE_AREA,right:SAFE_AREA,bottom:SAFE_AREA,left:SAFE_AREA}},"getSafeArea"),signalIsSettingsOpen=y$4(!1),signalRefWidget=y$4(null),getDefaultWidgetConfig=__name(()=>({corner:"bottom-right",dimensions:{isFullWidth:!1,isFullHeight:!1,width:MIN_SIZE.width,height:MIN_SIZE.height,position:{x:SAFE_AREA,y:SAFE_AREA}},lastDimensions:{isFullWidth:!1,isFullHeight:!1,width:MIN_SIZE.width,height:MIN_SIZE.height,position:{x:SAFE_AREA,y:SAFE_AREA}},componentsTree:{width:MIN_CONTAINER_WIDTH}}),"getDefaultWidgetConfig");getDefaultWidgetConfig();var getInitialWidgetConfig=__name(()=>{var _a,_b,_c,_d,_e2;const defaults=getDefaultWidgetConfig(),stored=readLocalStorage$1(LOCALSTORAGE_KEY);return stored?{corner:(_a=stored.corner)!=null?_a:defaults.corner,dimensions:(_b=stored.dimensions)!=null?_b:defaults.dimensions,lastDimensions:(_d=(_c=stored.lastDimensions)!=null?_c:stored.dimensions)!=null?_d:defaults.lastDimensions,componentsTree:(_e2=stored.componentsTree)!=null?_e2:defaults.componentsTree}:(saveLocalStorage$1(LOCALSTORAGE_KEY,{corner:defaults.corner,dimensions:defaults.dimensions,lastDimensions:defaults.lastDimensions,componentsTree:defaults.componentsTree}),defaults)},"getInitialWidgetConfig"),signalWidget=y$4(getInitialWidgetConfig()),updateDimensions=__name(()=>{if(!IS_CLIENT$1)return;const{dimensions}=signalWidget.value,{width,height,position}=dimensions,safeArea=getSafeArea();signalWidget.value={...signalWidget.value,dimensions:{isFullWidth:width>=window.innerWidth-safeArea.left-safeArea.right,isFullHeight:height>=window.innerHeight-safeArea.top-safeArea.bottom,width,height,position}}},"updateDimensions"),signalWidgetViews=y$4({view:"none"}),storedCollapsed=readLocalStorage$1(LOCALSTORAGE_COLLAPSED_KEY),signalWidgetCollapsed=y$4(storedCollapsed??null);function CONSTANT_UPDATE(){return!1}__name(CONSTANT_UPDATE,"CONSTANT_UPDATE");function constant(Component3){function Memoed(props){return this.shouldComponentUpdate=CONSTANT_UPDATE,k$4(Component3,props)}return __name(Memoed,"Memoed"),Memoed.displayName=`Memo(${Component3.displayName||Component3.name})`,Memoed.prototype.isReactComponent=!0,Memoed._forwarded=!0,Memoed}__name(constant,"constant");var useVirtualList=__name(options=>{const{count,getScrollElement,estimateSize,overscan=5}=options,[scrollTop,setScrollTop]=d$4(0),[containerHeight,setContainerHeight]=d$4(0),refResizeObserver=A$3(),refScrollElement=A$3(null),refRafId=A$3(null),itemHeight=estimateSize(),updateContainer=q$2(entries=>{var _a,_b;refScrollElement.current&&setContainerHeight((_b=(_a=entries?.[0])==null?void 0:_a.contentRect.height)!=null?_b:refScrollElement.current.getBoundingClientRect().height)},[]),debouncedUpdateContainer=q$2(()=>{refRafId.current!==null&&cancelAnimationFrame(refRafId.current),refRafId.current=requestAnimationFrame(()=>{updateContainer(),refRafId.current=null})},[updateContainer]);y$5(()=>{const element=getScrollElement();if(!element)return;refScrollElement.current=element;const handleScroll=__name(()=>{refScrollElement.current&&setScrollTop(refScrollElement.current.scrollTop)},"handleScroll");updateContainer(),refResizeObserver.current||(refResizeObserver.current=new ResizeObserver(()=>{debouncedUpdateContainer()})),refResizeObserver.current.observe(element),element.addEventListener("scroll",handleScroll,{passive:!0});const mutationObserver=new MutationObserver(debouncedUpdateContainer);return mutationObserver.observe(element,{attributes:!0,childList:!0,subtree:!0}),()=>{element.removeEventListener("scroll",handleScroll),refResizeObserver.current&&refResizeObserver.current.disconnect(),mutationObserver.disconnect(),refRafId.current!==null&&cancelAnimationFrame(refRafId.current)}},[getScrollElement,updateContainer,debouncedUpdateContainer]);const visibleRange=T$5(()=>{const start2=Math.floor(scrollTop/itemHeight),visibleCount=Math.ceil(containerHeight/itemHeight);return{start:Math.max(0,start2-overscan),end:Math.min(count,start2+visibleCount+overscan)}},[scrollTop,itemHeight,containerHeight,count,overscan]);return{virtualItems:T$5(()=>{const virtualItems=[];for(let index=visibleRange.start;index<visibleRange.end;index++)virtualItems.push({key:index,index,start:index*itemHeight});return virtualItems},[visibleRange,itemHeight]),totalSize:count*itemHeight,scrollTop,containerHeight}},"useVirtualList"),getFiberPath=__name(fiber=>{var _a;const pathSegments=[];let currentFiber=fiber;for(;currentFiber;){const elementType=currentFiber.elementType,name=typeof elementType=="function"?elementType.displayName||elementType.name:typeof elementType=="string"?elementType:"Unknown",index=currentFiber.index!==void 0?`[${currentFiber.index}]`:"";pathSegments.unshift(`${name}${index}`),currentFiber=(_a=currentFiber.return)!=null?_a:null}return pathSegments.join("::")},"getFiberPath"),TIMELINE_MAX_UPDATES=1e3,timelineStateDefault={updates:[],currentFiber:null,totalUpdates:0,windowOffset:0,currentIndex:0,isViewingHistory:!1,latestFiber:null,isVisible:!1,playbackSpeed:1},timelineState=y$4(timelineStateDefault),inspectorUpdateSignal=y$4(0),pendingUpdates=[],batchTimeout=null,batchUpdates=__name(()=>{if(pendingUpdates.length===0)return;const batchedUpdates=[...pendingUpdates],{updates,totalUpdates,currentIndex,isViewingHistory}=timelineState.value,newUpdates=[...updates];let newTotalUpdates=totalUpdates;for(const{update}of batchedUpdates)newUpdates.length>=TIMELINE_MAX_UPDATES&&newUpdates.shift(),newUpdates.push(update),newTotalUpdates++;const newWindowOffset=Math.max(0,newTotalUpdates-TIMELINE_MAX_UPDATES);let newCurrentIndex;isViewingHistory?currentIndex===totalUpdates-1?newCurrentIndex=newUpdates.length-1:currentIndex===0?newCurrentIndex=0:newWindowOffset===0?newCurrentIndex=currentIndex:newCurrentIndex=currentIndex-1:newCurrentIndex=newUpdates.length-1;const lastUpdate=batchedUpdates[batchedUpdates.length-1];timelineState.value={...timelineState.value,latestFiber:lastUpdate.fiber,updates:newUpdates,totalUpdates:newTotalUpdates,windowOffset:newWindowOffset,currentIndex:newCurrentIndex,isViewingHistory},pendingUpdates=pendingUpdates.slice(batchedUpdates.length)},"batchUpdates"),timelineActions={showTimeline:__name(()=>{timelineState.value={...timelineState.value,isVisible:!0}},"showTimeline"),hideTimeline:__name(()=>{timelineState.value={...timelineState.value,isVisible:!1,currentIndex:timelineState.value.updates.length-1}},"hideTimeline"),updateFrame:__name((index,isViewingHistory)=>{timelineState.value={...timelineState.value,currentIndex:index,isViewingHistory}},"updateFrame"),updatePlaybackSpeed:__name(speed=>{timelineState.value={...timelineState.value,playbackSpeed:speed}},"updatePlaybackSpeed"),addUpdate:__name((update,latestFiber)=>{if(pendingUpdates.push({update,fiber:latestFiber}),!batchTimeout){const processBatch=__name(()=>{batchUpdates(),batchTimeout=null,pendingUpdates.length>0&&(batchTimeout=setTimeout(processBatch,96))},"processBatch");batchTimeout=setTimeout(processBatch,96)}},"addUpdate"),reset:__name(()=>{batchTimeout&&(clearTimeout(batchTimeout),batchTimeout=null),pendingUpdates=[],timelineState.value=timelineStateDefault},"reset")},searchState=y$4({query:"",matches:[],currentMatchIndex:-1}),signalSkipTreeUpdate=y$4(!1),flattenTree=__name((nodes,depth=0,parentPath=null)=>nodes.reduce((acc,node,index)=>{var _a,_b;const nodePath=node.element?getFiberPath(node.fiber):`${parentPath}-${index}`,renderData=(_a=node.fiber)!=null&&_a.type?getRenderData(node.fiber):void 0,flatNode={...node,depth,nodeId:nodePath,parentId:parentPath,fiber:node.fiber,renderData};return acc.push(flatNode),(_b=node.children)!=null&&_b.length&&acc.push(...flattenTree(node.children,depth+1,nodePath)),acc},[]),"flattenTree"),getMaxDepth=__name(nodes=>nodes.reduce((max,node)=>Math.max(max,node.depth),0),"getMaxDepth"),calculateIndentSize=__name((containerWidth,maxDepth)=>{if(maxDepth<=0)return 24;const availableSpace=Math.max(0,containerWidth-MIN_CONTAINER_WIDTH);if(availableSpace<24)return 0;const baseIndent=Math.min(availableSpace*.3,maxDepth*24)/maxDepth;return Math.max(0,Math.min(24,baseIndent))},"calculateIndentSize"),VALID_TYPES=["memo","forwardRef","lazy","suspense"],parseTypeSearch=__name(query=>{const typeMatch=query.match(/\[(.*?)\]/);if(!typeMatch)return null;const typeSearches=[],parts=typeMatch[1].split(",");for(const part of parts){const trimmed=part.trim().toLowerCase();trimmed&&typeSearches.push(trimmed)}return typeSearches},"parseTypeSearch"),isValidTypeSearch=__name(typeSearches=>{if(typeSearches.length===0)return!1;for(const search of typeSearches){let isValid=!1;for(const validType of VALID_TYPES)if(validType.toLowerCase().includes(search)){isValid=!0;break}if(!isValid)return!1}return!0},"isValidTypeSearch"),matchesTypeSearch=__name((typeSearches,wrapperTypes)=>{if(typeSearches.length===0)return!0;if(!wrapperTypes.length)return!1;for(const search of typeSearches){let foundMatch=!1;for(const wrapper of wrapperTypes)if(wrapper.type.toLowerCase().includes(search)){foundMatch=!0;break}if(!foundMatch)return!1}return!0},"matchesTypeSearch"),useNodeHighlighting=__name((node,searchValue)=>T$5(()=>{const{query,matches}=searchValue,isMatch=matches.some(match=>match.nodeId===node.nodeId),typeSearches=parseTypeSearch(query)||[],searchQuery=query?query.replace(/\[.*?\]/,"").trim():"";if(!query||!isMatch)return{highlightedText:u$2("span",{className:"truncate",children:node.label}),typeHighlight:!1};let matchesType=!0;if(typeSearches.length>0)if(!node.fiber)matchesType=!1;else{const{wrapperTypes}=getExtendedDisplayName(node.fiber);matchesType=matchesTypeSearch(typeSearches,wrapperTypes)}let textContent=u$2("span",{className:"truncate",children:node.label});if(searchQuery)try{if(searchQuery.startsWith("/")&&searchQuery.endsWith("/")){const pattern=searchQuery.slice(1,-1),regex=new RegExp(`(${pattern})`,"i"),parts=node.label.split(regex);textContent=u$2("span",{className:"tree-node-search-highlight",children:parts.map((part,index)=>regex.test(part)?u$2("span",{className:cn("regex",{start:regex.test(part)&&index===0,middle:regex.test(part)&&index%2===1,end:regex.test(part)&&index===parts.length-1,"!ml-0":index===1}),children:part},`${node.nodeId}-${part}`):part)})}else{const lowerLabel=node.label.toLowerCase(),lowerQuery=searchQuery.toLowerCase(),index=lowerLabel.indexOf(lowerQuery);index>=0&&(textContent=u$2("span",{className:"tree-node-search-highlight",children:[node.label.slice(0,index),u$2("span",{className:"single",children:node.label.slice(index,index+searchQuery.length)}),node.label.slice(index+searchQuery.length)]}))}}catch{}return{highlightedText:textContent,typeHighlight:matchesType&&typeSearches.length>0}},[node.label,node.nodeId,node.fiber,searchValue]),"useNodeHighlighting"),formatTime=__name(time=>time>0?time<.1-Number.EPSILON?"< 0.1":time<1e3?Number(time.toFixed(1)).toString():`${(time/1e3).toFixed(1)}k`:"0","formatTime"),TreeNodeItem=__name(({node,nodeIndex,hasChildren,isCollapsed,handleTreeNodeClick,handleTreeNodeToggle,searchValue})=>{var _a,_b,_c;const refRenderCount=A$3(null),refPrevRenderCount=A$3((_b=(_a=node.renderData)==null?void 0:_a.renderCount)!=null?_b:0),{highlightedText,typeHighlight}=useNodeHighlighting(node,searchValue);y$5(()=>{var _a2;const currentRenderCount=(_a2=node.renderData)==null?void 0:_a2.renderCount,element=refRenderCount.current;!element||!refPrevRenderCount.current||!currentRenderCount||refPrevRenderCount.current===currentRenderCount||(element.classList.remove("count-flash"),element.offsetWidth,element.classList.add("count-flash"),refPrevRenderCount.current=currentRenderCount)},[(_c=node.renderData)==null?void 0:_c.renderCount]);const renderTimeInfo=T$5(()=>{if(!node.renderData)return null;const{selfTime,totalTime,renderCount}=node.renderData;return renderCount?u$2("span",{className:cn("flex items-center gap-x-0.5 ml-1.5","text-[10px] text-neutral-400"),children:u$2("span",{ref:refRenderCount,title:`Self time: ${formatTime(selfTime)}ms
Total time: ${formatTime(totalTime)}ms`,className:"count-badge",children:["×",renderCount]})}):null},[node.renderData]),componentTypes=T$5(()=>{if(!node.fiber)return null;const{wrapperTypes}=getExtendedDisplayName(node.fiber),firstWrapperType=wrapperTypes[0];return u$2("span",{className:cn("flex items-center gap-x-1","text-[10px] text-neutral-400 tracking-wide","overflow-hidden"),children:[firstWrapperType&&u$2(S$4,{children:[u$2("span",{title:firstWrapperType?.title,className:cn("rounded py-[1px] px-1","bg-neutral-700 text-neutral-300","truncate",firstWrapperType.type==="memo"&&"bg-[#8e61e3] text-white",typeHighlight&&"bg-yellow-300 text-black"),children:firstWrapperType.type},firstWrapperType.type),firstWrapperType.compiler&&u$2("span",{className:"text-yellow-300 ml-1",children:"✨"})]}),wrapperTypes.length>1&&`×${wrapperTypes.length}`,renderTimeInfo]})},[node.fiber,typeHighlight,renderTimeInfo]);return u$2("button",{type:"button",title:node.title,"data-index":nodeIndex,className:cn("flex items-center gap-x-1","pl-1 pr-2","w-full h-7","text-left","rounded","cursor-pointer select-none"),onClick:handleTreeNodeClick,children:[u$2("button",{type:"button","data-index":nodeIndex,onClick:handleTreeNodeToggle,className:cn("w-6 h-6 flex items-center justify-center","text-left"),children:hasChildren&&u$2(Icon,{name:"icon-chevron-right",size:12,className:cn("transition-transform",!isCollapsed&&"rotate-90")})}),highlightedText,componentTypes]})},"TreeNodeItem"),ComponentsTree=__name(()=>{const refContainer=A$3(null),refMainContainer=A$3(null),refSearchInputContainer=A$3(null),refSearchInput=A$3(null),refSelectedElement=A$3(null),refMaxTreeDepth=A$3(0),refIsHovering=A$3(!1),refIsResizing=A$3(!1),refResizeHandle=A$3(null),[flattenedNodes,setFlattenedNodes]=d$4([]),[collapsedNodes,setCollapsedNodes]=d$4(new Set),[selectedIndex,setSelectedIndex]=d$4(void 0),[searchValue,setSearchValue]=d$4(searchState.value),visibleNodes=T$5(()=>{const visible=[],nodes=flattenedNodes,nodeMap=new Map(nodes.map(node=>[node.nodeId,node]));for(const node of nodes){let isVisible=!0,currentNode=node;for(;currentNode.parentId;){const parent=nodeMap.get(currentNode.parentId);if(!parent)break;if(collapsedNodes.has(parent.nodeId)){isVisible=!1;break}currentNode=parent}isVisible&&visible.push(node)}return visible},[collapsedNodes,flattenedNodes]),ITEM_HEIGHT=28,{virtualItems,totalSize}=useVirtualList({count:visibleNodes.length,getScrollElement:__name(()=>refContainer.current,"getScrollElement"),estimateSize:__name(()=>ITEM_HEIGHT,"estimateSize"),overscan:5}),handleElementClick=q$2(element=>{var _a;refIsHovering.current=!0,(_a=refSearchInput.current)==null||_a.blur(),signalSkipTreeUpdate.value=!0;const{parentCompositeFiber}=getCompositeComponentFromElement(element);if(!parentCompositeFiber)return;Store.inspectState.value={kind:"focused",focusedDomElement:element,fiber:parentCompositeFiber};const nodeIndex=visibleNodes.findIndex(node=>node.element===element);if(nodeIndex!==-1){setSelectedIndex(nodeIndex);const itemTop=nodeIndex*ITEM_HEIGHT,container=refContainer.current;if(container){const containerHeight=container.clientHeight,scrollTop=container.scrollTop;(itemTop<scrollTop||itemTop+ITEM_HEIGHT>scrollTop+containerHeight)&&container.scrollTo({top:Math.max(0,itemTop-containerHeight/2),behavior:"instant"})}}},[visibleNodes]),handleTreeNodeClick=q$2(e2=>{const target=e2.currentTarget,index=Number(target.dataset.index);if(Number.isNaN(index))return;const element=visibleNodes[index].element;element&&handleElementClick(element)},[visibleNodes,handleElementClick]),handleToggle=q$2(nodeId=>{setCollapsedNodes(prev=>{const next=new Set(prev);return next.has(nodeId)?next.delete(nodeId):next.add(nodeId),next})},[]),handleTreeNodeToggle=q$2(e2=>{e2.stopPropagation();const target=e2.target,index=Number(target.dataset.index);if(Number.isNaN(index))return;const nodeId=visibleNodes[index].nodeId;handleToggle(nodeId)},[visibleNodes,handleToggle]),handleOnChangeSearch=q$2(query=>{var _a,_b,_c,_d,_e2;(_a=refSearchInputContainer.current)==null||_a.classList.remove("!border-red-500");const matches=[];if(!query){searchState.value={query,matches,currentMatchIndex:-1};return}if(query.includes("[")&&!query.includes("]")&&query.length>query.indexOf("[")+1){(_b=refSearchInputContainer.current)==null||_b.classList.add("!border-red-500");return}const typeSearches=parseTypeSearch(query)||[];if(query.includes("[")&&!isValidTypeSearch(typeSearches)){(_c=refSearchInputContainer.current)==null||_c.classList.add("!border-red-500");return}const searchQuery=query.replace(/\[.*?\]/,"").trim(),isRegex=/^\/.*\/$/.test(searchQuery);let matchesLabel=__name(_label=>!1,"matchesLabel");if(searchQuery.startsWith("/")&&!isRegex&&searchQuery.length>1){(_d=refSearchInputContainer.current)==null||_d.classList.add("!border-red-500");return}if(isRegex)try{const pattern=searchQuery.slice(1,-1),regex=new RegExp(pattern,"i");matchesLabel=__name(label=>regex.test(label),"matchesLabel")}catch{(_e2=refSearchInputContainer.current)==null||_e2.classList.add("!border-red-500");return}else if(searchQuery){const lowerQuery=searchQuery.toLowerCase();matchesLabel=__name(label=>label.toLowerCase().includes(lowerQuery),"matchesLabel")}for(const node of flattenedNodes){let matchesSearch=!0;if(searchQuery&&(matchesSearch=matchesLabel(node.label)),matchesSearch&&typeSearches.length>0)if(!node.fiber)matchesSearch=!1;else{const{wrapperTypes}=getExtendedDisplayName(node.fiber);matchesSearch=matchesTypeSearch(typeSearches,wrapperTypes)}matchesSearch&&matches.push(node)}if(searchState.value={query,matches,currentMatchIndex:matches.length>0?0:-1},matches.length>0){const firstMatch=matches[0],nodeIndex=visibleNodes.findIndex(node=>node.nodeId===firstMatch.nodeId);if(nodeIndex!==-1){const itemTop=nodeIndex*ITEM_HEIGHT,container=refContainer.current;if(container){const containerHeight=container.clientHeight;container.scrollTo({top:Math.max(0,itemTop-containerHeight/2),behavior:"instant"})}}}},[flattenedNodes,visibleNodes]),handleInputChange=q$2(e2=>{const target=e2.currentTarget;target&&handleOnChangeSearch(target.value)},[handleOnChangeSearch]),navigateSearch=q$2(direction=>{const{matches,currentMatchIndex}=searchState.value;if(matches.length===0)return;const newIndex=direction==="next"?(currentMatchIndex+1)%matches.length:(currentMatchIndex-1+matches.length)%matches.length;searchState.value={...searchState.value,currentMatchIndex:newIndex};const currentMatch=matches[newIndex],nodeIndex=visibleNodes.findIndex(node=>node.nodeId===currentMatch.nodeId);if(nodeIndex!==-1){setSelectedIndex(nodeIndex);const itemTop=nodeIndex*ITEM_HEIGHT,container=refContainer.current;if(container){const containerHeight=container.clientHeight;container.scrollTo({top:Math.max(0,itemTop-containerHeight/2),behavior:"instant"})}}},[visibleNodes]),updateContainerWidths=q$2(width=>{if(refMainContainer.current&&(refMainContainer.current.style.width=`${width}px`),refContainer.current){refContainer.current.style.width=`${width}px`;const indentSize=calculateIndentSize(width,refMaxTreeDepth.current);refContainer.current.style.setProperty("--indentation-size",`${indentSize}px`)}},[]),updateResizeDirection=q$2(width=>{if(!refResizeHandle.current)return;const parentWidth=signalWidget.value.dimensions.width,maxWidth=Math.floor(parentWidth-MIN_CONTAINER_WIDTH/2);refResizeHandle.current.classList.remove("cursor-ew-resize","cursor-w-resize","cursor-e-resize"),width<=MIN_CONTAINER_WIDTH?refResizeHandle.current.classList.add("cursor-w-resize"):width>=maxWidth?refResizeHandle.current.classList.add("cursor-e-resize"):refResizeHandle.current.classList.add("cursor-ew-resize")},[]),handleResize=q$2(e2=>{if(e2.preventDefault(),e2.stopPropagation(),!refContainer.current)return;refContainer.current.style.setProperty("pointer-events","none"),refIsResizing.current=!0;const startX=e2.clientX,startWidth=refContainer.current.offsetWidth,parentWidth=signalWidget.value.dimensions.width,maxWidth=Math.floor(parentWidth-MIN_CONTAINER_WIDTH/2);updateResizeDirection(startWidth);const handlePointerMove=__name(e22=>{const newWidth=startWidth+(startX-e22.clientX);updateResizeDirection(newWidth),updateContainerWidths(Math.min(maxWidth,Math.max(MIN_CONTAINER_WIDTH,newWidth)))},"handlePointerMove"),handlePointerUp=__name(()=>{refContainer.current&&(refContainer.current.style.removeProperty("pointer-events"),document.removeEventListener("pointermove",handlePointerMove),document.removeEventListener("pointerup",handlePointerUp),signalWidget.value={...signalWidget.value,componentsTree:{...signalWidget.value.componentsTree,width:refContainer.current.offsetWidth}},saveLocalStorage$1(LOCALSTORAGE_KEY,signalWidget.value),refIsResizing.current=!1)},"handlePointerUp");document.addEventListener("pointermove",handlePointerMove),document.addEventListener("pointerup",handlePointerUp)},[updateContainerWidths,updateResizeDirection]);y$5(()=>{if(!refContainer.current)return;const currentWidth=refContainer.current.offsetWidth;return updateResizeDirection(currentWidth),signalWidget.subscribe(()=>{refContainer.current&&updateResizeDirection(refContainer.current.offsetWidth)})},[updateResizeDirection]);const onPointerLeave=q$2(()=>{refIsHovering.current=!1},[]);return y$5(()=>{let isInitialTreeBuild=!0;const buildTreeFromElements=__name(elements=>{const nodeMap=new Map,rootNodes=[];for(const{element,name,fiber}of elements){if(!element)continue;let title=name;const{name:componentName,wrappers}=getExtendedDisplayName(fiber);componentName&&(wrappers.length>0?title=`${wrappers.join("(")}(${componentName})${")".repeat(wrappers.length)}`:title=componentName),nodeMap.set(element,{label:componentName||name,title,children:[],element,fiber})}for(const{element,depth}of elements){if(!element)continue;const node=nodeMap.get(element);if(node)if(depth===0)rootNodes.push(node);else{let parent=element.parentElement;for(;parent;){const parentNode=nodeMap.get(parent);if(parentNode){parentNode.children=parentNode.children||[],parentNode.children.push(node);break}parent=parent.parentElement}}}return rootNodes},"buildTreeFromElements"),updateTree=__name(()=>{const element=refSelectedElement.current;if(!element)return;const tree=buildTreeFromElements(getInspectableElements());if(tree.length>0){const flattened=flattenTree(tree);if(refMaxTreeDepth.current=getMaxDepth(flattened),updateContainerWidths(signalWidget.value.componentsTree.width),setFlattenedNodes(flattened),isInitialTreeBuild){isInitialTreeBuild=!1;const focusedIndex=flattened.findIndex(node=>node.element===element);if(focusedIndex!==-1){const itemTop=focusedIndex*ITEM_HEIGHT,container=refContainer.current;container&&setTimeout(()=>{container.scrollTo({top:itemTop,behavior:"instant"})},96)}}}},"updateTree"),unsubscribeStore=Store.inspectState.subscribe(state=>{if(state.kind==="focused"){if(signalSkipTreeUpdate.value)return;handleOnChangeSearch(""),refSelectedElement.current=state.focusedDomElement,updateTree()}});let rafId=0;const unsubscribeUpdates=inspectorUpdateSignal.subscribe(()=>{if(Store.inspectState.value.kind==="focused"){if(cancelAnimationFrame(rafId),refIsResizing.current)return;rafId=requestAnimationFrame(()=>{signalSkipTreeUpdate.value=!1,updateTree()})}});return()=>{unsubscribeStore(),unsubscribeUpdates(),searchState.value={query:"",matches:[],currentMatchIndex:-1}}},[]),y$5(()=>{const handleKeyDown=__name(e2=>{if(refIsHovering.current&&selectedIndex)switch(e2.key){case"ArrowUp":if(e2.preventDefault(),e2.stopPropagation(),selectedIndex>0){const currentNode=visibleNodes[selectedIndex-1];currentNode?.element&&handleElementClick(currentNode.element)}return;case"ArrowDown":if(e2.preventDefault(),e2.stopPropagation(),selectedIndex<visibleNodes.length-1){const currentNode=visibleNodes[selectedIndex+1];currentNode?.element&&handleElementClick(currentNode.element)}return;case"ArrowLeft":{e2.preventDefault(),e2.stopPropagation();const currentNode=visibleNodes[selectedIndex];currentNode?.nodeId&&handleToggle(currentNode.nodeId);return}case"ArrowRight":{e2.preventDefault(),e2.stopPropagation();const currentNode=visibleNodes[selectedIndex];currentNode?.nodeId&&handleToggle(currentNode.nodeId);return}}},"handleKeyDown");return document.addEventListener("keydown",handleKeyDown),()=>{document.removeEventListener("keydown",handleKeyDown)}},[selectedIndex,visibleNodes,handleElementClick,handleToggle]),y$5(()=>searchState.subscribe(setSearchValue),[]),y$5(()=>signalWidget.subscribe(state=>{var _a;(_a=refMainContainer.current)==null||_a.style.setProperty("transition","width 0.1s"),updateContainerWidths(state.componentsTree.width),setTimeout(()=>{var _a2;(_a2=refMainContainer.current)==null||_a2.style.removeProperty("transition")},500)}),[]),u$2("div",{className:"react-scan-components-tree flex",children:[u$2("div",{ref:refResizeHandle,onPointerDown:handleResize,className:"relative resize-v-line",children:u$2("span",{children:u$2(Icon,{name:"icon-ellipsis",size:18})})}),u$2("div",{ref:refMainContainer,className:"flex flex-col h-full",children:[u$2("div",{className:"p-2 border-b border-[#1e1e1e]",children:u$2("div",{ref:refSearchInputContainer,title:`Search components by:

• Name (e.g., "Button") — Case insensitive, matches any part

• Regular Expression (e.g., "/^Button/") — Use forward slashes

• Wrapper Type (e.g., "[memo,forwardRef]"):
   - Available types: memo, forwardRef, lazy, suspense
   - Matches any part of type name (e.g., "mo" matches "memo")
   - Use commas for multiple types

• Combined Search:
   - Mix name/regex with type: "button [for]"
   - Will match components satisfying both conditions

• Navigation:
   - Enter → Next match
   - Shift + Enter → Previous match
   - Cmd/Ctrl + Enter → Select and focus match
`,className:cn("relative","flex items-center gap-x-1 px-2","rounded","border border-transparent","focus-within:border-[#454545]","bg-[#1e1e1e] text-neutral-300","transition-colors","whitespace-nowrap","overflow-hidden"),children:[u$2(Icon,{name:"icon-search",size:12,className:" text-neutral-500"}),u$2("div",{className:"relative flex-1 h-7 overflow-hidden",children:u$2("input",{ref:refSearchInput,type:"text",value:searchState.value.query,onClick:__name(e2=>{e2.stopPropagation(),e2.currentTarget.focus()},"onClick"),onPointerDown:__name(e2=>{e2.stopPropagation()},"onPointerDown"),onKeyDown:__name(e2=>{e2.key==="Escape"&&e2.currentTarget.blur(),searchState.value.matches.length&&(e2.key==="Enter"&&e2.shiftKey?navigateSearch("prev"):e2.key==="Enter"&&(e2.metaKey||e2.ctrlKey?(e2.preventDefault(),e2.stopPropagation(),handleElementClick(searchState.value.matches[searchState.value.currentMatchIndex].element),e2.currentTarget.focus()):navigateSearch("next")))},"onKeyDown"),onChange:handleInputChange,className:"absolute inset-y-0 inset-x-1",placeholder:"Component name, /regex/, or [type]"})}),searchState.value.query?u$2(S$4,{children:[u$2("span",{className:"flex items-center gap-x-0.5 text-xs text-neutral-500",children:[searchState.value.currentMatchIndex+1,"|",searchState.value.matches.length]}),!!searchState.value.matches.length&&u$2(S$4,{children:[u$2("button",{type:"button",onClick:__name(e2=>{e2.stopPropagation(),navigateSearch("prev")},"onClick"),className:"button rounded w-4 h-4 flex items-center justify-center text-neutral-400 hover:text-neutral-300",children:u$2(Icon,{name:"icon-chevron-right",className:"-rotate-90",size:12})}),u$2("button",{type:"button",onClick:__name(e2=>{e2.stopPropagation(),navigateSearch("next")},"onClick"),className:"button rounded w-4 h-4 flex items-center justify-center text-neutral-400 hover:text-neutral-300",children:u$2(Icon,{name:"icon-chevron-right",className:"rotate-90",size:12})})]}),u$2("button",{type:"button",onClick:__name(e2=>{e2.stopPropagation(),handleOnChangeSearch("")},"onClick"),className:"button rounded w-4 h-4 flex items-center justify-center text-neutral-400 hover:text-neutral-300",children:u$2(Icon,{name:"icon-close",size:12})})]}):!!flattenedNodes.length&&u$2("span",{className:"text-xs text-neutral-500",children:flattenedNodes.length})]})}),u$2("div",{className:"flex-1 overflow-hidden",children:u$2("div",{ref:refContainer,onPointerLeave,className:"tree h-full overflow-auto will-change-transform",children:u$2("div",{className:"relative w-full",style:{height:totalSize},children:virtualItems.map(virtualItem=>{var _a;const node=visibleNodes[virtualItem.index];if(!node)return null;const isSelected=Store.inspectState.value.kind==="focused"&&node.element===Store.inspectState.value.focusedDomElement,isKeyboardSelected=virtualItem.index===selectedIndex;return u$2("div",{className:cn("absolute left-0 w-full overflow-hidden","text-neutral-400 hover:text-neutral-300","bg-transparent hover:bg-[#5f3f9a]/20",(isSelected||isKeyboardSelected)&&"text-neutral-300 bg-[#5f3f9a]/40 hover:bg-[#5f3f9a]/40"),style:{top:virtualItem.start,height:ITEM_HEIGHT},children:u$2("div",{className:"w-full h-full",style:{paddingLeft:`calc(${node.depth} * var(--indentation-size))`},children:u$2(TreeNodeItem,{node,nodeIndex:virtualItem.index,hasChildren:!!((_a=node.children)!=null&&_a.length),isCollapsed:collapsedNodes.has(node.nodeId),handleTreeNodeClick,handleTreeNodeToggle,searchValue})})},node.nodeId)})})})})]})]})},"ComponentsTree"),fadeOutTimers=new WeakMap,trackElementPosition=__name((element,callback)=>{const handleScroll=callback.bind(null,element);return document.addEventListener("scroll",handleScroll,{passive:!0,capture:!0}),()=>{document.removeEventListener("scroll",handleScroll,{capture:!0})}},"trackElementPosition"),flashManager={activeFlashes:new Map,create(container){const existingOverlay=container.querySelector(".react-scan-flash-overlay"),overlay=existingOverlay instanceof HTMLElement?existingOverlay:(()=>{const newOverlay=document.createElement("div");newOverlay.className="react-scan-flash-overlay",container.appendChild(newOverlay);const scrollCleanup=trackElementPosition(container,()=>{container.querySelector(".react-scan-flash-overlay")&&this.create(container)});return this.activeFlashes.set(container,{element:container,overlay:newOverlay,scrollCleanup}),newOverlay})(),existingTimer=fadeOutTimers.get(overlay);existingTimer&&(clearTimeout(existingTimer),fadeOutTimers.delete(overlay)),requestAnimationFrame(()=>{overlay.style.transition="none",overlay.style.opacity="0.9";const timerId=setTimeout(()=>{overlay.style.transition="opacity 150ms ease-out",overlay.style.opacity="0";const cleanupTimer=setTimeout(()=>{overlay.parentNode&&overlay.parentNode.removeChild(overlay);const entry=this.activeFlashes.get(container);entry?.scrollCleanup&&entry.scrollCleanup(),this.activeFlashes.delete(container),fadeOutTimers.delete(overlay)},150);fadeOutTimers.set(overlay,cleanupTimer)},300);fadeOutTimers.set(overlay,timerId)})},cleanup(container){const entry=this.activeFlashes.get(container);if(entry){const existingTimer=fadeOutTimers.get(entry.overlay);existingTimer&&(clearTimeout(existingTimer),fadeOutTimers.delete(entry.overlay)),entry.overlay.parentNode&&entry.overlay.parentNode.removeChild(entry.overlay),entry.scrollCleanup&&entry.scrollCleanup(),this.activeFlashes.delete(container)}},cleanupAll(){for(const[,entry]of this.activeFlashes)this.cleanup(entry.element)}},CopyToClipboard=N$1(({text,children,onCopy,className,iconSize=14})=>{const[isCopied,setIsCopied]=d$4(!1);y$5(()=>{if(isCopied){const timeout2=setTimeout(()=>setIsCopied(!1),600);return()=>{clearTimeout(timeout2)}}},[isCopied]);const copyToClipboard=q$2(e2=>{e2.preventDefault(),e2.stopPropagation(),navigator.clipboard.writeText(text).then(()=>{setIsCopied(!0),onCopy?.(!0,text)},()=>{onCopy?.(!1,text)})},[text,onCopy]),ClipboardIcon=u$2("button",{onClick:copyToClipboard,type:"button",className:cn("z-10","flex items-center justify-center","hover:text-dev-pink-400","transition-colors duration-200 ease-in-out","cursor-pointer",`size-[${iconSize}px]`,className),children:u$2(Icon,{name:`icon-${isCopied?"check":"copy"}`,size:[iconSize],className:cn(isCopied&&"text-green-500")})});return children?children({ClipboardIcon,onClick:copyToClipboard}):ClipboardIcon}),ArrayHeader=__name(({length,expanded,onToggle,isNegative})=>u$2("div",{className:"flex items-center gap-1",children:[u$2("button",{type:"button",onClick:onToggle,className:"flex items-center p-0 opacity-50",children:u$2(Icon,{name:"icon-chevron-right",size:12,className:cn("transition-[color,transform]",isNegative?"text-[#f87171]":"text-[#4ade80]",expanded&&"rotate-90")})}),u$2("span",{children:["Array(",length,")"]})]}),"ArrayHeader"),TreeNode=__name(({value,path,isNegative})=>{const[isExpanded,setIsExpanded]=d$4(!1);if(!(value!==null&&typeof value=="object"&&!(value instanceof Date)))return u$2("div",{className:"flex items-center gap-1",children:[u$2("span",{className:"text-gray-500",children:[path,":"]}),u$2("span",{className:"truncate",children:formatValuePreview(value)})]});const entries=Object.entries(value);return u$2("div",{className:"flex flex-col",children:[u$2("div",{className:"flex items-center gap-1",children:[u$2("button",{type:"button",onClick:__name(()=>setIsExpanded(!isExpanded),"onClick"),className:"flex items-center p-0 opacity-50",children:u$2(Icon,{name:"icon-chevron-right",size:12,className:cn("transition-[color,transform]",isNegative?"text-[#f87171]":"text-[#4ade80]",isExpanded&&"rotate-90")})}),u$2("span",{className:"text-gray-500",children:[path,":"]}),!isExpanded&&u$2("span",{className:"truncate",children:value instanceof Date?formatValuePreview(value):`{${Object.keys(value).join(", ")}}`})]}),isExpanded&&u$2("div",{className:"pl-5 border-l border-[#333] mt-0.5 ml-1 flex flex-col gap-0.5",children:entries.map(([key,val])=>u$2(TreeNode,{value:val,path:key,isNegative},key))})]})},"TreeNode"),DiffValueView=__name(({value,expanded,onToggle,isNegative})=>{const{value:safeValue,error}=safeGetValue(value);return error?u$2("span",{className:"text-gray-500 font-italic",children:error}):safeValue!==null&&typeof safeValue=="object"&&!(safeValue instanceof Promise)?Array.isArray(safeValue)?u$2("div",{className:"flex flex-col gap-1 relative",children:[u$2(ArrayHeader,{length:safeValue.length,expanded,onToggle,isNegative}),expanded&&u$2("div",{className:"pl-2 border-l border-[#333] mt-0.5 ml-1 flex flex-col gap-0.5",children:safeValue.map((item,index)=>u$2(TreeNode,{value:item,path:index.toString(),isNegative},index.toString()))}),u$2(CopyToClipboard,{text:formatForClipboard(safeValue),className:"absolute top-0.5 right-0.5 opacity-0 transition-opacity group-hover:opacity-100 self-end",children:__name(({ClipboardIcon})=>u$2(S$4,{children:ClipboardIcon}),"children")})]}):u$2("div",{className:"flex items-start gap-1 relative",children:[u$2("button",{type:"button",onClick:onToggle,className:cn("flex items-center","p-0 mt-0.5 mr-1","opacity-50"),children:u$2(Icon,{name:"icon-chevron-right",size:12,className:cn("transition-[color,transform]",isNegative?"text-[#f87171]":"text-[#4ade80]",expanded&&"rotate-90")})}),u$2("div",{className:"flex-1",children:expanded?u$2("div",{className:"pl-2 border-l border-[#333] mt-0.5 ml-1 flex flex-col gap-0.5",children:Object.entries(safeValue).map(([key,val])=>u$2(TreeNode,{value:val,path:key,isNegative},key))}):u$2("span",{children:formatValuePreview(safeValue)})}),u$2(CopyToClipboard,{text:formatForClipboard(safeValue),className:"absolute top-0.5 right-0.5 opacity-0 transition-opacity group-hover:opacity-100 self-end",children:__name(({ClipboardIcon})=>u$2(S$4,{children:ClipboardIcon}),"children")})]}):u$2("span",{children:formatValuePreview(safeValue)})},"DiffValueView"),CHANGES_QUEUE_INTERVAL=50,getContextChangesValue=__name(discriminated=>{switch(discriminated.kind){case"initialized":return discriminated.changes.currentValue;case"partially-initialized":return discriminated.value}},"getContextChangesValue"),processChanges=__name((changes,targetMap)=>{for(const change of changes){const existing=targetMap.get(change.name);if(existing){targetMap.set(existing.name,{count:existing.count+1,currentValue:change.value,id:existing.name,lastUpdated:Date.now(),name:existing.name,previousValue:change.prevValue});continue}targetMap.set(change.name,{count:1,currentValue:change.value,id:change.name,lastUpdated:Date.now(),name:change.name,previousValue:change.prevValue})}},"processChanges"),processContextChanges=__name((contextChanges,aggregatedChanges)=>{for(const change of contextChanges){const existing=aggregatedChanges.contextChanges.get(change.contextType);if(existing){if(isEqual(getContextChangesValue(existing),change.value))continue;if(existing.kind==="partially-initialized"){aggregatedChanges.contextChanges.set(change.contextType,{kind:"initialized",changes:{count:1,currentValue:change.value,id:change.contextType.toString(),lastUpdated:Date.now(),name:change.name,previousValue:existing.value}});continue}aggregatedChanges.contextChanges.set(change.contextType,{kind:"initialized",changes:{count:existing.changes.count+1,currentValue:change.value,id:change.contextType.toString(),lastUpdated:Date.now(),name:change.name,previousValue:existing.changes.currentValue}});continue}aggregatedChanges.contextChanges.set(change.contextType,{kind:"partially-initialized",id:change.contextType.toString(),lastUpdated:Date.now(),name:change.name,value:change.value})}},"processContextChanges"),collapseQueue=__name(queue=>{const localAggregatedChanges={contextChanges:new Map,propsChanges:new Map,stateChanges:new Map};return queue.forEach(changes=>{processContextChanges(changes.contextChanges,localAggregatedChanges),processChanges(changes.stateChanges,localAggregatedChanges.stateChanges),processChanges(changes.propsChanges,localAggregatedChanges.propsChanges)}),localAggregatedChanges},"collapseQueue"),mergeSimpleChanges=__name((existingChanges,incomingChanges)=>{const mergedChanges=new Map;return existingChanges.forEach((value,key)=>{mergedChanges.set(key,value)}),incomingChanges.forEach((incomingChange,key)=>{const existing=mergedChanges.get(key);if(!existing){mergedChanges.set(key,incomingChange);return}mergedChanges.set(key,{count:existing.count+incomingChange.count,currentValue:incomingChange.currentValue,id:incomingChange.id,lastUpdated:incomingChange.lastUpdated,name:incomingChange.name,previousValue:incomingChange.previousValue})}),mergedChanges},"mergeSimpleChanges"),mergeContextChanges=__name((existing,incoming)=>{const contextChanges=new Map;return existing.contextChanges.forEach((value,key)=>{contextChanges.set(key,value)}),incoming.contextChanges.forEach((incomingChange,key)=>{const existingChange=contextChanges.get(key);if(!existingChange){contextChanges.set(key,incomingChange);return}if(getContextChangesValue(incomingChange)!==getContextChangesValue(existingChange))switch(existingChange.kind){case"initialized":switch(incomingChange.kind){case"initialized":{contextChanges.set(key,{kind:"initialized",changes:{...incomingChange.changes,count:incomingChange.changes.count+existingChange.changes.count+1,currentValue:incomingChange.changes.currentValue,previousValue:incomingChange.changes.previousValue}});return}case"partially-initialized":contextChanges.set(key,{kind:"initialized",changes:{count:existingChange.changes.count+1,currentValue:incomingChange.value,id:incomingChange.id,lastUpdated:incomingChange.lastUpdated,name:incomingChange.name,previousValue:existingChange.changes.currentValue}});return}case"partially-initialized":switch(incomingChange.kind){case"initialized":contextChanges.set(key,{kind:"initialized",changes:{count:incomingChange.changes.count+1,currentValue:incomingChange.changes.currentValue,id:incomingChange.changes.id,lastUpdated:incomingChange.changes.lastUpdated,name:incomingChange.changes.name,previousValue:existingChange.value}});return;case"partially-initialized":contextChanges.set(key,{kind:"initialized",changes:{count:1,currentValue:incomingChange.value,id:incomingChange.id,lastUpdated:incomingChange.lastUpdated,name:incomingChange.name,previousValue:existingChange.value}});return}}}),contextChanges},"mergeContextChanges"),mergeChanges=__name((existing,incoming)=>({contextChanges:mergeContextChanges(existing,incoming),propsChanges:mergeSimpleChanges(existing.propsChanges,incoming.propsChanges),stateChanges:mergeSimpleChanges(existing.stateChanges,incoming.stateChanges)}),"mergeChanges"),calculateTotalChanges=__name(changes=>Array.from(changes.propsChanges.values()).reduce((acc,change)=>acc+change.count,0)+Array.from(changes.stateChanges.values()).reduce((acc,change)=>acc+change.count,0)+Array.from(changes.contextChanges.values()).filter(change=>change.kind==="initialized").reduce((acc,change)=>acc+change.changes.count,0),"calculateTotalChanges"),useInspectedFiberChangeStore=__name(opts=>{const pendingChanges=A$3({queue:[]}),[aggregatedChanges,setAggregatedChanges]=d$4({propsChanges:new Map,stateChanges:new Map,contextChanges:new Map}),fiber=Store.inspectState.value.kind==="focused"?Store.inspectState.value.fiber:null,fiberId=fiber?z$2(fiber):null;return y$5(()=>{const interval=setInterval(()=>{pendingChanges.current.queue.length!==0&&(setAggregatedChanges(prevAggregatedChanges=>{var _a;const merged=mergeChanges(prevAggregatedChanges,collapseQueue(pendingChanges.current.queue)),prevTotal=calculateTotalChanges(prevAggregatedChanges),changeCount=calculateTotalChanges(merged)-prevTotal;return(_a=opts?.onChangeUpdate)==null||_a.call(opts,changeCount),merged}),pendingChanges.current.queue=[])},CHANGES_QUEUE_INTERVAL);return()=>{clearInterval(interval)}},[fiber]),y$5(()=>{if(!fiberId)return;const listener=__name(change=>{var _a;(_a=pendingChanges.current)==null||_a.queue.push(change)},"listener");let listeners=Store.changesListeners.get(fiberId);return listeners||(listeners=[],Store.changesListeners.set(fiberId,listeners)),listeners.push(listener),()=>{var _a,_b;setAggregatedChanges({propsChanges:new Map,stateChanges:new Map,contextChanges:new Map}),pendingChanges.current.queue=[],Store.changesListeners.set(fiberId,(_b=(_a=Store.changesListeners.get(fiberId))==null?void 0:_a.filter(l2=>l2!==listener))!=null?_b:[])}},[fiberId]),y$5(()=>()=>{setAggregatedChanges({propsChanges:new Map,stateChanges:new Map,contextChanges:new Map}),pendingChanges.current.queue=[]},[fiberId]),aggregatedChanges},"useInspectedFiberChangeStore"),WhatChanged=N$1(()=>{const[isExpanded,setIsExpanded]=d$4(!0),aggregatedChanges=useInspectedFiberChangeStore(),[hasInitialized,setHasInitialized]=d$4(!1),hasAnyChanges=calculateTotalChanges(aggregatedChanges)>0;y$5(()=>{if(!hasInitialized&&hasAnyChanges){const timer2=setTimeout(()=>{setHasInitialized(!0),requestAnimationFrame(()=>{setIsExpanded(!0)})},0);return()=>clearTimeout(timer2)}},[hasInitialized,hasAnyChanges]);const initializedContextChanges=new Map(Array.from(aggregatedChanges.contextChanges.entries()).filter(([,value])=>value.kind==="initialized").map(([key,value])=>[key,value.kind==="partially-initialized"?null:value.changes])),fiber=Store.inspectState.value.kind==="focused"?Store.inspectState.value.fiber:null;if(fiber)return u$2(S$4,{children:[u$2(WhatsChangedHeader,{}),u$2("div",{className:"overflow-hidden h-full flex flex-col gap-y-2",children:[u$2("div",{className:"flex flex-col gap-2 px-3 pt-2",children:[u$2("span",{className:"text-sm font-medium text-[#888]",children:["Why did ",u$2("span",{className:"text-[#A855F7]",children:we$1(fiber)})," render?"]}),!hasAnyChanges&&u$2("div",{className:"text-sm text-[#737373] bg-[#1E1E1E] rounded-md p-4 flex flex-col gap-4",children:[u$2("div",{children:"No changes detected since selecting"}),u$2("div",{children:"The props, state, and context changes within your component will be reported here"})]})]}),u$2("div",{className:cn("flex flex-col gap-y-2 pl-3 relative overflow-y-auto h-full"),children:[u$2(Section,{changes:aggregatedChanges.propsChanges,title:"Changed Props",isExpanded}),u$2(Section,{renderName:__name(name=>{var _a;return renderStateName(name,(_a=we$1(P$3(fiber)))!=null?_a:"Unknown Component")},"renderName"),changes:aggregatedChanges.stateChanges,title:"Changed State",isExpanded}),u$2(Section,{changes:initializedContextChanges,title:"Changed Context",isExpanded})]})]})]})}),renderStateName=__name((key,componentName)=>{if(Number.isNaN(Number(key)))return key;const n2=Number.parseInt(key);return u$2("span",{className:"truncate",children:[u$2("span",{className:"text-white",children:[n2,__name(num=>{const lastDigit=num%10,lastTwoDigits=num%100;if(lastTwoDigits>=11&&lastTwoDigits<=13)return"th";switch(lastDigit){case 1:return"st";case 2:return"nd";case 3:return"rd";default:return"th"}},"getOrdinalSuffix")(n2)," hook"," "]}),u$2("span",{style:{color:"#666"},children:["called in ",u$2("i",{className:"text-[#A855F7] truncate",children:componentName})]})]})},"renderStateName"),WhatsChangedHeader=N$1(()=>{const refProps=A$3(null),refState=A$3(null),refContext=A$3(null),refStats=A$3({isPropsChanged:!1,isStateChanged:!1,isContextChanged:!1});return y$5(()=>{const flash=throttle(()=>{var _a,_b,_c;const flashElements=[];((_a=refProps.current)==null?void 0:_a.dataset.flash)==="true"&&flashElements.push(refProps.current),((_b=refState.current)==null?void 0:_b.dataset.flash)==="true"&&flashElements.push(refState.current),((_c=refContext.current)==null?void 0:_c.dataset.flash)==="true"&&flashElements.push(refContext.current);for(const element of flashElements)element.classList.remove("count-flash-white"),element.offsetWidth,element.classList.add("count-flash-white")},400);return timelineState.subscribe(state=>{var _a,_b,_c,_d,_e2,_f,_g,_h,_i;if(!refProps.current||!refState.current||!refContext.current)return;const{currentIndex,updates}=state,currentUpdate=updates[currentIndex];!currentUpdate||currentIndex===0||(flash(),refStats.current={isPropsChanged:((_c=(_b=(_a=currentUpdate.props)==null?void 0:_a.changes)==null?void 0:_b.size)!=null?_c:0)>0,isStateChanged:((_f=(_e2=(_d=currentUpdate.state)==null?void 0:_d.changes)==null?void 0:_e2.size)!=null?_f:0)>0,isContextChanged:((_i=(_h=(_g=currentUpdate.context)==null?void 0:_g.changes)==null?void 0:_h.size)!=null?_i:0)>0},refProps.current.dataset.flash!=="true"&&(refProps.current.dataset.flash=refStats.current.isPropsChanged.toString()),refState.current.dataset.flash!=="true"&&(refState.current.dataset.flash=refStats.current.isStateChanged.toString()),refContext.current.dataset.flash!=="true"&&(refContext.current.dataset.flash=refStats.current.isContextChanged.toString()))})},[]),u$2("button",{type:"button",className:cn("react-section-header","overflow-hidden","max-h-0","transition-[max-height]"),children:u$2("div",{className:cn("flex-1 react-scan-expandable"),children:u$2("div",{className:"overflow-hidden",children:u$2("div",{className:"flex items-center whitespace-nowrap",children:[u$2("div",{className:"flex items-center gap-x-2",children:"What changed?"}),u$2("div",{className:cn("ml-auto","change-scope","transition-opacity duration-300 delay-150"),children:[u$2("div",{ref:refProps,children:"props"}),u$2("div",{ref:refState,children:"state"}),u$2("div",{ref:refContext,children:"context"})]})]})})})})}),identity=__name(x2=>x2,"identity"),Section=N$1(({title,changes,renderName=identity})=>{const[expandedFns,setExpandedFns]=d$4(new Set),[expandedEntries,setExpandedEntries]=d$4(new Set),entries=Array.from(changes.entries());return changes.size===0?null:u$2("div",{children:[u$2("div",{className:"text-xs text-[#888] mb-1.5",children:title}),u$2("div",{className:"flex flex-col gap-2",children:entries.map(([entryKey,change])=>{const isEntryExpanded=expandedEntries.has(String(entryKey)),{value:prevValue,error:prevError}=safeGetValue(change.previousValue),{value:currValue,error:currError}=safeGetValue(change.currentValue),diff=getObjectDiff(prevValue,currValue);return u$2("div",{children:[u$2("button",{onClick:__name(()=>{setExpandedEntries(prev=>{const next=new Set(prev);return next.has(String(entryKey))?next.delete(String(entryKey)):next.add(String(entryKey)),next})},"onClick"),className:"flex items-center gap-2 w-full bg-transparent border-none p-0 cursor-pointer text-white text-xs",children:u$2("div",{className:"flex items-center gap-1.5 flex-1",children:[u$2(Icon,{name:"icon-chevron-right",size:12,className:cn("text-[#666] transition-transform duration-200 ease-[cubic-bezier(0.25,0.1,0.25,1)]",{"rotate-90":isEntryExpanded})}),u$2("div",{className:"whitespace-pre-wrap break-words text-left font-medium flex items-center gap-x-1.5",children:[renderName(change.name),u$2(CountBadge,{count:change.count,isFunction:typeof change.currentValue=="function",showWarning:diff.changes.length===0,forceFlash:!0})]})]})}),u$2("div",{className:cn("react-scan-expandable",{"react-scan-expanded":isEntryExpanded}),children:u$2("div",{className:"pl-3 text-xs font-mono border-l-1 border-[#333]",children:u$2("div",{className:"flex flex-col gap-0.5",children:prevError||currError?u$2(AccessError,{currError,prevError}):diff.changes.length>0?u$2(DiffChange,{change,diff,expandedFns,renderName,setExpandedFns,title}):u$2(ReferenceOnlyChange,{currValue,entryKey,expandedFns,prevValue,setExpandedFns})})})})]},entryKey)})})]})}),AccessError=__name(({prevError,currError})=>u$2(S$4,{children:[prevError&&u$2("div",{className:"text-[#f87171] bg-[#2a1515] pr-1.5 py-[3px] rounded italic",children:prevError}),currError&&u$2("div",{className:"text-[#4ade80] bg-[#1a2a1a] pr-1.5 py-[3px] rounded italic mt-0.5",children:currError})]}),"AccessError"),DiffChange=__name(({diff,title,renderName,change,expandedFns,setExpandedFns})=>diff.changes.map((diffChange,i2)=>{const{value:prevDiffValue,error:prevDiffError}=safeGetValue(diffChange.prevValue),{value:currDiffValue,error:currDiffError}=safeGetValue(diffChange.currentValue),isFunction=typeof prevDiffValue=="function"||typeof currDiffValue=="function";let path;return title==="Props"&&(path=diffChange.path.length>0?`${renderName(String(change.name))}.${formatPath(diffChange.path)}`:void 0),title==="State"&&diffChange.path.length>0&&(path=`state.${formatPath(diffChange.path)}`),path||(path=formatPath(diffChange.path)),u$2("div",{className:cn("flex flex-col gap-y-1",i2<diff.changes.length-1&&"mb-4"),children:[path&&u$2("div",{className:"text-[#666] text-[10px]",children:path}),u$2("button",{type:"button",className:cn("group","flex items-start","py-[3px] px-1.5","text-left text-[#f87171] bg-[#2a1515]","rounded","overflow-hidden break-all",isFunction&&"cursor-pointer"),onClick:isFunction?()=>{const fnKey=`${formatPath(diffChange.path)}-prev`;setExpandedFns(prev=>{const next=new Set(prev);return next.has(fnKey)?next.delete(fnKey):next.add(fnKey),next})}:void 0,children:[u$2("span",{className:"w-3 flex items-center justify-center opacity-50",children:"-"}),u$2("span",{className:"flex-1 whitespace-nowrap font-mono",children:prevDiffError?u$2("span",{className:"italic text-[#f87171]",children:prevDiffError}):isFunction?u$2("div",{className:"flex gap-1 items-start flex-col",children:[u$2("div",{className:"flex gap-1 items-start w-full",children:[u$2("span",{className:"flex-1 max-h-40",children:formatFunctionPreview(prevDiffValue,expandedFns.has(`${formatPath(diffChange.path)}-prev`))}),typeof prevDiffValue=="function"&&u$2(CopyToClipboard,{text:prevDiffValue.toString(),className:"opacity-0 transition-opacity group-hover:opacity-100",children:__name(({ClipboardIcon})=>u$2(S$4,{children:ClipboardIcon}),"children")})]}),prevDiffValue?.toString()===currDiffValue?.toString()&&u$2("div",{className:"text-[10px] text-[#666] italic",children:"Function reference changed"})]}):u$2(DiffValueView,{value:prevDiffValue,expanded:expandedFns.has(`${formatPath(diffChange.path)}-prev`),onToggle:__name(()=>{const key=`${formatPath(diffChange.path)}-prev`;setExpandedFns(prev=>{const next=new Set(prev);return next.has(key)?next.delete(key):next.add(key),next})},"onToggle"),isNegative:!0})})]}),u$2("button",{type:"button",className:cn("group","flex items-start","py-[3px] px-1.5","text-left text-[#4ade80] bg-[#1a2a1a]","rounded","overflow-hidden break-all",isFunction&&"cursor-pointer"),onClick:isFunction?()=>{const fnKey=`${formatPath(diffChange.path)}-current`;setExpandedFns(prev=>{const next=new Set(prev);return next.has(fnKey)?next.delete(fnKey):next.add(fnKey),next})}:void 0,children:[u$2("span",{className:"w-3 flex items-center justify-center opacity-50",children:"+"}),u$2("span",{className:"flex-1 whitespace-pre-wrap font-mono",children:currDiffError?u$2("span",{className:"italic text-[#4ade80]",children:currDiffError}):isFunction?u$2("div",{className:"flex gap-1 items-start flex-col",children:[u$2("div",{className:"flex gap-1 items-start w-full",children:[u$2("span",{className:"flex-1",children:formatFunctionPreview(currDiffValue,expandedFns.has(`${formatPath(diffChange.path)}-current`))}),typeof currDiffValue=="function"&&u$2(CopyToClipboard,{text:currDiffValue.toString(),className:"opacity-0 transition-opacity group-hover:opacity-100",children:__name(({ClipboardIcon})=>u$2(S$4,{children:ClipboardIcon}),"children")})]}),prevDiffValue?.toString()===currDiffValue?.toString()&&u$2("div",{className:"text-[10px] text-[#666] italic",children:"Function reference changed"})]}):u$2(DiffValueView,{value:currDiffValue,expanded:expandedFns.has(`${formatPath(diffChange.path)}-current`),onToggle:__name(()=>{const key=`${formatPath(diffChange.path)}-current`;setExpandedFns(prev=>{const next=new Set(prev);return next.has(key)?next.delete(key):next.add(key),next})},"onToggle"),isNegative:!1})})]})]},`${path}-${change.name}-${i2}`)}),"DiffChange"),ReferenceOnlyChange=__name(({prevValue,currValue,entryKey,expandedFns,setExpandedFns})=>u$2(S$4,{children:[u$2("div",{className:"group flex gap-0.5 items-start text-[#f87171] bg-[#2a1515] py-[3px] px-1.5 rounded",children:[u$2("span",{className:"w-3 flex items-center justify-center opacity-50",children:"-"}),u$2("span",{className:"flex-1 overflow-hidden whitespace-pre-wrap font-mono",children:u$2(DiffValueView,{value:prevValue,expanded:expandedFns.has(`${String(entryKey)}-prev`),onToggle:__name(()=>{const key=`${String(entryKey)}-prev`;setExpandedFns(prev=>{const next=new Set(prev);return next.has(key)?next.delete(key):next.add(key),next})},"onToggle"),isNegative:!0})})]}),u$2("div",{className:"group flex gap-0.5 items-start text-[#4ade80] bg-[#1a2a1a] py-[3px] px-1.5 rounded mt-0.5",children:[u$2("span",{className:"w-3 flex items-center justify-center opacity-50",children:"+"}),u$2("span",{className:"flex-1 overflow-hidden whitespace-pre-wrap font-mono",children:u$2(DiffValueView,{value:currValue,expanded:expandedFns.has(`${String(entryKey)}-current`),onToggle:__name(()=>{const key=`${String(entryKey)}-current`;setExpandedFns(prev=>{const next=new Set(prev);return next.has(key)?next.delete(key):next.add(key),next})},"onToggle"),isNegative:!1})})]}),typeof currValue=="object"&&currValue!==null&&u$2("div",{className:"text-[#666] text-[10px] italic mt-1 flex items-center gap-x-1",children:[u$2(Icon,{name:"icon-triangle-alert",className:"text-yellow-500 mb-px",size:14}),u$2("span",{children:"Reference changed but objects are structurally the same"})]})]}),"ReferenceOnlyChange"),CountBadge=__name(({count,forceFlash,isFunction,showWarning})=>{const refIsFirstRender=A$3(!0),refBadge=A$3(null),refPrevCount=A$3(count);return y$5(()=>{const element=refBadge.current;!element||refPrevCount.current===count||(element.classList.remove("count-flash"),element.offsetWidth,element.classList.add("count-flash"),refPrevCount.current=count)},[count]),y$5(()=>{if(refIsFirstRender.current){refIsFirstRender.current=!1;return}if(forceFlash){let timer2=setTimeout(()=>{var _a;(_a=refBadge.current)==null||_a.classList.add("count-flash-white"),timer2=setTimeout(()=>{var _a2;(_a2=refBadge.current)==null||_a2.classList.remove("count-flash-white")},300)},500);return()=>{clearTimeout(timer2)}}},[forceFlash]),u$2("div",{ref:refBadge,className:"count-badge",children:[showWarning&&u$2(Icon,{name:"icon-triangle-alert",className:"text-yellow-500 mb-px",size:14}),isFunction&&u$2(Icon,{name:"icon-function",className:"text-[#A855F7] mb-px",size:14}),"x",count]})},"CountBadge"),globalInspectorState={lastRendered:new Map,expandedPaths:new Set,cleanup:__name(()=>{globalInspectorState.lastRendered.clear(),globalInspectorState.expandedPaths.clear(),flashManager.cleanupAll(),resetTracking(),timelineActions.reset()},"cleanup")},InspectorErrorBoundary=class extends C$5{static{__name(this,"InspectorErrorBoundary")}constructor(){super(...arguments),__publicField(this,"state",{hasError:!1,error:null}),__publicField(this,"handleReset",()=>{this.setState({hasError:!1,error:null}),globalInspectorState.cleanup()})}static getDerivedStateFromError(e2){return{hasError:!0,error:e2}}render(){var _a;return this.state.hasError?u$2("div",{className:"p-4 bg-red-950/50 h-screen backdrop-blur-sm",children:[u$2("div",{className:"flex items-center gap-2 mb-3 text-red-400 font-medium",children:[u$2(Icon,{name:"icon-flame",className:"text-red-500",size:16}),"Something went wrong in the inspector"]}),u$2("div",{className:"p-3 bg-black/40 rounded font-mono text-xs text-red-300 mb-4 break-words",children:((_a=this.state.error)==null?void 0:_a.message)||JSON.stringify(this.state.error)}),u$2("button",{type:"button",onClick:this.handleReset,className:"px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-md text-sm font-medium transition-colors flex items-center justify-center gap-2",children:"Reset Inspector"})]}):this.props.children}},inspectorContainerClassName=g$4(()=>cn("react-scan-inspector","flex-1","opacity-0","overflow-y-auto overflow-x-hidden","transition-opacity delay-0","pointer-events-none",!signalIsSettingsOpen.value&&"opacity-100 delay-300 pointer-events-auto")),Inspector=constant(()=>{const refLastInspectedFiber=A$3(null),processUpdate=__name(fiber=>{if(!fiber)return;refLastInspectedFiber.current=fiber;const{data:inspectorData,shouldUpdate}=collectInspectorData(fiber);if(shouldUpdate){const update={timestamp:Date.now(),fiberInfo:extractMinimalFiberInfo(fiber),props:inspectorData.fiberProps,state:inspectorData.fiberState,context:inspectorData.fiberContext,stateNames:getStateNames(fiber)};timelineActions.addUpdate(update,fiber)}},"processUpdate");return useSignalEffect(()=>{const state=Store.inspectState.value;o$3(()=>{var _a;if(state.kind!=="focused"||!state.focusedDomElement){refLastInspectedFiber.current=null,globalInspectorState.cleanup();return}state.kind==="focused"&&(signalIsSettingsOpen.value=!1);const{parentCompositeFiber}=getCompositeFiberFromElement(state.focusedDomElement,state.fiber);if(!parentCompositeFiber){Store.inspectState.value={kind:"inspect-off"},signalWidgetViews.value={view:"none"};return}((_a=refLastInspectedFiber.current)==null?void 0:_a.type)!==parentCompositeFiber.type&&(refLastInspectedFiber.current=parentCompositeFiber,globalInspectorState.cleanup(),processUpdate(parentCompositeFiber))})}),useSignalEffect(()=>{inspectorUpdateSignal.value,o$3(()=>{const inspectState=Store.inspectState.value;if(inspectState.kind!=="focused"||!inspectState.focusedDomElement){refLastInspectedFiber.current=null,globalInspectorState.cleanup();return}const{parentCompositeFiber}=getCompositeFiberFromElement(inspectState.focusedDomElement,inspectState.fiber);if(!parentCompositeFiber){Store.inspectState.value={kind:"inspect-off"},signalWidgetViews.value={view:"none"};return}processUpdate(parentCompositeFiber),inspectState.focusedDomElement.isConnected||(refLastInspectedFiber.current=null,globalInspectorState.cleanup(),Store.inspectState.value={kind:"inspecting",hoveredDomElement:null})})}),y$5(()=>()=>{globalInspectorState.cleanup()},[]),u$2(InspectorErrorBoundary,{children:u$2("div",{className:inspectorContainerClassName,children:u$2("div",{className:"w-full h-full",children:u$2(WhatChanged,{})})})})}),ViewInspector=constant(()=>Store.inspectState.value.kind!=="focused"?null:u$2(InspectorErrorBoundary,{children:[u$2(Inspector,{}),u$2(ComponentsTree,{})]})),getFiberFromElement=__name(element=>{var _a,_b,_c,_d;if("__REACT_DEVTOOLS_GLOBAL_HOOK__"in window){const hook=window.__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!hook?.renderers)return null;for(const[,renderer]of Array.from(hook.renderers))try{const fiber=(_a=renderer.findFiberByHostInstance)==null?void 0:_a.call(renderer,element);if(fiber)return fiber}catch{}}if("_reactRootContainer"in element){const rootContainer2=element._reactRootContainer;return(_d=(_c=(_b=rootContainer2?._internalRoot)==null?void 0:_b.current)==null?void 0:_c.child)!=null?_d:null}for(const key in element)if(key.startsWith("__reactInternalInstance$")||key.startsWith("__reactFiber"))return element[key];return null},"getFiberFromElement"),getFirstStateNode=__name(fiber=>{let current=fiber;for(;current;){if(current.stateNode instanceof Element)return current.stateNode;if(!current.child)break;current=current.child}for(;current;){if(current.stateNode instanceof Element)return current.stateNode;if(!current.return)break;current=current.return}return null},"getFirstStateNode"),getNearestFiberFromElement=__name(element=>{if(!element)return null;try{const fiber=getFiberFromElement(element);if(!fiber)return null;const res=getParentCompositeFiber(fiber);return res?res[0]:null}catch{return null}},"getNearestFiberFromElement"),getParentCompositeFiber=__name(fiber=>{let current=fiber,prevHost=null;for(;current;){if(ve$1(current))return[current,prevHost];x$7(current)&&!prevHost&&(prevHost=current),current=current.return}return null},"getParentCompositeFiber"),isFiberInTree=__name((fiber,root)=>!!j$5(root,searchFiber=>searchFiber===fiber),"isFiberInTree"),getAssociatedFiberRect=__name(async element=>{const associatedFiber=getNearestFiberFromElement(element);if(!associatedFiber)return null;const stateNode=getFirstStateNode(associatedFiber);return stateNode?await new Promise(resolve=>{const observer=new IntersectionObserver(entries=>{var _a,_b;observer.disconnect(),resolve((_b=(_a=entries[0])==null?void 0:_a.boundingClientRect)!=null?_b:null)});observer.observe(stateNode)}):null},"getAssociatedFiberRect"),getCompositeComponentFromElement=__name(element=>{const associatedFiber=getNearestFiberFromElement(element);if(!associatedFiber)return{};if(!getFirstStateNode(associatedFiber))return{};const parentCompositeFiberInfo=getParentCompositeFiber(associatedFiber);if(!parentCompositeFiberInfo)return{};const[parentCompositeFiber]=parentCompositeFiberInfo;return{parentCompositeFiber}},"getCompositeComponentFromElement"),getCompositeFiberFromElement=__name((element,knownFiber)=>{var _a,_b,_c,_d;if(!element.isConnected)return{};let fiber=knownFiber??getNearestFiberFromElement(element);if(!fiber)return{};let curr=fiber,rootFiber=null,currentRootFiber=null;for(;curr;){if(!curr.stateNode){curr=curr.return;continue}if((_a=ReactScanInternals.instrumentation)!=null&&_a.fiberRoots.has(curr.stateNode)){rootFiber=curr,currentRootFiber=curr.stateNode.current;break}curr=curr.return}if(!rootFiber||!currentRootFiber)return{};if(fiber=isFiberInTree(fiber,currentRootFiber)?fiber:(_b=fiber.alternate)!=null?_b:fiber,!fiber)return{};if(!getFirstStateNode(fiber))return{};const parentCompositeFiber=(_c=getParentCompositeFiber(fiber))==null?void 0:_c[0];return parentCompositeFiber?{parentCompositeFiber:isFiberInTree(parentCompositeFiber,currentRootFiber)?parentCompositeFiber:(_d=parentCompositeFiber.alternate)!=null?_d:parentCompositeFiber}:{}},"getCompositeFiberFromElement"),getChangedPropsDetailed=__name(fiber=>{var _a,_b,_c;const currentProps=(_a=fiber.memoizedProps)!=null?_a:{},previousProps=(_c=(_b=fiber.alternate)==null?void 0:_b.memoizedProps)!=null?_c:{},changes=[];for(const key in currentProps){if(key==="children")continue;const currentValue=currentProps[key],prevValue=previousProps[key];isEqual(currentValue,prevValue)||changes.push({name:key,value:currentValue,prevValue,type:1})}return changes},"getChangedPropsDetailed"),nonVisualTags=new Set(["HTML","HEAD","META","TITLE","BASE","SCRIPT","SCRIPT","STYLE","LINK","NOSCRIPT","SOURCE","TRACK","EMBED","OBJECT","PARAM","TEMPLATE","PORTAL","SLOT","AREA","XML","DOCTYPE","COMMENT"]),findComponentDOMNode=__name((fiber,excludeNonVisualTags=!0)=>{if(fiber.stateNode&&"nodeType"in fiber.stateNode){const element=fiber.stateNode;return excludeNonVisualTags&&element.tagName&&nonVisualTags.has(element.tagName.toLowerCase())?null:element}let child=fiber.child;for(;child;){const result=findComponentDOMNode(child,excludeNonVisualTags);if(result)return result;child=child.sibling}return null},"findComponentDOMNode"),getInspectableElements=__name((root=document.body)=>{const result=[],findInspectableFiber=__name(element=>{if(!element)return null;const{parentCompositeFiber}=getCompositeComponentFromElement(element);return parentCompositeFiber&&findComponentDOMNode(parentCompositeFiber)===element?element:null},"findInspectableFiber"),traverse=__name((element,depth=0)=>{var _a;const inspectable=findInspectableFiber(element);if(inspectable){const{parentCompositeFiber}=getCompositeComponentFromElement(inspectable);if(!parentCompositeFiber)return;result.push({element:inspectable,depth,name:(_a=we$1(parentCompositeFiber.type))!=null?_a:"Unknown",fiber:parentCompositeFiber})}for(const child of Array.from(element.children))traverse(child,inspectable?depth+1:depth)},"traverse");return traverse(root),result},"getInspectableElements"),formatForClipboard=__name(value=>{try{if(value===null)return"null";if(value===void 0)return"undefined";if(isPromise(value))return"Promise";if(typeof value=="function"){const fnStr=value.toString();try{return fnStr.replace(/\s+/g," ").replace(/{\s+/g,`{
  `).replace(/;\s+/g,`;
  `).replace(/}\s*$/g,`
}`).replace(/\(\s+/g,"(").replace(/\s+\)/g,")").replace(/,\s+/g,", ")}catch{return fnStr}}switch(!0){case value instanceof Date:return value.toISOString();case value instanceof RegExp:return value.toString();case value instanceof Error:return`${value.name}: ${value.message}`;case value instanceof Map:return JSON.stringify(Array.from(value.entries()),null,2);case value instanceof Set:return JSON.stringify(Array.from(value),null,2);case value instanceof DataView:return JSON.stringify(Array.from(new Uint8Array(value.buffer)),null,2);case value instanceof ArrayBuffer:return JSON.stringify(Array.from(new Uint8Array(value)),null,2);case(ArrayBuffer.isView(value)&&"length"in value):return JSON.stringify(Array.from(value),null,2);case Array.isArray(value):return JSON.stringify(value,null,2);case typeof value=="object":return JSON.stringify(value,null,2);default:return String(value)}}catch{return String(value)}},"formatForClipboard"),areFunctionsEqual=__name((prev,current)=>{try{return typeof prev!="function"||typeof current!="function"?!1:prev.toString()===current.toString()}catch{return!1}},"areFunctionsEqual"),getObjectDiff=__name((prev,current,path=[],seen=new WeakSet)=>{if(prev===current)return{type:"primitive",changes:[],hasDeepChanges:!1};if(typeof prev=="function"&&typeof current=="function"){const isSameFunction=areFunctionsEqual(prev,current);return{type:"primitive",changes:[{path,prevValue:prev,currentValue:current,sameFunction:isSameFunction}],hasDeepChanges:!isSameFunction}}if(prev===null||current===null||prev===void 0||current===void 0||typeof prev!="object"||typeof current!="object")return{type:"primitive",changes:[{path,prevValue:prev,currentValue:current}],hasDeepChanges:!0};if(seen.has(prev)||seen.has(current))return{type:"object",changes:[{path,prevValue:"[Circular]",currentValue:"[Circular]"}],hasDeepChanges:!1};seen.add(prev),seen.add(current);const prevObj=prev,currentObj=current,allKeys=new Set([...Object.keys(prevObj),...Object.keys(currentObj)]),changes=[];let hasDeepChanges=!1;for(const key of allKeys){const prevValue=prevObj[key],currentValue=currentObj[key];if(prevValue!==currentValue)if(typeof prevValue=="object"&&typeof currentValue=="object"&&prevValue!==null&&currentValue!==null){const nestedDiff=getObjectDiff(prevValue,currentValue,[...path,key],seen);changes.push(...nestedDiff.changes),nestedDiff.hasDeepChanges&&(hasDeepChanges=!0)}else changes.push({path:[...path,key],prevValue,currentValue}),hasDeepChanges=!0}return{type:"object",changes,hasDeepChanges}},"getObjectDiff"),formatPath=__name(path=>path.length===0?"":path.reduce((acc,segment,i2)=>/^\d+$/.test(segment)?`${acc}[${segment}]`:i2===0?segment:`${acc}.${segment}`,""),"formatPath");function hackyJsFormatter(code){const normalizedCode=code.replace(/\s+/g," ").trim(),rawTokens=[];let current="";for(let i2=0;i2<normalizedCode.length;i2++){const c2=normalizedCode[i2];if(c2==="="&&normalizedCode[i2+1]===">"){current.trim()&&rawTokens.push(current.trim()),rawTokens.push("=>"),current="",i2++;continue}/[(){}[\];,<>:\?!]/.test(c2)?(current.trim()&&rawTokens.push(current.trim()),rawTokens.push(c2),current=""):/\s/.test(c2)?(current.trim()&&rawTokens.push(current.trim()),current=""):current+=c2}current.trim()&&rawTokens.push(current.trim());const merged=[];for(let i2=0;i2<rawTokens.length;i2++){const t2=rawTokens[i2],n2=rawTokens[i2+1];t2==="("&&n2===")"||t2==="["&&n2==="]"||t2==="{"&&n2==="}"||t2==="<"&&n2===">"?(merged.push(t2+n2),i2++):merged.push(t2)}const arrowParamSet=new Set,genericSet=new Set;function findMatchingPair(openTok,closeTok,startIndex){let depth=0;for(let j2=startIndex;j2<merged.length;j2++){const token=merged[j2];if(token===openTok)depth++;else if(token===closeTok&&(depth--,depth===0))return j2}return-1}__name(findMatchingPair,"findMatchingPair");for(let i2=0;i2<merged.length;i2++)if(merged[i2]==="("){const closeIndex=findMatchingPair("(",")",i2);if(closeIndex!==-1&&merged[closeIndex+1]==="=>")for(let k2=i2;k2<=closeIndex;k2++)arrowParamSet.add(k2)}for(let i2=1;i2<merged.length;i2++){const prev=merged[i2-1],t2=merged[i2];if(/^[a-zA-Z0-9_$]+$/.test(prev)&&t2==="<"){const closeIndex=findMatchingPair("<",">",i2);if(closeIndex!==-1)for(let k2=i2;k2<=closeIndex;k2++)genericSet.add(k2)}}let indentLevel=0;const indentStr="  ",lines=[];let line="";function pushLine(){line.trim()&&lines.push(line.replace(/\s+$/,"")),line=""}__name(pushLine,"pushLine");function newLine(){pushLine(),line=indentStr.repeat(indentLevel)}__name(newLine,"newLine");const stack=[];function stackTop(){return stack.length?stack[stack.length-1]:null}__name(stackTop,"stackTop");function placeToken(tok,noSpaceBefore=!1){line.trim()?noSpaceBefore||/^[),;:\].}>]$/.test(tok)?line+=tok:line+=` ${tok}`:line+=tok}__name(placeToken,"placeToken");for(let i2=0;i2<merged.length;i2++){const tok=merged[i2],next=merged[i2+1]||"";if(["(","{","[","<"].includes(tok))placeToken(tok),stack.push(tok),tok==="{"?(indentLevel++,newLine()):(tok==="("||tok==="["||tok==="<")&&(arrowParamSet.has(i2)&&tok==="("||genericSet.has(i2)&&tok==="<"||next!=={"(":")","[":"]","<":">"}[tok]&&next!=="()"&&next!=="[]"&&next!=="<>"&&(indentLevel++,newLine()));else if([")","}","]",">"].includes(tok)){const opening=stackTop();tok===")"&&opening==="("||tok==="]"&&opening==="["||tok===">"&&opening==="<"?!(arrowParamSet.has(i2)&&tok===")")&&!(genericSet.has(i2)&&tok===">")&&(indentLevel=Math.max(indentLevel-1,0),newLine()):tok==="}"&&opening==="{"&&(indentLevel=Math.max(indentLevel-1,0),newLine()),stack.pop(),placeToken(tok),tok==="}"&&newLine()}else if(/^\(\)|\[\]|\{\}|\<\>$/.test(tok))placeToken(tok);else if(tok==="=>")placeToken(tok);else if(tok===";")placeToken(tok,!0),newLine();else if(tok===","){placeToken(tok,!0);const top=stackTop();!(arrowParamSet.has(i2)&&top==="(")&&!(genericSet.has(i2)&&top==="<")&&top&&["{","[","(","<"].includes(top)&&newLine()}else placeToken(tok)}return pushLine(),lines.join(`
`).replace(/\n\s*\n+/g,`
`).trim()}__name(hackyJsFormatter,"hackyJsFormatter");var formatFunctionPreview=__name((fn2,expanded=!1)=>{try{const fnStr=fn2.toString(),match=fnStr.match(/(?:function\s*)?(?:\(([^)]*)\)|([^=>\s]+))\s*=>?/);if(!match)return"ƒ";const cleanParams=(match[1]||match[2]||"").replace(/\s+/g,"");return expanded?hackyJsFormatter(fnStr):`ƒ (${cleanParams}) => ...`}catch{return"ƒ"}},"formatFunctionPreview"),formatValuePreview=__name(value=>{if(value===null)return"null";if(value===void 0)return"undefined";if(typeof value=="string")return`"${value.length>150?`${value.slice(0,20)}...`:value}"`;if(typeof value=="number"||typeof value=="boolean")return String(value);if(typeof value=="function")return formatFunctionPreview(value);if(Array.isArray(value))return`Array(${value.length})`;if(value instanceof Map)return`Map(${value.size})`;if(value instanceof Set)return`Set(${value.size})`;if(value instanceof Date)return value.toISOString();if(value instanceof RegExp)return value.toString();if(value instanceof Error)return`${value.name}: ${value.message}`;if(typeof value=="object"){const keys=Object.keys(value);return`{${keys.length>2?`${keys.slice(0,2).join(", ")}, ...`:keys.join(", ")}}`}return String(value)},"formatValuePreview"),safeGetValue=__name(value=>{var _a;if(value==null)return{value};if(typeof value=="function")return{value};if(typeof value!="object")return{value};if(isPromise(value))return{value:"Promise"};try{const proto=Object.getPrototypeOf(value);return proto===Promise.prototype||((_a=proto?.constructor)==null?void 0:_a.name)==="Promise"?{value:"Promise"}:{value}}catch{return{value:null,error:"Error accessing value"}}},"safeGetValue"),isPromise=__name(value=>!!value&&(value instanceof Promise||typeof value=="object"&&"then"in value),"isPromise"),extractMinimalFiberInfo=__name(fiber=>{var _a,_b;const timings=Se$1(fiber);return{displayName:we$1(fiber)||"Unknown",type:fiber.type,key:fiber.key,id:fiber.index,selfTime:(_a=timings?.selfTime)!=null?_a:null,totalTime:(_b=timings?.totalTime)!=null?_b:null}},"extractMinimalFiberInfo"),propsTracker=new Map,stateTracker=new Map,contextTracker=new Map,lastComponentType=null,STATE_NAME_REGEX=/\[(?<name>\w+),\s*set\w+\]/g,getStateNames=__name(fiber=>{var _a,_b;const componentSource=((_b=(_a=fiber.type)==null?void 0:_a.toString)==null?void 0:_b.call(_a))||"";return componentSource?Array.from(componentSource.matchAll(STATE_NAME_REGEX),m2=>{var _a2,_b2;return(_b2=(_a2=m2.groups)==null?void 0:_a2.name)!=null?_b2:""}):[]},"getStateNames"),resetTracking=__name(()=>{propsTracker.clear(),stateTracker.clear(),contextTracker.clear(),lastComponentType=null},"resetTracking"),isInitialComponentUpdate=__name(fiber=>{const isNewComponent=fiber.type!==lastComponentType;return lastComponentType=fiber.type,isNewComponent},"isInitialComponentUpdate"),trackChange=__name((tracker,key,currentValue,previousValue)=>{const existing=tracker.get(key),isInitialValue=tracker===propsTracker||tracker===contextTracker,hasChanged=!isEqual(currentValue,previousValue);if(!existing)return tracker.set(key,{count:hasChanged&&isInitialValue?1:0,currentValue,previousValue,lastUpdated:Date.now()}),{hasChanged,count:hasChanged&&isInitialValue?1:isInitialValue?0:1};if(!isEqual(existing.currentValue,currentValue)){const newCount=existing.count+1;return tracker.set(key,{count:newCount,currentValue,previousValue:existing.currentValue,lastUpdated:Date.now()}),{hasChanged:!0,count:newCount}}return{hasChanged:!1,count:existing.count}},"trackChange"),getStateFromFiber=__name(fiber=>{if(!fiber)return{};if(fiber.tag===0||fiber.tag===11||fiber.tag===15||fiber.tag===14){let memoizedState=fiber.memoizedState;const state={};let index=0;for(;memoizedState;)memoizedState.queue&&memoizedState.memoizedState!==void 0&&(state[index]=memoizedState.memoizedState),memoizedState=memoizedState.next,index++;return state}return fiber.tag===1?fiber.memoizedState||{}:{}},"getStateFromFiber"),collectPropsChanges=__name(fiber=>{var _a;const currentProps=fiber.memoizedProps||{},prevProps=((_a=fiber.alternate)==null?void 0:_a.memoizedProps)||{},current={},prev={},allProps=Object.keys(currentProps);for(const key of allProps)key in currentProps&&(current[key]=currentProps[key],prev[key]=prevProps[key]);return{current,prev,changes:getChangedPropsDetailed(fiber).map(change=>({name:change.name,value:change.value,prevValue:change.prevValue}))}},"collectPropsChanges"),collectStateChanges=__name(fiber=>{const current=getStateFromFiber(fiber),prev=fiber.alternate?getStateFromFiber(fiber.alternate):{},changes=[];for(const[index,value]of Object.entries(current)){const stateKey=fiber.tag===1?index:Number(index);fiber.alternate&&!isEqual(prev[index],value)&&changes.push({name:stateKey,value,prevValue:prev[index]})}return{current,prev,changes}},"collectStateChanges"),collectContextChanges=__name(fiber=>{const currentContexts=getAllFiberContexts(fiber),prevContexts=fiber.alternate?getAllFiberContexts(fiber.alternate):new Map,current={},prev={},changes=[],seenContexts=new Set;for(const[contextType,ctx2]of currentContexts){const name=ctx2.displayName,contextKey=contextType;if(seenContexts.has(contextKey))continue;seenContexts.add(contextKey),current[name]=ctx2.value;const prevCtx=prevContexts.get(contextType);prevCtx&&(prev[name]=prevCtx.value,isEqual(prevCtx.value,ctx2.value)||changes.push({name,value:ctx2.value,prevValue:prevCtx.value,contextType}))}return{current,prev,changes}},"collectContextChanges"),collectInspectorData=__name(fiber=>{const emptySection=__name(()=>({current:[],changes:new Set,changesCounts:new Map}),"emptySection");if(!fiber)return{data:{fiberProps:emptySection(),fiberState:emptySection(),fiberContext:emptySection()},shouldUpdate:!1};let hasNewChanges=!1;const isInitialUpdate=isInitialComponentUpdate(fiber),propsData=emptySection();if(fiber.memoizedProps){const{current,changes}=collectPropsChanges(fiber);for(const[key,value]of Object.entries(current))propsData.current.push({name:key,value:isPromise(value)?{type:"promise",displayValue:"Promise"}:value});for(const change of changes){const{hasChanged,count}=trackChange(propsTracker,change.name,change.value,change.prevValue);hasChanged&&(hasNewChanges=!0,propsData.changes.add(change.name),propsData.changesCounts.set(change.name,count))}}const stateData=emptySection(),{current:stateCurrent,changes:stateChanges}=collectStateChanges(fiber);for(const[index,value]of Object.entries(stateCurrent)){const stateKey=fiber.tag===1?index:Number(index);stateData.current.push({name:stateKey,value})}for(const change of stateChanges){const{hasChanged,count}=trackChange(stateTracker,change.name,change.value,change.prevValue);hasChanged&&(hasNewChanges=!0,stateData.changes.add(change.name),stateData.changesCounts.set(change.name,count))}const contextData=emptySection(),{current:contextCurrent,changes:contextChanges}=collectContextChanges(fiber);for(const[name,value]of Object.entries(contextCurrent))contextData.current.push({name,value});if(!isInitialUpdate)for(const change of contextChanges){const{hasChanged,count}=trackChange(contextTracker,change.name,change.value,change.prevValue);hasChanged&&(hasNewChanges=!0,contextData.changes.add(change.name),contextData.changesCounts.set(change.name,count))}return!hasNewChanges&&!isInitialUpdate&&(propsData.changes.clear(),stateData.changes.clear(),contextData.changes.clear()),{data:{fiberProps:propsData,fiberState:stateData,fiberContext:contextData},shouldUpdate:hasNewChanges||isInitialUpdate}},"collectInspectorData"),fiberContextsCache=new WeakMap,getAllFiberContexts=__name(fiber=>{var _a;if(!fiber)return new Map;const cachedContexts=fiberContextsCache.get(fiber);if(cachedContexts)return cachedContexts;const contexts=new Map;let currentFiber=fiber;for(;currentFiber;){const dependencies=currentFiber.dependencies;if(dependencies?.firstContext){let contextItem=dependencies.firstContext;for(;contextItem;){const memoizedValue=contextItem.memoizedValue,displayName=(_a=contextItem.context)==null?void 0:_a.displayName;if(contexts.has(memoizedValue)||contexts.set(contextItem.context,{value:memoizedValue,displayName:displayName??"UnnamedContext",contextType:null}),contextItem===contextItem.next)break;contextItem=contextItem.next}}currentFiber=currentFiber.return}return fiberContextsCache.set(fiber,contexts),contexts},"getAllFiberContexts"),collectInspectorDataWithoutCounts=__name(fiber=>{const emptySection=__name(()=>({current:[],changes:new Set,changesCounts:new Map}),"emptySection");if(!fiber)return{fiberProps:emptySection(),fiberState:emptySection(),fiberContext:emptySection()};const propsData=emptySection();if(fiber.memoizedProps){const{current:current2,changes:changes2}=collectPropsChanges(fiber);for(const[key,value]of Object.entries(current2))propsData.current.push({name:key,value:isPromise(value)?{type:"promise",displayValue:"Promise"}:value});for(const change of changes2)propsData.changes.add(change.name),propsData.changesCounts.set(change.name,1)}const stateData=emptySection();if(fiber.memoizedState){const{current:current2,changes:changes2}=collectStateChanges(fiber);for(const[key,value]of Object.entries(current2))stateData.current.push({name:key,value:isPromise(value)?{type:"promise",displayValue:"Promise"}:value});for(const change of changes2)stateData.changes.add(change.name),stateData.changesCounts.set(change.name,1)}const contextData=emptySection(),{current,changes}=collectContextChanges(fiber);for(const[key,value]of Object.entries(current))contextData.current.push({name:key,value:isPromise(value)?{type:"promise",displayValue:"Promise"}:value});for(const change of changes)contextData.changes.add(change.name),contextData.changesCounts.set(change.name,1);return{fiberProps:propsData,fiberState:stateData,fiberContext:contextData}},"collectInspectorDataWithoutCounts"),RENDER_PHASE_STRING_TO_ENUM={mount:1,update:2,unmount:4},fps=0,lastTime=performance.now(),frameCount=0,initedFps=!1,updateFPS=__name(()=>{frameCount++;const now=performance.now();now-lastTime>=1e3&&(fps=frameCount,frameCount=0,lastTime=now),requestAnimationFrame(updateFPS)},"updateFPS"),getFPS=__name(()=>(initedFps||(initedFps=!0,updateFPS(),fps=60),fps),"getFPS"),isValueUnstable=__name((prevValue,nextValue)=>fastSerialize(prevValue)===fastSerialize(nextValue)&&unstableTypes.includes(typeof prevValue)&&unstableTypes.includes(typeof nextValue),"isValueUnstable"),unstableTypes=["function","object"],cache=new WeakMap;function fastSerialize(value,depth=0){var _a;if(depth<0)return"…";switch(typeof value){case"function":return value.toString();case"string":return value;case"number":case"boolean":case"undefined":return String(value);case"object":break;default:return String(value)}if(value===null)return"null";if(cache.has(value)){const cached=cache.get(value);if(cached!==void 0)return cached}if(Array.isArray(value)){const str2=value.length?`[${value.length}]`:"[]";return cache.set(value,str2),str2}if(t$3(value)){const str2=`<${(_a=we$1(value.type))!=null?_a:""} ${value.props?Object.keys(value.props).length:0}>`;return cache.set(value,str2),str2}if(Object.getPrototypeOf(value)===Object.prototype){const keys=Object.keys(value),str2=keys.length?`{${keys.length}}`:"{}";return cache.set(value,str2),str2}const ctor=value&&typeof value=="object"?value.constructor:void 0;if(ctor&&typeof ctor=="function"&&ctor.name){const str2=`${ctor.name}{…}`;return cache.set(value,str2),str2}const str=`${Object.prototype.toString.call(value).slice(8,-1)}{…}`;return cache.set(value,str),str}__name(fastSerialize,"fastSerialize");var getStateChanges=__name(fiber=>{var _a,_b;if(!fiber)return[];const changes=[];if(fiber.tag===0||fiber.tag===11||fiber.tag===15||fiber.tag===14){let memoizedState=fiber.memoizedState,prevState=(_a=fiber.alternate)==null?void 0:_a.memoizedState,index=0;for(;memoizedState;){if(memoizedState.queue&&memoizedState.memoizedState!==void 0){const change={type:2,name:index.toString(),value:memoizedState.memoizedState,prevValue:prevState?.memoizedState};isEqual(change.prevValue,change.value)||changes.push(change)}memoizedState=memoizedState.next,prevState=prevState?.next,index++}return changes}if(fiber.tag===1){const change={type:3,name:"state",value:fiber.memoizedState,prevValue:(_b=fiber.alternate)==null?void 0:_b.memoizedState};return isEqual(change.prevValue,change.value)||changes.push(change),changes}return changes},"getStateChanges"),lastContextId=0,contextIdMap=new WeakMap,getContextId=__name(contextFiber=>{const existing=contextIdMap.get(contextFiber);return existing||(lastContextId++,contextIdMap.set(contextFiber,lastContextId),lastContextId)},"getContextId");function getContextChangesTraversal(nextValue,prevValue){var _a;if(!nextValue||!prevValue)return;const nextMemoizedValue=nextValue.memoizedValue,change={type:4,name:(_a=nextValue.context.displayName)!=null?_a:"Context.Provider",value:nextMemoizedValue,contextType:getContextId(nextValue.context)};this.push(change)}__name(getContextChangesTraversal,"getContextChangesTraversal");var getContextChanges=__name(fiber=>{const changes=[];return xe$1(fiber,getContextChangesTraversal.bind(changes)),changes},"getContextChanges"),instrumentationInstances=new Map,inited=!1,getAllInstances=__name(()=>Array.from(instrumentationInstances.values()),"getAllInstances");function isRenderUnnecessaryTraversal(_propsName,prevValue,nextValue){!isEqual(prevValue,nextValue)&&!isValueUnstable(prevValue,nextValue)&&(this.isRequiredChange=!0)}__name(isRenderUnnecessaryTraversal,"isRenderUnnecessaryTraversal");var isRenderUnnecessary=__name(fiber=>{if(!T$7(fiber))return!0;const mutatedHostFibers=E$6(fiber);for(const mutatedHostFiber of mutatedHostFibers){const state={isRequiredChange:!1};if(C$6(mutatedHostFiber,isRenderUnnecessaryTraversal.bind(state)),state.isRequiredChange)return!1}return!0},"isRenderUnnecessary"),TRACK_UNNECESSARY_RENDERS=!1,RENDER_DEBOUNCE_MS=16,renderDataMap=new WeakMap;function getFiberIdentifier(fiber){return String(z$2(fiber))}__name(getFiberIdentifier,"getFiberIdentifier");function getRenderData(fiber){const id=getFiberIdentifier(fiber),keyMap=renderDataMap.get(P$3(fiber));if(keyMap)return keyMap.get(id)}__name(getRenderData,"getRenderData");function setRenderData(fiber,value){const type=P$3(fiber.type),id=getFiberIdentifier(fiber);let keyMap=renderDataMap.get(type);keyMap||(keyMap=new Map,renderDataMap.set(type,keyMap)),keyMap.set(id,value)}__name(setRenderData,"setRenderData");var trackRender=__name((fiber,fiberSelfTime,fiberTotalTime,hasChanges,hasDomMutations)=>{const currentTimestamp=Date.now(),existingData=getRenderData(fiber);if((hasChanges||hasDomMutations)&&(!existingData||currentTimestamp-(existingData.lastRenderTimestamp||0)>RENDER_DEBOUNCE_MS)){const renderData=existingData||{selfTime:0,totalTime:0,renderCount:0,lastRenderTimestamp:currentTimestamp};renderData.renderCount=(renderData.renderCount||0)+1,renderData.selfTime=fiberSelfTime||0,renderData.totalTime=fiberTotalTime||0,renderData.lastRenderTimestamp=currentTimestamp,setRenderData(fiber,{...renderData})}},"trackRender"),createInstrumentation=__name((instanceKey,config)=>{const instrumentation={isPaused:y$4(!ReactScanInternals.options.value.enabled),fiberRoots:new WeakSet};return instrumentationInstances.set(instanceKey,{key:instanceKey,config,instrumentation}),inited||(inited=!0,Me$1({name:"react-scan",onActive:config.onActive,onCommitFiberRoot(_rendererID,root){instrumentation.fiberRoots.add(root);const allInstances=getAllInstances();for(const instance of allInstances)instance.config.onCommitStart();Oe$1(root.current,(fiber,phase)=>{const type=P$3(fiber.type);if(!type)return null;const allInstances2=getAllInstances(),validInstancesIndicies=[];for(let i2=0,len=allInstances2.length;i2<len;i2++)allInstances2[i2].config.isValidFiber(fiber)&&validInstancesIndicies.push(i2);if(!validInstancesIndicies.length)return null;const changes=[];if(allInstances2.some(instance=>instance.config.trackChanges)){const changesProps=collectPropsChanges(fiber).changes,changesState=collectStateChanges(fiber).changes,changesContext=collectContextChanges(fiber).changes;changes.push.apply(null,changesProps.map(change=>({type:1,name:change.name,value:change.value})));for(const change of changesState)fiber.tag===1?changes.push({type:3,name:change.name.toString(),value:change.value}):changes.push({type:2,name:change.name.toString(),value:change.value});changes.push.apply(null,changesContext.map(change=>({type:4,name:change.name,value:change.value,contextType:Number(change.contextType)})))}const{selfTime:fiberSelfTime,totalTime:fiberTotalTime}=Se$1(fiber),fps2=getFPS(),render2={phase:RENDER_PHASE_STRING_TO_ENUM[phase],componentName:we$1(type),count:1,changes,time:fiberSelfTime,forget:Ce$1(fiber),unnecessary:TRACK_UNNECESSARY_RENDERS?isRenderUnnecessary(fiber):null,didCommit:T$7(fiber),fps:fps2},hasChanges=changes.length>0,hasDomMutations=E$6(fiber).length>0;phase==="update"&&trackRender(fiber,fiberSelfTime,fiberTotalTime,hasChanges,hasDomMutations);for(let i2=0,len=validInstancesIndicies.length;i2<len;i2++)allInstances2[validInstancesIndicies[i2]].config.onRender(fiber,[render2])});for(const instance of allInstances)instance.config.onCommitFinish()},onPostCommitFiberRoot(){const allInstances=getAllInstances();for(const instance of allInstances)instance.config.onPostCommitFiberRoot()}})),instrumentation},"createInstrumentation"),log=__name(renders=>{var _a;const logMap=new Map;for(let i2=0,len=renders.length;i2<len;i2++){const render2=renders[i2];if(!render2.componentName)continue;const changeLog=(_a=logMap.get(render2.componentName))!=null?_a:[],labelText=getLabelText([{aggregatedCount:1,computedKey:null,name:render2.componentName,frame:null,...render2,changes:{type:render2.changes.reduce((set,change)=>set|change.type,0),unstable:render2.changes.some(change=>change.unstable)},phase:render2.phase,computedCurrent:null}]);if(!labelText)continue;let prevChangedProps=null,nextChangedProps=null;if(render2.changes)for(let i22=0,len2=render2.changes.length;i22<len2;i22++){const{name,prevValue,nextValue,unstable,type}=render2.changes[i22];type===1?(prevChangedProps??={},nextChangedProps??={},prevChangedProps[`${unstable?"⚠️":""}${name} (prev)`]=prevValue,nextChangedProps[`${unstable?"⚠️":""}${name} (next)`]=nextValue):changeLog.push({prev:prevValue,next:nextValue,type:type===4?"context":"state",unstable:unstable??!1})}prevChangedProps&&nextChangedProps&&changeLog.push({prev:prevChangedProps,next:nextChangedProps,type:"props",unstable:!1}),logMap.set(labelText,changeLog)}for(const[name,changeLog]of Array.from(logMap.entries())){console.group(`%c${name}`,"background: hsla(0,0%,70%,.3); border-radius:3px; padding: 0 2px;");for(const{type,prev,next,unstable}of changeLog)console.log(`${type}:`,unstable?"⚠️":"",prev,"!==",next);console.groupEnd()}},"log"),logIntro=__name(()=>{if(window.hideIntro){window.hideIntro=void 0;return}console.log("%c[·] %cReact Scan","font-weight:bold;color:#7a68e8;font-size:20px;","font-weight:bold;font-size:14px;")},"logIntro"),OUTLINE_ARRAY_SIZE=7,MONO_FONT="Menlo,Consolas,Monaco,Liberation Mono,Lucida Console,monospace",INTERPOLATION_SPEED=.2,SNAP_THRESHOLD=.5,lerp=__name((start2,end)=>{const delta=end-start2;return Math.abs(delta)<SNAP_THRESHOLD?end:start2+delta*INTERPOLATION_SPEED},"lerp"),MAX_PARTS_LENGTH=4,MAX_LABEL_LENGTH=40,TOTAL_FRAMES=45,PRIMARY_COLOR="115,97,230";function sortEntry(prev,next){return next[0]-prev[0]}__name(sortEntry,"sortEntry");function getSortedEntries(countByNames){return[...countByNames.entries()].sort(sortEntry)}__name(getSortedEntries,"getSortedEntries");function getLabelTextPart([count,names]){let part=`${names.slice(0,MAX_PARTS_LENGTH).join(", ")} ×${count}`;return part.length>MAX_LABEL_LENGTH&&(part=`${part.slice(0,MAX_LABEL_LENGTH)}…`),part}__name(getLabelTextPart,"getLabelTextPart");var getLabelText2=__name(outlines=>{const nameByCount=new Map;for(const{name,count}of outlines)nameByCount.set(name,(nameByCount.get(name)||0)+count);const countByNames=new Map;for(const[name,count]of nameByCount){const names=countByNames.get(count);names?names.push(name):countByNames.set(count,[name])}const partsEntries=getSortedEntries(countByNames);let labelText=getLabelTextPart(partsEntries[0]);for(let i2=1,len=partsEntries.length;i2<len;i2++)labelText+=", "+getLabelTextPart(partsEntries[i2]);return labelText.length>MAX_LABEL_LENGTH?`${labelText.slice(0,MAX_LABEL_LENGTH)}…`:labelText},"getLabelText2"),getAreaFromOutlines=__name(outlines=>{let area=0;for(const outline of outlines)area+=outline.width*outline.height;return area},"getAreaFromOutlines"),updateOutlines=__name((activeOutlines2,outlines)=>{for(const{id,name,count,x:x2,y:y2,width,height,didCommit}of outlines){const outline={id,name,count,x:x2,y:y2,width,height,frame:0,targetX:x2,targetY:y2,targetWidth:width,targetHeight:height,didCommit},key=String(outline.id),existingOutline=activeOutlines2.get(key);existingOutline?(existingOutline.count++,existingOutline.frame=0,existingOutline.targetX=x2,existingOutline.targetY=y2,existingOutline.targetWidth=width,existingOutline.targetHeight=height,existingOutline.didCommit=didCommit):activeOutlines2.set(key,outline)}},"updateOutlines"),updateScroll=__name((activeOutlines2,deltaX,deltaY)=>{for(const outline of activeOutlines2.values()){const newX=outline.x-deltaX,newY=outline.y-deltaY;outline.targetX=newX,outline.targetY=newY}},"updateScroll"),initCanvas=__name((canvas2,dpr2)=>{const ctx2=canvas2.getContext("2d",{alpha:!0});return ctx2&&ctx2.scale(dpr2,dpr2),ctx2},"initCanvas"),drawCanvas=__name((ctx2,canvas2,dpr2,activeOutlines2)=>{ctx2.clearRect(0,0,canvas2.width/dpr2,canvas2.height/dpr2);const groupedOutlinesMap=new Map,rectMap=new Map;for(const outline of activeOutlines2.values()){const{x:x2,y:y2,width,height,targetX,targetY,targetWidth,targetHeight,frame}=outline;targetX!==x2&&(outline.x=lerp(x2,targetX)),targetY!==y2&&(outline.y=lerp(y2,targetY)),targetWidth!==width&&(outline.width=lerp(width,targetWidth)),targetHeight!==height&&(outline.height=lerp(height,targetHeight));const labelKey=`${targetX??x2},${targetY??y2}`,rectKey=`${labelKey},${targetWidth??width},${targetHeight??height}`,outlines=groupedOutlinesMap.get(labelKey);outlines?outlines.push(outline):groupedOutlinesMap.set(labelKey,[outline]);const alpha=1-frame/TOTAL_FRAMES;outline.frame++;const rect=rectMap.get(rectKey)||{x:x2,y:y2,width,height,alpha};alpha>rect.alpha&&(rect.alpha=alpha),rectMap.set(rectKey,rect)}for(const{x:x2,y:y2,width,height,alpha}of rectMap.values()){ctx2.strokeStyle=`rgba(${PRIMARY_COLOR},${alpha})`,ctx2.lineWidth=1;const rx=Math.round(x2)+.5,ry=Math.round(y2)+.5,rw=Math.round(width),rh=Math.round(height);ctx2.beginPath(),ctx2.rect(rx,ry,rw,rh),ctx2.stroke(),ctx2.fillStyle=`rgba(${PRIMARY_COLOR},${alpha*.1})`,ctx2.fill()}ctx2.font=`11px ${MONO_FONT}`;const labelMap=new Map;ctx2.textRendering="optimizeSpeed";for(const outlines of groupedOutlinesMap.values()){const{x:x2,y:y2,frame}=outlines[0],alpha=1-frame/TOTAL_FRAMES,text=getLabelText2(outlines),{width}=ctx2.measureText(text),height=11;labelMap.set(`${x2},${y2},${width},${text}`,{text,width,height,alpha,x:x2,y:y2,outlines});let labelY=y2-height-4;if(labelY<0&&(labelY=0),frame>TOTAL_FRAMES)for(const outline of outlines)activeOutlines2.delete(String(outline.id))}const sortedLabels=Array.from(labelMap.entries()).sort(([_2,a2],[__,b2])=>getAreaFromOutlines(b2.outlines)-getAreaFromOutlines(a2.outlines));for(const[labelKey,label]of sortedLabels)if(labelMap.has(labelKey))for(const[otherKey,otherLabel]of labelMap.entries()){if(labelKey===otherKey)continue;const{x:x2,y:y2,width,height}=label,{x:otherX,y:otherY,width:otherWidth,height:otherHeight}=otherLabel;x2+width>otherX&&otherX+otherWidth>x2&&y2+height>otherY&&otherY+otherHeight>y2&&(label.text=getLabelText2(label.outlines.concat(otherLabel.outlines)),label.width=ctx2.measureText(label.text).width,labelMap.delete(otherKey))}for(const label of labelMap.values()){const{x:x2,y:y2,alpha,width,height,text}=label;let labelY=y2-height-4;labelY<0&&(labelY=0),ctx2.fillStyle=`rgba(${PRIMARY_COLOR},${alpha})`,ctx2.fillRect(x2,labelY,width+4,height+4),ctx2.fillStyle=`rgba(255,255,255,${alpha})`,ctx2.fillText(text,x2+2,labelY+height)}return activeOutlines2.size>0},"drawCanvas"),workerCode='"use strict";(()=>{var D="Menlo,Consolas,Monaco,Liberation Mono,Lucida Console,monospace";var T=(t,n)=>{let r=n-t;return Math.abs(r)<.5?n:t+r*.2};var x="115,97,230";function P(t,n){return n[0]-t[0]}function F(t){return[...t.entries()].sort(P)}function v([t,n]){let r=`${n.slice(0,4).join(", ")} \\xD7${t}`;return r.length>40&&(r=`${r.slice(0,40)}\\u2026`),r}var $=t=>{let n=new Map;for(let{name:e,count:u}of t)n.set(e,(n.get(e)||0)+u);let r=new Map;for(let[e,u]of n){let A=r.get(u);A?A.push(e):r.set(u,[e])}let d=F(r),a=v(d[0]);for(let e=1,u=d.length;e<u;e++)a+=", "+v(d[e]);return a.length>40?`${a.slice(0,40)}\\u2026`:a},H=t=>{let n=0;for(let r of t)n+=r.width*r.height;return n};var N=(t,n)=>{let r=t.getContext("2d",{alpha:!0});return r&&r.scale(n,n),r},X=(t,n,r,d)=>{t.clearRect(0,0,n.width/r,n.height/r);let a=new Map,e=new Map;for(let i of d.values()){let{x:o,y:c,width:l,height:g,targetX:s,targetY:f,targetWidth:h,targetHeight:m,frame:O}=i;s!==o&&(i.x=T(o,s)),f!==c&&(i.y=T(c,f)),h!==l&&(i.width=T(l,h)),m!==g&&(i.height=T(g,m));let M=`${s??o},${f??c}`,L=`${M},${h??l},${m??g}`,S=a.get(M);S?S.push(i):a.set(M,[i]);let C=1-O/45;i.frame++;let _=e.get(L)||{x:o,y:c,width:l,height:g,alpha:C};C>_.alpha&&(_.alpha=C),e.set(L,_)}for(let{x:i,y:o,width:c,height:l,alpha:g}of e.values()){t.strokeStyle=`rgba(${x},${g})`,t.lineWidth=1;let s=Math.round(i)+.5,f=Math.round(o)+.5,h=Math.round(c),m=Math.round(l);t.beginPath(),t.rect(s,f,h,m),t.stroke(),t.fillStyle=`rgba(${x},${g*.1})`,t.fill()}t.font=`11px ${D}`;let u=new Map;t.textRendering="optimizeSpeed";for(let i of a.values()){let o=i[0],{x:c,y:l,frame:g}=o,s=1-g/45,f=$(i),{width:h}=t.measureText(f),m=11;u.set(`${c},${l},${h},${f}`,{text:f,width:h,height:m,alpha:s,x:c,y:l,outlines:i});let O=l-m-4;if(O<0&&(O=0),g>45)for(let M of i)d.delete(String(M.id))}let A=Array.from(u.entries()).sort(([i,o],[c,l])=>H(l.outlines)-H(o.outlines));for(let[i,o]of A)if(u.has(i))for(let[c,l]of u.entries()){if(i===c)continue;let{x:g,y:s,width:f,height:h}=o,{x:m,y:O,width:M,height:L}=l;g+f>m&&m+M>g&&s+h>O&&O+L>s&&(o.text=$(o.outlines.concat(l.outlines)),o.width=t.measureText(o.text).width,u.delete(c))}for(let i of u.values()){let{x:o,y:c,alpha:l,width:g,height:s,text:f}=i,h=c-s-4;h<0&&(h=0),t.fillStyle=`rgba(${x},${l})`,t.fillRect(o,h,g+4,s+4),t.fillStyle=`rgba(255,255,255,${l})`,t.fillText(f,o+2,h+s)}return d.size>0};var p=null,w=null,b=1,y=new Map,E=null,R=()=>{if(!w||!p)return;X(w,p,b,y)?E=requestAnimationFrame(R):E=null};self.onmessage=t=>{let{type:n}=t.data;if(n==="init"&&(p=t.data.canvas,b=t.data.dpr,p&&(p.width=t.data.width,p.height=t.data.height,w=N(p,b))),!(!p||!w)){if(n==="resize"){b=t.data.dpr,p.width=t.data.width*b,p.height=t.data.height*b,w.resetTransform(),w.scale(b,b),R();return}if(n==="draw-outlines"){let{data:r,names:d}=t.data,a=new Float32Array(r);for(let e=0;e<a.length;e+=7){let u=a[e+2],A=a[e+3],i=a[e+4],o=a[e+5],c=a[e+6],l={id:a[e],name:d[e/7],count:a[e+1],x:u,y:A,width:i,height:o,frame:0,targetX:u,targetY:A,targetWidth:i,targetHeight:o,didCommit:c},g=String(l.id),s=y.get(g);s?(s.count++,s.frame=0,s.targetX=u,s.targetY=A,s.targetWidth=i,s.targetHeight=o,s.didCommit=c):y.set(g,l)}E||(E=requestAnimationFrame(R));return}if(n==="scroll"){let{deltaX:r,deltaY:d}=t.data;for(let a of y.values()){let e=a.x-r,u=a.y-d;a.targetX=e,a.targetY=u}}}};})();\n',worker=null,canvas=null,ctx=null,dpr=1,animationFrameId=null,activeOutlines=new Map,blueprintMap=new Map,blueprintMapKeys=new Set,outlineFiber=__name(fiber=>{if(!ve$1(fiber))return;const name=typeof fiber.type=="string"?fiber.type:we$1(fiber);if(!name)return;const blueprint=blueprintMap.get(fiber),nearestFibers=A$5(fiber),didCommit=T$7(fiber);blueprint?blueprint.count++:(blueprintMap.set(fiber,{name,count:1,elements:nearestFibers.map(fiber2=>fiber2.stateNode),didCommit:didCommit?1:0}),blueprintMapKeys.add(fiber))},"outlineFiber"),mergeRects=__name(rects=>{const firstRect=rects[0];if(rects.length===1)return firstRect;let minX,minY,maxX,maxY;for(let i2=0,len=rects.length;i2<len;i2++){const rect=rects[i2];minX=minX==null?rect.x:Math.min(minX,rect.x),minY=minY==null?rect.y:Math.min(minY,rect.y),maxX=maxX==null?rect.x+rect.width:Math.max(maxX,rect.x+rect.width),maxY=maxY==null?rect.y+rect.height:Math.max(maxY,rect.y+rect.height)}return minX==null||minY==null||maxX==null||maxY==null?rects[0]:new DOMRect(minX,minY,maxX-minX,maxY-minY)},"mergeRects");function onIntersect(entries,observer){const newEntries=[];for(const entry of entries){const element=entry.target;this.seenElements.has(element)||(this.seenElements.add(element),newEntries.push(entry))}newEntries.length>0&&this.resolveNext&&(this.resolveNext(newEntries),this.resolveNext=null),this.seenElements.size===this.uniqueElements.size&&(observer.disconnect(),this.done=!0,this.resolveNext&&this.resolveNext([]))}__name(onIntersect,"onIntersect");var getBatchedRectMap=__name(async function*(elements){const state={uniqueElements:new Set(elements),seenElements:new Set,resolveNext:null,done:!1},observer=new IntersectionObserver(onIntersect.bind(state));for(const element of state.uniqueElements)observer.observe(element);for(;!state.done;){const entries=await new Promise(resolve=>{state.resolveNext=resolve});entries.length>0&&(yield entries)}},"getBatchedRectMap"),SupportedArrayBuffer=typeof SharedArrayBuffer<"u"?SharedArrayBuffer:ArrayBuffer,flushOutlines=__name(async()=>{const elements=[];for(const fiber of blueprintMapKeys){const blueprint=blueprintMap.get(fiber);if(blueprint)for(let i2=0;i2<blueprint.elements.length;i2++)blueprint.elements[i2]instanceof Element&&elements.push(blueprint.elements[i2])}const rectsMap=new Map;for await(const entries of getBatchedRectMap(elements)){for(const entry of entries){const element=entry.target,rect=entry.intersectionRect;entry.isIntersecting&&rect.width&&rect.height&&rectsMap.set(element,rect)}const blueprints=[],blueprintRects=[],blueprintIds=[];for(const fiber of blueprintMapKeys){const blueprint=blueprintMap.get(fiber);if(!blueprint)continue;const rects=[];for(let i2=0;i2<blueprint.elements.length;i2++){const element=blueprint.elements[i2],rect=rectsMap.get(element);rect&&rects.push(rect)}rects.length&&(blueprints.push(blueprint),blueprintRects.push(mergeRects(rects)),blueprintIds.push(z$2(fiber)))}if(blueprints.length>0){const arrayBuffer=new SupportedArrayBuffer(blueprints.length*OUTLINE_ARRAY_SIZE*4),sharedView=new Float32Array(arrayBuffer),blueprintNames=new Array(blueprints.length);let outlineData;for(let i2=0,len=blueprints.length;i2<len;i2++){const blueprint=blueprints[i2],id=blueprintIds[i2],{x:x2,y:y2,width,height}=blueprintRects[i2],{count,name,didCommit}=blueprint;if(worker){const scaledIndex=i2*OUTLINE_ARRAY_SIZE;sharedView[scaledIndex]=id,sharedView[scaledIndex+1]=count,sharedView[scaledIndex+2]=x2,sharedView[scaledIndex+3]=y2,sharedView[scaledIndex+4]=width,sharedView[scaledIndex+5]=height,sharedView[scaledIndex+6]=didCommit,blueprintNames[i2]=name}else outlineData||(outlineData=new Array(blueprints.length)),outlineData[i2]={id,name,count,x:x2,y:y2,width,height,didCommit}}worker?worker.postMessage({type:"draw-outlines",data:arrayBuffer,names:blueprintNames}):canvas&&ctx&&outlineData&&(updateOutlines(activeOutlines,outlineData),animationFrameId||(animationFrameId=requestAnimationFrame(draw)))}}for(const fiber of blueprintMapKeys)blueprintMap.delete(fiber),blueprintMapKeys.delete(fiber)},"flushOutlines"),draw=__name(()=>{!ctx||!canvas||(drawCanvas(ctx,canvas,dpr,activeOutlines)?animationFrameId=requestAnimationFrame(draw):animationFrameId=null)},"draw"),IS_OFFSCREEN_CANVAS_WORKER_SUPPORTED=typeof OffscreenCanvas<"u"&&typeof Worker<"u",getDpr=__name(()=>Math.min(window.devicePixelRatio||1,2),"getDpr"),getCanvasEl=__name(()=>{cleanup();const host=document.createElement("div");host.setAttribute("data-react-scan","true");const shadowRoot2=host.attachShadow({mode:"open"}),canvasEl=document.createElement("canvas");if(canvasEl.style.position="fixed",canvasEl.style.top="0",canvasEl.style.left="0",canvasEl.style.pointerEvents="none",canvasEl.style.zIndex="2147483646",canvasEl.setAttribute("aria-hidden","true"),shadowRoot2.appendChild(canvasEl),!canvasEl)return null;dpr=getDpr(),canvas=canvasEl;const{innerWidth,innerHeight}=window;canvasEl.style.width=`${innerWidth}px`,canvasEl.style.height=`${innerHeight}px`;const width=innerWidth*dpr,height=innerHeight*dpr;canvasEl.width=width,canvasEl.height=height;const workerOptOut=ReactScanInternals.options.value.useOffscreenCanvasWorker===!1;if(IS_OFFSCREEN_CANVAS_WORKER_SUPPORTED&&!window.__REACT_SCAN_EXTENSION__&&!workerOptOut)try{const blobUrl=URL.createObjectURL(new Blob([workerCode],{type:"application/javascript"}));worker=new Worker(blobUrl);const offscreenCanvas=canvasEl.transferControlToOffscreen();worker.postMessage({type:"init",canvas:offscreenCanvas,width:canvasEl.width,height:canvasEl.height,dpr},[offscreenCanvas])}catch(error){worker=null,ReactScanInternals.options.value._debug==="verbose"&&console.warn("Failed to initialize OffscreenCanvas worker:",error)}worker||(ctx=initCanvas(canvasEl,dpr));let isResizeScheduled=!1;window.addEventListener("resize",()=>{isResizeScheduled||(isResizeScheduled=!0,setTimeout(()=>{const width2=window.innerWidth,height2=window.innerHeight;dpr=getDpr(),canvasEl.style.width=`${width2}px`,canvasEl.style.height=`${height2}px`,worker?worker.postMessage({type:"resize",width:width2,height:height2,dpr}):(canvasEl.width=width2*dpr,canvasEl.height=height2*dpr,ctx&&(ctx.resetTransform(),ctx.scale(dpr,dpr)),draw()),isResizeScheduled=!1}))});let prevScrollX=window.scrollX,prevScrollY=window.scrollY,isScrollScheduled=!1;return window.addEventListener("scroll",()=>{isScrollScheduled||(isScrollScheduled=!0,setTimeout(()=>{const{scrollX,scrollY}=window,deltaX=scrollX-prevScrollX,deltaY=scrollY-prevScrollY;prevScrollX=scrollX,prevScrollY=scrollY,worker?worker.postMessage({type:"scroll",deltaX,deltaY}):requestAnimationFrame(updateScroll.bind(null,activeOutlines,deltaX,deltaY)),isScrollScheduled=!1},32))}),setInterval(()=>{blueprintMapKeys.size&&requestAnimationFrame(flushOutlines)},32),shadowRoot2.appendChild(canvasEl),host},"getCanvasEl"),hasStopped=__name(()=>globalThis.__REACT_SCAN_STOP__,"hasStopped"),cleanup=__name(()=>{const host=document.querySelector("[data-react-scan]");host&&host.remove()},"cleanup"),reportRenderToListeners=__name(fiber=>{var _a,_b;if(ve$1(fiber)&&ReactScanInternals.options.value.showToolbar!==!1&&Store.inspectState.value.kind==="focused"){const reportFiber=fiber,{selfTime}=Se$1(fiber),displayName=we$1(fiber.type),fiberId=z$2(reportFiber),currentData=Store.reportData.get(fiberId),existingCount=(_a=currentData?.count)!=null?_a:0,existingTime=(_b=currentData?.time)!=null?_b:0,changes=[],listeners=Store.changesListeners.get(z$2(fiber));if(listeners?.length){const propsChanges=getChangedPropsDetailed(fiber).map(change=>({type:1,name:change.name,value:change.value,prevValue:change.prevValue,unstable:!1})),stateChanges=getStateChanges(fiber),contextChanges=getContextChanges(fiber).map(info=>({name:info.name,type:4,value:info.value,contextType:info.contextType}));listeners.forEach(listener=>{listener({propsChanges,stateChanges,contextChanges})})}const fiberData={count:existingCount+1,time:existingTime+selfTime||0,renders:[],displayName,type:P$3(fiber.type)||null,changes};Store.reportData.set(fiberId,fiberData),needsReport=!0}},"reportRenderToListeners"),needsReport=!1,reportInterval,startReportInterval=__name(()=>{clearInterval(reportInterval),reportInterval=setInterval(()=>{needsReport&&(Store.lastReportTime.value=Date.now(),needsReport=!1)},50)},"startReportInterval"),isValidFiber=__name(fiber=>!ignoredProps.has(fiber.memoizedProps),"isValidFiber"),isInstrumentationInitialized=!1,initReactScanInstrumentation=__name(setupToolbar=>{if(hasStopped()||isInstrumentationInitialized)return;isInstrumentationInitialized=!0;let schedule,mounted=!1;const scheduleSetup=__name(()=>{mounted||(schedule&&cancelAnimationFrame(schedule),schedule=requestAnimationFrame(()=>{mounted=!0;const host=getCanvasEl();host&&document.documentElement.appendChild(host),setupToolbar()}))},"scheduleSetup");ReactScanInternals.instrumentation=createInstrumentation("react-scan-devtools-0.1.0",{onCommitStart:__name(()=>{var _a,_b;(_b=(_a=ReactScanInternals.options.value).onCommitStart)==null||_b.call(_a)},"onCommitStart"),onActive:(()=>{let didActivate=!1;return()=>{hasStopped()||didActivate||(didActivate=!0,scheduleSetup(),window.__REACT_SCAN_EXTENSION__||(globalThis.__REACT_SCAN__={ReactScanInternals}),startReportInterval(),logIntro())}})(),onError:__name(()=>{},"onError"),isValidFiber,onRender:__name((fiber,renders)=>{var _a,_b,_c,_d,_e2;ve$1(fiber)&&((_b=(_a=Store).interactionListeningForRenders)==null||_b.call(_a,fiber,renders));const isOverlayPaused=(_c=ReactScanInternals.instrumentation)==null?void 0:_c.isPaused.value,isInspectorInactive=Store.inspectState.value.kind==="inspect-off"||Store.inspectState.value.kind==="uninitialized";isOverlayPaused&&isInspectorInactive||(isOverlayPaused||outlineFiber(fiber),ReactScanInternals.options.value.log&&log(renders),Store.inspectState.value.kind==="focused"&&(inspectorUpdateSignal.value=Date.now()),isInspectorInactive||reportRenderToListeners(fiber),(_e2=(_d=ReactScanInternals.options.value).onRender)==null||_e2.call(_d,fiber,renders))},"onRender"),onCommitFinish:__name(()=>{var _a,_b;scheduleSetup(),(_b=(_a=ReactScanInternals.options.value).onCommitFinish)==null||_b.call(_a)},"onCommitFinish"),onPostCommitFiberRoot(){scheduleSetup()},trackChanges:!1})},"initReactScanInstrumentation"),styles_default=`/*! tailwindcss v4.2.4 | MIT License | https://tailwindcss.com */
@layer properties;
@layer theme, base, components, utilities;
@layer theme {
  :root, :host {
    --font-sans: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji",
      "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
    --color-red-300: oklch(80.8% 0.114 19.571);
    --color-red-400: oklch(70.4% 0.191 22.216);
    --color-red-500: oklch(63.7% 0.237 25.331);
    --color-red-600: oklch(57.7% 0.245 27.325);
    --color-red-950: oklch(25.8% 0.092 26.042);
    --color-yellow-300: oklch(90.5% 0.182 98.111);
    --color-yellow-500: oklch(79.5% 0.184 86.047);
    --color-green-500: oklch(72.3% 0.219 149.579);
    --color-purple-400: oklch(71.4% 0.203 305.504);
    --color-purple-500: oklch(62.7% 0.265 303.9);
    --color-purple-800: oklch(43.8% 0.218 303.724);
    --color-gray-100: oklch(96.7% 0.003 264.542);
    --color-gray-300: oklch(87.2% 0.01 258.338);
    --color-gray-400: oklch(70.7% 0.022 261.325);
    --color-gray-500: oklch(55.1% 0.027 264.364);
    --color-zinc-200: oklch(92% 0.004 286.32);
    --color-zinc-400: oklch(70.5% 0.015 286.067);
    --color-zinc-500: oklch(55.2% 0.016 285.938);
    --color-zinc-600: oklch(44.2% 0.017 285.786);
    --color-zinc-700: oklch(37% 0.013 285.805);
    --color-zinc-800: oklch(27.4% 0.006 286.033);
    --color-zinc-900: oklch(21% 0.006 285.885);
    --color-neutral-300: oklch(87% 0 0);
    --color-neutral-400: oklch(70.8% 0 0);
    --color-neutral-500: oklch(55.6% 0 0);
    --color-neutral-700: oklch(37.1% 0 0);
    --color-black: #000;
    --color-white: #fff;
    --spacing: 4px;
    --container-md: 448px;
    --text-xs: 12px;
    --text-xs--line-height: calc(1 / 0.75);
    --text-sm: 14px;
    --text-sm--line-height: calc(1.25 / 0.875);
    --font-weight-medium: 500;
    --font-weight-semibold: 600;
    --font-weight-bold: 700;
    --tracking-wide: 0.025em;
    --radius-sm: 4px;
    --radius-md: 6px;
    --radius-lg: 8px;
    --ease-in: cubic-bezier(0.4, 0, 1, 1);
    --ease-out: cubic-bezier(0, 0, 0.2, 1);
    --ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);
    --blur-sm: 8px;
    --default-transition-duration: 150ms;
    --default-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    --default-font-family: var(--font-sans);
  }
}
@layer base {
  *, ::after, ::before, ::backdrop, ::file-selector-button {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    border: 0 solid;
  }
  html, :host {
    line-height: 1.5;
    -webkit-text-size-adjust: 100%;
    -moz-tab-size: 4;
      -o-tab-size: 4;
         tab-size: 4;
    font-family: var(--default-font-family, ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji");
    font-feature-settings: var(--default-font-feature-settings, normal);
    font-variation-settings: var(--default-font-variation-settings, normal);
    -webkit-tap-highlight-color: transparent;
  }
  hr {
    height: 0;
    color: inherit;
    border-top-width: 1px;
  }
  abbr:where([title]) {
    -webkit-text-decoration: underline dotted;
    text-decoration: underline dotted;
  }
  h1, h2, h3, h4, h5, h6 {
    font-size: inherit;
    font-weight: inherit;
  }
  a {
    color: inherit;
    -webkit-text-decoration: inherit;
    text-decoration: inherit;
  }
  b, strong {
    font-weight: bolder;
  }
  code, kbd, samp, pre {
    font-family: Menlo, Consolas, Monaco, Liberation Mono, Lucida Console, monospace;
    font-feature-settings: normal;
    font-variation-settings: normal;
    font-size: 1em;
  }
  small {
    font-size: 80%;
  }
  sub, sup {
    font-size: 75%;
    line-height: 0;
    position: relative;
    vertical-align: baseline;
  }
  sub {
    bottom: -0.25em;
  }
  sup {
    top: -0.5em;
  }
  table {
    text-indent: 0;
    border-color: inherit;
    border-collapse: collapse;
  }
  :-moz-focusring {
    outline: auto;
  }
  progress {
    vertical-align: baseline;
  }
  summary {
    display: list-item;
  }
  ol, ul, menu {
    list-style: none;
  }
  img, svg, video, canvas, audio, iframe, embed, object {
    display: block;
    vertical-align: middle;
  }
  img, video {
    max-width: 100%;
    height: auto;
  }
  button, input, select, optgroup, textarea, ::file-selector-button {
    font: inherit;
    font-feature-settings: inherit;
    font-variation-settings: inherit;
    letter-spacing: inherit;
    color: inherit;
    border-radius: 0;
    background-color: transparent;
    opacity: 1;
  }
  :where(select:is([multiple], [size])) optgroup {
    font-weight: bolder;
  }
  :where(select:is([multiple], [size])) optgroup option {
    padding-inline-start: 20px;
  }
  ::file-selector-button {
    margin-inline-end: 4px;
  }
  ::-moz-placeholder {
    opacity: 1;
  }
  ::placeholder {
    opacity: 1;
  }
  @supports (not (-webkit-appearance: -apple-pay-button))  or (contain-intrinsic-size: 1px) {
    ::-moz-placeholder {
      color: currentcolor;
      @supports (color: color-mix(in lab, red, red)) {
        color: color-mix(in oklab, currentcolor 50%, transparent);
      }
    }
    ::placeholder {
      color: currentcolor;
      @supports (color: color-mix(in lab, red, red)) {
        color: color-mix(in oklab, currentcolor 50%, transparent);
      }
    }
  }
  textarea {
    resize: vertical;
  }
  ::-webkit-search-decoration {
    -webkit-appearance: none;
  }
  ::-webkit-date-and-time-value {
    min-height: 1lh;
    text-align: inherit;
  }
  ::-webkit-datetime-edit {
    display: inline-flex;
  }
  ::-webkit-datetime-edit-fields-wrapper {
    padding: 0;
  }
  ::-webkit-datetime-edit, ::-webkit-datetime-edit-year-field, ::-webkit-datetime-edit-month-field, ::-webkit-datetime-edit-day-field, ::-webkit-datetime-edit-hour-field, ::-webkit-datetime-edit-minute-field, ::-webkit-datetime-edit-second-field, ::-webkit-datetime-edit-millisecond-field, ::-webkit-datetime-edit-meridiem-field {
    padding-block: 0;
  }
  ::-webkit-calendar-picker-indicator {
    line-height: 1;
  }
  :-moz-ui-invalid {
    box-shadow: none;
  }
  button, input:where([type="button"], [type="reset"], [type="submit"]), ::file-selector-button {
    -webkit-appearance: button;
       -moz-appearance: button;
            appearance: button;
  }
  ::-webkit-inner-spin-button, ::-webkit-outer-spin-button {
    height: auto;
  }
  [hidden]:where(:not([hidden="until-found"])) {
    display: none !important;
  }
}
@layer utilities {
  .pointer-events-auto {
    pointer-events: auto;
  }
  .pointer-events-bounding-box {
    pointer-events: bounding-box;
  }
  .pointer-events-none {
    pointer-events: none;
  }
  .collapse {
    visibility: collapse;
  }
  .visible {
    visibility: visible;
  }
  .absolute {
    position: absolute;
  }
  .fixed {
    position: fixed;
  }
  .relative {
    position: relative;
  }
  .static {
    position: static;
  }
  .inset-0 {
    inset: calc(var(--spacing) * 0);
  }
  .inset-x-1 {
    inset-inline: calc(var(--spacing) * 1);
  }
  .inset-y-0 {
    inset-block: calc(var(--spacing) * 0);
  }
  .start {
    inset-inline-start: var(--spacing);
  }
  .end {
    inset-inline-end: var(--spacing);
  }
  .-top-1 {
    top: calc(var(--spacing) * -1);
  }
  .-top-2\\.5 {
    top: calc(var(--spacing) * -2.5);
  }
  .top-0 {
    top: calc(var(--spacing) * 0);
  }
  .top-0\\.5 {
    top: calc(var(--spacing) * 0.5);
  }
  .top-1\\/2 {
    top: calc(1 / 2 * 100%);
  }
  .top-2 {
    top: calc(var(--spacing) * 2);
  }
  .-right-1 {
    right: calc(var(--spacing) * -1);
  }
  .-right-2\\.5 {
    right: calc(var(--spacing) * -2.5);
  }
  .right-0 {
    right: calc(var(--spacing) * 0);
  }
  .right-0\\.5 {
    right: calc(var(--spacing) * 0.5);
  }
  .right-2 {
    right: calc(var(--spacing) * 2);
  }
  .right-4 {
    right: calc(var(--spacing) * 4);
  }
  .bottom-0 {
    bottom: calc(var(--spacing) * 0);
  }
  .bottom-4 {
    bottom: calc(var(--spacing) * 4);
  }
  .left-0 {
    left: calc(var(--spacing) * 0);
  }
  .left-3 {
    left: calc(var(--spacing) * 3);
  }
  .z-10 {
    z-index: 10;
  }
  .z-50 {
    z-index: 50;
  }
  .z-100 {
    z-index: 100;
  }
  .z-\\[214748365\\] {
    z-index: 214748365;
  }
  .z-\\[214748367\\] {
    z-index: 214748367;
  }
  .z-\\[124124124124\\] {
    z-index: 124124124124;
  }
  .container {
    width: 100%;
    @media (width >= 640px) {
      max-width: 640px;
    }
    @media (width >= 768px) {
      max-width: 768px;
    }
    @media (width >= 1024px) {
      max-width: 1024px;
    }
    @media (width >= 1280px) {
      max-width: 1280px;
    }
    @media (width >= 1536px) {
      max-width: 1536px;
    }
  }
  .m-\\[2px\\] {
    margin: 2px;
  }
  .mx-0\\.5 {
    margin-inline: calc(var(--spacing) * 0.5);
  }
  .mt-0\\.5 {
    margin-top: calc(var(--spacing) * 0.5);
  }
  .mt-1 {
    margin-top: calc(var(--spacing) * 1);
  }
  .mt-4 {
    margin-top: calc(var(--spacing) * 4);
  }
  .mr-0\\.5 {
    margin-right: calc(var(--spacing) * 0.5);
  }
  .mr-1 {
    margin-right: calc(var(--spacing) * 1);
  }
  .mr-1\\.5 {
    margin-right: calc(var(--spacing) * 1.5);
  }
  .mr-16 {
    margin-right: calc(var(--spacing) * 16);
  }
  .mr-auto {
    margin-right: auto;
  }
  .mb-1\\.5 {
    margin-bottom: calc(var(--spacing) * 1.5);
  }
  .mb-2 {
    margin-bottom: calc(var(--spacing) * 2);
  }
  .mb-3 {
    margin-bottom: calc(var(--spacing) * 3);
  }
  .mb-4 {
    margin-bottom: calc(var(--spacing) * 4);
  }
  .mb-px {
    margin-bottom: 1px;
  }
  .\\!ml-0 {
    margin-left: calc(var(--spacing) * 0) !important;
  }
  .ml-1 {
    margin-left: calc(var(--spacing) * 1);
  }
  .ml-1\\.5 {
    margin-left: calc(var(--spacing) * 1.5);
  }
  .ml-auto {
    margin-left: auto;
  }
  .block {
    display: block;
  }
  .contents {
    display: contents;
  }
  .flex {
    display: flex;
  }
  .hidden {
    display: none;
  }
  .inline {
    display: inline;
  }
  .aspect-square {
    aspect-ratio: 1 / 1;
  }
  .h-1 {
    height: calc(var(--spacing) * 1);
  }
  .h-4 {
    height: calc(var(--spacing) * 4);
  }
  .h-4\\/5 {
    height: calc(4 / 5 * 100%);
  }
  .h-6 {
    height: calc(var(--spacing) * 6);
  }
  .h-7 {
    height: calc(var(--spacing) * 7);
  }
  .h-8 {
    height: calc(var(--spacing) * 8);
  }
  .h-10 {
    height: calc(var(--spacing) * 10);
  }
  .h-12 {
    height: calc(var(--spacing) * 12);
  }
  .h-\\[28px\\] {
    height: 28px;
  }
  .h-\\[48px\\] {
    height: 48px;
  }
  .h-\\[50px\\] {
    height: 50px;
  }
  .h-\\[150px\\] {
    height: 150px;
  }
  .h-\\[235px\\] {
    height: 235px;
  }
  .h-\\[calc\\(100\\%-25px\\)\\] {
    height: calc(100% - 25px);
  }
  .h-\\[calc\\(100\\%-40px\\)\\] {
    height: calc(100% - 40px);
  }
  .h-\\[calc\\(100\\%-48px\\)\\] {
    height: calc(100% - 48px);
  }
  .h-\\[calc\\(100\\%-150px\\)\\] {
    height: calc(100% - 150px);
  }
  .h-\\[calc\\(100\\%-200px\\)\\] {
    height: calc(100% - 200px);
  }
  .h-fit {
    height: -moz-fit-content;
    height: fit-content;
  }
  .h-full {
    height: 100%;
  }
  .h-screen {
    height: 100vh;
  }
  .max-h-0 {
    max-height: calc(var(--spacing) * 0);
  }
  .max-h-9 {
    max-height: calc(var(--spacing) * 9);
  }
  .max-h-40 {
    max-height: calc(var(--spacing) * 40);
  }
  .min-h-9 {
    min-height: calc(var(--spacing) * 9);
  }
  .min-h-\\[48px\\] {
    min-height: 48px;
  }
  .min-h-fit {
    min-height: -moz-fit-content;
    min-height: fit-content;
  }
  .w-1 {
    width: calc(var(--spacing) * 1);
  }
  .w-1\\/2 {
    width: calc(1 / 2 * 100%);
  }
  .w-1\\/3 {
    width: calc(1 / 3 * 100%);
  }
  .w-2\\/4 {
    width: calc(2 / 4 * 100%);
  }
  .w-3 {
    width: calc(var(--spacing) * 3);
  }
  .w-4 {
    width: calc(var(--spacing) * 4);
  }
  .w-4\\/5 {
    width: calc(4 / 5 * 100%);
  }
  .w-6 {
    width: calc(var(--spacing) * 6);
  }
  .w-80 {
    width: calc(var(--spacing) * 80);
  }
  .w-\\[20px\\] {
    width: 20px;
  }
  .w-\\[72px\\] {
    width: 72px;
  }
  .w-\\[90\\%\\] {
    width: 90%;
  }
  .w-\\[calc\\(100\\%-200px\\)\\] {
    width: calc(100% - 200px);
  }
  .w-fit {
    width: -moz-fit-content;
    width: fit-content;
  }
  .w-full {
    width: 100%;
  }
  .w-px {
    width: 1px;
  }
  .w-screen {
    width: 100vw;
  }
  .max-w-md {
    max-width: var(--container-md);
  }
  .min-w-0 {
    min-width: calc(var(--spacing) * 0);
  }
  .min-w-\\[200px\\] {
    min-width: 200px;
  }
  .min-w-fit {
    min-width: -moz-fit-content;
    min-width: fit-content;
  }
  .flex-1 {
    flex: 1;
  }
  .shrink-0 {
    flex-shrink: 0;
  }
  .grow {
    flex-grow: 1;
  }
  .-translate-y-1\\/2 {
    --tw-translate-y: calc(calc(1 / 2 * 100%) * -1);
    translate: var(--tw-translate-x) var(--tw-translate-y);
  }
  .-translate-y-\\[200\\%\\] {
    --tw-translate-y: calc(200% * -1);
    translate: var(--tw-translate-x) var(--tw-translate-y);
  }
  .translate-y-0 {
    --tw-translate-y: calc(var(--spacing) * 0);
    translate: var(--tw-translate-x) var(--tw-translate-y);
  }
  .scale-110 {
    --tw-scale-x: 110%;
    --tw-scale-y: 110%;
    --tw-scale-z: 110%;
    scale: var(--tw-scale-x) var(--tw-scale-y);
  }
  .-rotate-90 {
    rotate: calc(90deg * -1);
  }
  .rotate-90 {
    rotate: 90deg;
  }
  .rotate-180 {
    rotate: 180deg;
  }
  .transform {
    transform: var(--tw-rotate-x,) var(--tw-rotate-y,) var(--tw-rotate-z,) var(--tw-skew-x,) var(--tw-skew-y,);
  }
  .animate-fade-in {
    animation: fadeIn ease-in forwards;
  }
  .cursor-default {
    cursor: default;
  }
  .cursor-e-resize {
    cursor: e-resize;
  }
  .cursor-ew-resize {
    cursor: ew-resize;
  }
  .cursor-ew-resize {
    cursor: ew-resize;
  }
  .cursor-move {
    cursor: move;
  }
  .cursor-move {
    cursor: move;
  }
  .cursor-nesw-resize {
    cursor: nesw-resize;
  }
  .cursor-nesw-resize {
    cursor: nesw-resize;
  }
  .cursor-ns-resize {
    cursor: ns-resize;
  }
  .cursor-ns-resize {
    cursor: ns-resize;
  }
  .cursor-nwse-resize {
    cursor: nwse-resize;
  }
  .cursor-nwse-resize {
    cursor: nwse-resize;
  }
  .cursor-pointer {
    cursor: pointer;
  }
  .cursor-w-resize {
    cursor: w-resize;
  }
  .\\[touch-action\\:none\\] {
    touch-action: none;
  }
  .resize {
    resize: both;
  }
  .flex-col {
    flex-direction: column;
  }
  .items-center {
    align-items: center;
  }
  .items-end {
    align-items: flex-end;
  }
  .items-start {
    align-items: flex-start;
  }
  .items-stretch {
    align-items: stretch;
  }
  .justify-between {
    justify-content: space-between;
  }
  .justify-center {
    justify-content: center;
  }
  .justify-end {
    justify-content: flex-end;
  }
  .justify-start {
    justify-content: flex-start;
  }
  .gap-0\\.5 {
    gap: calc(var(--spacing) * 0.5);
  }
  .gap-1 {
    gap: calc(var(--spacing) * 1);
  }
  .gap-1\\.5 {
    gap: calc(var(--spacing) * 1.5);
  }
  .gap-2 {
    gap: calc(var(--spacing) * 2);
  }
  .gap-4 {
    gap: calc(var(--spacing) * 4);
  }
  .space-y-1\\.5 {
    :where(& > :not(:last-child)) {
      --tw-space-y-reverse: 0;
      margin-block-start: calc(calc(var(--spacing) * 1.5) * var(--tw-space-y-reverse));
      margin-block-end: calc(calc(var(--spacing) * 1.5) * calc(1 - var(--tw-space-y-reverse)));
    }
  }
  .gap-x-0\\.5 {
    -moz-column-gap: calc(var(--spacing) * 0.5);
         column-gap: calc(var(--spacing) * 0.5);
  }
  .gap-x-1 {
    -moz-column-gap: calc(var(--spacing) * 1);
         column-gap: calc(var(--spacing) * 1);
  }
  .gap-x-1\\.5 {
    -moz-column-gap: calc(var(--spacing) * 1.5);
         column-gap: calc(var(--spacing) * 1.5);
  }
  .gap-x-2 {
    -moz-column-gap: calc(var(--spacing) * 2);
         column-gap: calc(var(--spacing) * 2);
  }
  .gap-x-3 {
    -moz-column-gap: calc(var(--spacing) * 3);
         column-gap: calc(var(--spacing) * 3);
  }
  .gap-x-4 {
    -moz-column-gap: calc(var(--spacing) * 4);
         column-gap: calc(var(--spacing) * 4);
  }
  .gap-y-0\\.5 {
    row-gap: calc(var(--spacing) * 0.5);
  }
  .gap-y-1 {
    row-gap: calc(var(--spacing) * 1);
  }
  .gap-y-2 {
    row-gap: calc(var(--spacing) * 2);
  }
  .gap-y-4 {
    row-gap: calc(var(--spacing) * 4);
  }
  .divide-y {
    :where(& > :not(:last-child)) {
      --tw-divide-y-reverse: 0;
      border-bottom-style: var(--tw-border-style);
      border-top-style: var(--tw-border-style);
      border-top-width: calc(1px * var(--tw-divide-y-reverse));
      border-bottom-width: calc(1px * calc(1 - var(--tw-divide-y-reverse)));
    }
  }
  .divide-zinc-800 {
    :where(& > :not(:last-child)) {
      border-color: var(--color-zinc-800);
    }
  }
  .place-self-center {
    place-self: center;
  }
  .self-end {
    align-self: flex-end;
  }
  .truncate {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .\\!overflow-visible {
    overflow: visible !important;
  }
  .overflow-auto {
    overflow: auto;
  }
  .overflow-hidden {
    overflow: hidden;
  }
  .overflow-x-auto {
    overflow-x: auto;
  }
  .overflow-x-hidden {
    overflow-x: hidden;
  }
  .overflow-y-auto {
    overflow-y: auto;
  }
  .rounded {
    border-radius: 4px;
  }
  .rounded-full {
    border-radius: calc(infinity * 1px);
  }
  .rounded-lg {
    border-radius: var(--radius-lg);
  }
  .rounded-md {
    border-radius: var(--radius-md);
  }
  .rounded-sm {
    border-radius: var(--radius-sm);
  }
  .rounded-t-lg {
    border-top-left-radius: var(--radius-lg);
    border-top-right-radius: var(--radius-lg);
  }
  .rounded-t-sm {
    border-top-left-radius: var(--radius-sm);
    border-top-right-radius: var(--radius-sm);
  }
  .rounded-l-md {
    border-top-left-radius: var(--radius-md);
    border-bottom-left-radius: var(--radius-md);
  }
  .rounded-l-sm {
    border-top-left-radius: var(--radius-sm);
    border-bottom-left-radius: var(--radius-sm);
  }
  .rounded-tl-lg {
    border-top-left-radius: var(--radius-lg);
  }
  .rounded-r-md {
    border-top-right-radius: var(--radius-md);
    border-bottom-right-radius: var(--radius-md);
  }
  .rounded-r-sm {
    border-top-right-radius: var(--radius-sm);
    border-bottom-right-radius: var(--radius-sm);
  }
  .rounded-tr-lg {
    border-top-right-radius: var(--radius-lg);
  }
  .rounded-br-lg {
    border-bottom-right-radius: var(--radius-lg);
  }
  .rounded-bl-lg {
    border-bottom-left-radius: var(--radius-lg);
  }
  .border {
    border-style: var(--tw-border-style);
    border-width: 1px;
  }
  .border-4 {
    border-style: var(--tw-border-style);
    border-width: 4px;
  }
  .border-t {
    border-top-style: var(--tw-border-style);
    border-top-width: 1px;
  }
  .border-r {
    border-right-style: var(--tw-border-style);
    border-right-width: 1px;
  }
  .border-b {
    border-bottom-style: var(--tw-border-style);
    border-bottom-width: 1px;
  }
  .border-l {
    border-left-style: var(--tw-border-style);
    border-left-width: 1px;
  }
  .border-l-0 {
    border-left-style: var(--tw-border-style);
    border-left-width: 0px;
  }
  .border-l-1 {
    border-left-style: var(--tw-border-style);
    border-left-width: 1px;
  }
  .border-none {
    --tw-border-style: none;
    border-style: none;
  }
  .\\!border-red-500 {
    border-color: var(--color-red-500) !important;
  }
  .border-\\[\\#1e1e1e\\] {
    border-color: #1e1e1e;
  }
  .border-\\[\\#222\\] {
    border-color: #222;
  }
  .border-\\[\\#333\\] {
    border-color: #333;
  }
  .border-\\[\\#27272A\\] {
    border-color: #27272A;
  }
  .border-transparent {
    border-color: transparent;
  }
  .border-zinc-800 {
    border-color: var(--color-zinc-800);
  }
  .bg-\\[\\#0A0A0A\\] {
    background-color: #0A0A0A;
  }
  .bg-\\[\\#1D3A66\\] {
    background-color: #1D3A66;
  }
  .bg-\\[\\#1E1E1E\\] {
    background-color: #1E1E1E;
  }
  .bg-\\[\\#1a2a1a\\] {
    background-color: #1a2a1a;
  }
  .bg-\\[\\#1e1e1e\\] {
    background-color: #1e1e1e;
  }
  .bg-\\[\\#2a1515\\] {
    background-color: #2a1515;
  }
  .bg-\\[\\#4b4b4b\\] {
    background-color: #4b4b4b;
  }
  .bg-\\[\\#5f3f9a\\] {
    background-color: #5f3f9a;
  }
  .bg-\\[\\#5f3f9a\\]\\/40 {
    background-color: color-mix(in oklab, #5f3f9a 40%, transparent);
  }
  .bg-\\[\\#6a369e\\] {
    background-color: #6a369e;
  }
  .bg-\\[\\#8e61e3\\] {
    background-color: #8e61e3;
  }
  .bg-\\[\\#7521c8\\] {
    background-color: #7521c8;
  }
  .bg-\\[\\#18181B\\] {
    background-color: #18181B;
  }
  .bg-\\[\\#18181B\\]\\/50 {
    background-color: color-mix(in oklab, #18181B 50%, transparent);
  }
  .bg-\\[\\#27272A\\] {
    background-color: #27272A;
  }
  .bg-\\[\\#44444a\\] {
    background-color: #44444a;
  }
  .bg-\\[\\#141414\\] {
    background-color: #141414;
  }
  .bg-\\[\\#214379d4\\] {
    background-color: #214379d4;
  }
  .bg-\\[\\#412162\\] {
    background-color: #412162;
  }
  .bg-\\[\\#EFD81A\\] {
    background-color: #EFD81A;
  }
  .bg-\\[\\#b77116\\] {
    background-color: #b77116;
  }
  .bg-\\[\\#b94040\\] {
    background-color: #b94040;
  }
  .bg-\\[\\#d36cff\\] {
    background-color: #d36cff;
  }
  .bg-\\[\\#efd81a6b\\] {
    background-color: #efd81a6b;
  }
  .bg-black {
    background-color: var(--color-black);
  }
  .bg-black\\/40 {
    background-color: color-mix(in srgb, #000 40%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-black) 40%, transparent);
    }
  }
  .bg-green-500\\/50 {
    background-color: color-mix(in srgb, oklch(72.3% 0.219 149.579) 50%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-green-500) 50%, transparent);
    }
  }
  .bg-green-500\\/60 {
    background-color: color-mix(in srgb, oklch(72.3% 0.219 149.579) 60%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-green-500) 60%, transparent);
    }
  }
  .bg-neutral-700 {
    background-color: var(--color-neutral-700);
  }
  .bg-purple-500 {
    background-color: var(--color-purple-500);
  }
  .bg-purple-500\\/90 {
    background-color: color-mix(in srgb, oklch(62.7% 0.265 303.9) 90%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-purple-500) 90%, transparent);
    }
  }
  .bg-purple-800 {
    background-color: var(--color-purple-800);
  }
  .bg-red-500 {
    background-color: var(--color-red-500);
  }
  .bg-red-500\\/90 {
    background-color: color-mix(in srgb, oklch(63.7% 0.237 25.331) 90%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-red-500) 90%, transparent);
    }
  }
  .bg-red-950\\/50 {
    background-color: color-mix(in srgb, oklch(25.8% 0.092 26.042) 50%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-red-950) 50%, transparent);
    }
  }
  .bg-transparent {
    background-color: transparent;
  }
  .bg-white {
    background-color: var(--color-white);
  }
  .bg-yellow-300 {
    background-color: var(--color-yellow-300);
  }
  .bg-zinc-800 {
    background-color: var(--color-zinc-800);
  }
  .bg-zinc-900\\/30 {
    background-color: color-mix(in srgb, oklch(21% 0.006 285.885) 30%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-zinc-900) 30%, transparent);
    }
  }
  .bg-zinc-900\\/50 {
    background-color: color-mix(in srgb, oklch(21% 0.006 285.885) 50%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-zinc-900) 50%, transparent);
    }
  }
  .p-0 {
    padding: calc(var(--spacing) * 0);
  }
  .p-1 {
    padding: calc(var(--spacing) * 1);
  }
  .p-2 {
    padding: calc(var(--spacing) * 2);
  }
  .p-3 {
    padding: calc(var(--spacing) * 3);
  }
  .p-4 {
    padding: calc(var(--spacing) * 4);
  }
  .p-5 {
    padding: calc(var(--spacing) * 5);
  }
  .p-6 {
    padding: calc(var(--spacing) * 6);
  }
  .px-1 {
    padding-inline: calc(var(--spacing) * 1);
  }
  .px-1\\.5 {
    padding-inline: calc(var(--spacing) * 1.5);
  }
  .px-2 {
    padding-inline: calc(var(--spacing) * 2);
  }
  .px-2\\.5 {
    padding-inline: calc(var(--spacing) * 2.5);
  }
  .px-3 {
    padding-inline: calc(var(--spacing) * 3);
  }
  .px-4 {
    padding-inline: calc(var(--spacing) * 4);
  }
  .py-0\\.5 {
    padding-block: calc(var(--spacing) * 0.5);
  }
  .py-1 {
    padding-block: calc(var(--spacing) * 1);
  }
  .py-1\\.5 {
    padding-block: calc(var(--spacing) * 1.5);
  }
  .py-2 {
    padding-block: calc(var(--spacing) * 2);
  }
  .py-3 {
    padding-block: calc(var(--spacing) * 3);
  }
  .py-4 {
    padding-block: calc(var(--spacing) * 4);
  }
  .py-\\[1px\\] {
    padding-block: 1px;
  }
  .py-\\[3px\\] {
    padding-block: 3px;
  }
  .py-\\[5px\\] {
    padding-block: 5px;
  }
  .pt-0 {
    padding-top: calc(var(--spacing) * 0);
  }
  .pt-2 {
    padding-top: calc(var(--spacing) * 2);
  }
  .pt-5 {
    padding-top: calc(var(--spacing) * 5);
  }
  .pr-1 {
    padding-right: calc(var(--spacing) * 1);
  }
  .pr-1\\.5 {
    padding-right: calc(var(--spacing) * 1.5);
  }
  .pr-2 {
    padding-right: calc(var(--spacing) * 2);
  }
  .pr-2\\.5 {
    padding-right: calc(var(--spacing) * 2.5);
  }
  .pb-2 {
    padding-bottom: calc(var(--spacing) * 2);
  }
  .pl-1 {
    padding-left: calc(var(--spacing) * 1);
  }
  .pl-2 {
    padding-left: calc(var(--spacing) * 2);
  }
  .pl-2\\.5 {
    padding-left: calc(var(--spacing) * 2.5);
  }
  .pl-3 {
    padding-left: calc(var(--spacing) * 3);
  }
  .pl-5 {
    padding-left: calc(var(--spacing) * 5);
  }
  .pl-6 {
    padding-left: calc(var(--spacing) * 6);
  }
  .text-left {
    text-align: left;
  }
  .font-mono {
    font-family: Menlo, Consolas, Monaco, Liberation Mono, Lucida Console, monospace;
  }
  .text-sm {
    font-size: var(--text-sm);
    line-height: var(--tw-leading, var(--text-sm--line-height));
  }
  .text-xs {
    font-size: var(--text-xs);
    line-height: var(--tw-leading, var(--text-xs--line-height));
  }
  .text-\\[8px\\] {
    font-size: 8px;
  }
  .text-\\[10px\\] {
    font-size: 10px;
  }
  .text-\\[11px\\] {
    font-size: 11px;
  }
  .text-\\[13px\\] {
    font-size: 13px;
  }
  .text-\\[14px\\] {
    font-size: 14px;
  }
  .text-\\[17px\\] {
    font-size: 17px;
  }
  .leading-6 {
    --tw-leading: calc(var(--spacing) * 6);
    line-height: calc(var(--spacing) * 6);
  }
  .leading-none {
    --tw-leading: 1;
    line-height: 1;
  }
  .font-bold {
    --tw-font-weight: var(--font-weight-bold);
    font-weight: var(--font-weight-bold);
  }
  .font-medium {
    --tw-font-weight: var(--font-weight-medium);
    font-weight: var(--font-weight-medium);
  }
  .font-semibold {
    --tw-font-weight: var(--font-weight-semibold);
    font-weight: var(--font-weight-semibold);
  }
  .tracking-wide {
    --tw-tracking: var(--tracking-wide);
    letter-spacing: var(--tracking-wide);
  }
  .text-wrap {
    text-wrap: wrap;
  }
  .break-words {
    overflow-wrap: break-word;
  }
  .break-all {
    word-break: break-all;
  }
  .whitespace-nowrap {
    white-space: nowrap;
  }
  .whitespace-pre-wrap {
    white-space: pre-wrap;
  }
  .text-\\[\\#4ade80\\] {
    color: #4ade80;
  }
  .text-\\[\\#5a5a5a\\] {
    color: #5a5a5a;
  }
  .text-\\[\\#6E6E77\\] {
    color: #6E6E77;
  }
  .text-\\[\\#6F6F78\\] {
    color: #6F6F78;
  }
  .text-\\[\\#8E61E3\\] {
    color: #8E61E3;
  }
  .text-\\[\\#666\\] {
    color: #666;
  }
  .text-\\[\\#888\\] {
    color: #888;
  }
  .text-\\[\\#999\\] {
    color: #999;
  }
  .text-\\[\\#7346a0\\] {
    color: #7346a0;
  }
  .text-\\[\\#65656D\\] {
    color: #65656D;
  }
  .text-\\[\\#737373\\] {
    color: #737373;
  }
  .text-\\[\\#A1A1AA\\] {
    color: #A1A1AA;
  }
  .text-\\[\\#A855F7\\] {
    color: #A855F7;
  }
  .text-\\[\\#E4E4E7\\] {
    color: #E4E4E7;
  }
  .text-\\[\\#d36cff\\] {
    color: #d36cff;
  }
  .text-\\[\\#f87171\\] {
    color: #f87171;
  }
  .text-black {
    color: var(--color-black);
  }
  .text-gray-100 {
    color: var(--color-gray-100);
  }
  .text-gray-300 {
    color: var(--color-gray-300);
  }
  .text-gray-400 {
    color: var(--color-gray-400);
  }
  .text-gray-500 {
    color: var(--color-gray-500);
  }
  .text-green-500 {
    color: var(--color-green-500);
  }
  .text-neutral-300 {
    color: var(--color-neutral-300);
  }
  .text-neutral-400 {
    color: var(--color-neutral-400);
  }
  .text-neutral-500 {
    color: var(--color-neutral-500);
  }
  .text-purple-400 {
    color: var(--color-purple-400);
  }
  .text-red-300 {
    color: var(--color-red-300);
  }
  .text-red-400 {
    color: var(--color-red-400);
  }
  .text-red-500 {
    color: var(--color-red-500);
  }
  .text-white {
    color: var(--color-white);
  }
  .text-white\\/30 {
    color: color-mix(in srgb, #fff 30%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      color: color-mix(in oklab, var(--color-white) 30%, transparent);
    }
  }
  .text-white\\/70 {
    color: color-mix(in srgb, #fff 70%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      color: color-mix(in oklab, var(--color-white) 70%, transparent);
    }
  }
  .text-yellow-300 {
    color: var(--color-yellow-300);
  }
  .text-yellow-500 {
    color: var(--color-yellow-500);
  }
  .text-zinc-200 {
    color: var(--color-zinc-200);
  }
  .text-zinc-400 {
    color: var(--color-zinc-400);
  }
  .text-zinc-500 {
    color: var(--color-zinc-500);
  }
  .text-zinc-600 {
    color: var(--color-zinc-600);
  }
  .uppercase {
    text-transform: uppercase;
  }
  .italic {
    font-style: italic;
  }
  .opacity-0 {
    opacity: 0%;
  }
  .opacity-50 {
    opacity: 50%;
  }
  .opacity-100 {
    opacity: 100%;
  }
  .shadow-lg {
    --tw-shadow: 0 10px 15px -3px var(--tw-shadow-color, rgb(0 0 0 / 0.1)), 0 4px 6px -4px var(--tw-shadow-color, rgb(0 0 0 / 0.1));
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .ring-1 {
    --tw-ring-shadow: var(--tw-ring-inset,) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color, currentcolor);
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .ring-white\\/\\[0\\.08\\] {
    --tw-ring-color: color-mix(in srgb, #fff 8%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      --tw-ring-color: color-mix(in oklab, var(--color-white) 8%, transparent);
    }
  }
  .outline {
    outline-style: var(--tw-outline-style);
    outline-width: 1px;
  }
  .filter {
    filter: var(--tw-blur,) var(--tw-brightness,) var(--tw-contrast,) var(--tw-grayscale,) var(--tw-hue-rotate,) var(--tw-invert,) var(--tw-saturate,) var(--tw-sepia,) var(--tw-drop-shadow,);
  }
  .backdrop-blur-sm {
    --tw-backdrop-blur: blur(var(--blur-sm));
    backdrop-filter: var(--tw-backdrop-blur,) var(--tw-backdrop-brightness,) var(--tw-backdrop-contrast,) var(--tw-backdrop-grayscale,) var(--tw-backdrop-hue-rotate,) var(--tw-backdrop-invert,) var(--tw-backdrop-opacity,) var(--tw-backdrop-saturate,) var(--tw-backdrop-sepia,);
  }
  .transition {
    transition-property: color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to, opacity, box-shadow, transform, translate, scale, rotate, filter, backdrop-filter, display, content-visibility, overlay, pointer-events;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  .transition-\\[border-radius\\] {
    transition-property: border-radius;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  .transition-\\[color\\,transform\\] {
    transition-property: color,transform;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  .transition-\\[max-height\\] {
    transition-property: max-height;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  .transition-\\[opacity\\] {
    transition-property: opacity;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  .transition-all {
    transition-property: all;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  .transition-colors {
    transition-property: color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  .transition-opacity {
    transition-property: opacity;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  .transition-transform {
    transition-property: transform, translate, scale, rotate;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  .transition-none {
    transition-property: none;
  }
  .delay-0 {
    transition-delay: 0ms;
  }
  .delay-150 {
    transition-delay: 150ms;
  }
  .delay-300 {
    transition-delay: 300ms;
  }
  .\\!duration-0 {
    --tw-duration: 0ms !important;
    transition-duration: 0ms !important;
  }
  .duration-0 {
    --tw-duration: 0ms;
    transition-duration: 0ms;
  }
  .duration-120 {
    --tw-duration: 120ms;
    transition-duration: 120ms;
  }
  .duration-200 {
    --tw-duration: 200ms;
    transition-duration: 200ms;
  }
  .duration-300 {
    --tw-duration: 300ms;
    transition-duration: 300ms;
  }
  .ease-\\[cubic-bezier\\(0\\.25\\,0\\.1\\,0\\.25\\,1\\)\\] {
    --tw-ease: cubic-bezier(0.25,0.1,0.25,1);
    transition-timing-function: cubic-bezier(0.25,0.1,0.25,1);
  }
  .ease-in {
    --tw-ease: var(--ease-in);
    transition-timing-function: var(--ease-in);
  }
  .ease-in-out {
    --tw-ease: var(--ease-in-out);
    transition-timing-function: var(--ease-in-out);
  }
  .ease-out {
    --tw-ease: var(--ease-out);
    transition-timing-function: var(--ease-out);
  }
  .will-change-transform {
    will-change: transform;
  }
  .select-none {
    -webkit-user-select: none;
    -moz-user-select: none;
         user-select: none;
  }
  .animation-delay-0 {
    animation-delay: 0s;
  }
  .animation-delay-100 {
    animation-delay: .1s;
  }
  .animation-delay-150 {
    animation-delay: .15s;
  }
  .animation-delay-200 {
    animation-delay: .2s;
  }
  .animation-delay-300 {
    animation-delay: .3s;
  }
  .animation-delay-500 {
    animation-delay: .5s;
  }
  .animation-delay-700 {
    animation-delay: .7s;
  }
  .animation-delay-1000 {
    animation-delay: 1s;
  }
  .animation-duration-0 {
    animation-duration: 0s;
  }
  .animation-duration-100 {
    animation-duration: .1s;
  }
  .animation-duration-200 {
    animation-duration: .2s;
  }
  .animation-duration-300 {
    animation-duration: .3s;
  }
  .animation-duration-500 {
    animation-duration: .5s;
  }
  .animation-duration-700 {
    animation-duration: .7s;
  }
  .animation-duration-1000 {
    animation-duration: 1s;
  }
  .group-hover\\:bg-\\[\\#5b2d89\\] {
    &:is(:where(.group):hover *) {
      @media (hover: hover) {
        background-color: #5b2d89;
      }
    }
  }
  .group-hover\\:bg-\\[\\#6a6a6a\\] {
    &:is(:where(.group):hover *) {
      @media (hover: hover) {
        background-color: #6a6a6a;
      }
    }
  }
  .group-hover\\:bg-\\[\\#21437982\\] {
    &:is(:where(.group):hover *) {
      @media (hover: hover) {
        background-color: #21437982;
      }
    }
  }
  .group-hover\\:bg-\\[\\#efda1a2f\\] {
    &:is(:where(.group):hover *) {
      @media (hover: hover) {
        background-color: #efda1a2f;
      }
    }
  }
  .group-hover\\:opacity-100 {
    &:is(:where(.group):hover *) {
      @media (hover: hover) {
        opacity: 100%;
      }
    }
  }
  .peer-hover\\/bottom\\:rounded-b-none {
    &:is(:where(.peer\\/bottom):hover ~ *) {
      @media (hover: hover) {
        border-bottom-right-radius: 0;
        border-bottom-left-radius: 0;
      }
    }
  }
  .peer-hover\\/left\\:rounded-l-none {
    &:is(:where(.peer\\/left):hover ~ *) {
      @media (hover: hover) {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
      }
    }
  }
  .peer-hover\\/right\\:rounded-r-none {
    &:is(:where(.peer\\/right):hover ~ *) {
      @media (hover: hover) {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
      }
    }
  }
  .peer-hover\\/top\\:rounded-t-none {
    &:is(:where(.peer\\/top):hover ~ *) {
      @media (hover: hover) {
        border-top-left-radius: 0;
        border-top-right-radius: 0;
      }
    }
  }
  .after\\:absolute {
    &::after {
      content: var(--tw-content);
      position: absolute;
    }
  }
  .after\\:inset-0 {
    &::after {
      content: var(--tw-content);
      inset: calc(var(--spacing) * 0);
    }
  }
  .after\\:top-\\[100\\%\\] {
    &::after {
      content: var(--tw-content);
      top: 100%;
    }
  }
  .after\\:left-1\\/2 {
    &::after {
      content: var(--tw-content);
      left: calc(1 / 2 * 100%);
    }
  }
  .after\\:h-\\[6px\\] {
    &::after {
      content: var(--tw-content);
      height: 6px;
    }
  }
  .after\\:w-\\[10px\\] {
    &::after {
      content: var(--tw-content);
      width: 10px;
    }
  }
  .after\\:-translate-x-1\\/2 {
    &::after {
      content: var(--tw-content);
      --tw-translate-x: calc(calc(1 / 2 * 100%) * -1);
      translate: var(--tw-translate-x) var(--tw-translate-y);
    }
  }
  .after\\:animate-\\[fadeOut_1s_ease-out_forwards\\] {
    &::after {
      content: var(--tw-content);
      animation: fadeOut 1s ease-out forwards;
    }
  }
  .after\\:border-t-\\[6px\\] {
    &::after {
      content: var(--tw-content);
      border-top-style: var(--tw-border-style);
      border-top-width: 6px;
    }
  }
  .after\\:border-r-\\[5px\\] {
    &::after {
      content: var(--tw-content);
      border-right-style: var(--tw-border-style);
      border-right-width: 5px;
    }
  }
  .after\\:border-l-\\[5px\\] {
    &::after {
      content: var(--tw-content);
      border-left-style: var(--tw-border-style);
      border-left-width: 5px;
    }
  }
  .after\\:border-t-white {
    &::after {
      content: var(--tw-content);
      border-top-color: var(--color-white);
    }
  }
  .after\\:border-r-transparent {
    &::after {
      content: var(--tw-content);
      border-right-color: transparent;
    }
  }
  .after\\:border-l-transparent {
    &::after {
      content: var(--tw-content);
      border-left-color: transparent;
    }
  }
  .after\\:bg-purple-500\\/30 {
    &::after {
      content: var(--tw-content);
      background-color: color-mix(in srgb, oklch(62.7% 0.265 303.9) 30%, transparent);
      @supports (color: color-mix(in lab, red, red)) {
        background-color: color-mix(in oklab, var(--color-purple-500) 30%, transparent);
      }
    }
  }
  .after\\:content-\\[\\"\\"\\] {
    &::after {
      --tw-content: "";
      content: var(--tw-content);
    }
  }
  .focus-within\\:border-\\[\\#454545\\] {
    &:focus-within {
      border-color: #454545;
    }
  }
  .hover\\:bg-\\[\\#0f0f0f\\] {
    &:hover {
      @media (hover: hover) {
        background-color: #0f0f0f;
      }
    }
  }
  .hover\\:bg-\\[\\#5f3f9a\\]\\/20 {
    &:hover {
      @media (hover: hover) {
        background-color: color-mix(in oklab, #5f3f9a 20%, transparent);
      }
    }
  }
  .hover\\:bg-\\[\\#5f3f9a\\]\\/40 {
    &:hover {
      @media (hover: hover) {
        background-color: color-mix(in oklab, #5f3f9a 40%, transparent);
      }
    }
  }
  .hover\\:bg-\\[\\#18181B\\] {
    &:hover {
      @media (hover: hover) {
        background-color: #18181B;
      }
    }
  }
  .hover\\:bg-\\[\\#34343b\\] {
    &:hover {
      @media (hover: hover) {
        background-color: #34343b;
      }
    }
  }
  .hover\\:bg-red-600 {
    &:hover {
      @media (hover: hover) {
        background-color: var(--color-red-600);
      }
    }
  }
  .hover\\:bg-zinc-700 {
    &:hover {
      @media (hover: hover) {
        background-color: var(--color-zinc-700);
      }
    }
  }
  .hover\\:bg-zinc-800\\/50 {
    &:hover {
      @media (hover: hover) {
        background-color: color-mix(in srgb, oklch(27.4% 0.006 286.033) 50%, transparent);
        @supports (color: color-mix(in lab, red, red)) {
          background-color: color-mix(in oklab, var(--color-zinc-800) 50%, transparent);
        }
      }
    }
  }
  .hover\\:text-neutral-300 {
    &:hover {
      @media (hover: hover) {
        color: var(--color-neutral-300);
      }
    }
  }
  .hover\\:text-white {
    &:hover {
      @media (hover: hover) {
        color: var(--color-white);
      }
    }
  }
}
* {
  outline: none !important;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  &::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }
  &::-webkit-scrollbar-track {
    border-radius: 10px;
    background: transparent;
  }
  &::-webkit-scrollbar-thumb {
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.3);
  }
  &::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.4);
  }
  &::-webkit-scrollbar-corner {
    background: transparent;
  }
}
@-moz-document url-prefix() {
  * {
    scrollbar-width: thin;
    scrollbar-color: rgba(255, 255, 255, 0.4) transparent;
    scrollbar-width: 6px;
  }
}
button {
  &:hover {
    @media (hover: hover) {
      background-image: none;
    }
  }
  --tw-outline-style: none;
  outline-style: none;
  --tw-border-style: none;
  border-style: none;
  transition-property: color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to;
  transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
  transition-duration: var(--tw-duration, var(--default-transition-duration));
  --tw-ease: var(--ease-out);
  transition-timing-function: var(--ease-out);
  cursor: pointer;
}
input {
  --tw-outline-style: none;
  outline-style: none;
  --tw-border-style: none;
  border-style: none;
  background-color: transparent;
  background-image: none;
  &::-moz-placeholder {
    font-size: var(--text-xs);
    line-height: var(--tw-leading, var(--text-xs--line-height));
  }
  &::placeholder {
    font-size: var(--text-xs);
    line-height: var(--tw-leading, var(--text-xs--line-height));
  }
  &::-moz-placeholder {
    color: var(--color-neutral-500);
  }
  &::placeholder {
    color: var(--color-neutral-500);
  }
  &::-moz-placeholder {
    font-style: italic;
  }
  &::placeholder {
    font-style: italic;
  }
  &:-moz-placeholder {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  &:placeholder-shown {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}
svg {
  height: auto;
  width: auto;
  pointer-events: none;
}
.with-data-text {
  overflow: hidden;
  &::before {
    content: attr(data-text);
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}
#react-scan-toolbar {
  position: fixed;
  top: calc(var(--spacing) * 0);
  left: calc(var(--spacing) * 0);
  display: flex;
  flex-direction: column;
  --tw-shadow: 0 10px 15px -3px var(--tw-shadow-color, rgb(0 0 0 / 0.1)), 0 4px 6px -4px var(--tw-shadow-color, rgb(0 0 0 / 0.1));
  font-family: Menlo, Consolas, Monaco, Liberation Mono, Lucida Console, monospace;
  font-size: 13px;
  color: var(--color-white);
  background-color: var(--color-black);
  -webkit-user-select: none;
  -moz-user-select: none;
       user-select: none;
  cursor: move;
  opacity: 0%;
  z-index: 2147483678;
  animation: fadeIn ease-in forwards;
  animation-delay: .3s;
  animation-duration: .3s;
  --tw-shadow: 0 4px 12px var(--tw-shadow-color, rgba(0,0,0,0.2));
  box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  place-self: start;
  will-change: transform;
  backface-visibility: hidden;
}
#react-scan-toolbar pre,
#react-scan-toolbar textarea,
#react-scan-toolbar input[type='text'],
#react-scan-toolbar input[type='search'],
#react-scan-toolbar [data-react-scan-selectable] {
  -webkit-user-select: text;
  -moz-user-select: text;
       user-select: text;
  cursor: text;
}
.button {
  &:hover {
    background: rgba(255, 255, 255, 0.1);
  }
  &:active {
    background: rgba(255, 255, 255, 0.15);
  }
}
.resize-line-wrapper {
  position: absolute;
  overflow: hidden;
}
.resize-line {
  position: absolute;
  inset: calc(var(--spacing) * 0);
  overflow: hidden;
  background-color: var(--color-black);
  transition-property: all;
  transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
  transition-duration: var(--tw-duration, var(--default-transition-duration));
  svg {
    position: absolute;
    top: calc(1 / 2 * 100%);
    left: calc(1 / 2 * 100%);
    --tw-translate-x: calc(calc(1 / 2 * 100%) * -1);
    --tw-translate-y: calc(calc(1 / 2 * 100%) * -1);
    translate: var(--tw-translate-x) var(--tw-translate-y);
  }
}
.resize-right,
.resize-left {
  inset-block: calc(var(--spacing) * 0);
  width: calc(var(--spacing) * 6);
  cursor: ew-resize;
  .resize-line-wrapper {
    inset-block: calc(var(--spacing) * 0);
    width: calc(1 / 2 * 100%);
  }
  &:hover {
    .resize-line {
      --tw-translate-x: calc(var(--spacing) * 0);
      translate: var(--tw-translate-x) var(--tw-translate-y);
    }
  }
}
.resize-right {
  right: calc(var(--spacing) * 0);
  --tw-translate-x: calc(1 / 2 * 100%);
  translate: var(--tw-translate-x) var(--tw-translate-y);
  .resize-line-wrapper {
    right: calc(var(--spacing) * 0);
  }
  .resize-line {
    border-top-right-radius: var(--radius-lg);
    border-bottom-right-radius: var(--radius-lg);
    --tw-translate-x: -100%;
    translate: var(--tw-translate-x) var(--tw-translate-y);
  }
}
.resize-left {
  left: calc(var(--spacing) * 0);
  --tw-translate-x: calc(calc(1 / 2 * 100%) * -1);
  translate: var(--tw-translate-x) var(--tw-translate-y);
  .resize-line-wrapper {
    left: calc(var(--spacing) * 0);
  }
  .resize-line {
    border-top-left-radius: var(--radius-lg);
    border-bottom-left-radius: var(--radius-lg);
    --tw-translate-x: 100%;
    translate: var(--tw-translate-x) var(--tw-translate-y);
  }
}
.resize-top,
.resize-bottom {
  inset-inline: calc(var(--spacing) * 0);
  height: calc(var(--spacing) * 6);
  cursor: ns-resize;
  .resize-line-wrapper {
    inset-inline: calc(var(--spacing) * 0);
    height: calc(1 / 2 * 100%);
  }
  &:hover {
    .resize-line {
      --tw-translate-y: calc(var(--spacing) * 0);
      translate: var(--tw-translate-x) var(--tw-translate-y);
    }
  }
}
.resize-top {
  top: calc(var(--spacing) * 0);
  --tw-translate-y: calc(calc(1 / 2 * 100%) * -1);
  translate: var(--tw-translate-x) var(--tw-translate-y);
  .resize-line-wrapper {
    top: calc(var(--spacing) * 0);
  }
  .resize-line {
    border-top-left-radius: var(--radius-lg);
    border-top-right-radius: var(--radius-lg);
    --tw-translate-y: 100%;
    translate: var(--tw-translate-x) var(--tw-translate-y);
  }
}
.resize-bottom {
  bottom: calc(var(--spacing) * 0);
  --tw-translate-y: calc(1 / 2 * 100%);
  translate: var(--tw-translate-x) var(--tw-translate-y);
  .resize-line-wrapper {
    bottom: calc(var(--spacing) * 0);
  }
  .resize-line {
    border-bottom-right-radius: var(--radius-lg);
    border-bottom-left-radius: var(--radius-lg);
    --tw-translate-y: -100%;
    translate: var(--tw-translate-x) var(--tw-translate-y);
  }
}
.react-scan-header {
  display: flex;
  align-items: center;
  -moz-column-gap: calc(var(--spacing) * 2);
       column-gap: calc(var(--spacing) * 2);
  padding-right: calc(var(--spacing) * 2);
  padding-left: calc(var(--spacing) * 3);
  min-height: calc(var(--spacing) * 9);
  border-bottom-style: var(--tw-border-style);
  border-bottom-width: 1px;
  border-color: #222;
  overflow: hidden;
  white-space: nowrap;
}
.react-scan-replay-button,
.react-scan-close-button {
  display: flex;
  align-items: center;
  padding: calc(var(--spacing) * 1);
  min-width: -moz-fit-content;
  min-width: fit-content;
  border-radius: 4px;
  transition-property: all;
  transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
  transition-duration: var(--tw-duration, var(--default-transition-duration));
  --tw-duration: 300ms;
  transition-duration: 300ms;
}
.react-scan-replay-button {
  position: relative;
  overflow: hidden;
  background-color: color-mix(in srgb, oklch(62.7% 0.265 303.9) 50%, transparent) !important;
  @supports (color: color-mix(in lab, red, red)) {
    background-color: color-mix(in oklab, var(--color-purple-500) 50%, transparent) !important;
  }
  &:hover {
    background-color: color-mix(in srgb, oklch(62.7% 0.265 303.9) 25%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-purple-500) 25%, transparent);
    }
  }
  &.disabled {
    opacity: 50%;
    pointer-events: none;
  }
  &:before {
    content: "";
    position: absolute;
    inset: calc(var(--spacing) * 0);
    --tw-translate-x: -100%;
    translate: var(--tw-translate-x) var(--tw-translate-y);
    animation: shimmer 2s infinite;
    background: linear-gradient(
      to right,
      transparent,
      rgba(142, 97, 227, 0.3),
      transparent
    );
  }
}
.react-scan-close-button {
  background-color: color-mix(in srgb, #fff 10%, transparent);
  @supports (color: color-mix(in lab, red, red)) {
    background-color: color-mix(in oklab, var(--color-white) 10%, transparent);
  }
  &:hover {
    background-color: color-mix(in srgb, #fff 15%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-white) 15%, transparent);
    }
  }
}
@keyframes shimmer {
  100% {
    transform: translateX(100%);
  }
}
.react-section-header {
  position: sticky;
  z-index: 100;
  display: flex;
  align-items: center;
  -moz-column-gap: calc(var(--spacing) * 2);
       column-gap: calc(var(--spacing) * 2);
  padding-inline: calc(var(--spacing) * 3);
  height: calc(var(--spacing) * 7);
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: #888;
  border-bottom-style: var(--tw-border-style);
  border-bottom-width: 1px;
  border-color: #222;
  background-color: #0a0a0a;
}
.react-scan-section {
  display: flex;
  flex-direction: column;
  padding-inline: calc(var(--spacing) * 2);
  color: #888;
  &::before {
    content: var(--tw-content);
    color: var(--color-gray-500);
  }
  &::before {
    --tw-content: attr(data-section);
    content: var(--tw-content);
  }
  font-size: var(--text-xs);
  line-height: var(--tw-leading, var(--text-xs--line-height));
  > .react-scan-property {
    margin-left: calc(14px * -1);
  }
}
.react-scan-property {
  position: relative;
  display: flex;
  flex-direction: column;
  padding-left: calc(var(--spacing) * 8);
  border-left-style: var(--tw-border-style);
  border-left-width: 1px;
  border-color: transparent;
  overflow: hidden;
}
.react-scan-property-content {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-height: calc(var(--spacing) * 7);
  max-width: 100%;
  overflow: hidden;
}
.react-scan-string {
  color: #9ecbff;
}
.react-scan-number {
  color: #79c7ff;
}
.react-scan-boolean {
  color: #56b6c2;
}
.react-scan-key {
  width: -moz-fit-content;
  width: fit-content;
  max-width: calc(var(--spacing) * 60);
  white-space: nowrap;
  color: var(--color-white);
}
.react-scan-input {
  color: var(--color-white);
  background-color: var(--color-black);
}
@keyframes blink {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
.react-scan-arrow {
  position: absolute;
  top: calc(var(--spacing) * 0);
  left: calc(var(--spacing) * 7);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  height: calc(var(--spacing) * 7);
  width: calc(var(--spacing) * 6);
  --tw-translate-x: -100%;
  translate: var(--tw-translate-x) var(--tw-translate-y);
  z-index: 10;
  > svg {
    transition-property: transform, translate, scale, rotate;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
}
.react-scan-nested {
  position: relative;
  overflow: hidden;
  &:before {
    content: "";
    position: absolute;
    top: calc(var(--spacing) * 0);
    left: calc(var(--spacing) * 0);
    height: 100%;
    width: 1px;
    background-color: color-mix(in srgb, oklch(55.1% 0.027 264.364) 30%, transparent);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-gray-500) 30%, transparent);
    }
  }
}
.react-scan-settings {
  position: absolute;
  inset: calc(var(--spacing) * 0);
  display: flex;
  flex-direction: column;
  gap: calc(var(--spacing) * 4);
  padding-inline: calc(var(--spacing) * 4);
  padding-block: calc(var(--spacing) * 2);
  color: #888;
  > div {
    display: flex;
    align-items: center;
    justify-content: space-between;
    transition-property: color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
    --tw-duration: 300ms;
    transition-duration: 300ms;
  }
}
.react-scan-preview-line {
  position: relative;
  display: flex;
  min-height: calc(var(--spacing) * 7);
  align-items: center;
  -moz-column-gap: calc(var(--spacing) * 2);
       column-gap: calc(var(--spacing) * 2);
}
.react-scan-flash-overlay {
  position: absolute;
  inset: calc(var(--spacing) * 0);
  opacity: 0%;
  z-index: 50;
  pointer-events: none;
  transition-property: opacity;
  transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
  transition-duration: var(--tw-duration, var(--default-transition-duration));
  mix-blend-mode: multiply;
  background-color: color-mix(in srgb, oklch(62.7% 0.265 303.9) 90%, transparent);
  @supports (color: color-mix(in lab, red, red)) {
    background-color: color-mix(in oklab, var(--color-purple-500) 90%, transparent);
  }
}
.react-scan-toggle {
  position: relative;
  display: inline-flex;
  height: calc(var(--spacing) * 6);
  width: calc(var(--spacing) * 10);
  input {
    position: absolute;
    inset: calc(var(--spacing) * 0);
    z-index: 20;
    opacity: 0%;
    cursor: pointer;
    height: 100%;
    width: 100%;
  }
  input:checked {
    + div {
      background-color: #5f3f9a;
      &::before {
        --tw-translate-x: 100%;
        translate: var(--tw-translate-x) var(--tw-translate-y);
        left: auto;
        border-color: #5f3f9a;
      }
    }
  }
  > div {
    position: absolute;
    inset: calc(var(--spacing) * 1);
    background-color: var(--color-neutral-700);
    border-radius: calc(infinity * 1px);
    pointer-events: none;
    transition-property: color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
    --tw-duration: 300ms;
    transition-duration: 300ms;
    &:before {
      --tw-content: '';
      content: var(--tw-content);
      position: absolute;
      top: calc(1 / 2 * 100%);
      left: calc(var(--spacing) * 0);
      --tw-translate-y: calc(calc(1 / 2 * 100%) * -1);
      translate: var(--tw-translate-x) var(--tw-translate-y);
      height: calc(var(--spacing) * 4);
      width: calc(var(--spacing) * 4);
      background-color: var(--color-white);
      border-style: var(--tw-border-style);
      border-width: 2px;
      border-color: var(--color-neutral-700);
      border-radius: calc(infinity * 1px);
      --tw-shadow: 0 1px 3px 0 var(--tw-shadow-color, rgb(0 0 0 / 0.1)), 0 1px 2px -1px var(--tw-shadow-color, rgb(0 0 0 / 0.1));
      box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
      transition-property: all;
      transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
      transition-duration: var(--tw-duration, var(--default-transition-duration));
      --tw-duration: 300ms;
      transition-duration: 300ms;
    }
  }
}
.react-scan-flash-active {
  opacity: 40%;
  transition-property: opacity;
  transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
  transition-duration: var(--tw-duration, var(--default-transition-duration));
  --tw-duration: 300ms;
  transition-duration: 300ms;
}
.react-scan-inspector-overlay {
  display: flex;
  flex-direction: column;
  opacity: 0%;
  transition-property: opacity;
  transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
  transition-duration: var(--tw-duration, var(--default-transition-duration));
  --tw-duration: 200ms;
  transition-duration: 200ms;
  --tw-ease: var(--ease-out);
  transition-timing-function: var(--ease-out);
  will-change: opacity;
  &.fade-out {
    opacity: 0%;
  }
  &.fade-in {
    opacity: 100%;
  }
}
.react-scan-what-changed {
  ul {
    list-style-type: disc;
    padding-left: calc(var(--spacing) * 4);
  }
  li {
    white-space: nowrap;
    > div {
      display: flex;
      align-items: center;
      justify-content: space-between;
      -moz-column-gap: calc(var(--spacing) * 2);
           column-gap: calc(var(--spacing) * 2);
    }
  }
}
.count-badge {
  display: flex;
  align-items: center;
  -moz-column-gap: calc(var(--spacing) * 2);
       column-gap: calc(var(--spacing) * 2);
  padding-inline: calc(var(--spacing) * 1.5);
  padding-block: calc(var(--spacing) * 0.5);
  border-radius: 4px;
  font-size: var(--text-xs);
  line-height: var(--tw-leading, var(--text-xs--line-height));
  --tw-font-weight: var(--font-weight-medium);
  font-weight: var(--font-weight-medium);
  color: #a855f7;
  --tw-numeric-spacing: tabular-nums;
  font-variant-numeric: var(--tw-ordinal,) var(--tw-slashed-zero,) var(--tw-numeric-figure,) var(--tw-numeric-spacing,) var(--tw-numeric-fraction,);
  background-color: color-mix(in oklab, #a855f7 10%, transparent);
  transform-origin: center;
  transition-property: all;
  transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
  transition-duration: var(--tw-duration, var(--default-transition-duration));
  transition-delay: 150ms;
  --tw-duration: 300ms;
  transition-duration: 300ms;
}
.count-flash {
  animation: countFlash .3s ease-out forwards;
}
.count-flash-white {
  animation: countFlashShake .3s ease-out forwards;
  transition-delay: 500ms !important;
}
.change-scope {
  display: flex;
  align-items: center;
  -moz-column-gap: calc(var(--spacing) * 1);
       column-gap: calc(var(--spacing) * 1);
  color: #666;
  font-size: var(--text-xs);
  line-height: var(--tw-leading, var(--text-xs--line-height));
  font-family: Menlo, Consolas, Monaco, Liberation Mono, Lucida Console, monospace;
  > div {
    padding-inline: calc(var(--spacing) * 1.5);
    padding-block: calc(var(--spacing) * 0.5);
    border-radius: 4px;
    font-size: var(--text-xs);
    line-height: var(--tw-leading, var(--text-xs--line-height));
    --tw-font-weight: var(--font-weight-medium);
    font-weight: var(--font-weight-medium);
    --tw-numeric-spacing: tabular-nums;
    font-variant-numeric: var(--tw-ordinal,) var(--tw-slashed-zero,) var(--tw-numeric-figure,) var(--tw-numeric-spacing,) var(--tw-numeric-fraction,);
    transform-origin: center;
    transition-property: all;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
    transition-delay: 150ms;
    --tw-duration: 300ms;
    transition-duration: 300ms;
    &[data-flash="true"] {
      background-color: color-mix(in oklab, #a855f7 10%, transparent);
      color: #a855f7;
    }
  }
}
.react-scan-slider {
  position: relative;
  min-height: calc(var(--spacing) * 6);
  > input {
    position: absolute;
    inset: calc(var(--spacing) * 0);
    opacity: 0%;
  }
  &:before {
    --tw-content: '';
    content: var(--tw-content);
    position: absolute;
    inset-inline: calc(var(--spacing) * 0);
    top: calc(1 / 2 * 100%);
    --tw-translate-y: calc(calc(1 / 2 * 100%) * -1);
    translate: var(--tw-translate-x) var(--tw-translate-y);
    height: calc(var(--spacing) * 1.5);
    background-color: color-mix(in oklab, #8e61e3 40%, transparent);
    border-radius: var(--radius-lg);
    pointer-events: none;
  }
  &:after {
    --tw-content: '';
    content: var(--tw-content);
    position: absolute;
    inset-inline: calc(var(--spacing) * 0);
    inset-block: calc(var(--spacing) * -2);
    z-index: calc(10 * -1);
  }
  span {
    position: absolute;
    top: calc(1 / 2 * 100%);
    left: calc(var(--spacing) * 0);
    --tw-translate-y: calc(calc(1 / 2 * 100%) * -1);
    translate: var(--tw-translate-x) var(--tw-translate-y);
    height: calc(var(--spacing) * 2.5);
    width: calc(var(--spacing) * 2.5);
    border-radius: var(--radius-lg);
    background-color: #8e61e3;
    pointer-events: none;
    transition-property: transform, translate, scale, rotate;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
    --tw-duration: 75ms;
    transition-duration: 75ms;
  }
}
.resize-v-line {
  display: flex;
  align-items: center;
  justify-content: center;
  max-width: calc(var(--spacing) * 1);
  min-width: calc(var(--spacing) * 1);
  height: 100%;
  width: 100%;
  transition-property: color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to;
  transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
  transition-duration: var(--tw-duration, var(--default-transition-duration));
  &:hover,
  &:active {
    > span {
      background-color: #222;
    }
    svg {
      opacity: 100%;
    }
  }
  &::before {
    --tw-content: "";
    content: var(--tw-content);
    position: absolute;
    inset: calc(var(--spacing) * 0);
    left: calc(1 / 2 * 100%);
    --tw-translate-x: calc(calc(1 / 2 * 100%) * -1);
    translate: var(--tw-translate-x) var(--tw-translate-y);
    width: 1px;
    background-color: #222;
    transition-property: color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  > span {
    position: absolute;
    top: calc(1 / 2 * 100%);
    left: calc(1 / 2 * 100%);
    --tw-translate-x: calc(calc(1 / 2 * 100%) * -1);
    --tw-translate-y: calc(calc(1 / 2 * 100%) * -1);
    translate: var(--tw-translate-x) var(--tw-translate-y);
    height: 18px;
    width: calc(var(--spacing) * 1.5);
    border-radius: 4px;
    transition-property: color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  svg {
    position: absolute;
    top: calc(1 / 2 * 100%);
    left: calc(1 / 2 * 100%);
    --tw-translate-x: calc(calc(1 / 2 * 100%) * -1);
    --tw-translate-y: calc(calc(1 / 2 * 100%) * -1);
    translate: var(--tw-translate-x) var(--tw-translate-y);
    rotate: 90deg;
    color: var(--color-neutral-400);
    opacity: 0%;
    transition-property: opacity;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
    z-index: 50;
  }
}
.tree-node-search-highlight {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  span {
    padding-block: 1px;
    border-radius: var(--radius-sm);
    background-color: var(--color-yellow-300);
    --tw-font-weight: var(--font-weight-medium);
    font-weight: var(--font-weight-medium);
    color: var(--color-black);
  }
  .single {
    margin-right: 1px;
    padding-inline: 2px;
  }
  .regex {
    padding-inline: 2px;
  }
  .start {
    margin-left: 1px;
    border-top-left-radius: var(--radius-sm);
    border-bottom-left-radius: var(--radius-sm);
  }
  .end {
    margin-right: 1px;
    border-top-right-radius: var(--radius-sm);
    border-bottom-right-radius: var(--radius-sm);
  }
  .middle {
    margin-inline: 1px;
    border-radius: var(--radius-sm);
  }
}
.react-scan-toolbar-notification {
  position: absolute;
  inset-inline: calc(var(--spacing) * 0);
  display: flex;
  align-items: center;
  -moz-column-gap: calc(var(--spacing) * 2);
       column-gap: calc(var(--spacing) * 2);
  padding: calc(var(--spacing) * 1);
  padding-left: calc(var(--spacing) * 2);
  font-size: 10px;
  color: var(--color-neutral-300);
  background-color: color-mix(in srgb, #000 90%, transparent);
  @supports (color: color-mix(in lab, red, red)) {
    background-color: color-mix(in oklab, var(--color-black) 90%, transparent);
  }
  transition-property: transform, translate, scale, rotate;
  transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
  transition-duration: var(--tw-duration, var(--default-transition-duration));
  &:before {
    --tw-content: '';
    content: var(--tw-content);
    position: absolute;
    inset-inline: calc(var(--spacing) * 0);
    background-color: var(--color-black);
    height: calc(var(--spacing) * 2);
  }
  &.position-top {
    top: 100%;
    --tw-translate-y: -100%;
    translate: var(--tw-translate-x) var(--tw-translate-y);
    border-bottom-right-radius: var(--radius-lg);
    border-bottom-left-radius: var(--radius-lg);
    &::before {
      top: calc(var(--spacing) * 0);
      --tw-translate-y: -100%;
      translate: var(--tw-translate-x) var(--tw-translate-y);
    }
  }
  &.position-bottom {
    bottom: 100%;
    --tw-translate-y: 100%;
    translate: var(--tw-translate-x) var(--tw-translate-y);
    border-top-left-radius: var(--radius-lg);
    border-top-right-radius: var(--radius-lg);
    &::before {
      bottom: calc(var(--spacing) * 0);
      --tw-translate-y: 100%;
      translate: var(--tw-translate-x) var(--tw-translate-y);
    }
  }
  &.is-open {
    --tw-translate-y: calc(var(--spacing) * 0);
    translate: var(--tw-translate-x) var(--tw-translate-y);
  }
}
.react-scan-header-item {
  position: absolute;
  inset: calc(var(--spacing) * 0);
  --tw-translate-y: calc(200% * -1);
  translate: var(--tw-translate-x) var(--tw-translate-y);
  transition-property: transform, translate, scale, rotate;
  transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
  transition-duration: var(--tw-duration, var(--default-transition-duration));
  --tw-duration: 300ms;
  transition-duration: 300ms;
  &.is-visible {
    --tw-translate-y: calc(var(--spacing) * 0);
    translate: var(--tw-translate-x) var(--tw-translate-y);
  }
}
.react-scan-components-tree:has(.resize-v-line:hover, .resize-v-line:active)
  .tree {
  overflow: hidden;
}
.react-scan-expandable {
  display: grid;
  grid-template-rows: 0fr;
  overflow: hidden;
  transition-property: all;
  transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
  transition-duration: var(--tw-duration, var(--default-transition-duration));
  --tw-duration: 75ms;
  transition-duration: 75ms;
  transition-timing-function: ease-out;
  > * {
    min-height: 0;
  }
  &.react-scan-expanded {
    grid-template-rows: 1fr;
    transition-duration: 100ms;
  }
}
@property --tw-translate-x {
  syntax: "*";
  inherits: false;
  initial-value: 0;
}
@property --tw-translate-y {
  syntax: "*";
  inherits: false;
  initial-value: 0;
}
@property --tw-translate-z {
  syntax: "*";
  inherits: false;
  initial-value: 0;
}
@property --tw-scale-x {
  syntax: "*";
  inherits: false;
  initial-value: 1;
}
@property --tw-scale-y {
  syntax: "*";
  inherits: false;
  initial-value: 1;
}
@property --tw-scale-z {
  syntax: "*";
  inherits: false;
  initial-value: 1;
}
@property --tw-rotate-x {
  syntax: "*";
  inherits: false;
}
@property --tw-rotate-y {
  syntax: "*";
  inherits: false;
}
@property --tw-rotate-z {
  syntax: "*";
  inherits: false;
}
@property --tw-skew-x {
  syntax: "*";
  inherits: false;
}
@property --tw-skew-y {
  syntax: "*";
  inherits: false;
}
@property --tw-space-y-reverse {
  syntax: "*";
  inherits: false;
  initial-value: 0;
}
@property --tw-divide-y-reverse {
  syntax: "*";
  inherits: false;
  initial-value: 0;
}
@property --tw-border-style {
  syntax: "*";
  inherits: false;
  initial-value: solid;
}
@property --tw-leading {
  syntax: "*";
  inherits: false;
}
@property --tw-font-weight {
  syntax: "*";
  inherits: false;
}
@property --tw-tracking {
  syntax: "*";
  inherits: false;
}
@property --tw-shadow {
  syntax: "*";
  inherits: false;
  initial-value: 0 0 #0000;
}
@property --tw-shadow-color {
  syntax: "*";
  inherits: false;
}
@property --tw-shadow-alpha {
  syntax: "<percentage>";
  inherits: false;
  initial-value: 100%;
}
@property --tw-inset-shadow {
  syntax: "*";
  inherits: false;
  initial-value: 0 0 #0000;
}
@property --tw-inset-shadow-color {
  syntax: "*";
  inherits: false;
}
@property --tw-inset-shadow-alpha {
  syntax: "<percentage>";
  inherits: false;
  initial-value: 100%;
}
@property --tw-ring-color {
  syntax: "*";
  inherits: false;
}
@property --tw-ring-shadow {
  syntax: "*";
  inherits: false;
  initial-value: 0 0 #0000;
}
@property --tw-inset-ring-color {
  syntax: "*";
  inherits: false;
}
@property --tw-inset-ring-shadow {
  syntax: "*";
  inherits: false;
  initial-value: 0 0 #0000;
}
@property --tw-ring-inset {
  syntax: "*";
  inherits: false;
}
@property --tw-ring-offset-width {
  syntax: "<length>";
  inherits: false;
  initial-value: 0px;
}
@property --tw-ring-offset-color {
  syntax: "*";
  inherits: false;
  initial-value: #fff;
}
@property --tw-ring-offset-shadow {
  syntax: "*";
  inherits: false;
  initial-value: 0 0 #0000;
}
@property --tw-outline-style {
  syntax: "*";
  inherits: false;
  initial-value: solid;
}
@property --tw-blur {
  syntax: "*";
  inherits: false;
}
@property --tw-brightness {
  syntax: "*";
  inherits: false;
}
@property --tw-contrast {
  syntax: "*";
  inherits: false;
}
@property --tw-grayscale {
  syntax: "*";
  inherits: false;
}
@property --tw-hue-rotate {
  syntax: "*";
  inherits: false;
}
@property --tw-invert {
  syntax: "*";
  inherits: false;
}
@property --tw-opacity {
  syntax: "*";
  inherits: false;
}
@property --tw-saturate {
  syntax: "*";
  inherits: false;
}
@property --tw-sepia {
  syntax: "*";
  inherits: false;
}
@property --tw-drop-shadow {
  syntax: "*";
  inherits: false;
}
@property --tw-drop-shadow-color {
  syntax: "*";
  inherits: false;
}
@property --tw-drop-shadow-alpha {
  syntax: "<percentage>";
  inherits: false;
  initial-value: 100%;
}
@property --tw-drop-shadow-size {
  syntax: "*";
  inherits: false;
}
@property --tw-backdrop-blur {
  syntax: "*";
  inherits: false;
}
@property --tw-backdrop-brightness {
  syntax: "*";
  inherits: false;
}
@property --tw-backdrop-contrast {
  syntax: "*";
  inherits: false;
}
@property --tw-backdrop-grayscale {
  syntax: "*";
  inherits: false;
}
@property --tw-backdrop-hue-rotate {
  syntax: "*";
  inherits: false;
}
@property --tw-backdrop-invert {
  syntax: "*";
  inherits: false;
}
@property --tw-backdrop-opacity {
  syntax: "*";
  inherits: false;
}
@property --tw-backdrop-saturate {
  syntax: "*";
  inherits: false;
}
@property --tw-backdrop-sepia {
  syntax: "*";
  inherits: false;
}
@property --tw-duration {
  syntax: "*";
  inherits: false;
}
@property --tw-ease {
  syntax: "*";
  inherits: false;
}
@property --tw-content {
  syntax: "*";
  initial-value: "";
  inherits: false;
}
@property --tw-ordinal {
  syntax: "*";
  inherits: false;
}
@property --tw-slashed-zero {
  syntax: "*";
  inherits: false;
}
@property --tw-numeric-figure {
  syntax: "*";
  inherits: false;
}
@property --tw-numeric-spacing {
  syntax: "*";
  inherits: false;
}
@property --tw-numeric-fraction {
  syntax: "*";
  inherits: false;
}
@keyframes fadeIn {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
@keyframes fadeOut {
  0% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
}
@keyframes countFlash {
  0% {
    background-color: rgba(168, 85, 247, 0.3);
    transform: scale(1.05);
  }
  100% {
    background-color: rgba(168, 85, 247, 0.1);
    transform: scale(1);
  }
}
@keyframes countFlashShake {
  0% {
    transform: translateX(0);
  }
  25% {
    transform: translateX(-5px);
  }
  50% {
    transform: translateX(5px) scale(1.1);
  }
  75% {
    transform: translateX(-5px);
  }
  100% {
    transform: translateX(0);
  }
}
@layer properties {
  @supports ((-webkit-hyphens: none) and (not (margin-trim: inline))) or ((-moz-orient: inline) and (not (color:rgb(from red r g b)))) {
    *, ::before, ::after, ::backdrop {
      --tw-translate-x: 0;
      --tw-translate-y: 0;
      --tw-translate-z: 0;
      --tw-scale-x: 1;
      --tw-scale-y: 1;
      --tw-scale-z: 1;
      --tw-rotate-x: initial;
      --tw-rotate-y: initial;
      --tw-rotate-z: initial;
      --tw-skew-x: initial;
      --tw-skew-y: initial;
      --tw-space-y-reverse: 0;
      --tw-divide-y-reverse: 0;
      --tw-border-style: solid;
      --tw-leading: initial;
      --tw-font-weight: initial;
      --tw-tracking: initial;
      --tw-shadow: 0 0 #0000;
      --tw-shadow-color: initial;
      --tw-shadow-alpha: 100%;
      --tw-inset-shadow: 0 0 #0000;
      --tw-inset-shadow-color: initial;
      --tw-inset-shadow-alpha: 100%;
      --tw-ring-color: initial;
      --tw-ring-shadow: 0 0 #0000;
      --tw-inset-ring-color: initial;
      --tw-inset-ring-shadow: 0 0 #0000;
      --tw-ring-inset: initial;
      --tw-ring-offset-width: 0px;
      --tw-ring-offset-color: #fff;
      --tw-ring-offset-shadow: 0 0 #0000;
      --tw-outline-style: solid;
      --tw-blur: initial;
      --tw-brightness: initial;
      --tw-contrast: initial;
      --tw-grayscale: initial;
      --tw-hue-rotate: initial;
      --tw-invert: initial;
      --tw-opacity: initial;
      --tw-saturate: initial;
      --tw-sepia: initial;
      --tw-drop-shadow: initial;
      --tw-drop-shadow-color: initial;
      --tw-drop-shadow-alpha: 100%;
      --tw-drop-shadow-size: initial;
      --tw-backdrop-blur: initial;
      --tw-backdrop-brightness: initial;
      --tw-backdrop-contrast: initial;
      --tw-backdrop-grayscale: initial;
      --tw-backdrop-hue-rotate: initial;
      --tw-backdrop-invert: initial;
      --tw-backdrop-opacity: initial;
      --tw-backdrop-saturate: initial;
      --tw-backdrop-sepia: initial;
      --tw-duration: initial;
      --tw-ease: initial;
      --tw-content: "";
      --tw-ordinal: initial;
      --tw-slashed-zero: initial;
      --tw-numeric-figure: initial;
      --tw-numeric-spacing: initial;
      --tw-numeric-fraction: initial;
    }
  }
}
`,useDelayedValue=__name((value,onDelay,offDelay=onDelay)=>{const[delayedValue,setDelayedValue]=d$4(value);return y$5(()=>{if(value===delayedValue)return;const timeout2=setTimeout(()=>setDelayedValue(value),value?onDelay:offDelay);return()=>clearTimeout(timeout2)},[value,onDelay,offDelay]),delayedValue},"useDelayedValue"),copyFocusedElement=__name(async element=>{try{const context=await D(element),snippet=`${context.htmlPreview}${context.stackString}`;return snippet.trim()?(await navigator.clipboard.writeText(snippet),!0):!1}catch{return!1}},"copyFocusedElement"),hasNonEmptyTextSelection=__name(()=>{var _a;const selection=(_a=window.getSelection)==null?void 0:_a.call(window);return!!(selection&&selection.toString().length>0)},"hasNonEmptyTextSelection"),isInputLikeFocused=__name(()=>{const active=document.activeElement;if(!active)return!1;const tag=active.tagName;return!!(tag==="INPUT"||tag==="TEXTAREA"||tag==="SELECT"||active instanceof HTMLElement&&active.isContentEditable)},"isInputLikeFocused"),isMac=__name(()=>{if(typeof navigator>"u")return!1;const platform=navigator.platform||"";return platform?/Mac|iPhone|iPad|iPod/i.test(platform):/Mac|iPhone|iPad|iPod/i.test(navigator.userAgent)},"isMac"),isUserReactGrabActive=__name(()=>typeof window<"u"&&!!window.__REACT_GRAB__,"isUserReactGrabActive"),headerInspectClassName=g$4(()=>cn("absolute inset-0 flex items-center gap-x-2","translate-y-0","transition-transform duration-300",signalIsSettingsOpen.value&&"-translate-y-[200%]")),HeaderInspect=__name(()=>{const refReRenders=A$3(null),refTiming=A$3(null),[currentFiber,setCurrentFiber]=d$4(null);return useSignalEffect(()=>{const state=Store.inspectState.value;state.kind==="focused"&&setCurrentFiber(state.fiber)}),useSignalEffect(()=>{const state=timelineState.value;o$3(()=>{var _a,_b;if(Store.inspectState.value.kind!=="focused"||!refReRenders.current||!refTiming.current)return;const{totalUpdates,currentIndex,updates,isVisible,windowOffset}=state,reRenders=Math.max(0,totalUpdates-1),headerText=isVisible?`#${windowOffset+currentIndex} Re-render`:reRenders>0?`×${reRenders}`:"";let formattedTime;if(reRenders>0&&currentIndex>=0&&currentIndex<updates.length){const time=(_b=(_a=updates[currentIndex])==null?void 0:_a.fiberInfo)==null?void 0:_b.selfTime;formattedTime=time>0?time<.1-Number.EPSILON?"< 0.1ms":`${Number(time.toFixed(1))}ms`:void 0}refReRenders.current.dataset.text=headerText?` • ${headerText}`:"",refTiming.current.dataset.text=formattedTime?` • ${formattedTime}`:""})}),u$2("div",{className:headerInspectClassName,children:[T$5(()=>{if(!currentFiber)return null;const{name,wrappers,wrapperTypes}=getExtendedDisplayName(currentFiber),title=wrappers.length?`${wrappers.join("(")}(${name})${")".repeat(wrappers.length)}`:name??"",firstWrapperType=wrapperTypes[0];return u$2("span",{title,className:"flex items-center gap-x-1",children:[name??"Unknown",u$2("span",{title:firstWrapperType?.title,className:"flex items-center gap-x-1 text-[10px] text-purple-400",children:!!firstWrapperType&&u$2(S$4,{children:[u$2("span",{className:cn("rounded py-[1px] px-1","truncate",firstWrapperType.compiler&&"bg-purple-800 text-neutral-400",!firstWrapperType.compiler&&"bg-neutral-700 text-neutral-300",firstWrapperType.type==="memo"&&"bg-[#5f3f9a] text-white"),children:firstWrapperType.type},firstWrapperType.type),firstWrapperType.compiler&&u$2("span",{className:"text-yellow-300",children:"✨"})]})}),wrapperTypes.length>1&&u$2("span",{className:"text-[10px] text-neutral-400",children:["×",wrapperTypes.length-1]})]})},[currentFiber]),u$2("div",{className:"flex items-center gap-x-2 mr-auto text-xs text-[#888]",children:[u$2("span",{ref:refReRenders,className:"with-data-text cursor-pointer !overflow-visible",title:"Click to toggle between rerenders and total renders"}),u$2("span",{ref:refTiming,className:"with-data-text !overflow-visible"})]})]})},"HeaderInspect"),Header=__name(()=>{const isInitialView=useDelayedValue(Store.inspectState.value.kind==="focused",150,0),isCopied=useSignal(!1),handleClose=__name(()=>{signalWidgetViews.value={view:"none"},Store.inspectState.value={kind:"inspect-off"}},"handleClose"),handleCopy=__name(async()=>{const state=Store.inspectState.value;state.kind!=="focused"||!state.focusedDomElement||await copyFocusedElement(state.focusedDomElement)&&(isCopied.value=!0,setTimeout(()=>{isCopied.value=!1,handleClose()},COPY_FEEDBACK_DURATION_MS))},"handleCopy"),refHandleCopy=A$3(handleCopy);if(refHandleCopy.current=handleCopy,y$5(()=>{const onKeyDown=__name(event=>{const state=Store.inspectState.value;state.kind!=="focused"||!state.focusedDomElement||isUserReactGrabActive()||(event.metaKey||event.ctrlKey)&&(event.shiftKey||event.altKey||event.key!=="c"&&event.code!=="KeyC"||isInputLikeFocused()||hasNonEmptyTextSelection()||(event.preventDefault(),event.stopImmediatePropagation(),refHandleCopy.current()))},"onKeyDown");return document.addEventListener("keydown",onKeyDown,{capture:!0}),()=>{document.removeEventListener("keydown",onKeyDown,{capture:!0})}},[]),signalWidgetViews.value.view==="notifications")return;const isFocused=Store.inspectState.value.kind==="focused",copyShortcutLabel=isMac()?"⌘C":"Ctrl+C";return u$2("div",{className:"react-scan-header",children:[u$2("div",{className:"relative flex-1 h-full",children:u$2("div",{className:cn("react-scan-header-item is-visible",!isInitialView&&"!duration-0"),children:u$2(HeaderInspect,{})})}),isFocused&&u$2("button",{type:"button",title:`Copy element (${copyShortcutLabel})`,className:"react-scan-close-button",onClick:handleCopy,children:u$2(Icon,{name:isCopied.value?"icon-check":"icon-copy",className:cn(isCopied.value&&"text-green-500")})}),u$2("button",{type:"button",title:"Close",className:"react-scan-close-button",onClick:handleClose,children:u$2(Icon,{name:"icon-close"})})]})},"Header"),Toggle=__name(({className,...props})=>u$2("div",{className:cn("react-scan-toggle",className),children:[u$2("input",{type:"checkbox",...props}),u$2("div",{})]}),"Toggle"),FpsMeterInner=__name(({fps:fps2})=>{const getColor=__name(fps3=>fps3<30?"#EF4444":fps3<50?"#F59E0B":"rgb(214,132,245)","getColor");return u$2("div",{className:cn("flex items-center gap-x-1 px-2 w-full","h-6","rounded-md","font-mono leading-none","bg-[#141414]","ring-1 ring-white/[0.08]"),children:[u$2("div",{style:{color:getColor(fps2)},className:"text-sm font-semibold tracking-wide transition-colors ease-in-out w-full flex justify-center items-center",children:fps2}),u$2("span",{className:"text-white/30 text-[11px] font-medium tracking-wide ml-auto min-w-fit",children:"FPS"})]})},"FpsMeterInner"),FPSMeter=__name(()=>{const[fps2,setFps]=d$4(null);return y$5(()=>{const intervalId=setInterval(()=>{setFps(getFPS())},200);return()=>clearInterval(intervalId)},[]),u$2("div",{className:cn("flex items-center justify-end gap-x-2 px-1 ml-1 w-[72px]","whitespace-nowrap text-sm text-white"),children:fps2===null?u$2(S$4,{children:"️"}):u$2(FpsMeterInner,{fps:fps2})})},"FPSMeter"),THROW_INVARIANTS=!1,invariantError=__name(message=>{if(THROW_INVARIANTS)throw new Error(message)},"invariantError"),iife=__name(fn2=>fn2(),"iife"),BoundedArray=class _BoundedArray extends Array{static{__name(this,"_BoundedArray")}constructor(capacity=25){super(),__publicField(this,"capacity",capacity)}push(...items){const result=super.push(...items);for(;this.length>this.capacity;)this.shift();return result}static fromArray(array,capacity){const arr=new _BoundedArray(capacity);return arr.push(...array),arr}},Store2=class{static{__name(this,"Store2")}constructor(initialValue){__publicField(this,"subscribers",new Set),__publicField(this,"currentValue"),this.currentValue=initialValue}subscribe(subscriber){return this.subscribers.add(subscriber),subscriber(this.currentValue),()=>{this.subscribers.delete(subscriber)}}setState(data){this.currentValue=data,this.subscribers.forEach(subscriber=>subscriber(data))}getCurrentState(){return this.currentValue}},MAX_INTERACTION_BATCH=150,interactionStore=new Store2(new BoundedArray(MAX_INTERACTION_BATCH)),MAX_CHANNEL_SIZE=50,PerformanceEntryChannels=class{static{__name(this,"PerformanceEntryChannels")}constructor(){__publicField(this,"channels",{})}publish(item,to,createIfNoChannel=!0){const existingChannel=this.channels[to];if(!existingChannel){if(!createIfNoChannel)return;this.channels[to]={callbacks:new BoundedArray(MAX_CHANNEL_SIZE),state:new BoundedArray(MAX_CHANNEL_SIZE)},this.channels[to].state.push(item);return}existingChannel.state.push(item),existingChannel.callbacks.forEach(cb=>cb(item))}getAvailableChannels(){return BoundedArray.fromArray(Object.keys(this.channels),MAX_CHANNEL_SIZE)}subscribe(to,cb,dropFirst=!1){const defer=__name(()=>(dropFirst||this.channels[to].state.forEach(item=>{cb(item)}),()=>{const filtered=this.channels[to].callbacks.filter(subscribed=>subscribed!==cb);this.channels[to].callbacks=BoundedArray.fromArray(filtered,MAX_CHANNEL_SIZE)}),"defer"),existing=this.channels[to];return existing?(existing.callbacks.push(cb),defer()):(this.channels[to]={callbacks:new BoundedArray(MAX_CHANNEL_SIZE),state:new BoundedArray(MAX_CHANNEL_SIZE)},this.channels[to].callbacks.push(cb),defer())}updateChannelState(channel,updater,createIfNoChannel=!0){const existingChannel=this.channels[channel];if(!existingChannel){if(!createIfNoChannel)return;const state=new BoundedArray(MAX_CHANNEL_SIZE),newChannel={callbacks:new BoundedArray(MAX_CHANNEL_SIZE),state};this.channels[channel]=newChannel,newChannel.state=updater(state);return}existingChannel.state=updater(existingChannel.state)}getChannelState(channel){var _a;return(_a=this.channels[channel].state)!=null?_a:new BoundedArray(MAX_CHANNEL_SIZE)}},performanceEntryChannels=new PerformanceEntryChannels,DEFAULT_PATH_FILTERS={skipProviders:!0,skipHocs:!0,skipContainers:!0,skipMinified:!0,skipUtilities:!0,skipBoundaries:!0},PATH_FILTER_PATTERNS={providers:[/Provider$/,/^Provider$/,/^Context$/],hocs:[/^with[A-Z]/,/^forward(?:Ref)?$/i,/^Forward(?:Ref)?\(/],containers:[/^(?:App)?Container$/,/^Root$/,/^ReactDev/],utilities:[/^Fragment$/,/^Suspense$/,/^ErrorBoundary$/,/^Portal$/,/^Consumer$/,/^Layout$/,/^Router/,/^Hydration/],boundaries:[/^Boundary$/,/Boundary$/,/^Provider$/,/Provider$/]},shouldIncludeInPath=__name((name,filters=DEFAULT_PATH_FILTERS)=>{const patternsToCheck=[];return filters.skipProviders&&patternsToCheck.push(...PATH_FILTER_PATTERNS.providers),filters.skipHocs&&patternsToCheck.push(...PATH_FILTER_PATTERNS.hocs),filters.skipContainers&&patternsToCheck.push(...PATH_FILTER_PATTERNS.containers),filters.skipUtilities&&patternsToCheck.push(...PATH_FILTER_PATTERNS.utilities),filters.skipBoundaries&&patternsToCheck.push(...PATH_FILTER_PATTERNS.boundaries),!patternsToCheck.some(pattern=>pattern.test(name))},"shouldIncludeInPath"),minifiedPatterns=[/^[a-z]$/,/^[a-z][0-9]$/,/^_+$/,/^[A-Za-z][_$]$/,/^[a-z]{1,2}$/],isMinified=__name(name=>{var _a,_b;for(let i2=0;i2<minifiedPatterns.length;i2++)if(minifiedPatterns[i2].test(name))return!0;const hasNoVowels=!/[aeiou]/i.test(name),hasMostlyNumbers=((_b=(_a=name.match(/\d/g))==null?void 0:_a.length)!=null?_b:0)>name.length/2,isSingleWordLowerCase=/^[a-z]+$/.test(name),hasRandomLookingChars=/[$_]{2,}/.test(name);return Number(hasNoVowels)+Number(hasMostlyNumbers)+Number(isSingleWordLowerCase)+Number(hasRandomLookingChars)>=2},"isMinified"),getCleanComponentName=__name(component=>{const name=we$1(component);return name?name.replace(/^(?:Memo|Forward(?:Ref)?|With.*?)\((?<inner>.*?)\)$/,"$<inner>"):""},"getCleanComponentName"),getInteractionPath=__name((initialFiber,filters=DEFAULT_PATH_FILTERS)=>{if(!initialFiber)return[];if(!we$1(initialFiber.type))return[];const stack=new Array;let fiber=initialFiber;for(;fiber.return;){const name=getCleanComponentName(fiber.type);name&&!isMinified(name)&&shouldIncludeInPath(name,filters)&&name.toLowerCase()!==name&&stack.push(name),fiber=fiber.return}const fullPath=new Array(stack.length);for(let i2=0;i2<stack.length;i2++)fullPath[i2]=stack[stack.length-i2-1];return fullPath},"getInteractionPath"),getFirstNameFromAncestor=__name((fiber,accept=()=>!0)=>{let curr=fiber;for(;curr;){const currName=we$1(curr.type);if(currName&&accept(currName))return currName;curr=curr.return}return null},"getFirstNameFromAncestor"),unsubscribeTrackVisibilityChange,lastVisibilityHiddenAt="never-hidden",trackVisibilityChange=__name(()=>{unsubscribeTrackVisibilityChange?.();const onVisibilityChange=__name(()=>{document.hidden&&(lastVisibilityHiddenAt=Date.now())},"onVisibilityChange");document.addEventListener("visibilitychange",onVisibilityChange),unsubscribeTrackVisibilityChange=__name(()=>{document.removeEventListener("visibilitychange",onVisibilityChange)},"unsubscribeTrackVisibilityChange")},"trackVisibilityChange"),getInteractionType=__name(eventName=>["pointerup","click"].includes(eventName)?"pointer":(eventName.includes("key"),["keydown","keyup"].includes(eventName)?"keyboard":null),"getInteractionType"),onEntryAnimationId=null,setupPerformanceListener=__name(onEntry=>{trackVisibilityChange();const interactionMap=new Map,interactionTargetMap=new Map,processInteractionEntry=__name(entry=>{if(!entry.interactionId)return;if(entry.interactionId&&entry.target&&!interactionTargetMap.has(entry.interactionId)&&interactionTargetMap.set(entry.interactionId,entry.target),entry.target){let current=entry.target;for(;current;){if(current.id==="react-scan-toolbar-root"||current.id==="react-scan-root")return;current=current.parentElement}}const existingInteraction=interactionMap.get(entry.interactionId);if(existingInteraction)entry.duration>existingInteraction.latency?(existingInteraction.entries=[entry],existingInteraction.latency=entry.duration):entry.duration===existingInteraction.latency&&entry.startTime===existingInteraction.entries[0].startTime&&existingInteraction.entries.push(entry);else{const interactionType=getInteractionType(entry.name);if(!interactionType)return;const interaction={id:entry.interactionId,latency:entry.duration,entries:[entry],target:entry.target,type:interactionType,startTime:entry.startTime,endTime:Date.now(),processingStart:entry.processingStart,processingEnd:entry.processingEnd,duration:entry.duration,inputDelay:entry.processingStart-entry.startTime,processingDuration:entry.processingEnd-entry.processingStart,presentationDelay:entry.duration-(entry.processingEnd-entry.startTime),timestamp:Date.now(),timeSinceTabInactive:lastVisibilityHiddenAt==="never-hidden"?"never-hidden":Date.now()-lastVisibilityHiddenAt,visibilityState:document.visibilityState,timeOrigin:performance.timeOrigin,referrer:document.referrer};interactionMap.set(interaction.id,interaction),onEntryAnimationId||(onEntryAnimationId=requestAnimationFrame(()=>{requestAnimationFrame(()=>{onEntry(interactionMap.get(interaction.id)),onEntryAnimationId=null})}))}},"processInteractionEntry"),po=new PerformanceObserver(list=>{const entries=list.getEntries();for(let i2=0,len=entries.length;i2<len;i2++){const entry=entries[i2];processInteractionEntry(entry)}});try{po.observe({type:"event",buffered:!0,durationThreshold:16}),po.observe({type:"first-input",buffered:!0})}catch{}return()=>po.disconnect()},"setupPerformanceListener"),setupPerformancePublisher=__name(()=>setupPerformanceListener(entry=>{performanceEntryChannels.publish({kind:"entry-received",entry},"recording")}),"setupPerformancePublisher"),MAX_INTERACTION_TASKS=25,tasks=new BoundedArray(MAX_INTERACTION_TASKS),getAssociatedDetailedTimingInteraction=__name((entry,activeTasks)=>{let closestTask=null;for(const task of activeTasks){if(task.type!==entry.type)continue;if(closestTask===null){closestTask=task;continue}const getAbsoluteDiff=__name((task2,entry2)=>Math.abs(task2.startDateTime)-(entry2.startTime+entry2.timeOrigin),"getAbsoluteDiff");getAbsoluteDiff(task,entry)<getAbsoluteDiff(closestTask,entry)&&(closestTask=task)}return closestTask},"getAssociatedDetailedTimingInteraction"),listenForPerformanceEntryInteractions=__name(onComplete=>performanceEntryChannels.subscribe("recording",event=>{const associatedDetailedInteraction=event.kind==="auto-complete-race"?tasks.find(task=>task.interactionUUID===event.interactionUUID):getAssociatedDetailedTimingInteraction(event.entry,tasks);associatedDetailedInteraction&&onComplete(associatedDetailedInteraction.completeInteraction(event))}),"listenForPerformanceEntryInteractions"),trackDetailedTiming=__name(({onMicroTask,onRAF,onTimeout,abort})=>{queueMicrotask(()=>{abort?.()!==!0&&onMicroTask()&&requestAnimationFrame(()=>{abort?.()!==!0&&onRAF()&&setTimeout(()=>{abort?.()!==!0&&onTimeout()},0)})})},"trackDetailedTiming"),getTargetInteractionDetails=__name(target=>{var _a;const associatedFiber=getFiberFromElement(target);if(!associatedFiber)return;let componentName=associatedFiber?we$1(associatedFiber?.type):"N/A";if(componentName||(componentName=(_a=getFirstNameFromAncestor(associatedFiber,name=>name.length>2))!=null?_a:"N/A"),!!componentName)return{componentPath:getInteractionPath(associatedFiber),childrenTree:{},componentName,elementFiber:associatedFiber}},"getTargetInteractionDetails"),setupDetailedPointerTimingListener=__name((kind,options)=>{let instrumentationIdInControl=null;const getEvent=__name(info=>{switch(kind){case"pointer":return info.phase==="start"?"pointerup":info.target instanceof HTMLInputElement||info.target instanceof HTMLSelectElement?"change":"click";case"keyboard":return info.phase==="start"?"keydown":"change"}},"getEvent"),lastInteractionRef={current:{kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:Date.now(),interactionType:kind}},onInteractionStart=__name(e2=>{var _a,_b;if(e2.composedPath().some(el=>el instanceof Element&&el.id==="react-scan-toolbar-root")||(Date.now()-lastInteractionRef.current.stageStart>2e3&&(lastInteractionRef.current={kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:Date.now(),interactionType:kind}),lastInteractionRef.current.kind!=="uninitialized-stage"))return;const pointerUpStart=performance.now();(_a=options?.onStart)==null||_a.call(options,lastInteractionRef.current.interactionUUID);const details=getTargetInteractionDetails(e2.target);if(!details){(_b=options?.onError)==null||_b.call(options,lastInteractionRef.current.interactionUUID);return}const fiberRenders={},stopListeningForRenders=listenForRenders(fiberRenders);lastInteractionRef.current={...lastInteractionRef.current,interactionType:kind,blockingTimeStart:Date.now(),childrenTree:details.childrenTree,componentName:details.componentName,componentPath:details.componentPath,fiberRenders,kind:"interaction-start",interactionStartDetail:pointerUpStart,stopListeningForRenders};const event=getEvent({phase:"end",target:e2.target});document.addEventListener(event,onLastJS,{once:!0}),requestAnimationFrame(()=>{document.removeEventListener(event,onLastJS)})},"onInteractionStart");document.addEventListener(getEvent({phase:"start"}),onInteractionStart,{capture:!0});const onLastJS=__name((e2,instrumentationId,abort)=>{var _a;if(lastInteractionRef.current.kind!=="interaction-start"&&instrumentationId===instrumentationIdInControl){if(kind==="pointer"&&e2.target instanceof HTMLSelectElement){lastInteractionRef.current={kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:Date.now(),interactionType:kind};return}(_a=options?.onError)==null||_a.call(options,lastInteractionRef.current.interactionUUID),lastInteractionRef.current={kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:Date.now(),interactionType:kind},invariantError("pointer -> click");return}instrumentationIdInControl=instrumentationId,trackDetailedTiming({abort,onMicroTask:__name(()=>lastInteractionRef.current.kind==="uninitialized-stage"?!1:(lastInteractionRef.current={...lastInteractionRef.current,kind:"js-end-stage",jsEndDetail:performance.now()},!0),"onMicroTask"),onRAF:__name(()=>{var _a2;return lastInteractionRef.current.kind!=="js-end-stage"&&lastInteractionRef.current.kind!=="raf-stage"?((_a2=options?.onError)==null||_a2.call(options,lastInteractionRef.current.interactionUUID),invariantError("bad transition to raf"),lastInteractionRef.current={kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:Date.now(),interactionType:kind},!1):(lastInteractionRef.current={...lastInteractionRef.current,kind:"raf-stage",rafStart:performance.now()},!0)},"onRAF"),onTimeout:__name(()=>{var _a2;if(lastInteractionRef.current.kind!=="raf-stage"){(_a2=options?.onError)==null||_a2.call(options,lastInteractionRef.current.interactionUUID),lastInteractionRef.current={kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:Date.now(),interactionType:kind},invariantError("raf->timeout");return}const now=Date.now(),timeoutStage=Object.freeze({...lastInteractionRef.current,kind:"timeout-stage",blockingTimeEnd:now,commitEnd:performance.now()});lastInteractionRef.current={kind:"uninitialized-stage",interactionUUID:not_globally_unique_generateId(),stageStart:now,interactionType:kind};let completed=!1;const completeInteraction=__name(event=>{var _a3;completed=!0;const finalInteraction={detailedTiming:timeoutStage,latency:event.kind==="auto-complete-race"?event.detailedTiming.commitEnd-event.detailedTiming.interactionStartDetail:event.entry.latency,completedAt:Date.now(),flushNeeded:!0};(_a3=options?.onComplete)==null||_a3.call(options,timeoutStage.interactionUUID,finalInteraction,event);const newTasks=tasks.filter(task2=>task2.interactionUUID!==timeoutStage.interactionUUID);return tasks=BoundedArray.fromArray(newTasks,MAX_INTERACTION_TASKS),finalInteraction},"completeInteraction"),task={completeInteraction,endDateTime:Date.now(),startDateTime:timeoutStage.blockingTimeStart,type:kind,interactionUUID:timeoutStage.interactionUUID};if(tasks.push(task),isPerformanceEventAvailable())setTimeout(()=>{if(completed)return;completeInteraction({kind:"auto-complete-race",detailedTiming:timeoutStage,interactionUUID:timeoutStage.interactionUUID});const newTasks=tasks.filter(task2=>task2.interactionUUID!==timeoutStage.interactionUUID);tasks=BoundedArray.fromArray(newTasks,MAX_INTERACTION_TASKS)},1e3);else{const newTasks=tasks.filter(task2=>task2.interactionUUID!==timeoutStage.interactionUUID);tasks=BoundedArray.fromArray(newTasks,MAX_INTERACTION_TASKS),completeInteraction({kind:"auto-complete-race",detailedTiming:timeoutStage,interactionUUID:timeoutStage.interactionUUID})}},"onTimeout")})},"onLastJS"),onKeyPress=__name(e2=>{const id=not_globally_unique_generateId();onLastJS(e2,id,()=>id!==instrumentationIdInControl)},"onKeyPress");return kind==="keyboard"&&document.addEventListener("keypress",onKeyPress),()=>{document.removeEventListener(getEvent({phase:"start"}),onInteractionStart,{capture:!0}),document.removeEventListener("keypress",onKeyPress)}},"setupDetailedPointerTimingListener"),getHostFromFiber=__name(fiber=>{var _a;return(_a=j$5(fiber,node=>{if(x$7(node))return!0}))==null?void 0:_a.stateNode},"getHostFromFiber"),isPerformanceEventAvailable=__name(()=>"PerformanceEventTiming"in globalThis,"isPerformanceEventAvailable"),listenForRenders=__name(fiberRenders=>{const listener=__name(fiber=>{var _a,_b,_c,_d,_e2,_f,_g;const displayName=we$1(fiber.type);if(!displayName)return;const existing=fiberRenders[displayName];if(!existing){const parents=new Set,res=fiber.return&&getParentCompositeFiber(fiber.return),parentCompositeName=res&&we$1(res[0]);parentCompositeName&&parents.add(parentCompositeName);const{selfTime:selfTime2,totalTime:totalTime2}=Se$1(fiber),newChanges2=collectInspectorDataWithoutCounts(fiber),emptySection2={current:[],changes:new Set,changesCounts:new Map},changes={fiberProps:newChanges2.fiberProps||emptySection2,fiberState:newChanges2.fiberState||emptySection2,fiberContext:newChanges2.fiberContext||emptySection2};fiberRenders[displayName]={renderCount:1,hasMemoCache:Ce$1(fiber),wasFiberRenderMount:wasFiberRenderMount(fiber),parents,selfTime:selfTime2,totalTime:totalTime2,nodeInfo:[{element:getHostFromFiber(fiber),name:(_a=we$1(fiber.type))!=null?_a:"Unknown",selfTime:Se$1(fiber).selfTime}],changes};return}if((_c=(_b=getParentCompositeFiber(fiber))==null?void 0:_b[0])!=null&&_c.type){const res=fiber.return&&getParentCompositeFiber(fiber.return),parentCompositeName=res&&we$1(res[0]);parentCompositeName&&existing.parents.add(parentCompositeName)}const{selfTime,totalTime}=Se$1(fiber),newChanges=collectInspectorDataWithoutCounts(fiber);if(!newChanges)return;const emptySection={current:[],changes:new Set,changesCounts:new Map};existing.wasFiberRenderMount=existing.wasFiberRenderMount||wasFiberRenderMount(fiber),existing.hasMemoCache=existing.hasMemoCache||Ce$1(fiber),existing.changes={fiberProps:mergeSectionData(((_d=existing.changes)==null?void 0:_d.fiberProps)||emptySection,newChanges.fiberProps||emptySection),fiberState:mergeSectionData(((_e2=existing.changes)==null?void 0:_e2.fiberState)||emptySection,newChanges.fiberState||emptySection),fiberContext:mergeSectionData(((_f=existing.changes)==null?void 0:_f.fiberContext)||emptySection,newChanges.fiberContext||emptySection)},existing.renderCount+=1,existing.selfTime+=selfTime,existing.totalTime+=totalTime,existing.nodeInfo.push({element:getHostFromFiber(fiber),name:(_g=we$1(fiber.type))!=null?_g:"Unknown",selfTime:Se$1(fiber).selfTime})},"listener");return Store.interactionListeningForRenders=listener,()=>{Store.interactionListeningForRenders===listener&&(Store.interactionListeningForRenders=null)}},"listenForRenders"),mergeSectionData=__name((existing,newData)=>{const mergedSection={current:[...existing.current],changes:new Set,changesCounts:new Map};for(const value of newData.current)mergedSection.current.some(item=>item.name===value.name)||mergedSection.current.push(value);for(const change of newData.changes)if(typeof change=="string"||typeof change=="number"){mergedSection.changes.add(change);const existingCount=existing.changesCounts.get(change)||0,newCount=newData.changesCounts.get(change)||0;mergedSection.changesCounts.set(change,existingCount+newCount)}return mergedSection},"mergeSectionData"),wasFiberRenderMount=__name(fiber=>{if(!fiber.alternate)return!0;const prevFiber=fiber.alternate,wasMounted=prevFiber&&prevFiber.memoizedState!=null&&prevFiber.memoizedState.element!=null&&prevFiber.memoizedState.isDehydrated!==!0,isMounted=fiber.memoizedState!=null&&fiber.memoizedState.element!=null&&fiber.memoizedState.isDehydrated!==!0;return!wasMounted&&isMounted},"wasFiberRenderMount"),createStoreImpl=__name(createState=>{let state;const listeners=new Set,setState=__name((partial,replace)=>{const nextState=typeof partial=="function"?partial(state):partial;if(!Object.is(nextState,state)){const previousState=state;state=replace??(typeof nextState!="object"||nextState===null)?nextState:Object.assign({},state,nextState),listeners.forEach(listener=>listener(state,previousState))}},"setState"),getState=__name(()=>state,"getState"),api={setState,getState,getInitialState:__name(()=>initialState,"getInitialState"),subscribe:__name((selectorOrListener,listener)=>{let selector,actualListener;listener?(selector=selectorOrListener,actualListener=listener):actualListener=selectorOrListener;let currentSlice=selector?selector(state):void 0;const wrappedListener=__name((newState,previousState)=>{if(selector){const nextSlice=selector(newState),prevSlice=selector(previousState);Object.is(currentSlice,nextSlice)||(currentSlice=nextSlice,actualListener(nextSlice,prevSlice))}else actualListener(newState,previousState)},"wrappedListener");return listeners.add(wrappedListener),()=>listeners.delete(wrappedListener)},"subscribe")},initialState=state=createState(setState,getState,api);return api},"createStoreImpl"),createStore=__name((createState=>createState?createStoreImpl(createState):createStoreImpl),"createStore"),accumulatedFiberRendersOverTask=null,EVENT_STORE_CAPACITY=200,toolbarEventStore=createStore()((set,get)=>{const listeners=new Set;return{state:{events:new BoundedArray(EVENT_STORE_CAPACITY)},actions:{addEvent:__name(event=>{listeners.forEach(listener=>listener(event));const events=[...get().state.events,event],applyOverlapCheckToLongRenderEvent=__name((longRenderEvent,onOverlap)=>{const overlapsWith=events.find(event2=>{if(event2.kind!=="long-render"&&event2.id!==longRenderEvent.id&&(longRenderEvent.data.startAt<=event2.data.startAt&&longRenderEvent.data.endAt<=event2.data.endAt&&longRenderEvent.data.endAt>=event2.data.startAt||event2.data.startAt<=longRenderEvent.data.startAt&&event2.data.endAt>=longRenderEvent.data.startAt||longRenderEvent.data.startAt<=event2.data.startAt&&longRenderEvent.data.endAt>=event2.data.endAt))return!0});overlapsWith&&onOverlap(overlapsWith)},"applyOverlapCheckToLongRenderEvent"),toRemove=new Set;events.forEach(event2=>{event2.kind!=="interaction"&&applyOverlapCheckToLongRenderEvent(event2,()=>{toRemove.add(event2.id)})});const withRemovedEvents=events.filter(event2=>!toRemove.has(event2.id));set(()=>({state:{events:BoundedArray.fromArray(withRemovedEvents,EVENT_STORE_CAPACITY)}}))},"addEvent"),addListener:__name(listener=>(listeners.add(listener),()=>{listeners.delete(listener)}),"addListener"),clear:__name(()=>{set({state:{events:new BoundedArray(EVENT_STORE_CAPACITY)}})},"clear")}}}),useToolbarEventLog=__name(()=>C$3(toolbarEventStore.subscribe,toolbarEventStore.getState),"useToolbarEventLog"),taskDirtyAt=null,taskDirtyOrigin=null,previousTrackCurrentMouseOverElementCallback=null,overToolbar,trackCurrentMouseOverToolbar=__name(()=>{const callback=__name(e2=>{overToolbar=e2.composedPath().map(path=>path.id).filter(Boolean).includes("react-scan-toolbar")},"callback");return document.addEventListener("mouseover",callback),previousTrackCurrentMouseOverElementCallback=callback,()=>{previousTrackCurrentMouseOverElementCallback&&document.removeEventListener("mouseover",previousTrackCurrentMouseOverElementCallback)}},"trackCurrentMouseOverToolbar"),startDirtyTaskTracking=__name(()=>{const onVisibilityChange=__name(()=>{taskDirtyAt=performance.now(),taskDirtyOrigin=performance.timeOrigin},"onVisibilityChange");return document.addEventListener("visibilitychange",onVisibilityChange),()=>{document.removeEventListener("visibilitychange",onVisibilityChange)}},"startDirtyTaskTracking"),HIGH_SEVERITY_FPS_DROP_TIME=150,framesDrawnInTheLastSecond=[];function startLongPipelineTracking(){let rafHandle,timeoutHandle;function measure(){let unSub=null;accumulatedFiberRendersOverTask=null,accumulatedFiberRendersOverTask={},unSub=listenForRenders(accumulatedFiberRendersOverTask);const startOrigin=performance.timeOrigin,startTime=performance.now();return rafHandle=requestAnimationFrame(()=>{timeoutHandle=setTimeout(()=>{const endNow=performance.now(),duration=endNow-startTime,endOrigin=performance.timeOrigin;framesDrawnInTheLastSecond.push(endNow+endOrigin);const framesInTheLastSecond=framesDrawnInTheLastSecond.filter(frameAt=>endNow+endOrigin-frameAt<=1e3),fps2=framesInTheLastSecond.length;framesDrawnInTheLastSecond=framesInTheLastSecond;const taskConsideredDirty=taskDirtyAt!==null&&taskDirtyOrigin!==null?endNow+endOrigin-(taskDirtyOrigin+taskDirtyAt)<100:null,wasTaskInfluencedByToolbar=overToolbar!==null&&overToolbar;if(duration>HIGH_SEVERITY_FPS_DROP_TIME&&!taskConsideredDirty&&document.visibilityState==="visible"&&!wasTaskInfluencedByToolbar){const endAt=endOrigin+endNow,startAt=startTime+startOrigin;toolbarEventStore.getState().actions.addEvent({kind:"long-render",id:not_globally_unique_generateId(),data:{endAt,startAt,meta:{fiberRenders:accumulatedFiberRendersOverTask,latency:duration,fps:fps2}}})}taskDirtyAt=null,taskDirtyOrigin=null,unSub?.(),measure()},0)}),unSub}__name(measure,"measure");const measureUnSub=measure();return()=>{measureUnSub(),cancelAnimationFrame(rafHandle),clearTimeout(timeoutHandle)}}__name(startLongPipelineTracking,"startLongPipelineTracking");var startTimingTracking=__name(()=>{const unSubPerformance=setupPerformancePublisher(),unSubMouseOver=trackCurrentMouseOverToolbar(),unSubDirtyTaskTracking=startDirtyTaskTracking(),unSubLongPipelineTracking=startLongPipelineTracking(),onComplete=__name(async(_2,finalInteraction,event)=>{toolbarEventStore.getState().actions.addEvent({kind:"interaction",id:not_globally_unique_generateId(),data:{startAt:finalInteraction.detailedTiming.blockingTimeStart,endAt:performance.now()+performance.timeOrigin,meta:{...finalInteraction,kind:event.kind}}});const existingCompletedInteractions=performanceEntryChannels.getChannelState("recording");finalInteraction.detailedTiming.stopListeningForRenders(),existingCompletedInteractions.length&&performanceEntryChannels.updateChannelState("recording",()=>new BoundedArray(MAX_CHANNEL_SIZE))},"onComplete"),unSubDetailedPointerTiming=setupDetailedPointerTimingListener("pointer",{onComplete}),unSubDetailedKeyboardTiming=setupDetailedPointerTimingListener("keyboard",{onComplete}),unSubInteractions=listenForPerformanceEntryInteractions(completedInteraction=>{interactionStore.setState(BoundedArray.fromArray(interactionStore.getCurrentState().concat(completedInteraction),MAX_INTERACTION_BATCH))});return()=>{unSubMouseOver(),unSubDirtyTaskTracking(),unSubLongPipelineTracking(),unSubPerformance(),unSubDetailedPointerTiming(),unSubInteractions(),unSubDetailedKeyboardTiming()}},"startTimingTracking"),getComponentName=__name(path=>{var _a;const filteredPath=path.filter(item=>item.length>2);return filteredPath.length===0?(_a=path.at(-1))!=null?_a:"Unknown":filteredPath.at(-1)},"getComponentName"),getTotalTime=__name(timing=>{switch(timing.kind){case"interaction":{const{renderTime,otherJSTime,framePreparation,frameConstruction,frameDraw}=timing;return renderTime+otherJSTime+framePreparation+frameConstruction+(frameDraw??0)}case"dropped-frames":return timing.otherTime+timing.renderTime}},"getTotalTime"),isRenderMemoizable=__name(groupedFiberRender=>groupedFiberRender.wasFiberRenderMount||groupedFiberRender.hasMemoCache?!1:groupedFiberRender.changes.context.length===0&&groupedFiberRender.changes.props.length===0&&groupedFiberRender.changes.state.length===0,"isRenderMemoizable"),getEventSeverity=__name(event=>{const totalTime=getTotalTime(event.timing);switch(event.kind){case"interaction":return totalTime<200?"low":totalTime<500?"needs-improvement":"high";case"dropped-frames":return totalTime<50?"low":totalTime<HIGH_SEVERITY_FPS_DROP_TIME?"needs-improvement":"high"}},"getEventSeverity"),useNotificationsContext=__name(()=>x$5(NotificationStateContext),"useNotificationsContext"),NotificationStateContext=X$1(null),ChevronRight=__name(({size=24,className})=>u$2("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className:cn(["lucide lucide-chevron-right",className]),children:u$2("path",{d:"m9 18 6-6-6-6"})}),"ChevronRight"),Notification=__name(({className="",size=24,events=[]})=>{const hasHighSeverity=events.includes(!0),totalSevere=events.filter(e2=>e2).length,displayCount=totalSevere>99?">99":totalSevere,badgeSize=hasHighSeverity?Math.max(size*.6,14):Math.max(size*.4,6);return u$2("div",{className:"relative",children:[u$2("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className:`lucide lucide-bell ${className}`,children:[u$2("path",{d:"M10.268 21a2 2 0 0 0 3.464 0"}),u$2("path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326"})]}),events.length>0&&totalSevere>0&&ReactScanInternals.options.value.showNotificationCount&&u$2("div",{className:cn(["absolute",hasHighSeverity?"-top-2.5 -right-2.5":"-top-1 -right-1","rounded-full","flex items-center justify-center","text-[8px] font-medium text-white","aspect-square",hasHighSeverity?"bg-red-500/90":"bg-purple-500/90"]),style:{width:`${badgeSize}px`,height:`${badgeSize}px`,padding:hasHighSeverity?"0.5px":"0"},children:hasHighSeverity&&displayCount})]})},"Notification"),CloseIcon=__name(({className="",size=24})=>u$2("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className,children:[u$2("path",{d:"M18 6 6 18"}),u$2("path",{d:"m6 6 12 12"})]}),"CloseIcon"),VolumeOnIcon=__name(({className="",size=24})=>u$2("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className,children:[u$2("path",{d:"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"}),u$2("path",{d:"M16 9a5 5 0 0 1 0 6"}),u$2("path",{d:"M19.364 18.364a9 9 0 0 0 0-12.728"})]}),"VolumeOnIcon"),VolumeOffIcon=__name(({className="",size=24})=>u$2("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className,children:[u$2("path",{d:"M16 9a5 5 0 0 1 .95 2.293"}),u$2("path",{d:"M19.364 5.636a9 9 0 0 1 1.889 9.96"}),u$2("path",{d:"m2 2 20 20"}),u$2("path",{d:"m7 7-.587.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298V11"}),u$2("path",{d:"M9.828 4.172A.686.686 0 0 1 11 4.657v.686"})]}),"VolumeOffIcon"),ArrowLeft=__name(({size=24,className})=>u$2("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className:cn(["lucide lucide-arrow-left",className]),children:[u$2("path",{d:"m12 19-7-7 7-7"}),u$2("path",{d:"M19 12H5"})]}),"ArrowLeft"),PointerIcon=__name(({className="",size=24})=>u$2("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className,children:[u$2("path",{d:"M14 4.1 12 6"}),u$2("path",{d:"m5.1 8-2.9-.8"}),u$2("path",{d:"m6 12-1.9 2"}),u$2("path",{d:"M7.2 2.2 8 5.1"}),u$2("path",{d:"M9.037 9.69a.498.498 0 0 1 .653-.653l11 4.5a.5.5 0 0 1-.074.949l-4.349 1.041a1 1 0 0 0-.74.739l-1.04 4.35a.5.5 0 0 1-.95.074z"})]}),"PointerIcon"),KeyboardIcon=__name(({className="",size=24})=>u$2("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className,children:[u$2("path",{d:"M10 8h.01"}),u$2("path",{d:"M12 12h.01"}),u$2("path",{d:"M14 8h.01"}),u$2("path",{d:"M16 12h.01"}),u$2("path",{d:"M18 8h.01"}),u$2("path",{d:"M6 8h.01"}),u$2("path",{d:"M7 16h10"}),u$2("path",{d:"M8 12h.01"}),u$2("rect",{width:"20",height:"16",x:"2",y:"4",rx:"2"})]}),"KeyboardIcon"),ClearIcon=__name(({className="",size=24})=>u$2("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",className,style:{transform:"rotate(180deg)"},children:[u$2("circle",{cx:"12",cy:"12",r:"10"}),u$2("path",{d:"m4.9 4.9 14.2 14.2"})]}),"ClearIcon"),TrendingDownIcon=__name(({className="",size=24})=>u$2("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className,children:[u$2("polyline",{points:"22 17 13.5 8.5 8.5 13.5 2 7"}),u$2("polyline",{points:"16 17 22 17 22 11"})]}),"TrendingDownIcon"),Popover=__name(({children,triggerContent,wrapperProps})=>{const[popoverState,setPopoverState]=d$4("closed"),[elBoundingRect,setElBoundingRect]=d$4(null),[viewportSize,setViewportSize]=d$4({width:window.innerWidth,height:window.innerHeight}),triggerRef=A$3(null),popoverRef=A$3(null),portalEl=x$5(ToolbarElementContext),isHoveredRef=A$3(!1);y$5(()=>{const handleResize=__name(()=>{setViewportSize({width:window.innerWidth,height:window.innerHeight}),updateRect()},"handleResize");return window.addEventListener("resize",handleResize),()=>window.removeEventListener("resize",handleResize)},[]);const updateRect=__name(()=>{if(triggerRef.current&&portalEl){const triggerRect=triggerRef.current.getBoundingClientRect(),portalRect=portalEl.getBoundingClientRect(),centerX=triggerRect.left+triggerRect.width/2,centerY=triggerRect.top;setElBoundingRect(new DOMRect(centerX-portalRect.left,centerY-portalRect.top,triggerRect.width,triggerRect.height))}},"updateRect");y$5(()=>{updateRect()},[triggerRef.current]),y$5(()=>{if(popoverState==="opening"){const timer2=setTimeout(()=>setPopoverState("open"),120);return()=>clearTimeout(timer2)}else if(popoverState==="closing"){const timer2=setTimeout(()=>setPopoverState("closed"),120);return()=>clearTimeout(timer2)}},[popoverState]),y$5(()=>{const interval=setInterval(()=>{!isHoveredRef.current&&popoverState!=="closed"&&setPopoverState("closing")},1e3);return()=>clearInterval(interval)},[popoverState]);const handleMouseEnter=__name(()=>{isHoveredRef.current=!0,updateRect(),setPopoverState("opening")},"handleMouseEnter"),handleMouseLeave=__name(()=>{isHoveredRef.current=!1,updateRect(),setPopoverState("closing")},"handleMouseLeave"),popoverPosition=__name(()=>{var _a;if(!elBoundingRect||!portalEl)return{top:0,left:0};const portalRect=portalEl.getBoundingClientRect(),popoverWidth=175,popoverHeight=((_a=popoverRef.current)==null?void 0:_a.offsetHeight)||40,safeArea=5,viewportX=elBoundingRect.x+portalRect.left,viewportY=elBoundingRect.y+portalRect.top;let left=viewportX,top=viewportY-4;return left-popoverWidth/2<safeArea?left=safeArea+popoverWidth/2:left+popoverWidth/2>viewportSize.width-safeArea&&(left=viewportSize.width-safeArea-popoverWidth/2),top-popoverHeight<safeArea&&(top=viewportY+elBoundingRect.height+4),{top:top-portalRect.top,left:left-portalRect.left}},"getPopoverPosition")();return u$2(S$4,{children:[portalEl&&elBoundingRect&&popoverState!=="closed"&&$(u$2("div",{ref:popoverRef,className:cn(["absolute z-100 bg-white text-black rounded-lg px-3 py-2 shadow-lg","transition-[opacity] duration-120 ease-out",'after:content-[""] after:absolute after:top-[100%]',"after:left-1/2 after:-translate-x-1/2","after:w-[10px] after:h-[6px]","after:border-l-[5px] after:border-l-transparent","after:border-r-[5px] after:border-r-transparent","after:border-t-[6px] after:border-t-white","pointer-events-none",popoverState==="opening"||popoverState==="closing"?"opacity-0":"opacity-100"]),style:{top:popoverPosition.top+"px",left:popoverPosition.left+"px",transform:`translate(-50%, calc(-100% - 4px)) scale(${popoverState==="open"?1:.97})`,minWidth:"175px",willChange:"opacity, transform"},children}),portalEl),u$2("div",{ref:triggerRef,onMouseEnter:handleMouseEnter,onMouseLeave:handleMouseLeave,...wrapperProps,children:triggerContent})]})},"Popover"),NotificationTabs=__name(({selectedEvent:_2})=>{const{notificationState,setNotificationState,setRoute}=useNotificationsContext();return u$2("div",{className:cn(["flex w-full justify-between items-center px-3 py-2 text-xs"]),children:[u$2("div",{className:cn(["bg-[#18181B] flex items-center gap-x-1 p-1 rounded-sm"]),children:[u$2("button",{onClick:__name(()=>{setRoute({route:"render-visualization",routeMessage:null})},"onClick"),className:cn(["w-1/2 flex items-center justify-center whitespace-nowrap py-[5px] px-1 gap-x-1",notificationState.route==="render-visualization"||notificationState.route==="render-explanation"?"text-white bg-[#7521c8] rounded-sm":"text-[#6E6E77] bg-[#18181B] rounded-sm"]),children:"Ranked"}),u$2("button",{onClick:__name(()=>{setRoute({route:"other-visualization",routeMessage:null})},"onClick"),className:cn(["w-1/2 flex items-center justify-center whitespace-nowrap py-[5px] px-1 gap-x-1",notificationState.route==="other-visualization"?"text-white bg-[#7521c8] rounded-sm":"text-[#6E6E77] bg-[#18181B] rounded-sm"]),children:"Overview"}),u$2("button",{onClick:__name(()=>{setRoute({route:"optimize",routeMessage:null})},"onClick"),className:cn(["w-1/2 flex items-center justify-center whitespace-nowrap py-[5px] px-1 gap-x-1",notificationState.route==="optimize"?"text-white bg-[#7521c8] rounded-sm":"text-[#6E6E77] bg-[#18181B] rounded-sm"]),children:u$2("span",{children:"Prompts"})})]}),u$2(Popover,{triggerContent:u$2("button",{onClick:__name(()=>{setNotificationState(prev=>{prev.audioNotificationsOptions.enabled&&prev.audioNotificationsOptions.audioContext.state!=="closed"&&prev.audioNotificationsOptions.audioContext.close();const prevEnabledState=prev.audioNotificationsOptions.enabled;localStorage.setItem("react-scan-notifications-audio",String(!prevEnabledState));const audioContext=new AudioContext;return prev.audioNotificationsOptions.enabled||playNotificationSound(audioContext),prevEnabledState&&audioContext.close(),{...prev,audioNotificationsOptions:prevEnabledState?{audioContext:null,enabled:!1}:{audioContext,enabled:!0}}})},"onClick"),className:"ml-auto",children:u$2("div",{className:cn(["flex gap-x-2 justify-center items-center text-[#6E6E77]"]),children:[u$2("span",{children:"Alerts"}),notificationState.audioNotificationsOptions.enabled?u$2(VolumeOnIcon,{size:16,className:"text-[#6E6E77]"}):u$2(VolumeOffIcon,{size:16,className:"text-[#6E6E77]"})]})}),children:u$2(S$4,{children:"Play a chime when a slowdown is recorded"})})]})},"NotificationTabs"),formatReactData=__name(groupedFiberRenders=>{let text="";return groupedFiberRenders.toSorted((a2,b2)=>b2.totalTime-a2.totalTime).slice(0,30).filter(fiber=>fiber.totalTime>5).forEach(fiberRender=>{let localText="";localText+="Component Name:",localText+=fiberRender.name,localText+=`
`,localText+=`Rendered: ${fiberRender.count} times
`,localText+=`Sum of self times for ${fiberRender.name} is ${fiberRender.totalTime.toFixed(0)}ms
`,fiberRender.changes.props.length>0&&(localText+=`Changed props for all ${fiberRender.name} instances ("name:count" pairs)
`,fiberRender.changes.props.forEach(change=>{localText+=`${change.name}:${change.count}x
`})),fiberRender.changes.state.length>0&&(localText+=`Changed state for all ${fiberRender.name} instances ("hook index:count" pairs)
`,fiberRender.changes.state.forEach(change=>{localText+=`${change.index}:${change.count}x
`})),fiberRender.changes.context.length>0&&(localText+=`Changed context for all ${fiberRender.name} instances ("context display name (if exists):count" pairs)
`,fiberRender.changes.context.forEach(change=>{localText+=`${change.name}:${change.count}x
`})),text+=localText,text+=`
`}),text},"formatReactData"),generateInteractionDataPrompt=__name(({renderTime,eHandlerTimeExcludingRenders,toRafTime,commitTime,framePresentTime,formattedReactData})=>`I will provide you with a set of high level, and low level performance data about an interaction in a React App:
### High level
- react component render time: ${renderTime.toFixed(0)}ms
- how long it took to run javascript event handlers (EXCLUDING REACT RENDERS): ${eHandlerTimeExcludingRenders.toFixed(0)}ms
- how long it took from the last event handler time, to the last request animation frame: ${toRafTime.toFixed(0)}ms
	- things like prepaint, style recalculations, layerization, async web API's like observers may occur during this time
- how long it took from the last request animation frame to when the dom was committed: ${commitTime.toFixed(0)}ms
	- during this period you will see paint, commit, potential style recalcs, and other misc browser activity. Frequently high times here imply css that makes the browser do a lot of work, or mutating expensive dom properties during the event handler stage. This can be many things, but it narrows the problem scope significantly when this is high
${framePresentTime===null?"":`- how long it took from dom commit for the frame to be presented: ${framePresentTime.toFixed(0)}ms. This is when information about how to paint the next frame is sent to the compositor threads, and when the GPU does work. If this is high, look for issues that may be a bottleneck for operations occurring during this time`}

### Low level
We also have lower level information about react components, such as their render time, and which props/state/context changed when they re-rendered.
${formattedReactData}`,"generateInteractionDataPrompt"),generateInteractionOptimizationPrompt=__name(({interactionType,name,componentPath,time,renderTime,eHandlerTimeExcludingRenders,toRafTime,commitTime,framePresentTime,formattedReactData})=>`You will attempt to implement a performance improvement to a user interaction in a React app. You will be provided with data about the interaction, and the slow down.

Your should split your goals into 2 parts:
- identifying the problem
- fixing the problem
	- it is okay to implement a fix even if you aren't 100% sure the fix solves the performance problem. When you aren't sure, you should tell the user to try repeating the interaction, and feeding the "Formatted Data" in the React Scan notifications optimize tab. This allows you to start a debugging flow with the user, where you attempt a fix, and observe the result. The user may make a mistake when they pass you the formatted data, so must make sure, given the data passed to you, that the associated data ties to the same interaction you were trying to debug.


Make sure to check if the user has the react compiler enabled (project dependent, configured through build tool), so you don't unnecessarily memoize components. If it is, you do not need to worry about memoizing user components

One challenge you may face is the performance problem lies in a node_module, not in user code. If you are confident the problem originates because of a node_module, there are multiple strategies, which are context dependent:
- you can try to work around the problem, knowing which module is slow
- you can determine if its possible to resolve the problem in the node_module by modifying non node_module code
- you can monkey patch the node_module to experiment and see if it's really the problem (you can modify a functions properties to hijack the call for example)
- you can determine if it's feasible to replace whatever node_module is causing the problem with a performant option (this is an extreme)

The interaction was a ${interactionType} on the component named ${name}. This component has the following ancestors ${componentPath}. This is the path from the component, to the root. This should be enough information to figure out where this component is in the user's code base

This path is the component that was clicked, so it should tell you roughly where component had an event handler that triggered a state change.

Please note that the leaf node of this path might not be user code (if they use a UI library), and they may contain many wrapper components that just pass through children that aren't relevant to the actual click. So make you sure analyze the path and understand what the user code is doing

We have a set of high level, and low level data about the performance issue.

The click took ${time.toFixed(0)}ms from interaction start, to when a new frame was presented to a user.

We also provide you with a breakdown of what the browser spent time on during the period of interaction start to frame presentation.

- react component render time: ${renderTime.toFixed(0)}ms
- how long it took to run javascript event handlers (EXCLUDING REACT RENDERS): ${eHandlerTimeExcludingRenders.toFixed(0)}ms
- how long it took from the last event handler time, to the last request animation frame: ${toRafTime.toFixed(0)}ms
	- things like prepaint, style recalculations, layerization, async web API's like observers may occur during this time
- how long it took from the last request animation frame to when the dom was committed: ${commitTime.toFixed(0)}ms
	- during this period you will see paint, commit, potential style recalcs, and other misc browser activity. Frequently high times here imply css that makes the browser do a lot of work, or mutating expensive dom properties during the event handler stage. This can be many things, but it narrows the problem scope significantly when this is high
${framePresentTime===null?"":`- how long it took from dom commit for the frame to be presented: ${framePresentTime.toFixed(0)}ms. This is when information about how to paint the next frame is sent to the compositor threads, and when the GPU does work. If this is high, look for issues that may be a bottleneck for operations occurring during this time`}


We also have lower level information about react components, such as their render time, and which props/state/context changed when they re-rendered.

${formattedReactData}

You may notice components have many renders, but much fewer props/state/context changes. This normally implies most of the components could have been memoized to avoid computation

It's also important to remember if a component had no props/state/context change, and it was memoized, it would not render. So the flow should be:
- find the most expensive components
- see what's causing them to render
- determine how you can make those state/props/context not change for a large set of the renders
- once there are no more changes left, you can memoize the component so it no longer unnecessarily re-renders. 

An important thing to note is that if you see a lot of react renders (some components with very high render counts), but javascript excluding renders is much higher than render time, it is possible that the components with lots of renders run hooks like useEffect/useLayoutEffect, which run during the JS event handler period.

It's also good to note that react profiles hook times in development, and if many hooks are called (lets say 5,000 components all called a useEffect), it will have to profile every single one. And it may also be the case the comparison of the hooks dependency can be expensive, and that would not be tracked in render time.

If a node_module is the component with high renders, you can experiment to see if that component is the root issue (because of hooks). You should use the same instructions for node_module debugging mentioned previously.

`,"generateInteractionOptimizationPrompt"),generateFrameDropOptimizationPrompt=__name(({renderTime,otherTime,formattedReactData})=>`You will attempt to implement a performance improvement to a large slowdown in a react app

Your should split your goals into 2 parts:
- identifying the problem
- fixing the problem
	- it is okay to implement a fix even if you aren't 100% sure the fix solves the performance problem. When you aren't sure, you should tell the user to try repeating the interaction, and feeding the "Formatted Data" in the React Scan notifications optimize tab. This allows you to start a debugging flow with the user, where you attempt a fix, and observe the result. The user may make a mistake when they pass you the formatted data, so must make sure, given the data passed to you, that the associated data ties to the same interaction you were trying to debug.

Make sure to check if the user has the react compiler enabled (project dependent, configured through build tool), so you don't unnecessarily memoize components. If it is, you do not need to worry about memoizing user components

One challenge you may face is the performance problem lies in a node_module, not in user code. If you are confident the problem originates because of a node_module, there are multiple strategies, which are context dependent:
- you can try to work around the problem, knowing which module is slow
- you can determine if its possible to resolve the problem in the node_module by modifying non node_module code
- you can monkey patch the node_module to experiment and see if it's really the problem (you can modify a functions properties to hijack the call for example)
- you can determine if it's feasible to replace whatever node_module is causing the problem with a performant option (this is an extreme)


We have the high level time of how much react spent rendering, and what else the browser spent time on during this slowdown

- react component render time: ${renderTime.toFixed(0)}ms
- other time: ${otherTime}ms


We also have lower level information about react components, such as their render time, and which props/state/context changed when they re-rendered.

${formattedReactData}

You may notice components have many renders, but much fewer props/state/context changes. This normally implies most of the components could have been memoized to avoid computation

It's also important to remember if a component had no props/state/context change, and it was memoized, it would not render. So the flow should be:
- find the most expensive components
- see what's causing them to render
- determine how you can make those state/props/context not change for a large set of the renders
- once there are no more changes left, you can memoize the component so it no longer unnecessarily re-renders. 

An important thing to note is that if you see a lot of react renders (some components with very high render counts), but other time is much higher than render time, it is possible that the components with lots of renders run hooks like useEffect/useLayoutEffect, which run outside of what we profile (just react render time).

It's also good to note that react profiles hook times in development, and if many hooks are called (lets say 5,000 components all called a useEffect), it will have to profile every single one. And it may also be the case the comparison of the hooks dependency can be expensive, and that would not be tracked in render time.

If a node_module is the component with high renders, you can experiment to see if that component is the root issue (because of hooks). You should use the same instructions for node_module debugging mentioned previously.

If renders don't seem to be the problem, see if there are any expensive CSS properties being added/mutated, or any expensive DOM Element mutations/new elements being created that could cause this slowdown. 
`,"generateFrameDropOptimizationPrompt"),generateFrameDropExplanationPrompt=__name(({renderTime,otherTime,formattedReactData})=>`Your goal will be to help me find the source of a performance problem in a React App. I collected a large dataset about this specific performance problem.

We have the high level time of how much react spent rendering, and what else the browser spent time on during this slowdown

- react component render time: ${renderTime.toFixed(0)}ms
- other time (other JavaScript, hooks like useEffect, style recalculations, layerization, paint & commit and everything else the browser might do to draw a new frame after javascript mutates the DOM): ${otherTime}ms


We also have lower level information about react components, such as their render time, and which props/state/context changed when they re-rendered.

${formattedReactData}

You may notice components have many renders, but much fewer props/state/context changes. This normally implies most of the components could have been memoized to avoid computation

It's also important to remember if a component had no props/state/context change, and it was memoized, it would not render. So a flow we can go through is:
- find the most expensive components
- see what's causing them to render
- determine how you can make those state/props/context not change for a large set of the renders
- once there are no more changes left, you can memoize the component so it no longer unnecessarily re-renders. 


An important thing to note is that if you see a lot of react renders (some components with very high render counts), but other time is much higher than render time, it is possible that the components with lots of renders run hooks like useEffect/useLayoutEffect, which run outside of what we profile (just react render time).

It's also good to note that react profiles hook times in development, and if many hooks are called (lets say 5,000 components all called a useEffect), it will have to profile every single one, and this can add significant overhead when thousands of effects ran.

If it's not possible to explain the root problem from this data, please ask me for more data explicitly, and what we would need to know to find the source of the performance problem.
`,"generateFrameDropExplanationPrompt"),generateFrameDropDataPrompt=__name(({renderTime,otherTime,formattedReactData})=>`I will provide you with a set of high level, and low level performance data about a large frame drop in a React App:
### High level
- react component render time: ${renderTime.toFixed(0)}ms
- how long it took to run everything else (other JavaScript, hooks like useEffect, style recalculations, layerization, paint & commit and everything else the browser might do to draw a new frame after javascript mutates the DOM): ${otherTime}ms

### Low level
We also have lower level information about react components, such as their render time, and which props/state/context changed when they re-rendered.
${formattedReactData}`,"generateFrameDropDataPrompt"),generateInteractionExplanationPrompt=__name(({interactionType,name,time,renderTime,eHandlerTimeExcludingRenders,toRafTime,commitTime,framePresentTime,formattedReactData})=>`Your goal will be to help me find the source of a performance problem. I collected a large dataset about this specific performance problem.

There was a ${interactionType} on a component named ${name}. This means, roughly, the component that handled the ${interactionType} event was named ${name}.

We have a set of high level, and low level data about the performance issue.

The click took ${time.toFixed(0)}ms from interaction start, to when a new frame was presented to a user.

We also provide you with a breakdown of what the browser spent time on during the period of interaction start to frame presentation.

- react component render time: ${renderTime.toFixed(0)}ms
- how long it took to run javascript event handlers (EXCLUDING REACT RENDERS): ${eHandlerTimeExcludingRenders.toFixed(0)}ms
- how long it took from the last event handler time, to the last request animation frame: ${toRafTime.toFixed(0)}ms
	- things like prepaint, style recalculations, layerization, async web API's like observers may occur during this time
- how long it took from the last request animation frame to when the dom was committed: ${commitTime.toFixed(0)}ms
	- during this period you will see paint, commit, potential style recalcs, and other misc browser activity. Frequently high times here imply css that makes the browser do a lot of work, or mutating expensive dom properties during the event handler stage. This can be many things, but it narrows the problem scope significantly when this is high
${framePresentTime===null?"":`- how long it took from dom commit for the frame to be presented: ${framePresentTime.toFixed(0)}ms. This is when information about how to paint the next frame is sent to the compositor threads, and when the GPU does work. If this is high, look for issues that may be a bottleneck for operations occurring during this time`}

We also have lower level information about react components, such as their render time, and which props/state/context changed when they re-rendered.

${formattedReactData}


You may notice components have many renders, but much fewer props/state/context changes. This normally implies most of the components could have been memoized to avoid computation

It's also important to remember if a component had no props/state/context change, and it was memoized, it would not render. So a flow we can go through is:
- find the most expensive components
- see what's causing them to render
- determine how you can make those state/props/context not change for a large set of the renders
- once there are no more changes left, you can memoize the component so it no longer unnecessarily re-renders. 


An important thing to note is that if you see a lot of react renders (some components with very high render counts), but javascript excluding renders is much higher than render time, it is possible that the components with lots of renders run hooks like useEffect/useLayoutEffect, which run during the JS event handler period.

It's also good to note that react profiles hook times in development, and if many hooks are called (lets say 5,000 components all called a useEffect), it will have to profile every single one. And it may also be the case the comparison of the hooks dependency can be expensive, and that would not be tracked in render time.

If it's not possible to explain the root problem from this data, please ask me for more data explicitly, and what we would need to know to find the source of the performance problem.
`,"generateInteractionExplanationPrompt"),getLLMPrompt=__name((activeTab,selectedEvent)=>iife(()=>{switch(activeTab){case"data":switch(selectedEvent.kind){case"dropped-frames":return generateFrameDropDataPrompt({formattedReactData:formatReactData(selectedEvent.groupedFiberRenders),renderTime:selectedEvent.groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0),otherTime:selectedEvent.timing.otherTime});case"interaction":return generateInteractionDataPrompt({commitTime:selectedEvent.timing.frameConstruction,eHandlerTimeExcludingRenders:selectedEvent.timing.otherJSTime,formattedReactData:formatReactData(selectedEvent.groupedFiberRenders),framePresentTime:selectedEvent.timing.frameDraw,renderTime:selectedEvent.groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0),toRafTime:selectedEvent.timing.framePreparation})}case"explanation":switch(selectedEvent.kind){case"dropped-frames":return generateFrameDropExplanationPrompt({formattedReactData:formatReactData(selectedEvent.groupedFiberRenders),renderTime:selectedEvent.groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0),otherTime:selectedEvent.timing.otherTime});case"interaction":return generateInteractionExplanationPrompt({commitTime:selectedEvent.timing.frameConstruction,eHandlerTimeExcludingRenders:selectedEvent.timing.otherJSTime,formattedReactData:formatReactData(selectedEvent.groupedFiberRenders),framePresentTime:selectedEvent.timing.frameDraw,interactionType:selectedEvent.type,name:getComponentName(selectedEvent.componentPath),renderTime:selectedEvent.groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0),time:getTotalTime(selectedEvent.timing),toRafTime:selectedEvent.timing.framePreparation})}case"fix":switch(selectedEvent.kind){case"dropped-frames":return generateFrameDropOptimizationPrompt({formattedReactData:formatReactData(selectedEvent.groupedFiberRenders),renderTime:selectedEvent.groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0),otherTime:selectedEvent.timing.otherTime});case"interaction":return generateInteractionOptimizationPrompt({commitTime:selectedEvent.timing.frameConstruction,componentPath:selectedEvent.componentPath.join(">"),eHandlerTimeExcludingRenders:selectedEvent.timing.otherJSTime,formattedReactData:formatReactData(selectedEvent.groupedFiberRenders),framePresentTime:selectedEvent.timing.frameDraw,interactionType:selectedEvent.type,name:getComponentName(selectedEvent.componentPath),renderTime:selectedEvent.groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0),time:getTotalTime(selectedEvent.timing),toRafTime:selectedEvent.timing.framePreparation})}}}),"getLLMPrompt"),Optimize=__name(({selectedEvent})=>{const[activeTab,setActiveTab]=d$4("fix"),[copying,setCopying]=d$4(!1);return u$2("div",{className:cn(["w-full h-full"]),children:[u$2("div",{className:cn(["border border-[#27272A] rounded-sm h-4/5 text-xs overflow-hidden"]),children:[u$2("div",{className:cn(["bg-[#18181B] p-1 rounded-t-sm"]),children:u$2("div",{className:cn(["flex items-center gap-x-1"]),children:[u$2("button",{onClick:__name(()=>setActiveTab("fix"),"onClick"),className:cn(["flex items-center justify-center whitespace-nowrap py-1.5 px-3 rounded-sm",activeTab==="fix"?"text-white bg-[#7521c8]":"text-[#6E6E77] hover:text-white"]),children:"Fix"}),u$2("button",{onClick:__name(()=>setActiveTab("explanation"),"onClick"),className:cn(["flex items-center justify-center whitespace-nowrap py-1.5 px-3 rounded-sm",activeTab==="explanation"?"text-white bg-[#7521c8]":"text-[#6E6E77] hover:text-white"]),children:"Explanation"}),u$2("button",{onClick:__name(()=>setActiveTab("data"),"onClick"),className:cn(["flex items-center justify-center whitespace-nowrap py-1.5 px-3 rounded-sm",activeTab==="data"?"text-white bg-[#7521c8]":"text-[#6E6E77] hover:text-white"]),children:"Data"})]})}),u$2("div",{className:cn(["overflow-y-auto h-full"]),children:u$2("pre",{className:cn(["p-2 h-full","whitespace-pre-wrap break-words","text-gray-300 font-mono "]),children:getLLMPrompt(activeTab,selectedEvent)})})]}),u$2("button",{onClick:__name(async()=>{const text=getLLMPrompt(activeTab,selectedEvent);await navigator.clipboard.writeText(text),setCopying(!0),setTimeout(()=>setCopying(!1),1e3)},"onClick"),className:cn(["mt-4 px-4 py-2 bg-[#18181B] text-[#6E6E77] rounded-sm","hover:text-white transition-colors duration-200","flex items-center justify-center gap-x-2 text-xs"]),children:[u$2("span",{children:copying?"Copied!":"Copy Prompt"}),u$2("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className:cn(["transition-transform duration-200",copying&&"scale-110"]),children:copying?u$2("path",{d:"M20 6L9 17l-5-5"}):u$2(S$4,{children:[u$2("rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2"}),u$2("path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"})]})})]})]})},"Optimize"),getTimeData=__name((selectedEvent,isProduction2)=>{switch(selectedEvent.kind){case"dropped-frames":return[...isProduction2?[{name:"Total Processing Time",time:getTotalTime(selectedEvent.timing),color:"bg-red-500",kind:"total-processing-time"}]:[{name:"Renders",time:selectedEvent.timing.renderTime,color:"bg-purple-500",kind:"render"},{name:"JavaScript, DOM updates, Draw Frame",time:selectedEvent.timing.otherTime,color:"bg-[#4b4b4b]",kind:"other-frame-drop"}]];case"interaction":return[...isProduction2?[]:[{name:"Renders",time:selectedEvent.timing.renderTime,color:"bg-purple-500",kind:"render"}],{name:isProduction2?"React Renders, Hooks, Other JavaScript":"JavaScript/React Hooks ",time:selectedEvent.timing.otherJSTime,color:"bg-[#EFD81A]",kind:"other-javascript"},{name:"Update DOM and Draw New Frame",time:getTotalTime(selectedEvent.timing)-selectedEvent.timing.renderTime-selectedEvent.timing.otherJSTime,color:"bg-[#1D3A66]",kind:"other-not-javascript"}]}},"getTimeData"),OtherVisualization=__name(({selectedEvent})=>{var _a,_b;const[isProduction2]=d$4((_a=getIsProduction())!=null?_a:!1),{notificationState}=useNotificationsContext(),[expandedItems,setExpandedItems]=d$4((_b=notificationState.routeMessage)!=null&&_b.name?[notificationState.routeMessage.name]:[]),timeData=getTimeData(selectedEvent,isProduction2),root=x$5(ToolbarElementContext);y$5(()=>{var _a2;if((_a2=notificationState.routeMessage)!=null&&_a2.name){const container=root?.querySelector("#overview-scroll-container"),element=root?.querySelector(`#react-scan-overview-bar-${notificationState.routeMessage.name}`);if(container&&element){const scrollOffset=element.getBoundingClientRect().top-container.getBoundingClientRect().top;container.scrollTop=container.scrollTop+scrollOffset}}},[notificationState.route]),y$5(()=>{notificationState.route==="other-visualization"&&setExpandedItems(prev=>{var _a2;return(_a2=notificationState.routeMessage)!=null&&_a2.name?[notificationState.routeMessage.name]:prev})},[notificationState.route]);const totalTime=timeData.reduce((acc,item)=>acc+item.time,0);return u$2("div",{className:"rounded-sm border border-zinc-800 text-xs",children:[u$2("div",{className:"p-2 border-b border-zinc-800 bg-zinc-900/50",children:u$2("div",{className:"flex items-center justify-between",children:[u$2("h3",{className:"text-xs font-medium",children:"What was time spent on?"}),u$2("span",{className:"text-xs text-zinc-400",children:["Total: ",totalTime.toFixed(0),"ms"]})]})}),u$2("div",{className:"divide-y divide-zinc-800",children:timeData.map(entry=>{const isExpanded=expandedItems.includes(entry.kind);return u$2("div",{id:`react-scan-overview-bar-${entry.kind}`,children:[u$2("button",{onClick:__name(()=>setExpandedItems(prev=>prev.includes(entry.kind)?prev.filter(item=>item!==entry.kind):[...prev,entry.kind]),"onClick"),className:"w-full px-3 py-2 flex items-center gap-4 hover:bg-zinc-800/50 transition-colors",children:u$2("div",{className:"flex-1",children:[u$2("div",{className:"flex items-center justify-between mb-2",children:[u$2("div",{className:"flex items-center gap-0.5",children:[u$2("svg",{className:`h-4 w-4 text-zinc-400 transition-transform ${isExpanded?"rotate-90":""}`,fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:u$2("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 5l7 7-7 7"})}),u$2("span",{className:"font-medium flex items-center text-left",children:entry.name})]}),u$2("span",{className:" text-zinc-400",children:[entry.time.toFixed(0),"ms"]})]}),u$2("div",{className:"h-1 bg-zinc-800 rounded-full overflow-hidden",children:u$2("div",{className:`h-full ${entry.color} transition-all`,style:{width:`${entry.time/totalTime*100}%`}})})]})}),isExpanded&&u$2("div",{className:"bg-zinc-900/30 border-t border-zinc-800 px-2.5 py-3",children:u$2("p",{className:" text-zinc-400 mb-4 text-xs",children:iife(()=>{switch(selectedEvent.kind){case"interaction":switch(entry.kind){case"render":return u$2(Explanation,{input:getRenderInput(selectedEvent)});case"other-javascript":return u$2(Explanation,{input:getJSInput(selectedEvent)});case"other-not-javascript":return u$2(Explanation,{input:getDrawInput(selectedEvent)})}case"dropped-frames":switch(entry.kind){case"total-processing-time":return u$2(Explanation,{input:{kind:"total-processing",data:{time:getTotalTime(selectedEvent.timing)}}});case"render":return u$2(S$4,{children:u$2(Explanation,{input:{kind:"render",data:{topByTime:selectedEvent.groupedFiberRenders.toSorted((a2,b2)=>b2.totalTime-a2.totalTime).slice(0,3).map(render2=>({name:render2.name,percentage:render2.totalTime/getTotalTime(selectedEvent.timing)}))}}})});case"other-frame-drop":return u$2(Explanation,{input:{kind:"other"}})}}})})})]},entry.kind)})})]})},"OtherVisualization"),getDrawInput=__name(event=>{const renderCount=event.groupedFiberRenders.reduce((prev,curr)=>prev+curr.count,0),renderPercentage=event.timing.renderTime/getTotalTime(event.timing)*100;return renderCount>100?{kind:"high-render-count-update-dom-draw-frame",data:{count:renderCount,percentageOfTotal:renderPercentage,copyButton:u$2(CopyPromptButton,{})}}:{kind:"update-dom-draw-frame",data:{copyButton:u$2(CopyPromptButton,{})}}},"getDrawInput"),CopyPromptButton=__name(()=>{const[copying,setCopying]=d$4(!1),{notificationState}=useNotificationsContext();return u$2("button",{onClick:__name(async()=>{notificationState.selectedEvent&&(await navigator.clipboard.writeText(getLLMPrompt("explanation",notificationState.selectedEvent)),setCopying(!0),setTimeout(()=>setCopying(!1),1e3))},"onClick"),className:"bg-zinc-800 flex hover:bg-zinc-700 text-zinc-200 px-2 py-1 rounded gap-x-3",children:[u$2("span",{children:copying?"Copied!":"Copy Prompt"}),u$2("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className:cn(["transition-transform duration-200",copying&&"scale-110"]),children:copying?u$2("path",{d:"M20 6L9 17l-5-5"}):u$2(S$4,{children:[u$2("rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2"}),u$2("path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"})]})})]})},"CopyPromptButton"),getRenderInput=__name(event=>event.timing.renderTime/getTotalTime(event.timing)>.3?{kind:"render",data:{topByTime:event.groupedFiberRenders.toSorted((a2,b2)=>b2.totalTime-a2.totalTime).slice(0,3).map(e2=>({percentage:e2.totalTime/getTotalTime(event.timing),name:e2.name}))}}:{kind:"other"},"getRenderInput"),getJSInput=__name(event=>{const renderCount=event.groupedFiberRenders.reduce((prev,curr)=>prev+curr.count,0);return event.timing.otherJSTime/getTotalTime(event.timing)<.2?{kind:"js-explanation-base"}:event.groupedFiberRenders.find(render2=>render2.count>200)||event.groupedFiberRenders.reduce((prev,curr)=>prev+curr.count,0)>500?{kind:"high-render-count-high-js",data:{renderCount,topByCount:event.groupedFiberRenders.filter(groupedRender=>groupedRender.count>100).toSorted((a2,b2)=>b2.count-a2.count).slice(0,3)}}:event.timing.otherJSTime/getTotalTime(event.timing)>.3?event.timing.renderTime>.2?{kind:"js-explanation-base"}:{kind:"low-render-count-high-js",data:{renderCount}}:{kind:"js-explanation-base"}},"getJSInput"),Explanation=__name(({input})=>{switch(input.kind){case"total-processing":return u$2("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u$2("p",{children:["This is the time it took to draw the entire frame that was presented to the user. To be at 60FPS, this number needs to be ","<=16ms"]}),u$2("p",{children:'To debug the issue, check the "Ranked" tab to see if there are significant component renders'}),u$2("p",{children:"On a production React build, React Scan can't access the time it took for component to render. To get that information, run React Scan on a development build"}),u$2("p",{children:["To understand precisely what caused the slowdown while in production, use the"," ",u$2("strong",{children:"Chrome profiler"})," and analyze the function call times."]}),u$2("p",{})]});case"render":return u$2("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u$2("p",{children:"This is the time it took React to run components, and internal logic to handle the output of your component."}),u$2("div",{className:cn(["flex flex-col"]),children:[u$2("p",{children:"The slowest components for this time period were:"}),input.data.topByTime.map(item=>u$2("div",{children:[u$2("strong",{children:item.name}),": ",(item.percentage*100).toFixed(0),"% of total"]},item.name))]}),u$2("p",{children:'To view the render times of all your components, and what caused them to render, go to the "Ranked" tab'}),u$2("p",{children:'The "Ranked" tab shows the render times of every component.'}),u$2("p",{children:"The render times of the same components are grouped together into one bar."}),u$2("p",{children:"Clicking the component will show you what props, state, or context caused the component to re-render."})]});case"js-explanation-base":return u$2("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u$2("p",{children:"This is the period when JavaScript hooks and other JavaScript outside of React Renders run."}),u$2("p",{children:["The most common culprit for high JS time is expensive hooks, like expensive callbacks inside of ",u$2("code",{children:"useEffect"}),"'s or a large number of useEffect's called, but this can also be JavaScript event handlers (",u$2("code",{children:"'onclick'"}),", ",u$2("code",{children:"'onchange'"}),") that performed expensive computation."]}),u$2("p",{children:"If you have lots of components rendering that call hooks, like useEffect, it can add significant overhead even if the callbacks are not expensive. If this is the case, you can try optimizing the renders of those components to avoid the hook from having to run."}),u$2("p",{children:["You should profile your app using the ",u$2("strong",{children:"Chrome DevTools profiler"})," to learn exactly which functions took the longest to execute."]})]});case"high-render-count-high-js":return u$2("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u$2("p",{children:"This is the period when JavaScript hooks and other JavaScript outside of React Renders run."}),input.data.renderCount===0?u$2(S$4,{children:[u$2("p",{children:"There were no renders, which means nothing related to React caused this slowdown. The most likely cause of the slowdown is a slow JavaScript event handler, or code related to a Web API"}),u$2("p",{children:["You should try to reproduce the slowdown while profiling your website with the",u$2("strong",{children:"Chrome DevTools profiler"})," to see exactly what functions took the longest to execute."]})]}):u$2(S$4,{children:[" ",u$2("p",{children:["There were ",u$2("strong",{children:input.data.renderCount})," renders, which could have contributed to the high JavaScript/Hook time if they ran lots of hooks, like"," ",u$2("code",{children:"useEffects"}),"."]}),u$2("div",{className:cn(["flex flex-col"]),children:[u$2("p",{children:"You should try optimizing the renders of:"}),input.data.topByCount.map(item=>u$2("div",{children:["- ",u$2("strong",{children:item.name})," (rendered ",item.count,"x)"]},item.name))]}),"and then checking if the problem still exists.",u$2("p",{children:["You can also try profiling your app using the"," ",u$2("strong",{children:"Chrome DevTools profiler"})," to see exactly what functions took the longest to execute."]})]})]});case"low-render-count-high-js":return u$2("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u$2("p",{children:"This is the period when JavaScript hooks and other JavaScript outside of React Renders run."}),u$2("p",{children:["There were only ",u$2("strong",{children:input.data.renderCount})," renders detected, which means either you had very expensive hooks like ",u$2("code",{children:"useEffect"}),"/",u$2("code",{children:"useLayoutEffect"}),", or there is other JavaScript running during this interaction that took up the majority of the time."]}),u$2("p",{children:["To understand precisely what caused the slowdown, use the"," ",u$2("strong",{children:"Chrome profiler"})," and analyze the function call times."]})]});case"high-render-count-update-dom-draw-frame":return u$2("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u$2("p",{children:"These are the calculations the browser is forced to do in response to the JavaScript that ran during the interaction."}),u$2("p",{children:"This can be caused by CSS updates/CSS recalculations, or new DOM elements/DOM mutations."}),u$2("p",{children:["During this interaction, there were ",u$2("strong",{children:input.data.count})," renders, which was ",u$2("strong",{children:[input.data.percentageOfTotal.toFixed(0),"%"]})," of the time spent processing"]}),u$2("p",{children:"The work performed as a result of the renders may have forced the browser to spend a lot of time to draw the next frame."}),u$2("p",{children:'You can try optimizing the renders to see if the performance problem still exists using the "Ranked" tab.'}),u$2("p",{children:"If you use an AI-based code editor, you can export the performance data collected as a prompt."}),u$2("p",{children:input.data.copyButton}),u$2("p",{children:"Provide this formatted data to the model and ask it to find, or fix, what could be causing this performance problem."}),u$2("p",{children:'For a larger selection of prompts, try the "Prompts" tab'})]});case"update-dom-draw-frame":return u$2("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u$2("p",{children:"These are the calculations the browser is forced to do in response to the JavaScript that ran during the interaction."}),u$2("p",{children:"This can be caused by CSS updates/CSS recalculations, or new DOM elements/DOM mutations."}),u$2("p",{children:"If you use an AI-based code editor, you can export the performance data collected as a prompt."}),u$2("p",{children:input.data.copyButton}),u$2("p",{children:"Provide this formatted data to the model and ask it to find, or fix, what could be causing this performance problem."}),u$2("p",{children:'For a larger selection of prompts, try the "Prompts" tab'})]});case"other":return u$2("div",{className:cn(["text-[#E4E4E7] text-[10px] leading-6 flex flex-col gap-y-2"]),children:[u$2("p",{children:["This is the time it took to run everything other than React renders. This can be hooks like ",u$2("code",{children:"useEffect"}),", other JavaScript not part of React, or work the browser has to do to update the DOM and draw the next frame."]}),u$2("p",{children:["To get a better picture of what happened, profile your app using the"," ",u$2("strong",{children:"Chrome profiler"})," when the performance problem arises."]})]})}},"Explanation"),highlightCanvas=null,highlightCtx=null,animationFrame=null,HighlightStore=y$4({kind:"idle",current:null}),currFrame=null,lastFrameTime=0,FADE_SPEED=1.8,MAX_DELTA=.05,DEFAULT_DELTA=1/60,drawHighlights=__name(()=>{currFrame&&cancelAnimationFrame(currFrame),currFrame=requestAnimationFrame(timestamp=>{if(!highlightCanvas||!highlightCtx)return;const dt2=lastFrameTime?Math.min((timestamp-lastFrameTime)/1e3,MAX_DELTA):DEFAULT_DELTA;lastFrameTime=timestamp;const step=FADE_SPEED*dt2;highlightCtx.clearRect(0,0,highlightCanvas.width,highlightCanvas.height);const color="hsl(271, 76%, 53%)",state=HighlightStore.value,{alpha,current}=iife(()=>{var _a,_b,_c;switch(state.kind){case"transition":{const current2=(_a=state.current)!=null&&_a.alpha&&state.current.alpha>0?state.current:state.transitionTo;return{alpha:current2?current2.alpha:0,current:current2}}case"move-out":return{alpha:(_c=(_b=state.current)==null?void 0:_b.alpha)!=null?_c:0,current:state.current};case"idle":return{alpha:1,current:state.current}}});switch(current?.rects.forEach(rect=>{highlightCtx&&(highlightCtx.shadowColor=color,highlightCtx.shadowBlur=6,highlightCtx.strokeStyle=color,highlightCtx.lineWidth=2,highlightCtx.globalAlpha=alpha,highlightCtx.beginPath(),highlightCtx.rect(rect.left,rect.top,rect.width,rect.height),highlightCtx.stroke(),highlightCtx.shadowBlur=0,highlightCtx.beginPath(),highlightCtx.rect(rect.left,rect.top,rect.width,rect.height),highlightCtx.stroke())}),state.kind){case"move-out":if(state.current.alpha===0){HighlightStore.value={kind:"idle",current:null},lastFrameTime=0;return}state.current.alpha<=.01&&(state.current.alpha=0),state.current.alpha=Math.max(0,state.current.alpha-step),drawHighlights();return;case"transition":if(state.current&&state.current.alpha>0){state.current.alpha=Math.max(0,state.current.alpha-step),drawHighlights();return}if(state.transitionTo.alpha===1){HighlightStore.value={kind:"idle",current:state.transitionTo},lastFrameTime=0;return}state.transitionTo.alpha=Math.min(state.transitionTo.alpha+step,1),drawHighlights();case"idle":lastFrameTime=0;return}})},"drawHighlights"),handleResizeListener=null,createHighlightCanvas=__name(root=>{if(highlightCanvas=document.createElement("canvas"),highlightCtx=highlightCanvas.getContext("2d",{alpha:!0}),!highlightCtx)return null;const dpr2=window.devicePixelRatio||1,{innerWidth,innerHeight}=window;highlightCanvas.style.width=`${innerWidth}px`,highlightCanvas.style.height=`${innerHeight}px`,highlightCanvas.width=innerWidth*dpr2,highlightCanvas.height=innerHeight*dpr2,highlightCanvas.style.position="fixed",highlightCanvas.style.left="0",highlightCanvas.style.top="0",highlightCanvas.style.pointerEvents="none",highlightCanvas.style.zIndex="2147483600",highlightCtx.scale(dpr2,dpr2),root.appendChild(highlightCanvas),handleResizeListener&&window.removeEventListener("resize",handleResizeListener);const handleResize=__name(()=>{if(!highlightCanvas||!highlightCtx)return;const dpr3=window.devicePixelRatio||1,{innerWidth:innerWidth2,innerHeight:innerHeight2}=window;highlightCanvas.style.width=`${innerWidth2}px`,highlightCanvas.style.height=`${innerHeight2}px`,highlightCanvas.width=innerWidth2*dpr3,highlightCanvas.height=innerHeight2*dpr3,highlightCtx.scale(dpr3,dpr3),drawHighlights()},"handleResize");return handleResizeListener=handleResize,window.addEventListener("resize",handleResize),HighlightStore.subscribe(()=>{requestAnimationFrame(()=>{drawHighlights()})}),cleanup2},"createHighlightCanvas");function cleanup2(){animationFrame&&(cancelAnimationFrame(animationFrame),animationFrame=null),highlightCanvas?.parentNode&&highlightCanvas.parentNode.removeChild(highlightCanvas),highlightCanvas=null,highlightCtx=null}__name(cleanup2,"cleanup2");var fadeOutHighlights=__name(()=>{var _a,_b;const curr=HighlightStore.value.current?HighlightStore.value.current:HighlightStore.value.kind==="transition"?HighlightStore.value.transitionTo:null;if(curr){if(HighlightStore.value.kind==="transition"){HighlightStore.value={kind:"move-out",current:((_a=HighlightStore.value.current)==null?void 0:_a.alpha)===0?HighlightStore.value.transitionTo:(_b=HighlightStore.value.current)!=null?_b:HighlightStore.value.transitionTo};return}HighlightStore.value={kind:"move-out",current:{alpha:0,...curr}}}},"fadeOutHighlights"),RenderBarChart=__name(({selectedEvent})=>{const totalInteractionTime=getTotalTime(selectedEvent.timing),nonRender=totalInteractionTime-selectedEvent.timing.renderTime,[isProduction2]=d$4(getIsProduction()),bars=selectedEvent.groupedFiberRenders.map(event=>({event,kind:"render",totalTime:isProduction2?event.count:event.totalTime})),isShowingExtraInfo=iife(()=>{switch(selectedEvent.kind){case"dropped-frames":return selectedEvent.timing.renderTime/totalInteractionTime<.1;case"interaction":return(selectedEvent.timing.otherJSTime+selectedEvent.timing.renderTime)/totalInteractionTime<.2}});selectedEvent.kind==="interaction"&&!isProduction2&&bars.push({kind:"other-javascript",totalTime:selectedEvent.timing.otherJSTime}),isShowingExtraInfo&&!isProduction2&&(selectedEvent.kind==="interaction"?bars.push({kind:"other-not-javascript",totalTime:getTotalTime(selectedEvent.timing)-selectedEvent.timing.renderTime-selectedEvent.timing.otherJSTime}):bars.push({kind:"other-frame-drop",totalTime:nonRender}));const debouncedMouseEnter=A$3({lastCallAt:null,timer:null}),totalBarTime=bars.reduce((prev,curr)=>prev+curr.totalTime,0);return u$2("div",{className:cn(["flex flex-col h-full w-full gap-y-1"]),children:[iife(()=>{if(isProduction2&&bars.length===0)return u$2("div",{className:"flex flex-col items-center justify-center h-full text-zinc-400",children:[u$2("p",{className:"text-sm w-full text-left text-white mb-1.5",children:"No data available"}),u$2("p",{className:"text-x w-full text-lefts",children:"No data was collected during this period"})]});if(bars.length===0)return u$2("div",{className:"flex flex-col items-center justify-center h-full text-zinc-400",children:[u$2("p",{className:"text-sm w-full text-left text-white mb-1.5",children:"No renders collected"}),u$2("p",{className:"text-x w-full text-lefts",children:"There were no renders during this period"})]})}),bars.toSorted((a2,b2)=>b2.totalTime-a2.totalTime).map(bar=>u$2(RenderBar,{bars,bar,debouncedMouseEnter,totalBarTime,isProduction:isProduction2},bar.kind==="render"?bar.event.id:bar.kind))]})},"RenderBarChart"),getTransitionState=__name(state=>state.current&&state.current.alpha>0?"fading-out":"fading-in","getTransitionState"),RenderBar=__name(({bar,debouncedMouseEnter,totalBarTime,isProduction:isProduction2,bars,depth=0})=>{const{setNotificationState,setRoute}=useNotificationsContext(),[isExpanded,setIsExpanded]=d$4(!1),isLeaf=bar.kind==="render"?bar.event.parents.size===0:!0,parentBars=bars.filter(otherBar=>otherBar.kind==="render"&&bar.kind==="render"?bar.event.parents.has(otherBar.event.name)&&otherBar.event.name!==bar.event.name:!1),missingParentNames=bar.kind==="render"?Array.from(bar.event.parents).filter(parentName=>!bars.some(b2=>b2.kind==="render"&&b2.event.name===parentName)):[],handleBarClick=__name(()=>{bar.kind==="render"?(setNotificationState(prev=>({...prev,selectedFiber:bar.event})),setRoute({route:"render-explanation",routeMessage:null})):setRoute({route:"other-visualization",routeMessage:{kind:"auto-open-overview-accordion",name:bar.kind}})},"handleBarClick");return u$2("div",{className:"w-full",children:[u$2("div",{className:cn(["w-full flex items-center relative text-xs min-w-0"]),children:[u$2("button",{onMouseLeave:__name(()=>{debouncedMouseEnter.current.timer&&clearTimeout(debouncedMouseEnter.current.timer),fadeOutHighlights()},"onMouseLeave"),onMouseEnter:__name(async()=>{const highlightBars=__name(async()=>{if(debouncedMouseEnter.current.lastCallAt=Date.now(),bar.kind!=="render"){const curr=HighlightStore.value.current?HighlightStore.value.current:HighlightStore.value.kind==="transition"?HighlightStore.value.transitionTo:null;if(!curr){HighlightStore.value={kind:"idle",current:null};return}HighlightStore.value={kind:"move-out",current:{alpha:0,...curr}};return}const state=HighlightStore.value,currentState=iife(()=>{switch(state.kind){case"transition":return state.transitionTo;case"idle":case"move-out":return state.current}}),stateRects=[];if(state.kind==="transition"){const transitionState=getTransitionState(state);iife(()=>{switch(transitionState){case"fading-in":HighlightStore.value={kind:"transition",current:state.transitionTo,transitionTo:{rects:stateRects,alpha:0,name:bar.event.name}};return;case"fading-out":HighlightStore.value={kind:"transition",current:HighlightStore.value.current?{alpha:0,...HighlightStore.value.current}:null,transitionTo:{rects:stateRects,alpha:0,name:bar.event.name}};return}})}else HighlightStore.value={kind:"transition",transitionTo:{rects:stateRects,alpha:0,name:bar.event.name},current:currentState?{alpha:0,...currentState}:null};const trueElements=bar.event.elements.filter(element=>element instanceof Element);for await(const entries of getBatchedRectMap(trueElements))entries.forEach(({boundingClientRect})=>{stateRects.push(boundingClientRect)}),drawHighlights()},"highlightBars");if(debouncedMouseEnter.current.lastCallAt&&Date.now()-debouncedMouseEnter.current.lastCallAt<200){debouncedMouseEnter.current.timer&&clearTimeout(debouncedMouseEnter.current.timer),debouncedMouseEnter.current.timer=setTimeout(()=>{highlightBars()},200);return}highlightBars()},"onMouseEnter"),onClick:handleBarClick,className:cn(["h-full w-[90%] flex items-center hover:bg-[#0f0f0f] rounded-l-md min-w-0 relative"]),children:[u$2("div",{style:{minWidth:"fit-content",width:`${bar.totalTime/totalBarTime*100}%`},className:cn(["flex items-center rounded-sm text-white text-xs h-[28px] shrink-0",bar.kind==="render"&&"bg-[#412162] group-hover:bg-[#5b2d89]",bar.kind==="other-frame-drop"&&"bg-[#44444a] group-hover:bg-[#6a6a6a]",bar.kind==="other-javascript"&&"bg-[#efd81a6b] group-hover:bg-[#efda1a2f]",bar.kind==="other-not-javascript"&&"bg-[#214379d4] group-hover:bg-[#21437982]"])}),u$2("div",{className:cn(["absolute inset-0 flex items-center px-2","min-w-0"]),children:u$2("div",{className:"flex items-center gap-x-2 min-w-0 w-full",children:[u$2("span",{className:cn(["truncate"]),children:iife(()=>{switch(bar.kind){case"other-frame-drop":return"JavaScript, DOM updates, Draw Frame";case"other-javascript":return"JavaScript/React Hooks";case"other-not-javascript":return"Update DOM and Draw New Frame";case"render":return bar.event.name}})}),bar.kind==="render"&&isRenderMemoizable(bar.event)&&u$2("div",{style:{lineHeight:"10px"},className:cn(["px-1 py-0.5 bg-[#6a369e] flex items-center rounded-sm font-semibold text-[8px] shrink-0"]),children:"Memoizable"})]})})]}),u$2("button",{onClick:__name(()=>bar.kind==="render"&&!isLeaf&&setIsExpanded(!isExpanded),"onClick"),className:cn(["flex items-center min-w-fit shrink-0 rounded-r-md h-[28px]",!isLeaf&&"hover:bg-[#0f0f0f]",bar.kind==="render"&&!isLeaf?"cursor-pointer":"cursor-default"]),children:[u$2("div",{className:"w-[20px] flex items-center justify-center",children:bar.kind==="render"&&!isLeaf&&u$2(ChevronRight,{className:cn("transition-transform",isExpanded&&"rotate-90"),size:16})}),u$2("div",{style:{minWidth:isLeaf?"fit-content":isProduction2?"30px":"60px"},className:"flex items-center justify-end gap-x-1",children:[bar.kind==="render"&&u$2("span",{className:cn(["text-[10px]"]),children:["x",bar.event.count]}),(bar.kind!=="render"||!isProduction2)&&u$2("span",{className:"text-[10px] text-[#7346a0] pr-1",children:[bar.totalTime<1?"<1":bar.totalTime.toFixed(0),"ms"]})]})]}),depth===0&&u$2("div",{className:cn(["absolute right-0 top-1/2 transition-none -translate-y-1/2 bg-white text-black px-2 py-1 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity mr-16","pointer-events-none"]),children:"Click to learn more"})]}),isExpanded&&(parentBars.length>0||missingParentNames.length>0)&&u$2("div",{className:"pl-3 flex flex-col gap-y-1 mt-1",children:[parentBars.toSorted((a2,b2)=>b2.totalTime-a2.totalTime).map((parentBar,i2)=>u$2(RenderBar,{depth:depth+1,bar:parentBar,debouncedMouseEnter,totalBarTime,isProduction:isProduction2,bars},i2)),missingParentNames.map(parentName=>u$2("div",{className:"w-full",children:u$2("div",{className:"w-full flex items-center relative text-xs",children:u$2("div",{className:"h-full w-full flex items-center relative",children:[u$2("div",{className:"flex items-center rounded-sm text-white text-xs h-[28px] w-full"}),u$2("div",{className:"absolute inset-0 flex items-center px-2",children:u$2("span",{className:"truncate whitespace-nowrap text-white/70 w-full",children:parentName})})]})})},parentName))]})]})},"RenderBar"),RenderExplanation=__name(({selectedEvent:_2,selectedFiber})=>{const{setRoute}=useNotificationsContext(),[tipisShown,setTipIsShown]=d$4(!0),[isProduction2]=d$4(getIsProduction());_$4(()=>{const res=localStorage.getItem("react-scan-tip-shown"),asBool=res==="true"?!0:res==="false"?!1:null;if(asBool===null){setTipIsShown(!0),localStorage.setItem("react-scan-tip-is-shown","true");return}asBool||setTipIsShown(!1)},[]);const isMemoizable=selectedFiber.changes.context.length===0&&selectedFiber.changes.props.length===0&&selectedFiber.changes.state.length===0;return u$2("div",{className:cn(["w-full min-h-fit h-full flex flex-col py-4 pt-0 rounded-sm"]),children:[u$2("div",{className:cn(["flex items-start gap-x-4 "]),children:[u$2("button",{onClick:__name(()=>{setRoute({route:"render-visualization",routeMessage:null})},"onClick"),className:cn(["text-white hover:bg-[#34343b] flex gap-x-1 justify-center items-center mb-4 w-fit px-2.5 py-1.5 text-xs rounded-sm bg-[#18181B]"]),children:[u$2(ArrowLeft,{size:14})," ",u$2("span",{children:"Overview"})]}),u$2("div",{className:cn(["flex flex-col gap-y-1"]),children:[u$2("div",{className:cn(["text-sm font-bold text-white overflow-x-hidden"]),children:u$2("div",{className:"flex items-center gap-x-2 truncate",children:selectedFiber.name})}),u$2("div",{className:cn(["flex gap-x-2"]),children:[!isProduction2&&u$2(S$4,{children:u$2("div",{className:cn(["text-xs text-gray-400"]),children:["• Render time: ",selectedFiber.totalTime.toFixed(0),"ms"]})}),u$2("div",{className:cn(["text-xs text-gray-400 mb-4"]),children:["• Renders: ",selectedFiber.count,"x"]})]})]})]}),tipisShown&&!isMemoizable&&u$2("div",{className:cn(["w-full mb-4 bg-[#0A0A0A] border border-[#27272A] rounded-sm overflow-hidden flex relative"]),children:[u$2("button",{onClick:__name(()=>{setTipIsShown(!1),localStorage.setItem("react-scan-tip-shown","false")},"onClick"),className:cn(["absolute right-2 top-2 rounded-sm p-1 hover:bg-[#18181B]"]),children:u$2(CloseIcon,{size:12})}),u$2("div",{className:cn(["w-1 bg-[#d36cff]"])}),u$2("div",{className:cn(["flex-1"]),children:[u$2("div",{className:cn(["px-3 py-2 text-gray-100 text-xs font-semibold"]),children:"How to stop renders"}),u$2("div",{className:cn(["px-3 pb-2 text-gray-400 text-[10px]"]),children:"Stop the following props, state and context from changing between renders, and wrap the component in React.memo if not already"})]})]}),isMemoizable&&u$2("div",{className:cn(["w-full mb-4 bg-[#0A0A0A] border border-[#27272A] rounded-sm overflow-hidden flex"]),children:[u$2("div",{className:cn(["w-1 bg-[#d36cff]"])}),u$2("div",{className:cn(["flex-1"]),children:[u$2("div",{className:cn(["px-3 py-2 text-gray-100 text-sm font-semibold"]),children:"No changes detected"}),u$2("div",{className:cn(["px-3 pb-2 text-gray-400 text-xs"]),children:"This component would not have rendered if it was memoized"})]})]}),u$2("div",{className:cn(["flex w-full"]),children:[u$2("div",{className:cn(["flex flex-col border border-[#27272A] rounded-l-sm overflow-hidden w-1/3"]),children:[u$2("div",{className:cn(["text-[14px] font-semibold px-2 py-2 bg-[#18181B] text-white flex justify-center"]),children:"Changed Props"}),selectedFiber.changes.props.length>0?selectedFiber.changes.props.toSorted((a2,b2)=>b2.count-a2.count).map(change=>u$2("div",{className:cn(["flex flex-col justify-between items-center border-t overflow-x-auto border-[#27272A] px-1 py-1 text-wrap bg-[#0A0A0A] text-[10px]"]),children:[u$2("span",{className:cn(["text-white "]),children:change.name}),u$2("div",{className:cn([" text-[8px]  text-[#d36cff] pl-1 py-1 "]),children:[change.count,"/",selectedFiber.count,"x"]})]},change.name)):u$2("div",{className:cn(["flex items-center justify-center h-full bg-[#0A0A0A] text-[#A1A1AA] border-t border-[#27272A]"]),children:"No changes"})]}),u$2("div",{className:cn(["flex flex-col border border-[#27272A] border-l-0 overflow-hidden w-1/3"]),children:[u$2("div",{className:cn([" text-[14px] font-semibold px-2 py-2 bg-[#18181B] text-white flex justify-center"]),children:"Changed State"}),selectedFiber.changes.state.length>0?selectedFiber.changes.state.toSorted((a2,b2)=>b2.count-a2.count).map(change=>u$2("div",{className:cn(["flex flex-col justify-between items-center border-t overflow-x-auto border-[#27272A] px-1 py-1 text-wrap bg-[#0A0A0A] text-[10px]"]),children:[u$2("span",{className:cn(["text-white "]),children:["index ",change.index]}),u$2("div",{className:cn(["rounded-full  text-[#d36cff] pl-1 py-1 text-[8px]"]),children:[change.count,"/",selectedFiber.count,"x"]})]},change.index)):u$2("div",{className:cn(["flex items-center justify-center h-full bg-[#0A0A0A] text-[#A1A1AA] border-t border-[#27272A]"]),children:"No changes"})]}),u$2("div",{className:cn(["flex flex-col border border-[#27272A] border-l-0 rounded-r-sm overflow-hidden w-1/3"]),children:[u$2("div",{className:cn([" text-[14px] font-semibold px-2 py-2 bg-[#18181B] text-white flex justify-center"]),children:"Changed Context"}),selectedFiber.changes.context.length>0?selectedFiber.changes.context.toSorted((a2,b2)=>b2.count-a2.count).map(change=>u$2("div",{className:cn(["flex flex-col justify-between items-center border-t  border-[#27272A] px-1 py-1 bg-[#0A0A0A] text-[10px] overflow-x-auto"]),children:[u$2("span",{className:cn(["text-white "]),children:change.name}),u$2("div",{className:cn(["rounded-full text-[#d36cff] pl-1 py-1 text-[8px] text-wrap"]),children:[change.count,"/",selectedFiber.count,"x"]})]},change.name)):u$2("div",{className:cn(["flex items-center justify-center h-full bg-[#0A0A0A] text-[#A1A1AA] border-t border-[#27272A] py-2"]),children:"No changes"})]})]})]})},"RenderExplanation"),DetailsRoutes=__name(()=>{const{notificationState,setNotificationState}=useNotificationsContext(),[dots,setDots]=d$4("..."),containerRef=A$3(null);if(y$5(()=>{const interval=setInterval(()=>{setDots(prev=>prev==="..."?"":prev+".")},500);return()=>clearInterval(interval)},[]),!notificationState.selectedEvent)return u$2("div",{ref:containerRef,className:cn(["h-full w-full flex flex-col items-center justify-center relative py-2 px-4"]),children:[u$2("div",{className:cn(["p-2 flex justify-center items-center border-[#27272A] absolute top-0 right-0"]),children:u$2("button",{onClick:__name(()=>{signalWidgetViews.value={view:"none"}},"onClick"),children:u$2(CloseIcon,{size:18,className:"text-[#6F6F78]"})})}),u$2("div",{className:cn(["flex flex-col items-start pt-5 bg-[#0A0A0A] p-5 rounded-sm max-w-md"," shadow-lg"]),children:u$2("div",{className:cn(["flex flex-col items-start gap-y-4"]),children:[u$2("div",{className:cn(["flex items-center"]),children:u$2("span",{className:cn(["text-zinc-400 font-medium text-[17px]"]),children:["Scanning for slowdowns",dots]})}),notificationState.events.length!==0&&u$2("p",{className:cn(["text-xs"]),children:["Click on an item in the"," ",u$2("span",{className:cn(["text-purple-400"]),children:"History"})," list to get started"]}),u$2("p",{className:cn(["text-zinc-600 text-xs"]),children:"You don't need to keep this panel open for React Scan to record slowdowns"}),u$2("p",{className:cn(["text-zinc-600 text-xs"]),children:"Enable audio alerts to hear a delightful ding every time a large slowdown is recorded"}),u$2("button",{onClick:__name(()=>{if(notificationState.audioNotificationsOptions.enabled){setNotificationState(prev=>{var _a,_b;return((_a=prev.audioNotificationsOptions.audioContext)==null?void 0:_a.state)!=="closed"&&((_b=prev.audioNotificationsOptions.audioContext)==null||_b.close()),localStorage.setItem("react-scan-notifications-audio","false"),{...prev,audioNotificationsOptions:{audioContext:null,enabled:!1}}});return}localStorage.setItem("react-scan-notifications-audio","true");const audioContext=new AudioContext;playNotificationSound(audioContext),setNotificationState(prev=>({...prev,audioNotificationsOptions:{enabled:!0,audioContext}}))},"onClick"),className:cn(["px-4 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-sm w-full"," text-sm flex items-center gap-x-2 justify-center"]),children:notificationState.audioNotificationsOptions.enabled?u$2(S$4,{children:u$2("span",{className:"flex items-center gap-x-1",children:"Disable audio alerts"})}):u$2(S$4,{children:u$2("span",{className:"flex items-center gap-x-1",children:"Enable audio alerts"})})})]})})]});switch(notificationState.route){case"render-visualization":return u$2(TabLayout,{children:u$2(RenderBarChart,{selectedEvent:notificationState.selectedEvent})});case"render-explanation":if(!notificationState.selectedFiber)throw new Error("Invariant: must have selected fiber when viewing render explanation");return u$2(TabLayout,{children:u$2(RenderExplanation,{selectedFiber:notificationState.selectedFiber,selectedEvent:notificationState.selectedEvent})});case"other-visualization":return u$2(TabLayout,{children:u$2("div",{className:cn(["flex w-full h-full flex-col overflow-y-auto"]),id:"overview-scroll-container",children:u$2(OtherVisualization,{selectedEvent:notificationState.selectedEvent})})});case"optimize":return u$2(TabLayout,{children:u$2(Optimize,{selectedEvent:notificationState.selectedEvent})})}notificationState.route},"DetailsRoutes"),TabLayout=__name(({children})=>{const{notificationState}=useNotificationsContext();if(!notificationState.selectedEvent)throw new Error("Invariant: d must have selected event when viewing render explanation");return u$2("div",{className:cn(["w-full h-full flex flex-col gap-y-2"]),children:[u$2("div",{className:cn(["h-[50px] w-full"]),children:u$2(NotificationTabs,{selectedEvent:notificationState.selectedEvent})}),u$2("div",{className:cn(["h-calc(100%-50px) flex flex-col overflow-y-auto px-3"]),children})]})},"TabLayout"),NotificationHeader=__name(({selectedEvent})=>{const severity=getEventSeverity(selectedEvent);switch(selectedEvent.kind){case"interaction":return u$2("div",{className:cn(["w-full flex border-b border-[#27272A] min-h-[48px]"]),children:u$2("div",{className:cn(["min-w-fit w-full justify-start flex items-center border-r border-[#27272A] pl-5 pr-2 text-sm gap-x-4"]),children:[u$2("div",{className:cn(["flex items-center gap-x-2 "]),children:[u$2("span",{className:cn(["text-[#5a5a5a] mr-0.5"]),children:selectedEvent.type==="click"?"Clicked ":"Typed in "}),u$2("span",{children:getComponentName(selectedEvent.componentPath)}),u$2("div",{className:cn(["w-fit flex items-center justify-center h-fit text-white px-1 rounded-sm font-semibold text-[10px] whitespace-nowrap",severity==="low"&&"bg-green-500/50",severity==="needs-improvement"&&"bg-[#b77116]",severity==="high"&&"bg-[#b94040]"]),children:[getTotalTime(selectedEvent.timing).toFixed(0),"ms processing time"]})]}),u$2("div",{className:cn(["flex items-center gap-x-2  justify-end ml-auto"]),children:u$2("div",{className:cn(["p-2 flex justify-center items-center border-[#27272A]"]),children:u$2("button",{onClick:__name(()=>{signalWidgetViews.value={view:"none"}},"onClick"),title:"Close",children:u$2(CloseIcon,{size:18,className:"text-[#6F6F78]"})})})})]})});case"dropped-frames":return u$2("div",{className:cn(["w-full flex border-b border-[#27272A] min-h-[48px]"]),children:u$2("div",{className:cn(["min-w-fit w-full justify-start flex items-center border-r border-[#27272A] pl-5 pr-2 text-sm gap-x-4"]),children:[u$2("div",{className:cn(["flex items-center gap-x-2 "]),children:["FPS Drop",u$2("div",{className:cn(["w-fit flex items-center justify-center h-fit text-white px-1 rounded-sm font-semibold text-[10px] whitespace-nowrap",severity==="low"&&"bg-green-500/50",severity==="needs-improvement"&&"bg-[#b77116]",severity==="high"&&"bg-[#b94040]"]),children:["dropped to ",selectedEvent.fps," FPS"]})]}),u$2("div",{className:cn(["flex items-center gap-x-2 w-2/4 justify-end ml-auto"]),children:u$2("div",{className:cn(["p-2 flex justify-center items-center border-[#27272A]"]),children:u$2("button",{onClick:__name(()=>{signalWidgetViews.value={view:"none"}},"onClick"),children:u$2(CloseIcon,{size:18,className:"text-[#6F6F78]"})})})})]})})}},"NotificationHeader"),useNestedFlash=__name(({flashingItemsCount,totalEvents})=>{const[newFlash,setNewFlash]=d$4(!1),flashedFor=A$3(0),lastFlashTime=A$3(0);return y$5(()=>{if(flashedFor.current>=totalEvents)return;const now=Date.now(),debounceTime=250,timeSinceLastFlash=now-lastFlashTime.current;if(timeSinceLastFlash>=debounceTime){setNewFlash(!1);const timeout2=setTimeout(()=>{flashedFor.current=totalEvents,lastFlashTime.current=Date.now(),setNewFlash(!0),setTimeout(()=>{setNewFlash(!1)},2e3)},50);return()=>clearTimeout(timeout2)}else{const delayNeeded=debounceTime-timeSinceLastFlash,timeout2=setTimeout(()=>{setNewFlash(!1),setTimeout(()=>{flashedFor.current=totalEvents,lastFlashTime.current=Date.now(),setNewFlash(!0),setTimeout(()=>{setNewFlash(!1)},2e3)},50)},delayNeeded);return()=>clearTimeout(timeout2)}},[flashingItemsCount]),newFlash},"useNestedFlash"),CollapsedItem=__name(({item,shouldFlash})=>{var _a,_b;const[expanded,setExpanded]=d$4(!1),severity=item.events.map(getEventSeverity).reduce((prev,curr)=>{switch(curr){case"high":return"high";case"needs-improvement":return prev==="high"?"high":"needs-improvement";case"low":return prev}},"low"),shouldFlashAgain=useNestedFlash({flashingItemsCount:item.events.reduce((prev,curr)=>shouldFlash(curr.id)?prev+1:prev,0),totalEvents:item.events.length});return u$2("div",{className:cn(["flex flex-col gap-y-0.5"]),children:[u$2("button",{onClick:__name(()=>setExpanded(expanded2=>!expanded2),"onClick"),className:cn(["pl-2 py-1.5  text-sm flex items-center rounded-sm hover:bg-[#18181B] relative overflow-hidden",shouldFlashAgain&&!expanded&&"after:absolute after:inset-0 after:bg-purple-500/30 after:animate-[fadeOut_1s_ease-out_forwards]"]),children:[u$2("div",{className:cn(["w-4/5 flex items-center justify-start h-full text-xs truncate gap-x-1.5"]),children:[u$2("span",{className:cn(["min-w-fit"]),children:u$2(ChevronRight,{className:cn(["text-[#A1A1AA] transition-transform",expanded?"rotate-90":""]),size:14},`chevron-${item.timestamp}`)}),u$2("span",{className:cn(["text-xs"]),children:item.kind==="collapsed-frame-drops"?"FPS Drops":getComponentName((_b=(_a=item.events.at(0))==null?void 0:_a.componentPath)!=null?_b:[])})]}),u$2("div",{className:cn(["ml-auto min-w-fit flex justify-end items-center"]),children:u$2("div",{style:{lineHeight:"10px"},className:cn(["w-fit flex items-center text-[10px] justify-center h-full text-white px-1 py-1 rounded-sm font-semibold",severity==="low"&&"bg-green-500/60",severity==="needs-improvement"&&"bg-[#b77116] text-[10px]",severity==="high"&&"bg-[#b94040]"]),children:["x",item.events.length]})})]}),expanded&&u$2(IndentedContent,{children:item.events.toSorted((a2,b2)=>b2.timestamp-a2.timestamp).map(event=>u$2(SlowdownHistoryItem,{event,shouldFlash:shouldFlash(event.id)}))})]})},"CollapsedItem"),IndentedContent=__name(({children})=>u$2("div",{className:"relative pl-6 flex flex-col gap-y-1",children:[u$2("div",{className:"absolute left-3 top-0 bottom-0 w-px bg-[#27272A]"}),children]}),"IndentedContent"),useFlashManager=__name(events=>{const prevEventsRef=A$3([]),[newEventIds,setNewEventIds]=d$4(new Set),isInitialMount=A$3(!0);return y$5(()=>{if(isInitialMount.current){isInitialMount.current=!1,prevEventsRef.current=events;return}const currentIds=new Set(events.map(e2=>e2.id)),prevIds=new Set(prevEventsRef.current.map(e2=>e2.id)),newIds=new Set;currentIds.forEach(id=>{prevIds.has(id)||newIds.add(id)}),newIds.size>0&&(setNewEventIds(newIds),setTimeout(()=>{setNewEventIds(new Set)},2e3)),prevEventsRef.current=events},[events]),id=>newEventIds.has(id)},"useFlashManager"),useFlash=__name(({shouldFlash})=>{const[isFlashing,setIsFlashing]=d$4(shouldFlash);return y$5(()=>{if(shouldFlash){setIsFlashing(!0);const timer2=setTimeout(()=>{setIsFlashing(!1)},1e3);return()=>clearTimeout(timer2)}},[shouldFlash]),isFlashing},"useFlash"),SlowdownHistoryItem=__name(({event,shouldFlash})=>{var _a,_b;const{notificationState,setNotificationState}=useNotificationsContext(),severity=getEventSeverity(event),isFlashing=useFlash({shouldFlash});switch(event.kind){case"interaction":return u$2("button",{onClick:__name(()=>{setNotificationState(prev=>({...prev,selectedEvent:event,route:"render-visualization",selectedFiber:null}))},"onClick"),className:cn(["pl-2 py-1.5  text-sm flex w-full items-center rounded-sm hover:bg-[#18181B] relative overflow-hidden",event.id===((_a=notificationState.selectedEvent)==null?void 0:_a.id)&&"bg-[#18181B]",isFlashing&&"after:absolute after:inset-0 after:bg-purple-500/30 after:animate-[fadeOut_1s_ease-out_forwards]"]),children:[u$2("div",{className:cn(["w-4/5 flex items-center justify-start h-full gap-x-1.5"]),children:[u$2("span",{className:cn(["min-w-fit text-xs"]),children:iife(()=>{switch(event.type){case"click":return u$2(PointerIcon,{size:14});case"keyboard":return u$2(KeyboardIcon,{size:14})}})}),u$2("span",{className:cn(["text-xs pr-1 truncate"]),children:getComponentName(event.componentPath)})]}),u$2("div",{className:cn([" min-w-fit flex justify-end items-center ml-auto"]),children:u$2("div",{style:{lineHeight:"10px"},className:cn(["gap-x-0.5 w-fit flex items-end justify-center h-full text-white px-1 py-1 rounded-sm font-semibold text-[10px]",severity==="low"&&"bg-green-500/50",severity==="needs-improvement"&&"bg-[#b77116] text-[10px]",severity==="high"&&"bg-[#b94040]"]),children:u$2("div",{style:{lineHeight:"10px"},className:cn(["text-[10px] text-white flex items-end"]),children:[getTotalTime(event.timing).toFixed(0),"ms"]})})})]});case"dropped-frames":return u$2("button",{onClick:__name(()=>{setNotificationState(prev=>({...prev,selectedEvent:event,route:"render-visualization",selectedFiber:null}))},"onClick"),className:cn(["pl-2 py-1.5  w-full text-sm flex items-center rounded-sm hover:bg-[#18181B] relative overflow-hidden",event.id===((_b=notificationState.selectedEvent)==null?void 0:_b.id)&&"bg-[#18181B]",isFlashing&&"after:absolute after:inset-0 after:bg-purple-500/30 after:animate-[fadeOut_1s_ease-out_forwards]"]),children:[u$2("div",{className:cn(["w-4/5 flex items-center justify-start h-full text-xs truncate"]),children:[u$2(TrendingDownIcon,{size:14,className:"mr-1.5"})," FPS Drop"]}),u$2("div",{className:cn([" min-w-fit flex justify-end items-center ml-auto"]),children:u$2("div",{style:{lineHeight:"10px"},className:cn(["w-fit flex items-center justify-center h-full text-white px-1 py-1 rounded-sm text-[10px] font-bold",severity==="low"&&"bg-green-500/60",severity==="needs-improvement"&&"bg-[#b77116] text-[10px]",severity==="high"&&"bg-[#b94040]"]),children:[event.fps," FPS"]})})]})}},"SlowdownHistoryItem"),collapseEvents=__name(events=>events.reduce((prev,curr)=>{const lastEvent=prev.at(-1);if(!lastEvent)return[{kind:"single",event:curr,timestamp:curr.timestamp}];switch(lastEvent.kind){case"collapsed-keyboard":return curr.kind==="interaction"&&curr.type==="keyboard"&&curr.componentPath.join("-")===lastEvent.events[0].componentPath.join("-")?[...prev.filter(e2=>e2!==lastEvent),{kind:"collapsed-keyboard",events:[...lastEvent.events,curr],timestamp:Math.max(...[...lastEvent.events,curr].map(e2=>e2.timestamp))}]:[...prev,{kind:"single",event:curr,timestamp:curr.timestamp}];case"single":return lastEvent.event.kind==="interaction"&&lastEvent.event.type==="keyboard"&&curr.kind==="interaction"&&curr.type==="keyboard"&&lastEvent.event.componentPath.join("-")===curr.componentPath.join("-")?[...prev.filter(e2=>e2!==lastEvent),{kind:"collapsed-keyboard",events:[lastEvent.event,curr],timestamp:Math.max(lastEvent.event.timestamp,curr.timestamp)}]:lastEvent.event.kind==="dropped-frames"&&curr.kind==="dropped-frames"?[...prev.filter(e2=>e2!==lastEvent),{kind:"collapsed-frame-drops",events:[lastEvent.event,curr],timestamp:Math.max(lastEvent.event.timestamp,curr.timestamp)}]:[...prev,{kind:"single",event:curr,timestamp:curr.timestamp}];case"collapsed-frame-drops":return curr.kind==="dropped-frames"?[...prev.filter(e2=>e2!==lastEvent),{kind:"collapsed-frame-drops",events:[...lastEvent.events,curr],timestamp:Math.max(...[...lastEvent.events,curr].map(e2=>e2.timestamp))}]:[...prev,{kind:"single",event:curr,timestamp:curr.timestamp}]}},[]),"collapseEvents"),useLaggedEvents=__name((lagMs=150)=>{const{notificationState}=useNotificationsContext(),[laggedEvents,setLaggedEvents]=d$4(notificationState.events);return y$5(()=>{setTimeout(()=>{setLaggedEvents(notificationState.events)},lagMs)},[notificationState.events]),[laggedEvents,setLaggedEvents]},"useLaggedEvents"),SlowdownHistory=__name(()=>{const{notificationState,setNotificationState}=useNotificationsContext(),shouldFlash=useFlashManager(notificationState.events),[laggedEvents,setLaggedEvents]=useLaggedEvents(),collapsedEvents=collapseEvents(laggedEvents).toSorted((a2,b2)=>b2.timestamp-a2.timestamp);return u$2("div",{className:cn(["w-full h-full gap-y-2 flex flex-col border-r border-[#27272A] overflow-y-auto"]),children:[u$2("div",{className:cn(["text-sm text-[#65656D] pl-3 pr-1 w-full flex items-center justify-between"]),children:[u$2("span",{children:"History"}),u$2(Popover,{wrapperProps:{className:"h-full flex items-center justify-center ml-auto"},triggerContent:u$2("button",{className:cn(["hover:bg-[#18181B] rounded-full p-2"]),title:"Clear all events",onClick:__name(()=>{toolbarEventStore.getState().actions.clear(),setNotificationState(prev=>({...prev,selectedEvent:null,selectedFiber:null,route:prev.route==="other-visualization"?"other-visualization":"render-visualization"})),setLaggedEvents([])},"onClick"),children:u$2(ClearIcon,{className:cn([""]),size:16})}),children:u$2("div",{className:cn(["w-full flex justify-center"]),children:"Clear all events"})})]}),u$2("div",{className:cn(["flex flex-col px-1 gap-y-1"]),children:[collapsedEvents.length===0&&u$2("div",{className:cn(["flex items-center justify-center text-zinc-500 text-sm py-4"]),children:"No Events"}),collapsedEvents.map(historyItem=>iife(()=>{switch(historyItem.kind){case"collapsed-keyboard":return u$2(CollapsedItem,{shouldFlash,item:historyItem});case"single":return u$2(SlowdownHistoryItem,{event:historyItem.event,shouldFlash:shouldFlash(historyItem.event.id)},historyItem.event.id);case"collapsed-frame-drops":return u$2(CollapsedItem,{shouldFlash,item:historyItem})}}))]})]})},"SlowdownHistory"),getGroupedFiberRenders=__name(fiberRenders=>Object.values(fiberRenders).map(render2=>({id:not_globally_unique_generateId(),totalTime:render2.nodeInfo.reduce((prev,curr)=>prev+curr.selfTime,0),count:render2.nodeInfo.length,name:render2.nodeInfo[0].name,deletedAll:!1,parents:render2.parents,hasMemoCache:render2.hasMemoCache,wasFiberRenderMount:render2.wasFiberRenderMount,elements:render2.nodeInfo.map(node=>node.element),changes:{context:render2.changes.fiberContext.current.filter(change=>render2.changes.fiberContext.changesCounts.get(change.name)).map(change=>{var _a;return{name:String(change.name),count:(_a=render2.changes.fiberContext.changesCounts.get(change.name))!=null?_a:0}}),props:render2.changes.fiberProps.current.filter(change=>render2.changes.fiberProps.changesCounts.get(change.name)).map(change=>{var _a;return{name:String(change.name),count:(_a=render2.changes.fiberProps.changesCounts.get(change.name))!=null?_a:0}}),state:render2.changes.fiberState.current.filter(change=>render2.changes.fiberState.changesCounts.get(Number(change.name))).map(change=>{var _a;return{index:change.name,count:(_a=render2.changes.fiberState.changesCounts.get(Number(change.name)))!=null?_a:0}})}})),"getGroupedFiberRenders"),useGarbageCollectElements=__name(notificationEvents=>{y$5(()=>{const intervalId=setInterval(__name(()=>{notificationEvents.forEach(event=>{event.groupedFiberRenders&&event.groupedFiberRenders.forEach(render2=>{if(render2.deletedAll)return;if(!render2.elements||render2.elements.length===0){render2.deletedAll=!0;return}const initialLength=render2.elements.length;render2.elements=render2.elements.filter(element=>element&&element.isConnected),render2.elements.length===0&&initialLength>0&&(render2.deletedAll=!0)})})},"checkElementsExistence"),5e3);return()=>{clearInterval(intervalId)}},[notificationEvents])},"useGarbageCollectElements"),useAppNotifications=__name(()=>{const log2=useToolbarEventLog(),notificationEvents=[];return useGarbageCollectElements(notificationEvents),log2.state.events.forEach(event=>{const groupedFiberRenders=getGroupedFiberRenders(event.kind==="interaction"?event.data.meta.detailedTiming.fiberRenders:event.data.meta.fiberRenders),renderTime=groupedFiberRenders.reduce((prev,curr)=>prev+curr.totalTime,0);switch(event.kind){case"interaction":{const{commitEnd,jsEndDetail,interactionStartDetail,rafStart}=event.data.meta.detailedTiming;jsEndDetail-interactionStartDetail-renderTime<0&&invariantError("js time must be longer than render time");const otherJSTime=Math.max(0,jsEndDetail-interactionStartDetail-renderTime),frameDraw=Math.max(event.data.meta.latency-(commitEnd-interactionStartDetail),0);notificationEvents.push({componentPath:event.data.meta.detailedTiming.componentPath,groupedFiberRenders,id:event.id,kind:"interaction",memory:null,timestamp:event.data.startAt,type:event.data.meta.detailedTiming.interactionType==="keyboard"?"keyboard":"click",timing:{renderTime,kind:"interaction",otherJSTime,framePreparation:rafStart-jsEndDetail,frameConstruction:commitEnd-rafStart,frameDraw}});return}case"long-render":notificationEvents.push({kind:"dropped-frames",id:event.id,memory:null,timing:{kind:"dropped-frames",renderTime,otherTime:event.data.meta.latency},groupedFiberRenders,timestamp:event.data.startAt,fps:event.data.meta.fps});return}}),notificationEvents},"useAppNotifications"),timeout=1e3,NotificationAudio=__name(()=>{const{notificationState,setNotificationState}=useNotificationsContext(),playedFor=A$3(null),debounceTimeout=A$3(null),lastPlayedTime=A$3(0),[laggedEvents]=useLaggedEvents(),alertEventsCount=laggedEvents.filter(event=>getEventSeverity(event)==="high").length;return y$5(()=>{const audioEnabledString=localStorage.getItem("react-scan-notifications-audio");if(audioEnabledString!=="false"&&audioEnabledString!=="true"){localStorage.setItem("react-scan-notifications-audio","false");return}if(audioEnabledString!=="false"){setNotificationState(prev=>prev.audioNotificationsOptions.enabled?prev:{...prev,audioNotificationsOptions:{enabled:!0,audioContext:new AudioContext}});return}},[]),y$5(()=>{const{audioNotificationsOptions}=notificationState;if(!audioNotificationsOptions.enabled||alertEventsCount===0||playedFor.current&&playedFor.current>=alertEventsCount)return;debounceTimeout.current&&clearTimeout(debounceTimeout.current);const timeSinceLastPlay=Date.now()-lastPlayedTime.current,remainingDebounceTime=Math.max(0,timeout-timeSinceLastPlay);debounceTimeout.current=setTimeout(()=>{playNotificationSound(audioNotificationsOptions.audioContext),playedFor.current=alertEventsCount,lastPlayedTime.current=Date.now(),debounceTimeout.current=null},remainingDebounceTime)},[alertEventsCount]),y$5(()=>{alertEventsCount===0&&(playedFor.current=null)},[alertEventsCount]),y$5(()=>()=>{debounceTimeout.current&&clearTimeout(debounceTimeout.current)},[]),null},"NotificationAudio"),NotificationWrapper=D$2((_2,ref)=>{var _a;const events=useAppNotifications(),[notificationState,setNotificationState]=d$4({detailsExpanded:!1,events,filterBy:"latest",moreInfoExpanded:!1,route:"render-visualization",selectedEvent:(_a=events.toSorted((a2,b2)=>a2.timestamp-b2.timestamp).at(-1))!=null?_a:null,selectedFiber:null,routeMessage:null,audioNotificationsOptions:{enabled:!1,audioContext:null}});return notificationState.events=events,u$2(NotificationStateContext.Provider,{value:{notificationState,setNotificationState,setRoute:__name(({route,routeMessage})=>{setNotificationState(prev=>{const newState={...prev,route,routeMessage};switch(route){case"render-visualization":return fadeOutHighlights(),{...newState,selectedFiber:null};case"optimize":return fadeOutHighlights(),{...newState,selectedFiber:null};case"other-visualization":return fadeOutHighlights(),{...newState,selectedFiber:null};case"render-explanation":return fadeOutHighlights(),newState}})},"setRoute")},children:[u$2(NotificationAudio,{}),u$2(Notifications,{ref})]})}),Notifications=D$2((_2,ref)=>{var _a;const{notificationState}=useNotificationsContext();return u$2("div",{ref,className:cn(["h-full w-full flex flex-col"]),children:[notificationState.selectedEvent&&u$2("div",{className:cn(["w-full h-[48px] flex flex-col",notificationState.moreInfoExpanded&&"h-[235px]",notificationState.moreInfoExpanded&&notificationState.selectedEvent.kind==="dropped-frames"&&"h-[150px]"]),children:[u$2(NotificationHeader,{selectedEvent:notificationState.selectedEvent}),notificationState.moreInfoExpanded&&u$2(MoreInfo,{})]}),u$2("div",{className:cn(["flex ",notificationState.selectedEvent?"h-[calc(100%-48px)]":"h-full",notificationState.moreInfoExpanded&&"h-[calc(100%-200px)]",notificationState.moreInfoExpanded&&((_a=notificationState.selectedEvent)==null?void 0:_a.kind)==="dropped-frames"&&"h-[calc(100%-150px)]"]),children:[u$2("div",{className:cn(["h-full min-w-[200px]"]),children:u$2(SlowdownHistory,{})}),u$2("div",{className:cn(["w-[calc(100%-200px)] h-full overflow-y-auto"]),children:u$2(DetailsRoutes,{})})]})]})}),MoreInfo=__name(()=>{const{notificationState}=useNotificationsContext();if(!notificationState.selectedEvent)throw new Error("Invariant must have selected event for more info");const event=notificationState.selectedEvent;return u$2("div",{className:cn(["px-4 py-2 border-b border-[#27272A] bg-[#18181B]/50 h-[calc(100%-40px)]",event.kind==="dropped-frames"&&"h-[calc(100%-25px)]"]),children:u$2("div",{className:cn(["flex flex-col gap-y-4 h-full"]),children:iife(()=>{switch(event.kind){case"interaction":return u$2(S$4,{children:[u$2("div",{className:cn(["flex items-center gap-x-3"]),children:[u$2("span",{className:"text-[#6F6F78] text-xs font-medium",children:event.type==="click"?"Clicked component location":"Typed in component location"}),u$2("div",{className:"font-mono text-[#E4E4E7] flex items-center bg-[#27272A] pl-2 py-1 rounded-sm overflow-x-auto",children:event.componentPath.toReversed().map((part,i2)=>u$2(S$4,{children:[u$2("span",{style:{lineHeight:"14px"},className:"text-[10px] whitespace-nowrap",children:part},part),i2<event.componentPath.length-1&&u$2("span",{className:"text-[#6F6F78] mx-0.5",children:"‹"})]}))})]}),u$2("div",{className:cn(["flex items-center gap-x-3"]),children:[u$2("span",{className:"text-[#6F6F78] text-xs font-medium",children:"Total Time"}),u$2("span",{className:"text-[#E4E4E7] bg-[#27272A] px-1.5 py-1 rounded-sm text-xs",children:[getTotalTime(event.timing).toFixed(0),"ms"]})]}),u$2("div",{className:cn(["flex items-center gap-x-3"]),children:[u$2("span",{className:"text-[#6F6F78] text-xs font-medium",children:"Occurred"}),u$2("span",{className:"text-[#E4E4E7] bg-[#27272A] px-1.5 py-1 rounded-sm text-xs",children:`${((Date.now()-event.timestamp)/1e3).toFixed(0)}s ago`})]})]});case"dropped-frames":return u$2(S$4,{children:[u$2("div",{className:cn(["flex items-center gap-x-3"]),children:[u$2("span",{className:"text-[#6F6F78] text-xs font-medium",children:"Total Time"}),u$2("span",{className:"text-[#E4E4E7] bg-[#27272A] px-1.5 py-1 rounded-sm text-xs",children:[getTotalTime(event.timing).toFixed(0),"ms"]})]}),u$2("div",{className:cn(["flex items-center gap-x-3"]),children:[u$2("span",{className:"text-[#6F6F78] text-xs font-medium",children:"Occurred"}),u$2("span",{className:"text-[#E4E4E7] bg-[#27272A] px-1.5 py-1 rounded-sm text-xs",children:`${((Date.now()-event.timestamp)/1e3).toFixed(0)}s ago`})]})]})}})})})},"MoreInfo"),Toolbar=constant(()=>{var _a;const events=useAppNotifications(),[laggedEvents,setLaggedEvents]=d$4(events);y$5(()=>{const timeout2=setTimeout(()=>{setLaggedEvents(events)},600);return()=>{clearTimeout(timeout2)}},[events]);const inspectState=Store.inspectState,isInspectActive=inspectState.value.kind==="inspecting",isInspectFocused=inspectState.value.kind==="focused",[seenEvents,setSeenEvents]=d$4([]),onToggleInspect=q$2(()=>{switch(Store.inspectState.value.kind){case"inspecting":signalWidgetViews.value={view:"none"},Store.inspectState.value={kind:"inspect-off"};return;case"focused":signalWidgetViews.value={view:"inspector"},Store.inspectState.value={kind:"inspecting",hoveredDomElement:null};return;case"inspect-off":signalWidgetViews.value={view:"none"},Store.inspectState.value={kind:"inspecting",hoveredDomElement:null};return;case"uninitialized":return}},[]),onToggleActive=q$2(e2=>{if(e2.preventDefault(),e2.stopPropagation(),!ReactScanInternals.instrumentation)return;const isPaused=!ReactScanInternals.instrumentation.isPaused.value;ReactScanInternals.instrumentation.isPaused.value=isPaused,saveLocalStorage$1("react-scan-options",{...readLocalStorage$1("react-scan-options"),enabled:!isPaused})},[]);useSignalEffect(()=>{Store.inspectState.value.kind==="uninitialized"&&(Store.inspectState.value={kind:"inspect-off"})});let inspectIcon=null,inspectColor="#999";return isInspectActive?(inspectIcon=u$2(Icon,{name:"icon-inspect"}),inspectColor="#8e61e3"):isInspectFocused?(inspectIcon=u$2(Icon,{name:"icon-focus"}),inspectColor="#8e61e3"):(inspectIcon=u$2(Icon,{name:"icon-inspect"}),inspectColor="#999"),_$4(()=>{signalWidgetViews.value.view==="notifications"&&setSeenEvents([...new Set(events.map(event=>event.id)).values()])},[events.length,signalWidgetViews.value.view]),u$2("div",{className:"flex max-h-9 min-h-9 flex-1 items-stretch overflow-hidden",children:[u$2("div",{className:"h-full flex items-center min-w-fit",children:u$2("button",{type:"button",id:"react-scan-inspect-element",title:"Inspect element",onClick:onToggleInspect,className:"button flex items-center justify-center h-full w-full pl-3 pr-2.5",style:{color:inspectColor},children:inspectIcon})}),u$2("div",{className:"h-full flex items-center justify-center",children:u$2("button",{type:"button",id:"react-scan-notifications",title:"Notifications",onClick:__name(()=>{switch(Store.inspectState.value.kind!=="inspect-off"&&(Store.inspectState.value={kind:"inspect-off"}),signalWidgetViews.value.view){case"inspector":Store.inspectState.value={kind:"inspect-off"},setSeenEvents([...new Set(events.map(event=>event.id)).values()]),signalWidgetViews.value={view:"notifications"};return;case"notifications":signalWidgetViews.value={view:"none"};return;case"none":setSeenEvents([...new Set(events.map(event=>event.id)).values()]),signalWidgetViews.value={view:"notifications"};return}},"onClick"),className:"button flex items-center justify-center h-full pl-2.5 pr-2.5",style:{color:inspectColor},children:u$2(Notification,{events:laggedEvents.filter(event=>!seenEvents.includes(event.id)).map(event=>getEventSeverity(event)==="high"),size:16,className:cn(["text-[#999]",signalWidgetViews.value.view==="notifications"&&"text-[#8E61E3]"])})})}),u$2(Toggle,{checked:!((_a=ReactScanInternals.instrumentation)!=null&&_a.isPaused.value),onChange:onToggleActive,className:"place-self-center",title:"Outline Re-renders"}),ReactScanInternals.options.value.showFPS&&u$2(FPSMeter,{})]})}),isInspecting=g$4(()=>Store.inspectState.value.kind==="inspecting"),headerClassName=g$4(()=>cn("relative","flex-1","flex flex-col","rounded-t-lg","overflow-hidden","opacity-100","transition-[opacity]",isInspecting.value&&"opacity-0 duration-0 delay-0")),isInspectorViewOpen=g$4(()=>signalWidgetViews.value.view==="inspector"),isNotificationsViewOpen=g$4(()=>signalWidgetViews.value.view==="notifications"),Content=__name(()=>u$2("div",{className:cn("flex flex-1 flex-col","overflow-hidden z-10","rounded-lg","bg-black","opacity-100","transition-[border-radius]","peer-hover/left:rounded-l-none","peer-hover/right:rounded-r-none","peer-hover/top:rounded-t-none","peer-hover/bottom:rounded-b-none"),children:[u$2("div",{className:headerClassName,children:[u$2(Header,{}),u$2("div",{className:cn("relative","flex-1 flex","text-white","bg-[#0A0A0A]","transition-opacity delay-150","overflow-hidden","border-b border-[#222]"),children:[u$2(ContentView,{isOpen:isInspectorViewOpen,children:u$2(ViewInspector,{})}),u$2(ContentView,{isOpen:isNotificationsViewOpen,children:u$2(NotificationWrapper,{})})]})]}),u$2(Toolbar,{})]}),"Content"),ContentView=__name(({isOpen,children})=>u$2("div",{className:cn("flex-1","opacity-0","overflow-y-auto overflow-x-hidden","transition-opacity delay-0","pointer-events-none",isOpen.value&&"opacity-100 delay-150 pointer-events-auto"),children:u$2("div",{className:"absolute inset-0 flex",children})}),"ContentView"),lerp2=__name((start2,end,t2)=>start2+(end-start2)*t2,"lerp2"),ANIMATION_CONFIG={frameInterval:1e3/60,speeds:{fast:.51,slow:.1,off:0}},OVERLAY_DPR=IS_CLIENT$1&&window.devicePixelRatio||1,ScanOverlay=__name(()=>{const refCanvas=A$3(null),refEventCatcher=A$3(null),refCurrentRect=A$3(null),refCurrentLockIconRect=A$3(null),refLastHoveredElement=A$3(null),refRafId=A$3(0),refTimeout=A$3(),refCleanupMap=A$3(new Map),refIsFadingOut=A$3(!1),refLastFrameTime=A$3(0),drawLockIcon=__name((ctx2,x2,y2,size)=>{ctx2.save(),ctx2.strokeStyle="white",ctx2.fillStyle="white",ctx2.lineWidth=1.5;const shackleWidth=size*.6,shackleHeight=size*.5,shackleX=x2+(size-shackleWidth)/2,shackleY=y2;ctx2.beginPath(),ctx2.arc(shackleX+shackleWidth/2,shackleY+shackleHeight/2,shackleWidth/2,Math.PI,0,!1),ctx2.stroke();const bodyWidth=size*.8,bodyHeight=size*.5,bodyX=x2+(size-bodyWidth)/2,bodyY=y2+shackleHeight/2;ctx2.fillRect(bodyX,bodyY,bodyWidth,bodyHeight),ctx2.restore()},"drawLockIcon"),drawStatsPill=__name((ctx2,rect,kind,fiber)=>{var _a;if(!fiber)return;const pillHeight=24,pillPadding=8,text=(_a=fiber?.type&&we$1(fiber.type))!=null?_a:"Unknown";ctx2.save(),ctx2.font="12px system-ui, -apple-system, sans-serif";const textWidth=ctx2.measureText(text).width,lockIconSize=kind==="locked"?14:0,lockIconPadding=kind==="locked"?6:0,pillWidth=textWidth+pillPadding*2+lockIconSize+lockIconPadding,pillX=rect.left,pillY=rect.top-pillHeight-4;if(ctx2.fillStyle="rgb(37, 37, 38, .75)",ctx2.beginPath(),ctx2.roundRect(pillX,pillY,pillWidth,pillHeight,3),ctx2.fill(),kind==="locked"){const lockX=pillX+pillPadding,lockY=pillY+(pillHeight-lockIconSize)/2+2;drawLockIcon(ctx2,lockX,lockY,lockIconSize),refCurrentLockIconRect.current={x:lockX,y:lockY,width:lockIconSize,height:lockIconSize}}else refCurrentLockIconRect.current=null;ctx2.fillStyle="white",ctx2.textBaseline="middle";const textX=pillX+pillPadding+(kind==="locked"?lockIconSize+lockIconPadding:0);ctx2.fillText(text,textX,pillY+pillHeight/2),ctx2.restore()},"drawStatsPill"),drawRect=__name((canvas2,ctx2,kind,fiber)=>{if(!refCurrentRect.current)return;const rect=refCurrentRect.current;ctx2.clearRect(0,0,canvas2.width,canvas2.height),ctx2.strokeStyle="rgba(142, 97, 227, 0.5)",ctx2.fillStyle="rgba(173, 97, 230, 0.10)",kind==="locked"?ctx2.setLineDash([]):ctx2.setLineDash([4]),ctx2.lineWidth=1,ctx2.fillRect(rect.left,rect.top,rect.width,rect.height),ctx2.strokeRect(rect.left,rect.top,rect.width,rect.height),drawStatsPill(ctx2,rect,kind,fiber)},"drawRect"),animate=__name((canvas2,ctx2,targetRect,kind,parentCompositeFiber,onComplete)=>{var _a;const speed=ReactScanInternals.options.value.animationSpeed,t2=(_a=ANIMATION_CONFIG.speeds[speed])!=null?_a:ANIMATION_CONFIG.speeds.off,animationFrame2=__name(timestamp=>{if(timestamp-refLastFrameTime.current<ANIMATION_CONFIG.frameInterval){refRafId.current=requestAnimationFrame(animationFrame2);return}if(refLastFrameTime.current=timestamp,!refCurrentRect.current){cancelAnimationFrame(refRafId.current);return}refCurrentRect.current={left:lerp2(refCurrentRect.current.left,targetRect.left,t2),top:lerp2(refCurrentRect.current.top,targetRect.top,t2),width:lerp2(refCurrentRect.current.width,targetRect.width,t2),height:lerp2(refCurrentRect.current.height,targetRect.height,t2)},drawRect(canvas2,ctx2,kind,parentCompositeFiber),Math.abs(refCurrentRect.current.left-targetRect.left)>.1||Math.abs(refCurrentRect.current.top-targetRect.top)>.1||Math.abs(refCurrentRect.current.width-targetRect.width)>.1||Math.abs(refCurrentRect.current.height-targetRect.height)>.1?refRafId.current=requestAnimationFrame(animationFrame2):(refCurrentRect.current=targetRect,drawRect(canvas2,ctx2,kind,parentCompositeFiber),cancelAnimationFrame(refRafId.current),ctx2.restore(),onComplete?.())},"animationFrame2");cancelAnimationFrame(refRafId.current),clearTimeout(refTimeout.current),refRafId.current=requestAnimationFrame(animationFrame2),refTimeout.current=setTimeout(()=>{cancelAnimationFrame(refRafId.current),refCurrentRect.current=targetRect,drawRect(canvas2,ctx2,kind,parentCompositeFiber),ctx2.restore(),onComplete?.()},1e3)},"animate"),setupOverlayAnimation=__name((canvas2,ctx2,targetRect,kind,parentCompositeFiber)=>{if(ctx2.save(),!refCurrentRect.current){refCurrentRect.current=targetRect,drawRect(canvas2,ctx2,kind,parentCompositeFiber),ctx2.restore();return}animate(canvas2,ctx2,targetRect,kind,parentCompositeFiber)},"setupOverlayAnimation"),drawHoverOverlay=__name(async(overlayElement,canvas2,ctx2,kind)=>{if(!overlayElement||!canvas2||!ctx2)return;const{parentCompositeFiber}=getCompositeComponentFromElement(overlayElement),targetRect=await getAssociatedFiberRect(overlayElement);!parentCompositeFiber||!targetRect||setupOverlayAnimation(canvas2,ctx2,targetRect,kind,parentCompositeFiber)},"drawHoverOverlay"),unsubscribeAll=__name(()=>{for(const cleanup3 of refCleanupMap.current.values())cleanup3?.()},"unsubscribeAll"),cleanupCanvas=__name(canvas2=>{const ctx2=canvas2.getContext("2d");ctx2&&ctx2.clearRect(0,0,canvas2.width,canvas2.height),refCurrentRect.current=null,refCurrentLockIconRect.current=null,refLastHoveredElement.current=null,canvas2.classList.remove("fade-in"),refIsFadingOut.current=!1},"cleanupCanvas"),startFadeOut=__name(onComplete=>{if(!refCanvas.current||refIsFadingOut.current)return;const handleTransitionEnd=__name(e2=>{!refCanvas.current||e2.propertyName!=="opacity"||!refIsFadingOut.current||(refCanvas.current.removeEventListener("transitionend",handleTransitionEnd),cleanupCanvas(refCanvas.current),onComplete?.())},"handleTransitionEnd"),existingListener=refCleanupMap.current.get("fade-out");existingListener&&(existingListener(),refCleanupMap.current.delete("fade-out")),refCanvas.current.addEventListener("transitionend",handleTransitionEnd),refCleanupMap.current.set("fade-out",()=>{var _a;(_a=refCanvas.current)==null||_a.removeEventListener("transitionend",handleTransitionEnd)}),refIsFadingOut.current=!0,refCanvas.current.classList.remove("fade-in"),requestAnimationFrame(()=>{var _a;(_a=refCanvas.current)==null||_a.classList.add("fade-out")})},"startFadeOut"),startFadeIn=__name(()=>{refCanvas.current&&(refIsFadingOut.current=!1,refCanvas.current.classList.remove("fade-out"),requestAnimationFrame(()=>{var _a;(_a=refCanvas.current)==null||_a.classList.add("fade-in")}))},"startFadeIn"),handleHoverableElement=__name(componentElement=>{componentElement!==refLastHoveredElement.current&&(refLastHoveredElement.current=componentElement,nonVisualTags.has(componentElement.tagName)?startFadeOut():startFadeIn(),Store.inspectState.value={kind:"inspecting",hoveredDomElement:componentElement})},"handleHoverableElement"),handleNonHoverableArea=__name(()=>{!refCurrentRect.current||!refCanvas.current||refIsFadingOut.current||startFadeOut()},"handleNonHoverableArea"),handlePointerMove=throttle(e2=>{var _a,_b;if(Store.inspectState.peek().kind!=="inspecting"||!refEventCatcher.current)return;refEventCatcher.current.style.pointerEvents="none";const element=document.elementFromPoint((_a=e2?.clientX)!=null?_a:0,(_b=e2?.clientY)!=null?_b:0);if(refEventCatcher.current.style.removeProperty("pointer-events"),clearTimeout(refTimeout.current),element&&element!==refCanvas.current){const{parentCompositeFiber}=getCompositeComponentFromElement(element);if(parentCompositeFiber){const componentElement=findComponentDOMNode(parentCompositeFiber);if(componentElement){handleHoverableElement(componentElement);return}}}handleNonHoverableArea()},32),isClickInLockIcon=__name((e2,canvas2)=>{const currentRect=refCurrentLockIconRect.current;if(!currentRect)return!1;const rect=canvas2.getBoundingClientRect(),scaleX=canvas2.width/rect.width,scaleY=canvas2.height/rect.height,x2=(e2.clientX-rect.left)*scaleX,y2=(e2.clientY-rect.top)*scaleY,adjustedX=x2/OVERLAY_DPR,adjustedY=y2/OVERLAY_DPR;return adjustedX>=currentRect.x&&adjustedX<=currentRect.x+currentRect.width&&adjustedY>=currentRect.y&&adjustedY<=currentRect.y+currentRect.height},"isClickInLockIcon"),handleLockIconClick=__name(state=>{state.kind==="focused"&&(Store.inspectState.value={kind:"inspecting",hoveredDomElement:state.focusedDomElement})},"handleLockIconClick"),handleElementClick=__name(e2=>{var _a,_b;const clickableElements=["react-scan-inspect-element","react-scan-power"];if(e2.target instanceof HTMLElement&&clickableElements.includes(e2.target.id))return;const tagName=(_a=refLastHoveredElement.current)==null?void 0:_a.tagName;if(tagName&&nonVisualTags.has(tagName))return;e2.preventDefault(),e2.stopPropagation();const element=(_b=refLastHoveredElement.current)!=null?_b:document.elementFromPoint(e2.clientX,e2.clientY);if(!element)return;const clickedEl=e2.composedPath().at(0);if(clickedEl instanceof HTMLElement&&clickableElements.includes(clickedEl.id)){const syntheticEvent=new MouseEvent(e2.type,e2);syntheticEvent.__reactScanSyntheticEvent=!0,clickedEl.dispatchEvent(syntheticEvent);return}const{parentCompositeFiber}=getCompositeComponentFromElement(element);if(!parentCompositeFiber)return;const componentElement=findComponentDOMNode(parentCompositeFiber);if(!componentElement){refLastHoveredElement.current=null,Store.inspectState.value={kind:"inspect-off"};return}Store.inspectState.value={kind:"focused",focusedDomElement:componentElement,fiber:parentCompositeFiber}},"handleElementClick"),handleClick=__name(e2=>{if(e2.__reactScanSyntheticEvent)return;const state=Store.inspectState.peek(),canvas2=refCanvas.current;if(!(!canvas2||!refEventCatcher.current)){if(isClickInLockIcon(e2,canvas2)){e2.preventDefault(),e2.stopPropagation(),handleLockIconClick(state);return}state.kind==="inspecting"&&handleElementClick(e2)}},"handleClick"),handleKeyDown=__name(e2=>{var _a;if(e2.key!=="Escape")return;const state=Store.inspectState.peek();if(refCanvas.current&&((_a=document.activeElement)==null?void 0:_a.id)!=="react-scan-root"&&(signalWidgetViews.value={view:"none"},state.kind==="focused"||state.kind==="inspecting"))switch(e2.preventDefault(),e2.stopPropagation(),state.kind){case"focused":startFadeIn(),refCurrentRect.current=null,refLastHoveredElement.current=state.focusedDomElement,Store.inspectState.value={kind:"inspecting",hoveredDomElement:state.focusedDomElement};break;case"inspecting":startFadeOut(()=>{signalIsSettingsOpen.value=!1,Store.inspectState.value={kind:"inspect-off"}});break}},"handleKeyDown"),handleStateChange=__name((state,canvas2,ctx2)=>{var _a;(_a=refCleanupMap.current.get(state.kind))==null||_a(),refEventCatcher.current&&state.kind!=="inspecting"&&(refEventCatcher.current.style.pointerEvents="none"),refRafId.current&&cancelAnimationFrame(refRafId.current);let unsubReport;switch(state.kind){case"inspect-off":startFadeOut();return;case"inspecting":drawHoverOverlay(state.hoveredDomElement,canvas2,ctx2,"inspecting");break;case"focused":if(!state.focusedDomElement)return;refLastHoveredElement.current!==state.focusedDomElement&&(refLastHoveredElement.current=state.focusedDomElement),signalWidgetViews.value={view:"inspector"},drawHoverOverlay(state.focusedDomElement,canvas2,ctx2,"locked"),unsubReport=Store.lastReportTime.subscribe(()=>{if(refRafId.current&&refCurrentRect.current){const{parentCompositeFiber}=getCompositeComponentFromElement(state.focusedDomElement);parentCompositeFiber&&drawHoverOverlay(state.focusedDomElement,canvas2,ctx2,"locked")}}),unsubReport&&refCleanupMap.current.set(state.kind,unsubReport);break}},"handleStateChange"),updateCanvasSize=__name((canvas2,ctx2)=>{const rect=canvas2.getBoundingClientRect();canvas2.width=rect.width*OVERLAY_DPR,canvas2.height=rect.height*OVERLAY_DPR,ctx2.scale(OVERLAY_DPR,OVERLAY_DPR),ctx2.save()},"updateCanvasSize"),handleResizeOrScroll=__name(()=>{const state=Store.inspectState.peek(),canvas2=refCanvas.current;if(!canvas2)return;const ctx2=canvas2?.getContext("2d");ctx2&&(cancelAnimationFrame(refRafId.current),clearTimeout(refTimeout.current),updateCanvasSize(canvas2,ctx2),refCurrentRect.current=null,state.kind==="focused"&&state.focusedDomElement?drawHoverOverlay(state.focusedDomElement,canvas2,ctx2,"locked"):state.kind==="inspecting"&&state.hoveredDomElement&&drawHoverOverlay(state.hoveredDomElement,canvas2,ctx2,"inspecting"))},"handleResizeOrScroll"),handlePointerDown=__name(e2=>{const state=Store.inspectState.peek(),canvas2=refCanvas.current;canvas2&&(state.kind==="inspecting"||isClickInLockIcon(e2,canvas2))&&(e2.preventDefault(),e2.stopPropagation(),e2.stopImmediatePropagation())},"handlePointerDown");return y$5(()=>{const canvas2=refCanvas.current;if(!canvas2)return;const ctx2=canvas2?.getContext("2d");if(!ctx2)return;updateCanvasSize(canvas2,ctx2);const unSubState=Store.inspectState.subscribe(state=>{handleStateChange(state,canvas2,ctx2)});return window.addEventListener("scroll",handleResizeOrScroll,{passive:!0}),window.addEventListener("resize",handleResizeOrScroll,{passive:!0}),document.addEventListener("pointermove",handlePointerMove,{passive:!0,capture:!0}),document.addEventListener("pointerdown",handlePointerDown,{capture:!0}),document.addEventListener("click",handleClick,{capture:!0}),document.addEventListener("keydown",handleKeyDown,{capture:!0}),()=>{unsubscribeAll(),unSubState(),window.removeEventListener("scroll",handleResizeOrScroll),window.removeEventListener("resize",handleResizeOrScroll),document.removeEventListener("pointermove",handlePointerMove,{capture:!0}),document.removeEventListener("click",handleClick,{capture:!0}),document.removeEventListener("pointerdown",handlePointerDown,{capture:!0}),document.removeEventListener("keydown",handleKeyDown,{capture:!0}),refRafId.current&&cancelAnimationFrame(refRafId.current),clearTimeout(refTimeout.current)}},[]),u$2(S$4,{children:[u$2("div",{ref:refEventCatcher,className:cn("fixed top-0 left-0 w-screen h-screen","z-[214748365]"),style:{pointerEvents:"none"}}),u$2("canvas",{ref:refCanvas,dir:"ltr",className:cn("react-scan-inspector-overlay","fixed top-0 left-0 w-screen h-screen","pointer-events-none","z-[214748367]")})]})},"ScanOverlay"),WindowDimensions=class{static{__name(this,"WindowDimensions")}constructor(width,height,safeArea){__publicField(this,"width",width),__publicField(this,"height",height),__publicField(this,"safeArea",safeArea),__publicField(this,"maxWidth"),__publicField(this,"maxHeight"),this.maxWidth=width-safeArea.left-safeArea.right,this.maxHeight=height-safeArea.top-safeArea.bottom}rightEdge(width){return this.width-width-this.safeArea.right}bottomEdge(height){return this.height-height-this.safeArea.bottom}isFullWidth(width){return width>=this.maxWidth}isFullHeight(height){return height>=this.maxHeight}},cachedWindowDimensions,safeAreaMatches=__name((a2,b2)=>a2.top===b2.top&&a2.right===b2.right&&a2.bottom===b2.bottom&&a2.left===b2.left,"safeAreaMatches"),getWindowDimensions=__name(()=>{const currentWidth=window.innerWidth,currentHeight=window.innerHeight,currentSafeArea=getSafeArea();return cachedWindowDimensions&&cachedWindowDimensions.width===currentWidth&&cachedWindowDimensions.height===currentHeight&&safeAreaMatches(cachedWindowDimensions.safeArea,currentSafeArea)||(cachedWindowDimensions=new WindowDimensions(currentWidth,currentHeight,currentSafeArea)),cachedWindowDimensions},"getWindowDimensions"),getOppositeCorner=__name((position,currentCorner,isFullScreen,isFullWidth,isFullHeight)=>{if(isFullScreen){if(position==="top-left")return"bottom-right";if(position==="top-right")return"bottom-left";if(position==="bottom-left")return"top-right";if(position==="bottom-right")return"top-left";const[vertical,horizontal]=currentCorner.split("-");if(position==="left")return`${vertical}-right`;if(position==="right")return`${vertical}-left`;if(position==="top")return`bottom-${horizontal}`;if(position==="bottom")return`top-${horizontal}`}if(isFullWidth){if(position==="left")return`${currentCorner.split("-")[0]}-right`;if(position==="right")return`${currentCorner.split("-")[0]}-left`}if(isFullHeight){if(position==="top")return`bottom-${currentCorner.split("-")[1]}`;if(position==="bottom")return`top-${currentCorner.split("-")[1]}`}return currentCorner},"getOppositeCorner"),calculatePosition=__name((corner,width,height)=>{const isRTL=getComputedStyle(document.body).direction==="rtl",windowWidth=window.innerWidth,windowHeight=window.innerHeight,safeArea=getSafeArea(),isMinimized=width===MIN_SIZE.width,effectiveWidth=isMinimized?width:Math.min(width,windowWidth-safeArea.left-safeArea.right),effectiveHeight=isMinimized?height:Math.min(height,windowHeight-safeArea.top-safeArea.bottom);let x2,y2,leftBound=safeArea.left,rightBound=windowWidth-effectiveWidth-safeArea.right,topBound=safeArea.top,bottomBound=windowHeight-effectiveHeight-safeArea.bottom;const rtlRightCornerX=-safeArea.right,rtlLeftCornerX=-(windowWidth-effectiveWidth-safeArea.left);switch(corner){case"top-right":x2=isRTL?rtlRightCornerX:rightBound,y2=topBound;break;case"bottom-right":x2=isRTL?rtlRightCornerX:rightBound,y2=bottomBound;break;case"bottom-left":x2=isRTL?rtlLeftCornerX:leftBound,y2=bottomBound;break;case"top-left":x2=isRTL?rtlLeftCornerX:leftBound,y2=topBound;break;default:x2=leftBound,y2=topBound;break}return isMinimized&&(isRTL?x2=Math.min(rtlRightCornerX,Math.max(x2,rtlLeftCornerX)):x2=Math.max(leftBound,Math.min(x2,rightBound)),y2=Math.max(topBound,Math.min(y2,bottomBound))),{x:x2,y:y2}},"calculatePosition"),positionMatchesCorner=__name((position,corner)=>{const[vertical,horizontal]=corner.split("-");return position!==vertical&&position!==horizontal},"positionMatchesCorner"),getHandleVisibility=__name((position,corner,isFullWidth,isFullHeight)=>isFullWidth&&isFullHeight?!0:!isFullWidth&&!isFullHeight?positionMatchesCorner(position,corner):isFullWidth?position!==corner.split("-")[0]:isFullHeight?position!==corner.split("-")[1]:!1,"getHandleVisibility"),calculateBoundedSize=__name((currentSize,delta,isWidth)=>{const min=isWidth?MIN_SIZE.width:MIN_SIZE.initialHeight,max=isWidth?getWindowDimensions().maxWidth:getWindowDimensions().maxHeight,newSize=currentSize+delta;return Math.min(Math.max(min,newSize),max)},"calculateBoundedSize"),calculateNewSizeAndPosition=__name((position,initialSize,initialPosition,deltaX,deltaY)=>{const isRTL=getComputedStyle(document.body).direction==="rtl",safeArea=getSafeArea(),maxWidth=window.innerWidth-safeArea.left-safeArea.right,maxHeight=window.innerHeight-safeArea.top-safeArea.bottom;let newWidth=initialSize.width,newHeight=initialSize.height,newX=initialPosition.x,newY=initialPosition.y;if(isRTL&&position.includes("right")){const availableWidth=-initialPosition.x+initialSize.width-safeArea.right,proposedWidth=Math.min(initialSize.width+deltaX,availableWidth);newWidth=Math.min(maxWidth,Math.max(MIN_SIZE.width,proposedWidth)),newX=initialPosition.x+(newWidth-initialSize.width)}if(isRTL&&position.includes("left")){const availableWidth=window.innerWidth-initialPosition.x-safeArea.left,proposedWidth=Math.min(initialSize.width-deltaX,availableWidth);newWidth=Math.min(maxWidth,Math.max(MIN_SIZE.width,proposedWidth))}if(!isRTL&&position.includes("right")){const availableWidth=window.innerWidth-initialPosition.x-safeArea.right,proposedWidth=Math.min(initialSize.width+deltaX,availableWidth);newWidth=Math.min(maxWidth,Math.max(MIN_SIZE.width,proposedWidth))}if(!isRTL&&position.includes("left")){const availableWidth=initialPosition.x+initialSize.width-safeArea.left,proposedWidth=Math.min(initialSize.width-deltaX,availableWidth);newWidth=Math.min(maxWidth,Math.max(MIN_SIZE.width,proposedWidth)),newX=initialPosition.x-(newWidth-initialSize.width)}if(position.includes("bottom")){const availableHeight=window.innerHeight-initialPosition.y-safeArea.bottom,proposedHeight=Math.min(initialSize.height+deltaY,availableHeight);newHeight=Math.min(maxHeight,Math.max(MIN_SIZE.initialHeight,proposedHeight))}if(position.includes("top")){const availableHeight=initialPosition.y+initialSize.height-safeArea.top,proposedHeight=Math.min(initialSize.height-deltaY,availableHeight);newHeight=Math.min(maxHeight,Math.max(MIN_SIZE.initialHeight,proposedHeight)),newY=initialPosition.y-(newHeight-initialSize.height)}let leftBound=safeArea.left,rightBound=window.innerWidth-safeArea.right-newWidth,topBound=safeArea.top,bottomBound=window.innerHeight-safeArea.bottom-newHeight;const rtlRightCornerX=-safeArea.right,rtlLeftCornerX=-(window.innerWidth-newWidth-safeArea.left);return isRTL?newX=Math.min(rtlRightCornerX,Math.max(newX,rtlLeftCornerX)):newX=Math.max(leftBound,Math.min(newX,rightBound)),newY=Math.max(topBound,Math.min(newY,bottomBound)),{newSize:{width:newWidth,height:newHeight},newPosition:{x:newX,y:newY}}},"calculateNewSizeAndPosition"),getClosestCorner=__name(position=>{const windowDims=getWindowDimensions(),distances={"top-left":Math.hypot(position.x,position.y),"top-right":Math.hypot(windowDims.maxWidth-position.x,position.y),"bottom-left":Math.hypot(position.x,windowDims.maxHeight-position.y),"bottom-right":Math.hypot(windowDims.maxWidth-position.x,windowDims.maxHeight-position.y)};let closest="top-left";for(const key in distances)distances[key]<distances[closest]&&(closest=key);return closest},"getClosestCorner"),getBestCorner=__name((mouseX,mouseY,initialMouseX,initialMouseY,threshold=100)=>{const deltaX=initialMouseX!==void 0?mouseX-initialMouseX:0,deltaY=initialMouseY!==void 0?mouseY-initialMouseY:0,windowCenterX=window.innerWidth/2,windowCenterY=window.innerHeight/2,movingRight=deltaX>threshold,movingLeft=deltaX<-threshold,movingDown=deltaY>threshold,movingUp=deltaY<-threshold;if(movingRight||movingLeft){const isBottom=mouseY>windowCenterY;return movingRight?isBottom?"bottom-right":"top-right":isBottom?"bottom-left":"top-left"}if(movingDown||movingUp){const isRight=mouseX>windowCenterX;return movingDown?isRight?"bottom-right":"bottom-left":isRight?"top-right":"top-left"}return mouseX>windowCenterX?mouseY>windowCenterY?"bottom-right":"top-right":mouseY>windowCenterY?"bottom-left":"top-left"},"getBestCorner"),ResizeHandle=__name(({position})=>{const refContainer=A$3(null),prevWidth=A$3(null),prevHeight=A$3(null),prevCorner=A$3(null);return y$5(()=>{const container=refContainer.current;if(!container)return;const updateVisibility=__name(()=>{container.classList.remove("pointer-events-none");const isFocused=Store.inspectState.value.kind==="focused",shouldShow=signalWidgetViews.value.view!=="none";(isFocused||shouldShow)&&getHandleVisibility(position,signalWidget.value.corner,signalWidget.value.dimensions.isFullWidth,signalWidget.value.dimensions.isFullHeight)?container.classList.remove("hidden","pointer-events-none","opacity-0"):container.classList.add("hidden","pointer-events-none","opacity-0")},"updateVisibility"),unsubscribeSignalWidget=signalWidget.subscribe(state=>{prevWidth.current!==null&&prevHeight.current!==null&&prevCorner.current!==null&&state.dimensions.width===prevWidth.current&&state.dimensions.height===prevHeight.current&&state.corner===prevCorner.current||(updateVisibility(),prevWidth.current=state.dimensions.width,prevHeight.current=state.dimensions.height,prevCorner.current=state.corner)}),unsubscribeInspectState=Store.inspectState.subscribe(()=>{updateVisibility()});return()=>{unsubscribeSignalWidget(),unsubscribeInspectState(),prevWidth.current=null,prevHeight.current=null,prevCorner.current=null}},[]),u$2("div",{ref:refContainer,onPointerDown:q$2(e2=>{e2.preventDefault(),e2.stopPropagation();const widget=signalRefWidget.value;if(!widget)return;const containerStyle=widget.style,{dimensions}=signalWidget.value,initialX=e2.clientX,initialY=e2.clientY,initialWidth=dimensions.width,initialHeight=dimensions.height,initialPosition=dimensions.position;signalWidget.value={...signalWidget.value,dimensions:{...dimensions,isFullWidth:!1,isFullHeight:!1,width:initialWidth,height:initialHeight,position:initialPosition}};let rafId=null;const handlePointerMove=__name(e22=>{rafId||(containerStyle.transition="none",rafId=requestAnimationFrame(()=>{const{newSize,newPosition}=calculateNewSizeAndPosition(position,{width:initialWidth,height:initialHeight},initialPosition,e22.clientX-initialX,e22.clientY-initialY);containerStyle.transform=`translate3d(${newPosition.x}px, ${newPosition.y}px, 0)`,containerStyle.width=`${newSize.width}px`,containerStyle.height=`${newSize.height}px`;const maxTreeWidth=Math.floor(newSize.width-MIN_CONTAINER_WIDTH/2),currentTreeWidth=signalWidget.value.componentsTree.width,newTreeWidth=Math.min(maxTreeWidth,Math.max(MIN_CONTAINER_WIDTH,currentTreeWidth));signalWidget.value={...signalWidget.value,dimensions:{isFullWidth:!1,isFullHeight:!1,width:newSize.width,height:newSize.height,position:newPosition},componentsTree:{...signalWidget.value.componentsTree,width:newTreeWidth}},rafId=null}))},"handlePointerMove"),handlePointerUp=__name(()=>{rafId&&(cancelAnimationFrame(rafId),rafId=null),document.removeEventListener("pointermove",handlePointerMove),document.removeEventListener("pointerup",handlePointerUp);const{dimensions:dimensions2,corner}=signalWidget.value,windowDims=getWindowDimensions(),isCurrentFullWidth=windowDims.isFullWidth(dimensions2.width),isCurrentFullHeight=windowDims.isFullHeight(dimensions2.height),isFullScreen=isCurrentFullWidth&&isCurrentFullHeight;let newCorner=corner;(isFullScreen||isCurrentFullWidth||isCurrentFullHeight)&&(newCorner=getClosestCorner(dimensions2.position));const newPosition=calculatePosition(newCorner,dimensions2.width,dimensions2.height),onTransitionEnd=__name(()=>{widget.removeEventListener("transitionend",onTransitionEnd)},"onTransitionEnd");widget.addEventListener("transitionend",onTransitionEnd),containerStyle.transform=`translate3d(${newPosition.x}px, ${newPosition.y}px, 0)`,signalWidget.value={...signalWidget.value,corner:newCorner,dimensions:{isFullWidth:isCurrentFullWidth,isFullHeight:isCurrentFullHeight,width:dimensions2.width,height:dimensions2.height,position:newPosition},lastDimensions:{isFullWidth:isCurrentFullWidth,isFullHeight:isCurrentFullHeight,width:dimensions2.width,height:dimensions2.height,position:newPosition}},saveLocalStorage$1(LOCALSTORAGE_KEY,{corner:newCorner,dimensions:signalWidget.value.dimensions,lastDimensions:signalWidget.value.lastDimensions,componentsTree:signalWidget.value.componentsTree})},"handlePointerUp");document.addEventListener("pointermove",handlePointerMove,{passive:!0}),document.addEventListener("pointerup",handlePointerUp)},[]),onDblClick:q$2(e2=>{e2.preventDefault(),e2.stopPropagation();const widget=signalRefWidget.value;if(!widget)return;const containerStyle=widget.style,{dimensions,corner}=signalWidget.value,windowDims=getWindowDimensions(),isCurrentFullWidth=windowDims.isFullWidth(dimensions.width),isCurrentFullHeight=windowDims.isFullHeight(dimensions.height),isFullScreen=isCurrentFullWidth&&isCurrentFullHeight,isPartiallyMaximized=(isCurrentFullWidth||isCurrentFullHeight)&&!isFullScreen;let newWidth=dimensions.width,newHeight=dimensions.height;const newCorner=getOppositeCorner(position,corner,isFullScreen,isCurrentFullWidth,isCurrentFullHeight);position==="left"||position==="right"?(newWidth=isCurrentFullWidth?dimensions.width:windowDims.maxWidth,isPartiallyMaximized&&(newWidth=isCurrentFullWidth?MIN_SIZE.width:windowDims.maxWidth)):(newHeight=isCurrentFullHeight?dimensions.height:windowDims.maxHeight,isPartiallyMaximized&&(newHeight=isCurrentFullHeight?MIN_SIZE.initialHeight:windowDims.maxHeight)),isFullScreen&&(position==="left"||position==="right"?newWidth=MIN_SIZE.width:newHeight=MIN_SIZE.initialHeight);const newPosition=calculatePosition(newCorner,newWidth,newHeight),newDimensions={isFullWidth:windowDims.isFullWidth(newWidth),isFullHeight:windowDims.isFullHeight(newHeight),width:newWidth,height:newHeight,position:newPosition},maxTreeWidth=Math.floor(newWidth-MIN_SIZE.width/2),currentTreeWidth=signalWidget.value.componentsTree.width,defaultWidth=Math.floor(newWidth*.3),newTreeWidth=isCurrentFullWidth?MIN_CONTAINER_WIDTH:(position==="left"||position==="right")&&!isCurrentFullWidth?Math.min(maxTreeWidth,Math.max(MIN_CONTAINER_WIDTH,defaultWidth)):Math.min(maxTreeWidth,Math.max(MIN_CONTAINER_WIDTH,currentTreeWidth));requestAnimationFrame(()=>{signalWidget.value={corner:newCorner,dimensions:newDimensions,lastDimensions:dimensions,componentsTree:{...signalWidget.value.componentsTree,width:newTreeWidth}},containerStyle.transition="all 0.25s cubic-bezier(0, 0, 0.2, 1)",containerStyle.width=`${newWidth}px`,containerStyle.height=`${newHeight}px`,containerStyle.transform=`translate3d(${newPosition.x}px, ${newPosition.y}px, 0)`}),saveLocalStorage$1(LOCALSTORAGE_KEY,{corner:newCorner,dimensions:newDimensions,lastDimensions:dimensions,componentsTree:{...signalWidget.value.componentsTree,width:newTreeWidth}})},[]),className:cn("absolute z-50","flex items-center justify-center","group","transition-colors select-none","peer",{"resize-left peer/left":position==="left","resize-right peer/right z-10":position==="right","resize-top peer/top":position==="top","resize-bottom peer/bottom":position==="bottom"}),children:u$2("span",{className:"resize-line-wrapper",children:u$2("span",{className:"resize-line",children:u$2(Icon,{name:"icon-ellipsis",size:18,className:cn("text-neutral-400",(position==="left"||position==="right")&&"rotate-90")})})})})},"ResizeHandle"),COLLAPSED_SIZE={horizontal:{width:20,height:48},vertical:{width:48,height:20}},Widget=__name(()=>{const refWidget=A$3(null),refShouldOpen=A$3(!1),refInitialMinimizedWidth=A$3(0),refInitialMinimizedHeight=A$3(0),refExpandingFromCollapsed=A$3(!1),updateWidgetPosition=q$2((shouldSave=!0)=>{if(!refWidget.current)return;const{corner}=signalWidget.value;let newWidth,newHeight;if(signalWidgetCollapsed.value){const size=COLLAPSED_SIZE[signalWidgetCollapsed.value.orientation||"horizontal"];newWidth=size.width,newHeight=size.height}else if(refShouldOpen.current){const lastDims=signalWidget.value.lastDimensions;newWidth=calculateBoundedSize(lastDims.width,0,!0),newHeight=calculateBoundedSize(lastDims.height,0,!1),refExpandingFromCollapsed.current&&(refExpandingFromCollapsed.current=!1)}else newWidth=refInitialMinimizedWidth.current,newHeight=refInitialMinimizedHeight.current;let finalPosition=calculatePosition(corner,newWidth,newHeight);if(signalWidgetCollapsed.value){const{corner:collapsedCorner,orientation="horizontal"}=signalWidgetCollapsed.value,size=COLLAPSED_SIZE[orientation],safeArea2=getSafeArea();switch(collapsedCorner){case"top-left":finalPosition=orientation==="horizontal"?{x:-1,y:safeArea2.top}:{x:safeArea2.left,y:-1};break;case"bottom-left":finalPosition=orientation==="horizontal"?{x:-1,y:window.innerHeight-size.height-safeArea2.bottom}:{x:safeArea2.left,y:window.innerHeight-size.height+1};break;case"top-right":finalPosition=orientation==="horizontal"?{x:window.innerWidth-size.width+1,y:safeArea2.top}:{x:window.innerWidth-size.width-safeArea2.right,y:-1};break;default:finalPosition=orientation==="horizontal"?{x:window.innerWidth-size.width+1,y:window.innerHeight-size.height-safeArea2.bottom}:{x:window.innerWidth-size.width-safeArea2.right,y:window.innerHeight-size.height+1};break}}const isTooSmall=newWidth<MIN_SIZE.width||newHeight<MIN_SIZE.initialHeight,shouldPersist=shouldSave&&!isTooSmall,container=refWidget.current,containerStyle=container.style;let rafId=null;const onTransitionEnd=__name(()=>{updateDimensions(),container.removeEventListener("transitionend",onTransitionEnd),rafId&&(cancelAnimationFrame(rafId),rafId=null)},"onTransitionEnd");container.addEventListener("transitionend",onTransitionEnd),containerStyle.transition="all 0.25s cubic-bezier(0, 0, 0.2, 1)",rafId=requestAnimationFrame(()=>{containerStyle.width=`${newWidth}px`,containerStyle.height=`${newHeight}px`,containerStyle.transform=`translate3d(${finalPosition.x}px, ${finalPosition.y}px, 0)`,rafId=null});const safeArea=getSafeArea(),newDimensions={isFullWidth:newWidth>=window.innerWidth-safeArea.left-safeArea.right,isFullHeight:newHeight>=window.innerHeight-safeArea.top-safeArea.bottom,width:newWidth,height:newHeight,position:finalPosition};signalWidget.value={corner,dimensions:newDimensions,lastDimensions:refShouldOpen?signalWidget.value.lastDimensions:newWidth>refInitialMinimizedWidth.current?newDimensions:signalWidget.value.lastDimensions,componentsTree:signalWidget.value.componentsTree},shouldPersist&&saveLocalStorage$1(LOCALSTORAGE_KEY,{corner:signalWidget.value.corner,dimensions:signalWidget.value.dimensions,lastDimensions:signalWidget.value.lastDimensions,componentsTree:signalWidget.value.componentsTree}),updateDimensions()},[]),handleDrag=q$2(e2=>{if(e2.target.closest(TOOLBAR_INTERACTIVE_SELECTOR)||(e2.preventDefault(),!refWidget.current))return;const container=refWidget.current,containerStyle=container.style,{dimensions}=signalWidget.value,initialMouseX=e2.clientX,initialMouseY=e2.clientY,initialX=dimensions.position.x,initialY=dimensions.position.y;let currentX=initialX,currentY=initialY,rafId=null,hasMoved=!1,lastMouseX=initialMouseX,lastMouseY=initialMouseY;const handlePointerMove=__name(e22=>{rafId||(hasMoved=!0,lastMouseX=e22.clientX,lastMouseY=e22.clientY,rafId=requestAnimationFrame(()=>{const deltaX=lastMouseX-initialMouseX,deltaY=lastMouseY-initialMouseY;currentX=Number(initialX)+deltaX,currentY=Number(initialY)+deltaY,containerStyle.transition="none",containerStyle.transform=`translate3d(${currentX}px, ${currentY}px, 0)`;const widgetRight=currentX+dimensions.width,widgetBottom=currentY+dimensions.height,outsideLeft=Math.max(0,-currentX),outsideRight=Math.max(0,widgetRight-window.innerWidth),outsideTop=Math.max(0,-currentY),outsideBottom=Math.max(0,widgetBottom-window.innerHeight),horizontalOutside=Math.min(dimensions.width,outsideLeft+outsideRight),verticalOutside=Math.min(dimensions.height,outsideTop+outsideBottom);let shouldCollapse=horizontalOutside*dimensions.height+verticalOutside*dimensions.width-horizontalOutside*verticalOutside>dimensions.width*dimensions.height*.35;if(!shouldCollapse&&ReactScanInternals.options.value.showFPS){const fpsRight=currentX+dimensions.width,fpsLeft=fpsRight-100;shouldCollapse=fpsRight<=0||fpsLeft>=window.innerWidth||currentY+dimensions.height<=0||currentY>=window.innerHeight}if(shouldCollapse){const widgetCenterX=currentX+dimensions.width/2,widgetCenterY=currentY+dimensions.height/2,screenCenterX=window.innerWidth/2,screenCenterY=window.innerHeight/2;let targetCorner;widgetCenterX<screenCenterX?targetCorner=widgetCenterY<screenCenterY?"top-left":"bottom-left":targetCorner=widgetCenterY<screenCenterY?"top-right":"bottom-right";let orientation;orientation=Math.max(outsideLeft,outsideRight)>Math.max(outsideTop,outsideBottom)?"horizontal":"vertical",signalWidget.value={...signalWidget.value,corner:targetCorner,lastDimensions:{...dimensions,position:calculatePosition(targetCorner,dimensions.width,dimensions.height)}};const collapsedPosition={corner:targetCorner,orientation};signalWidgetCollapsed.value=collapsedPosition,saveLocalStorage$1(LOCALSTORAGE_COLLAPSED_KEY,collapsedPosition),saveLocalStorage$1(LOCALSTORAGE_KEY,signalWidget.value),updateWidgetPosition(!1),document.removeEventListener("pointermove",handlePointerMove),document.removeEventListener("pointerup",handlePointerEnd),rafId&&(cancelAnimationFrame(rafId),rafId=null)}rafId=null}))},"handlePointerMove"),handlePointerEnd=__name(()=>{if(!container)return;rafId&&(cancelAnimationFrame(rafId),rafId=null),document.removeEventListener("pointermove",handlePointerMove),document.removeEventListener("pointerup",handlePointerEnd);const totalDeltaX=Math.abs(lastMouseX-initialMouseX),totalDeltaY=Math.abs(lastMouseY-initialMouseY),totalMovement=Math.sqrt(totalDeltaX*totalDeltaX+totalDeltaY*totalDeltaY);if(!hasMoved||totalMovement<60)return;const newCorner=getBestCorner(lastMouseX,lastMouseY,initialMouseX,initialMouseY,Store.inspectState.value.kind==="focused"?80:40);if(newCorner===signalWidget.value.corner){containerStyle.transition="transform 0.25s cubic-bezier(0, 0, 0.2, 1)";const currentPosition=signalWidget.value.dimensions.position;requestAnimationFrame(()=>{containerStyle.transform=`translate3d(${currentPosition.x}px, ${currentPosition.y}px, 0)`});return}const snappedPosition=calculatePosition(newCorner,dimensions.width,dimensions.height);if(currentX===initialX&&currentY===initialY)return;const onTransitionEnd=__name(()=>{containerStyle.transition="none",updateDimensions(),container.removeEventListener("transitionend",onTransitionEnd),rafId&&(cancelAnimationFrame(rafId),rafId=null)},"onTransitionEnd");container.addEventListener("transitionend",onTransitionEnd),containerStyle.transition="transform 0.25s cubic-bezier(0, 0, 0.2, 1)",requestAnimationFrame(()=>{containerStyle.transform=`translate3d(${snappedPosition.x}px, ${snappedPosition.y}px, 0)`}),signalWidget.value={corner:newCorner,dimensions:{isFullWidth:dimensions.isFullWidth,isFullHeight:dimensions.isFullHeight,width:dimensions.width,height:dimensions.height,position:snappedPosition},lastDimensions:signalWidget.value.lastDimensions,componentsTree:signalWidget.value.componentsTree},saveLocalStorage$1(LOCALSTORAGE_KEY,{corner:newCorner,dimensions:signalWidget.value.dimensions,lastDimensions:signalWidget.value.lastDimensions,componentsTree:signalWidget.value.componentsTree})},"handlePointerEnd");document.addEventListener("pointermove",handlePointerMove),document.addEventListener("pointerup",handlePointerEnd)},[]),handleCollapsedDrag=q$2(e2=>{if(e2.preventDefault(),!refWidget.current||!signalWidgetCollapsed.value)return;const{corner:collapsedCorner,orientation="horizontal"}=signalWidgetCollapsed.value,initialMouseX=e2.clientX,initialMouseY=e2.clientY;let rafId=null,hasExpanded=!1;const DRAG_THRESHOLD=50,handlePointerMove=__name(e22=>{if(hasExpanded||rafId)return;const deltaX=e22.clientX-initialMouseX,deltaY=e22.clientY-initialMouseY;let shouldExpand=!1;orientation==="horizontal"?(collapsedCorner.endsWith("left")&&deltaX>DRAG_THRESHOLD||collapsedCorner.endsWith("right")&&deltaX<-DRAG_THRESHOLD)&&(shouldExpand=!0):(collapsedCorner.startsWith("top")&&deltaY>DRAG_THRESHOLD||collapsedCorner.startsWith("bottom")&&deltaY<-DRAG_THRESHOLD)&&(shouldExpand=!0),shouldExpand&&(hasExpanded=!0,signalWidgetCollapsed.value=null,saveLocalStorage$1(LOCALSTORAGE_COLLAPSED_KEY,null),refInitialMinimizedWidth.current===0&&refWidget.current?requestAnimationFrame(()=>{if(refWidget.current){refWidget.current.style.width="min-content",refInitialMinimizedWidth.current=refWidget.current.offsetWidth||300;const lastDims=signalWidget.value.lastDimensions,targetWidth=calculateBoundedSize(lastDims.width,0,!0),targetHeight=calculateBoundedSize(lastDims.height,0,!1);let newX=e22.clientX-targetWidth/2,newY=e22.clientY-targetHeight/2;const safeArea=getSafeArea();newX=Math.max(safeArea.left,Math.min(newX,window.innerWidth-targetWidth-safeArea.right)),newY=Math.max(safeArea.top,Math.min(newY,window.innerHeight-targetHeight-safeArea.bottom)),signalWidget.value={...signalWidget.value,dimensions:{...signalWidget.value.dimensions,position:{x:newX,y:newY}}},updateWidgetPosition(!0),signalWidgetViews.value=readLocalStorage$1(LOCALSTORAGE_LAST_VIEW_KEY)||{view:"none"},setTimeout(()=>{if(refWidget.current){const dragEvent=new PointerEvent("pointerdown",{clientX:e22.clientX,clientY:e22.clientY,pointerId:e22.pointerId,bubbles:!0});refWidget.current.dispatchEvent(dragEvent)}},100)}}):(updateWidgetPosition(!0),signalWidgetViews.value=readLocalStorage$1(LOCALSTORAGE_LAST_VIEW_KEY)||{view:"none"}),document.removeEventListener("pointermove",handlePointerMove),document.removeEventListener("pointerup",handlePointerEnd))},"handlePointerMove"),handlePointerEnd=__name(()=>{rafId&&(cancelAnimationFrame(rafId),rafId=null),document.removeEventListener("pointermove",handlePointerMove),document.removeEventListener("pointerup",handlePointerEnd)},"handlePointerEnd");document.addEventListener("pointermove",handlePointerMove),document.addEventListener("pointerup",handlePointerEnd)},[]);y$5(()=>{if(!refWidget.current)return;removeLocalStorage(LOCALSTORAGE_LAST_VIEW_KEY),signalWidgetCollapsed.value?(refInitialMinimizedHeight.current=36,refInitialMinimizedWidth.current=0):(refWidget.current.style.width="min-content",refInitialMinimizedHeight.current=36,refInitialMinimizedWidth.current=refWidget.current.offsetWidth);const safeArea=getSafeArea();refWidget.current.style.maxWidth=`calc(100vw - ${safeArea.left+safeArea.right}px)`,refWidget.current.style.maxHeight=`calc(100vh - ${safeArea.top+safeArea.bottom}px)`,updateWidgetPosition(),Store.inspectState.value.kind!=="focused"&&!signalWidgetCollapsed.value&&!refExpandingFromCollapsed.current&&(signalWidget.value={...signalWidget.value,dimensions:{isFullWidth:!1,isFullHeight:!1,width:refInitialMinimizedWidth.current,height:refInitialMinimizedHeight.current,position:signalWidget.value.dimensions.position}}),signalRefWidget.value=refWidget.current;const unsubscribeSignalWidget=signalWidget.subscribe(widget=>{if(!refWidget.current)return;const{x:x2,y:y2}=widget.dimensions.position,{width,height}=widget.dimensions,container=refWidget.current;requestAnimationFrame(()=>{container.style.transform=`translate3d(${x2}px, ${y2}px, 0)`,container.style.width=`${width}px`,container.style.height=`${height}px`})}),unsubscribeSignalWidgetViews=signalWidgetViews.subscribe(state=>{refShouldOpen.current=state.view!=="none",updateWidgetPosition(),signalWidgetCollapsed.value||(state.view!=="none"?saveLocalStorage$1(LOCALSTORAGE_LAST_VIEW_KEY,state):removeLocalStorage(LOCALSTORAGE_LAST_VIEW_KEY))}),unsubscribeStoreInspectState=Store.inspectState.subscribe(state=>{refShouldOpen.current=state.kind==="focused",updateWidgetPosition()}),handleWindowResize=__name(()=>{updateWidgetPosition(!0)},"handleWindowResize");return window.addEventListener("resize",handleWindowResize,{passive:!0}),()=>{window.removeEventListener("resize",handleWindowResize),unsubscribeSignalWidgetViews(),unsubscribeStoreInspectState(),unsubscribeSignalWidget(),saveLocalStorage$1(LOCALSTORAGE_KEY,{...getDefaultWidgetConfig(),corner:signalWidget.value.corner})}},[]);const[_2,setTriggerRender]=d$4(!1);y$5(()=>{setTriggerRender(!0)},[]);const isCollapsed=signalWidgetCollapsed.value;let arrowRotationClass="";if(isCollapsed){const{orientation="horizontal",corner}=isCollapsed;orientation==="horizontal"?arrowRotationClass=corner?.endsWith("right")?"rotate-180":"":arrowRotationClass=corner?.startsWith("bottom")?"-rotate-90":"rotate-90"}return u$2(S$4,{children:[u$2(ScanOverlay,{}),u$2(ToolbarElementContext.Provider,{value:refWidget.current,children:u$2("div",{id:"react-scan-toolbar",dir:"ltr",ref:refWidget,onPointerDown:isCollapsed?handleCollapsedDrag:handleDrag,className:cn("fixed inset-0",isCollapsed?(()=>{const{orientation="horizontal",corner}=isCollapsed;return orientation==="horizontal"?corner?.endsWith("right")?"rounded-tl-lg rounded-bl-lg shadow-lg":"rounded-tr-lg rounded-br-lg shadow-lg":corner?.startsWith("bottom")?"rounded-tl-lg rounded-tr-lg shadow-lg":"rounded-bl-lg rounded-br-lg shadow-lg"})():"rounded-lg shadow-lg","flex flex-col","font-mono text-[13px]","user-select-none","opacity-0",isCollapsed?"cursor-pointer":"cursor-move","z-[124124124124]","animate-fade-in animation-duration-300 animation-delay-300","will-change-transform","[touch-action:none]"),style:{WebkitAppRegion:"no-drag"},children:isCollapsed?u$2("button",{type:"button",onClick:__name(()=>{signalWidgetCollapsed.value=null,saveLocalStorage$1(LOCALSTORAGE_COLLAPSED_KEY,null),refInitialMinimizedWidth.current===0&&refWidget.current&&requestAnimationFrame(()=>{refWidget.current&&(refWidget.current.style.width="min-content",refInitialMinimizedWidth.current=refWidget.current.offsetWidth||300,updateWidgetPosition(!0))}),signalWidgetViews.value=readLocalStorage$1(LOCALSTORAGE_LAST_VIEW_KEY)||{view:"none"}},"onClick"),className:"flex items-center justify-center w-full h-full text-white",title:"Expand toolbar",children:u$2(Icon,{name:"icon-chevron-right",size:16,className:cn("transition-transform",arrowRotationClass)})}):u$2(S$4,{children:[u$2(ResizeHandle,{position:"top"}),u$2(ResizeHandle,{position:"bottom"}),u$2(ResizeHandle,{position:"left"}),u$2(ResizeHandle,{position:"right"}),u$2(Content,{})]})})})]})},"Widget"),ToolbarElementContext=X$1(null),SvgSprite=__name(()=>u$2("svg",{xmlns:"http://www.w3.org/2000/svg",style:"display: none;",children:[u$2("title",{children:"React Scan Icons"}),u$2("symbol",{id:"icon-inspect",viewBox:"0 0 24 24",fill:"none","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("path",{d:"M12.034 12.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.943l-3.444 1.068a1 1 0 0 0-.66.66l-1.067 3.443a.5.5 0 0 1-.943.033z"}),u$2("path",{d:"M5 3a2 2 0 0 0-2 2"}),u$2("path",{d:"M19 3a2 2 0 0 1 2 2"}),u$2("path",{d:"M5 21a2 2 0 0 1-2-2"}),u$2("path",{d:"M9 3h1"}),u$2("path",{d:"M9 21h2"}),u$2("path",{d:"M14 3h1"}),u$2("path",{d:"M3 9v1"}),u$2("path",{d:"M21 9v2"}),u$2("path",{d:"M3 14v1"})]}),u$2("symbol",{id:"icon-focus",viewBox:"0 0 24 24",fill:"none","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("path",{d:"M12.034 12.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.943l-3.444 1.068a1 1 0 0 0-.66.66l-1.067 3.443a.5.5 0 0 1-.943.033z"}),u$2("path",{d:"M21 11V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6"})]}),u$2("symbol",{id:"icon-next",viewBox:"0 0 24 24",fill:"none","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:u$2("path",{d:"M6 9h6V5l7 7-7 7v-4H6V9z"})}),u$2("symbol",{id:"icon-previous",viewBox:"0 0 24 24",fill:"none","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:u$2("path",{d:"M18 15h-6v4l-7-7 7-7v4h6v6z"})}),u$2("symbol",{id:"icon-close",viewBox:"0 0 24 24",fill:"none","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("line",{x1:"18",y1:"6",x2:"6",y2:"18"}),u$2("line",{x1:"6",y1:"6",x2:"18",y2:"18"})]}),u$2("symbol",{id:"icon-replay",viewBox:"0 0 24 24",fill:"none","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("path",{d:"M3 7V5a2 2 0 0 1 2-2h2"}),u$2("path",{d:"M17 3h2a2 2 0 0 1 2 2v2"}),u$2("path",{d:"M21 17v2a2 2 0 0 1-2 2h-2"}),u$2("path",{d:"M7 21H5a2 2 0 0 1-2-2v-2"}),u$2("circle",{cx:"12",cy:"12",r:"1"}),u$2("path",{d:"M18.944 12.33a1 1 0 0 0 0-.66 7.5 7.5 0 0 0-13.888 0 1 1 0 0 0 0 .66 7.5 7.5 0 0 0 13.888 0"})]}),u$2("symbol",{id:"icon-ellipsis",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("circle",{cx:"12",cy:"12",r:"1"}),u$2("circle",{cx:"19",cy:"12",r:"1"}),u$2("circle",{cx:"5",cy:"12",r:"1"})]}),u$2("symbol",{id:"icon-copy",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2"}),u$2("path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"})]}),u$2("symbol",{id:"icon-check",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:u$2("path",{d:"M20 6 9 17l-5-5"})}),u$2("symbol",{id:"icon-chevron-right",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:u$2("path",{d:"m9 18 6-6-6-6"})}),u$2("symbol",{id:"icon-settings",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"}),u$2("circle",{cx:"12",cy:"12",r:"3"})]}),u$2("symbol",{id:"icon-flame",viewBox:"0 0 24 24",children:u$2("path",{d:"M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"})}),u$2("symbol",{id:"icon-function",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2"}),u$2("path",{d:"M9 17c2 0 2.8-1 2.8-2.8V10c0-2 1-3.3 3.2-3"}),u$2("path",{d:"M9 11.2h5.7"})]}),u$2("symbol",{id:"icon-triangle-alert",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"}),u$2("path",{d:"M12 9v4"}),u$2("path",{d:"M12 17h.01"})]}),u$2("symbol",{id:"icon-gallery-horizontal-end",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("path",{d:"M2 7v10"}),u$2("path",{d:"M6 5v14"}),u$2("rect",{width:"12",height:"18",x:"10",y:"3",rx:"2"})]}),u$2("symbol",{id:"icon-search",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("circle",{cx:"11",cy:"11",r:"8"}),u$2("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"})]}),u$2("symbol",{id:"icon-lock",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2"}),u$2("path",{d:"M7 11V7a5 5 0 0 1 10 0v4"})]}),u$2("symbol",{id:"icon-lock-open",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2"}),u$2("path",{d:"M7 11V7a5 5 0 0 1 9.9-1"})]}),u$2("symbol",{id:"icon-sanil",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round",children:[u$2("path",{d:"M2 13a6 6 0 1 0 12 0 4 4 0 1 0-8 0 2 2 0 0 0 4 0"}),u$2("circle",{cx:"10",cy:"13",r:"8"}),u$2("path",{d:"M2 21h12c4.4 0 8-3.6 8-8V7a2 2 0 1 0-4 0v6"}),u$2("path",{d:"M18 3 19.1 5.2"})]})]}),"SvgSprite"),ToolbarErrorBoundary=class extends C$5{static{__name(this,"ToolbarErrorBoundary")}constructor(){super(...arguments),__publicField(this,"state",{hasError:!1,error:null}),__publicField(this,"handleReset",()=>{this.setState({hasError:!1,error:null})})}static getDerivedStateFromError(error){return{hasError:!0,error}}render(){var _a;return this.state.hasError?u$2("div",{className:"fixed bottom-4 right-4 z-[124124124124]",children:u$2("div",{className:"p-3 bg-black rounded-lg shadow-lg w-80",children:[u$2("div",{className:"flex items-center gap-2 mb-2 text-red-400 text-sm font-medium",children:[u$2(Icon,{name:"icon-flame",className:"text-red-500",size:14}),"React Scan ran into a problem"]}),u$2("div",{className:"p-2 bg-black rounded font-mono text-xs text-red-300 mb-3 break-words",children:((_a=this.state.error)==null?void 0:_a.message)||JSON.stringify(this.state.error)}),u$2("button",{type:"button",onClick:this.handleReset,className:"px-3 py-1.5 bg-red-500 hover:bg-red-600 text-white rounded text-xs font-medium transition-colors flex items-center justify-center gap-1.5",children:"Restart"})]})}):this.props.children}},createToolbar=__name(root=>{const container=document.createElement("div");container.id="react-scan-toolbar-root",window.__REACT_SCAN_TOOLBAR_CONTAINER__=container,root.appendChild(container),R$1(u$2(ToolbarErrorBoundary,{children:u$2(S$4,{children:[u$2(SvgSprite,{}),u$2(Widget,{})]})}),container);const originalRemove=container.remove.bind(container);return container.remove=()=>{window.__REACT_SCAN_TOOLBAR_CONTAINER__=void 0,container.hasChildNodes()&&(R$1(null,container),R$1(null,container)),originalRemove()},container},"createToolbar"),didRunVersionCheck=!1,checkReactGrabVersion=__name(()=>{if(didRunVersionCheck||(didRunVersionCheck=!0,typeof window>"u")||window.__REACT_GRAB__||!navigator.onLine)return;const fetchOptions={referrerPolicy:"origin",keepalive:!0,priority:"low",cache:"no-store"};try{fetch(`https://www.react-grab.com/api/version?source=react-scan&v=${version}&t=${Date.now()}`,fetchOptions).then(response=>response.ok?response.text():null).then(rawLatestVersion=>{if(!rawLatestVersion)return;const latestVersion=rawLatestVersion.trim();/^\d+\.\d+\.\d+/.test(latestVersion)&&latestVersion!=="0.1.37"&&console.warn(`[React Scan] react-grab v${version} is outdated (latest: v${latestVersion}). Update react-scan to pick up the newer react-grab.`)}).catch(()=>null)}catch{}},"checkReactGrabVersion"),SAFE_AREA_EDGES=["top","right","bottom","left"],parseSafeAreaOption=__name(value=>{if(isFiniteNonNegative(value))return{ok:!0,value};if(!isPlainObject(value))return{ok:!1,error:`- safeArea must be a non-negative number or { top?, right?, bottom?, left? }. Got "${JSON.stringify(value)}"`};const inset={};for(const edge of SAFE_AREA_EDGES){const edgeValue=value[edge];if(edgeValue!==void 0){if(!isFiniteNonNegative(edgeValue))return{ok:!1,error:`- safeArea.${edge} must be a non-negative number. Got "${JSON.stringify(edgeValue)}"`};inset[edge]=edgeValue}}return{ok:!0,value:inset}},"parseSafeAreaOption"),package_default={name:"react-scan",version:"0.5.7",description:"Scan your React app for renders",keywords:["performance","react","react scan","react-scan","render"],homepage:"https://react-scan.million.dev",bugs:{url:"https://github.com/aidenybai/react-scan/issues"},license:"MIT",author:{name:"Aiden Bai",email:"aiden@million.dev",url:"https://million.dev"},repository:{type:"git",url:"git+https://github.com/aidenybai/react-scan.git"},bin:"bin/cli.js",files:["dist","bin","package.json","README.md","LICENSE","auto.d.ts"],main:"dist/index.js",module:"dist/index.mjs",browser:"dist/auto.global.js",types:"dist/index.d.ts",typesVersions:{"*":{"react-component-name/vite":["./dist/react-component-name/vite.d.ts"],"react-component-name/webpack":["./dist/react-component-name/webpack.d.ts"],"react-component-name/esbuild":["./dist/react-component-name/esbuild.d.ts"],"react-component-name/rspack":["./dist/react-component-name/rspack.d.ts"],"react-component-name/rolldown":["./dist/react-component-name/rolldown.d.ts"],"react-component-name/rollup":["./dist/react-component-name/rollup.d.ts"],"react-component-name/astro":["./dist/react-component-name/astro.d.ts"],"react-component-name/loader":["./dist/react-component-name/loader.d.ts"]}},exports:{"./package.json":"./package.json",".":{production:{import:{types:"./dist/index.d.mts","react-server":"./dist/rsc-shim.mjs",default:"./dist/index.mjs"},require:{types:"./dist/index.d.mts","react-server":"./dist/rsc-shim.js",default:"./dist/index.mjs"}},development:{import:{types:"./dist/index.d.mts","react-server":"./dist/rsc-shim.mjs",default:"./dist/index.mjs"},require:{types:"./dist/index.d.ts","react-server":"./dist/rsc-shim.js",default:"./dist/index.js"}},default:{import:{types:"./dist/index.d.mts","react-server":"./dist/rsc-shim.mjs",default:"./dist/index.mjs"},require:{types:"./dist/index.d.ts","react-server":"./dist/rsc-shim.js",default:"./dist/index.js"}}},"./all-environments":{types:"./dist/core/all-environments.d.ts",import:"./dist/core/all-environments.mjs",require:"./dist/core/all-environments.js"},"./install-hook":{types:"./dist/install-hook.d.ts",import:"./dist/install-hook.mjs",require:"./dist/install-hook.js"},"./lite":{types:"./dist/lite/index.d.ts",import:"./dist/lite/index.mjs",require:"./dist/lite/index.js"},"./auto":{production:{import:{types:"./dist/rsc-shim.d.mts","react-server":"./dist/rsc-shim.mjs",default:"./dist/rsc-shim.mjs"},require:{types:"./dist/rsc-shim.d.ts","react-server":"./dist/rsc-shim.js",default:"./dist/rsc-shim.js"}},development:{import:{types:"./dist/auto.d.mts","react-server":"./dist/rsc-shim.mjs",default:"./dist/auto.mjs"},require:{types:"./dist/auto.d.ts","react-server":"./dist/rsc-shim.js",default:"./dist/auto.js"}}},"./dist/*":"./dist/*.js","./dist/*.js":"./dist/*.js","./dist/*.mjs":"./dist/*.mjs","./react-component-name/vite":{types:"./dist/react-component-name/vite.d.ts",import:"./dist/react-component-name/vite.mjs",require:"./dist/react-component-name/vite.js"},"./react-component-name/webpack":{types:"./dist/react-component-name/webpack.d.ts",import:"./dist/react-component-name/webpack.mjs",require:"./dist/react-component-name/webpack.js"},"./react-component-name/esbuild":{types:"./dist/react-component-name/esbuild.d.ts",import:"./dist/react-component-name/esbuild.mjs",require:"./dist/react-component-name/esbuild.js"},"./react-component-name/rspack":{types:"./dist/react-component-name/rspack.d.ts",import:"./dist/react-component-name/rspack.mjs",require:"./dist/react-component-name/rspack.js"},"./react-component-name/rolldown":{types:"./dist/react-component-name/rolldown.d.ts",import:"./dist/react-component-name/rolldown.mjs",require:"./dist/react-component-name/rolldown.js"},"./react-component-name/rollup":{types:"./dist/react-component-name/rollup.d.ts",import:"./dist/react-component-name/rollup.mjs",require:"./dist/react-component-name/rollup.js"},"./react-component-name/astro":{types:"./dist/react-component-name/astro.d.ts",import:"./dist/react-component-name/astro.mjs",require:"./dist/react-component-name/astro.js"},"./react-component-name/loader":{types:"./dist/react-component-name/loader.d.ts",import:"./dist/react-component-name/loader.mjs",require:"./dist/react-component-name/loader.js"}},publishConfig:{access:"public"},scripts:{build:"pnpm build:css && NODE_ENV=production tsup","build:copy":"pnpm build && cat dist/auto.global.js | pbcopy","build:css":"postcss ./src/web/assets/css/styles.tailwind.css -o ./src/web/assets/css/styles.css","dev:css":"postcss ./src/web/assets/css/styles.tailwind.css -o ./src/web/assets/css/styles.css --watch","dev:tsup":"NODE_ENV=development tsup --watch",dev:'pnpm run --parallel "/^dev:(css|tsup)/"',pack:"npm version patch && pnpm build && npm pack","pack:bump":`node scripts/bump-version.mjs && pnpm run pack && echo $(pwd)/react-scan-$(node -p "require('./package.json').version").tgz | pbcopy`,publint:"publint",test:"vp test run","test:watch":"vp test",lint:"vp lint",format:"vp fmt",typecheck:"tsc --noEmit"},dependencies:{"@babel/core":"^7.29.0","@babel/types":"^7.29.0","@preact/signals":"^2.9.0","@rollup/pluginutils":"^5.3.0",bippy:"^0.5.39",commander:"^14.0.0",picocolors:"^1.1.1",preact:"^10.29.1",prompts:"^2.4.2","react-doctor":"latest","react-grab":"latest"},devDependencies:{"@esbuild-plugins/tsconfig-paths":"^0.1.2","@remix-run/react":"*","@tailwindcss/postcss":"^4.2.4","@types/babel__core":"^7.20.5","@types/prompts":"^2.4.9","@types/react":"^19.2.14",autoprefixer:"^10.5.0",clsx:"^2.1.1","es-module-lexer":"^2.1.0",esbuild:"^0.28.0",next:"*",postcss:"^8.5.13","postcss-cli":"^11.0.0",publint:"^0.3.18",react:"*","react-dom":"*","tailwind-merge":"^3.5.0",tailwindcss:"^4.2.4",terser:"^5.46.2",tsup:"^8.5.1",vitest:"^3.0.0"},peerDependencies:{esbuild:">=0.18.0",react:"^16.8.0 || ^17.0.0 || ^18.0.0 || ^19.0.0","react-dom":"^16.8.0 || ^17.0.0 || ^18.0.0 || ^19.0.0"},peerDependenciesMeta:{esbuild:{optional:!0}},optionalDependencies:{unplugin:"^3.0.0"}},rootContainer=null,shadowRoot=null,initRootContainer=__name(()=>{if(rootContainer&&shadowRoot)return{rootContainer,shadowRoot};rootContainer=document.createElement("div"),rootContainer.id="react-scan-root",shadowRoot=rootContainer.attachShadow({mode:"open"});const cssStyles=document.createElement("style");return cssStyles.textContent=styles_default,shadowRoot.appendChild(cssStyles),document.documentElement.appendChild(rootContainer),{rootContainer,shadowRoot}},"initRootContainer"),Store={wasDetailsOpen:y$4(!0),isInIframe:y$4(IS_CLIENT$1&&window.self!==window.top),inspectState:y$4({kind:"uninitialized"}),fiberRoots:new Set,reportData:new Map,legacyReportData:new Map,lastReportTime:y$4(0),interactionListeningForRenders:null,changesListeners:new Map},ReactScanInternals={instrumentation:null,componentAllowList:null,options:y$4({enabled:!0,log:!1,showToolbar:!0,animationSpeed:"fast",dangerouslyForceRunInProduction:!1,showFPS:!0,showNotificationCount:!0,allowInIframe:!1}),runInAllEnvironments:!1,onRender:null,Store,version:package_default.version};IS_CLIENT$1&&window.__REACT_SCAN_EXTENSION__&&(window.__REACT_SCAN_VERSION__=ReactScanInternals.version);var applyLocalStorageOptions=__name(options=>{const{onCommitStart,onRender:onRender2,onCommitFinish,...rest}=options;return rest},"applyLocalStorageOptions"),validateOptions=__name(options=>{const errors=[],validOptions={};for(const key in options){const value=options[key];switch(key){case"enabled":case"log":case"showToolbar":case"showNotificationCount":case"dangerouslyForceRunInProduction":case"showFPS":case"allowInIframe":case"useOffscreenCanvasWorker":typeof value!="boolean"?errors.push(`- ${key} must be a boolean. Got "${value}"`):validOptions[key]=value;break;case"animationSpeed":["slow","fast","off"].includes(value)?validOptions[key]=value:errors.push(`- Invalid animation speed "${value}". Using default "fast"`);break;case"safeArea":{const parsed=parseSafeAreaOption(value);parsed.ok?validOptions.safeArea=parsed.value:errors.push(parsed.error);break}case"onCommitStart":typeof value!="function"?errors.push(`- ${key} must be a function. Got "${value}"`):validOptions.onCommitStart=value;break;case"onCommitFinish":typeof value!="function"?errors.push(`- ${key} must be a function. Got "${value}"`):validOptions.onCommitFinish=value;break;case"onRender":typeof value!="function"?errors.push(`- ${key} must be a function. Got "${value}"`):validOptions.onRender=value;break;default:errors.push(`- Unknown option "${key}"`)}}return errors.length>0&&console.warn(`[React Scan] Invalid options:
${errors.join(`
`)}`),validOptions},"validateOptions"),setOptions=__name(userOptions=>{var _a;try{const validOptions=validateOptions(userOptions);if(Object.keys(validOptions).length===0)return;const shouldInitToolbar="showToolbar"in validOptions&&validOptions.showToolbar!==void 0,newOptions={...ReactScanInternals.options.value,...validOptions},{instrumentation}=ReactScanInternals;instrumentation&&"enabled"in validOptions&&(instrumentation.isPaused.value=validOptions.enabled===!1),ReactScanInternals.options.value=newOptions;try{const existing=(_a=readLocalStorage$1("react-scan-options"))==null?void 0:_a.enabled;typeof existing=="boolean"&&(newOptions.enabled=existing)}catch(e2){ReactScanInternals.options.value._debug==="verbose"&&console.error("[React Scan Internal Error]","Failed to create notifications outline canvas",e2)}return saveLocalStorage$1("react-scan-options",applyLocalStorageOptions(newOptions)),shouldInitToolbar&&initToolbar(!!newOptions.showToolbar),newOptions}catch(e2){ReactScanInternals.options.value._debug==="verbose"&&console.error("[React Scan Internal Error]","Failed to create notifications outline canvas",e2)}},"setOptions"),getOptions=__name(()=>ReactScanInternals.options,"getOptions"),isProduction=null,rdtHook,getIsProduction=__name(()=>{if(isProduction===!1)return!1;rdtHook??=h$7();const renderers=Array.from(rdtHook.renderers.values());if(renderers.length===0)return null;for(const renderer of renderers)if(F$4(renderer)!=="production")return isProduction=!1,!1;return!0},"getIsProduction"),start=__name(()=>{try{if(!IS_CLIENT$1||!ReactScanInternals.runInAllEnvironments&&getIsProduction()&&!ReactScanInternals.options.value.dangerouslyForceRunInProduction)return;checkReactGrabVersion();const localStorageOptions=readLocalStorage$1("react-scan-options");if(localStorageOptions){const validLocalOptions=validateOptions(localStorageOptions);Object.keys(validLocalOptions).length>0&&(ReactScanInternals.options.value={...ReactScanInternals.options.value,...validLocalOptions})}const options=getOptions();initReactScanInstrumentation(()=>{initToolbar(!!options.value.showToolbar)}),IS_CLIENT$1&&setTimeout(()=>{Te$1()||console.error("[React Scan] Failed to load. Must import React Scan before React runs.")},5e3)}catch(e2){ReactScanInternals.options.value._debug==="verbose"&&console.error("[React Scan Internal Error]","Failed to create notifications outline canvas",e2)}},"start"),initToolbar=__name(showToolbar=>{var _a;(_a=window.reactScanCleanupListeners)==null||_a.call(window);const cleanupTimingTracking=startTimingTracking(),cleanupOutlineCanvas=createNotificationsOutlineCanvas();window.reactScanCleanupListeners=()=>{cleanupTimingTracking(),cleanupOutlineCanvas?.()};const windowToolbarContainer=window.__REACT_SCAN_TOOLBAR_CONTAINER__;if(!showToolbar){windowToolbarContainer?.remove();return}windowToolbarContainer?.remove();const{shadowRoot:shadowRoot2}=initRootContainer();createToolbar(shadowRoot2)},"initToolbar"),createNotificationsOutlineCanvas=__name(()=>{try{const highlightRoot=document.documentElement;return createHighlightCanvas(highlightRoot)}catch(e2){ReactScanInternals.options.value._debug==="verbose"&&console.error("[React Scan Internal Error]","Failed to create notifications outline canvas",e2)}},"createNotificationsOutlineCanvas"),scan=__name((options={})=>{setOptions(options),!(Store.isInIframe.value&&!ReactScanInternals.options.value.allowInIframe&&!ReactScanInternals.runInAllEnvironments)&&(options.enabled===!1&&options.showToolbar!==!0||start())},"scan"),ignoredProps=new WeakSet,require_constants=__commonJSMin(((exports,module)=>{var SEMVER_SPEC_VERSION="2.0.0",MAX_LENGTH=256,MAX_SAFE_INTEGER=Number.MAX_SAFE_INTEGER||9007199254740991,MAX_SAFE_COMPONENT_LENGTH=16,MAX_SAFE_BUILD_LENGTH=MAX_LENGTH-6,RELEASE_TYPES=["major","premajor","minor","preminor","patch","prepatch","prerelease"];module.exports={MAX_LENGTH,MAX_SAFE_COMPONENT_LENGTH,MAX_SAFE_BUILD_LENGTH,MAX_SAFE_INTEGER,RELEASE_TYPES,SEMVER_SPEC_VERSION,FLAG_INCLUDE_PRERELEASE:1,FLAG_LOOSE:2}})),require_debug=__commonJSMin(((exports,module)=>{var debug=typeof process=="object"&&process.env&&process.env.NODE_DEBUG&&/\bsemver\b/i.test(process.env.NODE_DEBUG)?(...args)=>console.error("SEMVER",...args):()=>{};module.exports=debug})),require_re=__commonJSMin(((exports,module)=>{var{MAX_SAFE_COMPONENT_LENGTH,MAX_SAFE_BUILD_LENGTH,MAX_LENGTH}=require_constants(),debug=require_debug();exports=module.exports={};var re2=exports.re=[],safeRe=exports.safeRe=[],src=exports.src=[],safeSrc=exports.safeSrc=[],t2=exports.t={},R2=0,LETTERDASHNUMBER="[a-zA-Z0-9-]",safeRegexReplacements=[["\\s",1],["\\d",MAX_LENGTH],[LETTERDASHNUMBER,MAX_SAFE_BUILD_LENGTH]],makeSafeRegex=__name(value=>{for(const[token,max]of safeRegexReplacements)value=value.split(`${token}*`).join(`${token}{0,${max}}`).split(`${token}+`).join(`${token}{1,${max}}`);return value},"makeSafeRegex"),createToken=__name((name,value,isGlobal)=>{const safe=makeSafeRegex(value),index=R2++;debug(name,index,value),t2[name]=index,src[index]=value,safeSrc[index]=safe,re2[index]=new RegExp(value,isGlobal?"g":void 0),safeRe[index]=new RegExp(safe,isGlobal?"g":void 0)},"createToken");createToken("NUMERICIDENTIFIER","0|[1-9]\\d*"),createToken("NUMERICIDENTIFIERLOOSE","\\d+"),createToken("NONNUMERICIDENTIFIER",`\\d*[a-zA-Z-]${LETTERDASHNUMBER}*`),createToken("MAINVERSION",`(${src[t2.NUMERICIDENTIFIER]})\\.(${src[t2.NUMERICIDENTIFIER]})\\.(${src[t2.NUMERICIDENTIFIER]})`),createToken("MAINVERSIONLOOSE",`(${src[t2.NUMERICIDENTIFIERLOOSE]})\\.(${src[t2.NUMERICIDENTIFIERLOOSE]})\\.(${src[t2.NUMERICIDENTIFIERLOOSE]})`),createToken("PRERELEASEIDENTIFIER",`(?:${src[t2.NONNUMERICIDENTIFIER]}|${src[t2.NUMERICIDENTIFIER]})`),createToken("PRERELEASEIDENTIFIERLOOSE",`(?:${src[t2.NONNUMERICIDENTIFIER]}|${src[t2.NUMERICIDENTIFIERLOOSE]})`),createToken("PRERELEASE",`(?:-(${src[t2.PRERELEASEIDENTIFIER]}(?:\\.${src[t2.PRERELEASEIDENTIFIER]})*))`),createToken("PRERELEASELOOSE",`(?:-?(${src[t2.PRERELEASEIDENTIFIERLOOSE]}(?:\\.${src[t2.PRERELEASEIDENTIFIERLOOSE]})*))`),createToken("BUILDIDENTIFIER",`${LETTERDASHNUMBER}+`),createToken("BUILD",`(?:\\+(${src[t2.BUILDIDENTIFIER]}(?:\\.${src[t2.BUILDIDENTIFIER]})*))`),createToken("FULLPLAIN",`v?${src[t2.MAINVERSION]}${src[t2.PRERELEASE]}?${src[t2.BUILD]}?`),createToken("FULL",`^${src[t2.FULLPLAIN]}$`),createToken("LOOSEPLAIN",`[v=\\s]*${src[t2.MAINVERSIONLOOSE]}${src[t2.PRERELEASELOOSE]}?${src[t2.BUILD]}?`),createToken("LOOSE",`^${src[t2.LOOSEPLAIN]}$`),createToken("GTLT","((?:<|>)?=?)"),createToken("XRANGEIDENTIFIERLOOSE",`${src[t2.NUMERICIDENTIFIERLOOSE]}|x|X|\\*`),createToken("XRANGEIDENTIFIER",`${src[t2.NUMERICIDENTIFIER]}|x|X|\\*`),createToken("XRANGEPLAIN",`[v=\\s]*(${src[t2.XRANGEIDENTIFIER]})(?:\\.(${src[t2.XRANGEIDENTIFIER]})(?:\\.(${src[t2.XRANGEIDENTIFIER]})(?:${src[t2.PRERELEASE]})?${src[t2.BUILD]}?)?)?`),createToken("XRANGEPLAINLOOSE",`[v=\\s]*(${src[t2.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t2.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t2.XRANGEIDENTIFIERLOOSE]})(?:${src[t2.PRERELEASELOOSE]})?${src[t2.BUILD]}?)?)?`),createToken("XRANGE",`^${src[t2.GTLT]}\\s*${src[t2.XRANGEPLAIN]}$`),createToken("XRANGELOOSE",`^${src[t2.GTLT]}\\s*${src[t2.XRANGEPLAINLOOSE]}$`),createToken("COERCEPLAIN",`(^|[^\\d])(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}})(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?`),createToken("COERCE",`${src[t2.COERCEPLAIN]}(?:$|[^\\d])`),createToken("COERCEFULL",src[t2.COERCEPLAIN]+`(?:${src[t2.PRERELEASE]})?(?:${src[t2.BUILD]})?(?:$|[^\\d])`),createToken("COERCERTL",src[t2.COERCE],!0),createToken("COERCERTLFULL",src[t2.COERCEFULL],!0),createToken("LONETILDE","(?:~>?)"),createToken("TILDETRIM",`(\\s*)${src[t2.LONETILDE]}\\s+`,!0),exports.tildeTrimReplace="$1~",createToken("TILDE",`^${src[t2.LONETILDE]}${src[t2.XRANGEPLAIN]}$`),createToken("TILDELOOSE",`^${src[t2.LONETILDE]}${src[t2.XRANGEPLAINLOOSE]}$`),createToken("LONECARET","(?:\\^)"),createToken("CARETTRIM",`(\\s*)${src[t2.LONECARET]}\\s+`,!0),exports.caretTrimReplace="$1^",createToken("CARET",`^${src[t2.LONECARET]}${src[t2.XRANGEPLAIN]}$`),createToken("CARETLOOSE",`^${src[t2.LONECARET]}${src[t2.XRANGEPLAINLOOSE]}$`),createToken("COMPARATORLOOSE",`^${src[t2.GTLT]}\\s*(${src[t2.LOOSEPLAIN]})$|^$`),createToken("COMPARATOR",`^${src[t2.GTLT]}\\s*(${src[t2.FULLPLAIN]})$|^$`),createToken("COMPARATORTRIM",`(\\s*)${src[t2.GTLT]}\\s*(${src[t2.LOOSEPLAIN]}|${src[t2.XRANGEPLAIN]})`,!0),exports.comparatorTrimReplace="$1$2$3",createToken("HYPHENRANGE",`^\\s*(${src[t2.XRANGEPLAIN]})\\s+-\\s+(${src[t2.XRANGEPLAIN]})\\s*$`),createToken("HYPHENRANGELOOSE",`^\\s*(${src[t2.XRANGEPLAINLOOSE]})\\s+-\\s+(${src[t2.XRANGEPLAINLOOSE]})\\s*$`),createToken("STAR","(<|>)?=?\\s*\\*"),createToken("GTE0","^\\s*>=\\s*0\\.0\\.0\\s*$"),createToken("GTE0PRE","^\\s*>=\\s*0\\.0\\.0-0\\s*$")})),require_parse_options=__commonJSMin(((exports,module)=>{var looseOption=Object.freeze({loose:!0}),emptyOpts=Object.freeze({}),parseOptions=__name(options=>options?typeof options!="object"?looseOption:options:emptyOpts,"parseOptions");module.exports=parseOptions})),require_identifiers=__commonJSMin(((exports,module)=>{var numeric=/^[0-9]+$/,compareIdentifiers=__name((a2,b2)=>{if(typeof a2=="number"&&typeof b2=="number")return a2===b2?0:a2<b2?-1:1;const anum=numeric.test(a2),bnum=numeric.test(b2);return anum&&bnum&&(a2=+a2,b2=+b2),a2===b2?0:anum&&!bnum?-1:bnum&&!anum?1:a2<b2?-1:1},"compareIdentifiers"),rcompareIdentifiers=__name((a2,b2)=>compareIdentifiers(b2,a2),"rcompareIdentifiers");module.exports={compareIdentifiers,rcompareIdentifiers}})),require_semver$1=__commonJSMin(((exports,module)=>{var debug=require_debug(),{MAX_LENGTH,MAX_SAFE_INTEGER}=require_constants(),{safeRe:re2,t:t2}=require_re(),parseOptions=require_parse_options(),{compareIdentifiers}=require_identifiers(),SemVer=class SemVer2{static{__name(this,"SemVer")}constructor(version2,options){if(options=parseOptions(options),version2 instanceof SemVer2){if(version2.loose===!!options.loose&&version2.includePrerelease===!!options.includePrerelease)return version2;version2=version2.version}else if(typeof version2!="string")throw new TypeError(`Invalid version. Must be a string. Got type "${typeof version2}".`);if(version2.length>MAX_LENGTH)throw new TypeError(`version is longer than ${MAX_LENGTH} characters`);debug("SemVer",version2,options),this.options=options,this.loose=!!options.loose,this.includePrerelease=!!options.includePrerelease;const m2=version2.trim().match(options.loose?re2[t2.LOOSE]:re2[t2.FULL]);if(!m2)throw new TypeError(`Invalid Version: ${version2}`);if(this.raw=version2,this.major=+m2[1],this.minor=+m2[2],this.patch=+m2[3],this.major>MAX_SAFE_INTEGER||this.major<0)throw new TypeError("Invalid major version");if(this.minor>MAX_SAFE_INTEGER||this.minor<0)throw new TypeError("Invalid minor version");if(this.patch>MAX_SAFE_INTEGER||this.patch<0)throw new TypeError("Invalid patch version");m2[4]?this.prerelease=m2[4].split(".").map(id=>{if(/^[0-9]+$/.test(id)){const num=+id;if(num>=0&&num<MAX_SAFE_INTEGER)return num}return id}):this.prerelease=[],this.build=m2[5]?m2[5].split("."):[],this.format()}format(){return this.version=`${this.major}.${this.minor}.${this.patch}`,this.prerelease.length&&(this.version+=`-${this.prerelease.join(".")}`),this.version}toString(){return this.version}compare(other){if(debug("SemVer.compare",this.version,this.options,other),!(other instanceof SemVer2)){if(typeof other=="string"&&other===this.version)return 0;other=new SemVer2(other,this.options)}return other.version===this.version?0:this.compareMain(other)||this.comparePre(other)}compareMain(other){return other instanceof SemVer2||(other=new SemVer2(other,this.options)),this.major<other.major?-1:this.major>other.major?1:this.minor<other.minor?-1:this.minor>other.minor?1:this.patch<other.patch?-1:this.patch>other.patch?1:0}comparePre(other){if(other instanceof SemVer2||(other=new SemVer2(other,this.options)),this.prerelease.length&&!other.prerelease.length)return-1;if(!this.prerelease.length&&other.prerelease.length)return 1;if(!this.prerelease.length&&!other.prerelease.length)return 0;let i2=0;do{const a2=this.prerelease[i2],b2=other.prerelease[i2];if(debug("prerelease compare",i2,a2,b2),a2===void 0&&b2===void 0)return 0;if(b2===void 0)return 1;if(a2===void 0)return-1;if(a2===b2)continue;return compareIdentifiers(a2,b2)}while(++i2)}compareBuild(other){other instanceof SemVer2||(other=new SemVer2(other,this.options));let i2=0;do{const a2=this.build[i2],b2=other.build[i2];if(debug("build compare",i2,a2,b2),a2===void 0&&b2===void 0)return 0;if(b2===void 0)return 1;if(a2===void 0)return-1;if(a2===b2)continue;return compareIdentifiers(a2,b2)}while(++i2)}inc(release,identifier,identifierBase){if(release.startsWith("pre")){if(!identifier&&identifierBase===!1)throw new Error("invalid increment argument: identifier is empty");if(identifier){const match=`-${identifier}`.match(this.options.loose?re2[t2.PRERELEASELOOSE]:re2[t2.PRERELEASE]);if(!match||match[1]!==identifier)throw new Error(`invalid identifier: ${identifier}`)}}switch(release){case"premajor":this.prerelease.length=0,this.patch=0,this.minor=0,this.major++,this.inc("pre",identifier,identifierBase);break;case"preminor":this.prerelease.length=0,this.patch=0,this.minor++,this.inc("pre",identifier,identifierBase);break;case"prepatch":this.prerelease.length=0,this.inc("patch",identifier,identifierBase),this.inc("pre",identifier,identifierBase);break;case"prerelease":this.prerelease.length===0&&this.inc("patch",identifier,identifierBase),this.inc("pre",identifier,identifierBase);break;case"release":if(this.prerelease.length===0)throw new Error(`version ${this.raw} is not a prerelease`);this.prerelease.length=0;break;case"major":(this.minor!==0||this.patch!==0||this.prerelease.length===0)&&this.major++,this.minor=0,this.patch=0,this.prerelease=[];break;case"minor":(this.patch!==0||this.prerelease.length===0)&&this.minor++,this.patch=0,this.prerelease=[];break;case"patch":this.prerelease.length===0&&this.patch++,this.prerelease=[];break;case"pre":{const base=Number(identifierBase)?1:0;if(this.prerelease.length===0)this.prerelease=[base];else{let i2=this.prerelease.length;for(;--i2>=0;)typeof this.prerelease[i2]=="number"&&(this.prerelease[i2]++,i2=-2);if(i2===-1){if(identifier===this.prerelease.join(".")&&identifierBase===!1)throw new Error("invalid increment argument: identifier already exists");this.prerelease.push(base)}}if(identifier){let prerelease=[identifier,base];identifierBase===!1&&(prerelease=[identifier]),compareIdentifiers(this.prerelease[0],identifier)===0?isNaN(this.prerelease[1])&&(this.prerelease=prerelease):this.prerelease=prerelease}break}default:throw new Error(`invalid increment argument: ${release}`)}return this.raw=this.format(),this.build.length&&(this.raw+=`+${this.build.join(".")}`),this}};module.exports=SemVer})),require_parse=__commonJSMin(((exports,module)=>{var SemVer=require_semver$1(),parse=__name((version2,options,throwErrors=!1)=>{if(version2 instanceof SemVer)return version2;try{return new SemVer(version2,options)}catch(er2){if(!throwErrors)return null;throw er2}},"parse");module.exports=parse})),require_valid$1=__commonJSMin(((exports,module)=>{var parse=require_parse(),valid=__name((version2,options)=>{const v2=parse(version2,options);return v2?v2.version:null},"valid");module.exports=valid})),require_clean=__commonJSMin(((exports,module)=>{var parse=require_parse(),clean=__name((version2,options)=>{const s2=parse(version2.trim().replace(/^[=v]+/,""),options);return s2?s2.version:null},"clean");module.exports=clean})),require_inc=__commonJSMin(((exports,module)=>{var SemVer=require_semver$1(),inc=__name((version2,release,options,identifier,identifierBase)=>{typeof options=="string"&&(identifierBase=identifier,identifier=options,options=void 0);try{return new SemVer(version2 instanceof SemVer?version2.version:version2,options).inc(release,identifier,identifierBase).version}catch{return null}},"inc");module.exports=inc})),require_diff=__commonJSMin(((exports,module)=>{var parse=require_parse(),diff=__name((version1,version2)=>{const v1=parse(version1,null,!0),v2=parse(version2,null,!0),comparison=v1.compare(v2);if(comparison===0)return null;const v1Higher=comparison>0,highVersion=v1Higher?v1:v2,lowVersion=v1Higher?v2:v1,highHasPre=!!highVersion.prerelease.length;if(lowVersion.prerelease.length&&!highHasPre){if(!lowVersion.patch&&!lowVersion.minor)return"major";if(lowVersion.compareMain(highVersion)===0)return lowVersion.minor&&!lowVersion.patch?"minor":"patch"}const prefix=highHasPre?"pre":"";return v1.major!==v2.major?prefix+"major":v1.minor!==v2.minor?prefix+"minor":v1.patch!==v2.patch?prefix+"patch":"prerelease"},"diff");module.exports=diff})),require_major=__commonJSMin(((exports,module)=>{var SemVer=require_semver$1(),major=__name((a2,loose)=>new SemVer(a2,loose).major,"major");module.exports=major})),require_minor=__commonJSMin(((exports,module)=>{var SemVer=require_semver$1(),minor=__name((a2,loose)=>new SemVer(a2,loose).minor,"minor");module.exports=minor})),require_patch=__commonJSMin(((exports,module)=>{var SemVer=require_semver$1(),patch=__name((a2,loose)=>new SemVer(a2,loose).patch,"patch");module.exports=patch})),require_prerelease=__commonJSMin(((exports,module)=>{var parse=require_parse(),prerelease=__name((version2,options)=>{const parsed=parse(version2,options);return parsed&&parsed.prerelease.length?parsed.prerelease:null},"prerelease");module.exports=prerelease})),require_compare=__commonJSMin(((exports,module)=>{var SemVer=require_semver$1(),compare=__name((a2,b2,loose)=>new SemVer(a2,loose).compare(new SemVer(b2,loose)),"compare");module.exports=compare})),require_rcompare=__commonJSMin(((exports,module)=>{var compare=require_compare(),rcompare=__name((a2,b2,loose)=>compare(b2,a2,loose),"rcompare");module.exports=rcompare})),require_compare_loose=__commonJSMin(((exports,module)=>{var compare=require_compare(),compareLoose=__name((a2,b2)=>compare(a2,b2,!0),"compareLoose");module.exports=compareLoose})),require_compare_build=__commonJSMin(((exports,module)=>{var SemVer=require_semver$1(),compareBuild=__name((a2,b2,loose)=>{const versionA=new SemVer(a2,loose),versionB=new SemVer(b2,loose);return versionA.compare(versionB)||versionA.compareBuild(versionB)},"compareBuild");module.exports=compareBuild})),require_sort=__commonJSMin(((exports,module)=>{var compareBuild=require_compare_build(),sort=__name((list,loose)=>list.sort((a2,b2)=>compareBuild(a2,b2,loose)),"sort");module.exports=sort})),require_rsort=__commonJSMin(((exports,module)=>{var compareBuild=require_compare_build(),rsort=__name((list,loose)=>list.sort((a2,b2)=>compareBuild(b2,a2,loose)),"rsort");module.exports=rsort})),require_gt=__commonJSMin(((exports,module)=>{var compare=require_compare(),gt=__name((a2,b2,loose)=>compare(a2,b2,loose)>0,"gt");module.exports=gt})),require_lt=__commonJSMin(((exports,module)=>{var compare=require_compare(),lt2=__name((a2,b2,loose)=>compare(a2,b2,loose)<0,"lt");module.exports=lt2})),require_eq=__commonJSMin(((exports,module)=>{var compare=require_compare(),eq=__name((a2,b2,loose)=>compare(a2,b2,loose)===0,"eq");module.exports=eq})),require_neq=__commonJSMin(((exports,module)=>{var compare=require_compare(),neq=__name((a2,b2,loose)=>compare(a2,b2,loose)!==0,"neq");module.exports=neq})),require_gte=__commonJSMin(((exports,module)=>{var compare=require_compare(),gte=__name((a2,b2,loose)=>compare(a2,b2,loose)>=0,"gte");module.exports=gte})),require_lte=__commonJSMin(((exports,module)=>{var compare=require_compare(),lte=__name((a2,b2,loose)=>compare(a2,b2,loose)<=0,"lte");module.exports=lte})),require_cmp=__commonJSMin(((exports,module)=>{var eq=require_eq(),neq=require_neq(),gt=require_gt(),gte=require_gte(),lt2=require_lt(),lte=require_lte(),cmp=__name((a2,op,b2,loose)=>{switch(op){case"===":return typeof a2=="object"&&(a2=a2.version),typeof b2=="object"&&(b2=b2.version),a2===b2;case"!==":return typeof a2=="object"&&(a2=a2.version),typeof b2=="object"&&(b2=b2.version),a2!==b2;case"":case"=":case"==":return eq(a2,b2,loose);case"!=":return neq(a2,b2,loose);case">":return gt(a2,b2,loose);case">=":return gte(a2,b2,loose);case"<":return lt2(a2,b2,loose);case"<=":return lte(a2,b2,loose);default:throw new TypeError(`Invalid operator: ${op}`)}},"cmp");module.exports=cmp})),require_coerce=__commonJSMin(((exports,module)=>{var SemVer=require_semver$1(),parse=require_parse(),{safeRe:re2,t:t2}=require_re(),coerce=__name((version2,options)=>{if(version2 instanceof SemVer)return version2;if(typeof version2=="number"&&(version2=String(version2)),typeof version2!="string")return null;options=options||{};let match=null;if(!options.rtl)match=version2.match(options.includePrerelease?re2[t2.COERCEFULL]:re2[t2.COERCE]);else{const coerceRtlRegex=options.includePrerelease?re2[t2.COERCERTLFULL]:re2[t2.COERCERTL];let next;for(;(next=coerceRtlRegex.exec(version2))&&(!match||match.index+match[0].length!==version2.length);)(!match||next.index+next[0].length!==match.index+match[0].length)&&(match=next),coerceRtlRegex.lastIndex=next.index+next[1].length+next[2].length;coerceRtlRegex.lastIndex=-1}if(match===null)return null;const major=match[2];return parse(`${major}.${match[3]||"0"}.${match[4]||"0"}${options.includePrerelease&&match[5]?`-${match[5]}`:""}${options.includePrerelease&&match[6]?`+${match[6]}`:""}`,options)},"coerce");module.exports=coerce})),require_lrucache=__commonJSMin(((exports,module)=>{var LRUCache=class{static{__name(this,"LRUCache")}constructor(){this.max=1e3,this.map=new Map}get(key){const value=this.map.get(key);if(value!==void 0)return this.map.delete(key),this.map.set(key,value),value}delete(key){return this.map.delete(key)}set(key,value){if(!this.delete(key)&&value!==void 0){if(this.map.size>=this.max){const firstKey=this.map.keys().next().value;this.delete(firstKey)}this.map.set(key,value)}return this}};module.exports=LRUCache})),require_range=__commonJSMin(((exports,module)=>{var SPACE_CHARACTERS=/\s+/g,Range=class Range2{static{__name(this,"Range")}constructor(range,options){if(options=parseOptions(options),range instanceof Range2)return range.loose===!!options.loose&&range.includePrerelease===!!options.includePrerelease?range:new Range2(range.raw,options);if(range instanceof Comparator)return this.raw=range.value,this.set=[[range]],this.formatted=void 0,this;if(this.options=options,this.loose=!!options.loose,this.includePrerelease=!!options.includePrerelease,this.raw=range.trim().replace(SPACE_CHARACTERS," "),this.set=this.raw.split("||").map(r2=>this.parseRange(r2.trim())).filter(c2=>c2.length),!this.set.length)throw new TypeError(`Invalid SemVer Range: ${this.raw}`);if(this.set.length>1){const first=this.set[0];if(this.set=this.set.filter(c2=>!isNullSet(c2[0])),this.set.length===0)this.set=[first];else if(this.set.length>1){for(const c2 of this.set)if(c2.length===1&&isAny2(c2[0])){this.set=[c2];break}}}this.formatted=void 0}get range(){if(this.formatted===void 0){this.formatted="";for(let i2=0;i2<this.set.length;i2++){i2>0&&(this.formatted+="||");const comps=this.set[i2];for(let k2=0;k2<comps.length;k2++)k2>0&&(this.formatted+=" "),this.formatted+=comps[k2].toString().trim()}}return this.formatted}format(){return this.range}toString(){return this.range}parseRange(range){const memoKey=((this.options.includePrerelease&&FLAG_INCLUDE_PRERELEASE)|(this.options.loose&&FLAG_LOOSE))+":"+range,cached=cache2.get(memoKey);if(cached)return cached;const loose=this.options.loose,hr2=loose?re2[t2.HYPHENRANGELOOSE]:re2[t2.HYPHENRANGE];range=range.replace(hr2,hyphenReplace(this.options.includePrerelease)),debug("hyphen replace",range),range=range.replace(re2[t2.COMPARATORTRIM],comparatorTrimReplace),debug("comparator trim",range),range=range.replace(re2[t2.TILDETRIM],tildeTrimReplace),debug("tilde trim",range),range=range.replace(re2[t2.CARETTRIM],caretTrimReplace),debug("caret trim",range);let rangeList=range.split(" ").map(comp=>parseComparator(comp,this.options)).join(" ").split(/\s+/).map(comp=>replaceGTE0(comp,this.options));loose&&(rangeList=rangeList.filter(comp=>(debug("loose invalid filter",comp,this.options),!!comp.match(re2[t2.COMPARATORLOOSE])))),debug("range list",rangeList);const rangeMap=new Map,comparators=rangeList.map(comp=>new Comparator(comp,this.options));for(const comp of comparators){if(isNullSet(comp))return[comp];rangeMap.set(comp.value,comp)}rangeMap.size>1&&rangeMap.has("")&&rangeMap.delete("");const result=[...rangeMap.values()];return cache2.set(memoKey,result),result}intersects(range,options){if(!(range instanceof Range2))throw new TypeError("a Range is required");return this.set.some(thisComparators=>isSatisfiable(thisComparators,options)&&range.set.some(rangeComparators=>isSatisfiable(rangeComparators,options)&&thisComparators.every(thisComparator=>rangeComparators.every(rangeComparator=>thisComparator.intersects(rangeComparator,options)))))}test(version2){if(!version2)return!1;if(typeof version2=="string")try{version2=new SemVer(version2,this.options)}catch{return!1}for(let i2=0;i2<this.set.length;i2++)if(testSet(this.set[i2],version2,this.options))return!0;return!1}};module.exports=Range;var cache2=new(require_lrucache()),parseOptions=require_parse_options(),Comparator=require_comparator(),debug=require_debug(),SemVer=require_semver$1(),{safeRe:re2,t:t2,comparatorTrimReplace,tildeTrimReplace,caretTrimReplace}=require_re(),{FLAG_INCLUDE_PRERELEASE,FLAG_LOOSE}=require_constants(),isNullSet=__name(c2=>c2.value==="<0.0.0-0","isNullSet"),isAny2=__name(c2=>c2.value==="","isAny"),isSatisfiable=__name((comparators,options)=>{let result=!0;const remainingComparators=comparators.slice();let testComparator=remainingComparators.pop();for(;result&&remainingComparators.length;)result=remainingComparators.every(otherComparator=>testComparator.intersects(otherComparator,options)),testComparator=remainingComparators.pop();return result},"isSatisfiable"),parseComparator=__name((comp,options)=>(comp=comp.replace(re2[t2.BUILD],""),debug("comp",comp,options),comp=replaceCarets(comp,options),debug("caret",comp),comp=replaceTildes(comp,options),debug("tildes",comp),comp=replaceXRanges(comp,options),debug("xrange",comp),comp=replaceStars(comp,options),debug("stars",comp),comp),"parseComparator"),isX=__name(id=>!id||id.toLowerCase()==="x"||id==="*","isX"),replaceTildes=__name((comp,options)=>comp.trim().split(/\s+/).map(c2=>replaceTilde(c2,options)).join(" "),"replaceTildes"),replaceTilde=__name((comp,options)=>{const r2=options.loose?re2[t2.TILDELOOSE]:re2[t2.TILDE];return comp.replace(r2,(_2,M2,m2,p2,pr2)=>{debug("tilde",comp,_2,M2,m2,p2,pr2);let ret;return isX(M2)?ret="":isX(m2)?ret=`>=${M2}.0.0 <${+M2+1}.0.0-0`:isX(p2)?ret=`>=${M2}.${m2}.0 <${M2}.${+m2+1}.0-0`:pr2?(debug("replaceTilde pr",pr2),ret=`>=${M2}.${m2}.${p2}-${pr2} <${M2}.${+m2+1}.0-0`):ret=`>=${M2}.${m2}.${p2} <${M2}.${+m2+1}.0-0`,debug("tilde return",ret),ret})},"replaceTilde"),replaceCarets=__name((comp,options)=>comp.trim().split(/\s+/).map(c2=>replaceCaret(c2,options)).join(" "),"replaceCarets"),replaceCaret=__name((comp,options)=>{debug("caret",comp,options);const r2=options.loose?re2[t2.CARETLOOSE]:re2[t2.CARET],z2=options.includePrerelease?"-0":"";return comp.replace(r2,(_2,M2,m2,p2,pr2)=>{debug("caret",comp,_2,M2,m2,p2,pr2);let ret;return isX(M2)?ret="":isX(m2)?ret=`>=${M2}.0.0${z2} <${+M2+1}.0.0-0`:isX(p2)?M2==="0"?ret=`>=${M2}.${m2}.0${z2} <${M2}.${+m2+1}.0-0`:ret=`>=${M2}.${m2}.0${z2} <${+M2+1}.0.0-0`:pr2?(debug("replaceCaret pr",pr2),M2==="0"?m2==="0"?ret=`>=${M2}.${m2}.${p2}-${pr2} <${M2}.${m2}.${+p2+1}-0`:ret=`>=${M2}.${m2}.${p2}-${pr2} <${M2}.${+m2+1}.0-0`:ret=`>=${M2}.${m2}.${p2}-${pr2} <${+M2+1}.0.0-0`):(debug("no pr"),M2==="0"?m2==="0"?ret=`>=${M2}.${m2}.${p2}${z2} <${M2}.${m2}.${+p2+1}-0`:ret=`>=${M2}.${m2}.${p2}${z2} <${M2}.${+m2+1}.0-0`:ret=`>=${M2}.${m2}.${p2} <${+M2+1}.0.0-0`),debug("caret return",ret),ret})},"replaceCaret"),replaceXRanges=__name((comp,options)=>(debug("replaceXRanges",comp,options),comp.split(/\s+/).map(c2=>replaceXRange(c2,options)).join(" ")),"replaceXRanges"),replaceXRange=__name((comp,options)=>{comp=comp.trim();const r2=options.loose?re2[t2.XRANGELOOSE]:re2[t2.XRANGE];return comp.replace(r2,(ret,gtlt,M2,m2,p2,pr2)=>{debug("xRange",comp,ret,gtlt,M2,m2,p2,pr2);const xM=isX(M2),xm=xM||isX(m2),xp=xm||isX(p2),anyX=xp;return gtlt==="="&&anyX&&(gtlt=""),pr2=options.includePrerelease?"-0":"",xM?gtlt===">"||gtlt==="<"?ret="<0.0.0-0":ret="*":gtlt&&anyX?(xm&&(m2=0),p2=0,gtlt===">"?(gtlt=">=",xm?(M2=+M2+1,m2=0,p2=0):(m2=+m2+1,p2=0)):gtlt==="<="&&(gtlt="<",xm?M2=+M2+1:m2=+m2+1),gtlt==="<"&&(pr2="-0"),ret=`${gtlt+M2}.${m2}.${p2}${pr2}`):xm?ret=`>=${M2}.0.0${pr2} <${+M2+1}.0.0-0`:xp&&(ret=`>=${M2}.${m2}.0${pr2} <${M2}.${+m2+1}.0-0`),debug("xRange return",ret),ret})},"replaceXRange"),replaceStars=__name((comp,options)=>(debug("replaceStars",comp,options),comp.trim().replace(re2[t2.STAR],"")),"replaceStars"),replaceGTE0=__name((comp,options)=>(debug("replaceGTE0",comp,options),comp.trim().replace(re2[options.includePrerelease?t2.GTE0PRE:t2.GTE0],"")),"replaceGTE0"),hyphenReplace=__name(incPr=>($0,from,fM,fm,fp,fpr,fb,to,tM,tm,tp,tpr)=>(isX(fM)?from="":isX(fm)?from=`>=${fM}.0.0${incPr?"-0":""}`:isX(fp)?from=`>=${fM}.${fm}.0${incPr?"-0":""}`:fpr?from=`>=${from}`:from=`>=${from}${incPr?"-0":""}`,isX(tM)?to="":isX(tm)?to=`<${+tM+1}.0.0-0`:isX(tp)?to=`<${tM}.${+tm+1}.0-0`:tpr?to=`<=${tM}.${tm}.${tp}-${tpr}`:incPr?to=`<${tM}.${tm}.${+tp+1}-0`:to=`<=${to}`,`${from} ${to}`.trim()),"hyphenReplace"),testSet=__name((set,version2,options)=>{for(let i2=0;i2<set.length;i2++)if(!set[i2].test(version2))return!1;if(version2.prerelease.length&&!options.includePrerelease){for(let i2=0;i2<set.length;i2++)if(debug(set[i2].semver),set[i2].semver!==Comparator.ANY&&set[i2].semver.prerelease.length>0){const allowed=set[i2].semver;if(allowed.major===version2.major&&allowed.minor===version2.minor&&allowed.patch===version2.patch)return!0}return!1}return!0},"testSet")})),require_comparator=__commonJSMin(((exports,module)=>{var ANY=Symbol("SemVer ANY"),Comparator=class Comparator2{static{__name(this,"Comparator")}static get ANY(){return ANY}constructor(comp,options){if(options=parseOptions(options),comp instanceof Comparator2){if(comp.loose===!!options.loose)return comp;comp=comp.value}comp=comp.trim().split(/\s+/).join(" "),debug("comparator",comp,options),this.options=options,this.loose=!!options.loose,this.parse(comp),this.semver===ANY?this.value="":this.value=this.operator+this.semver.version,debug("comp",this)}parse(comp){const r2=this.options.loose?re2[t2.COMPARATORLOOSE]:re2[t2.COMPARATOR],m2=comp.match(r2);if(!m2)throw new TypeError(`Invalid comparator: ${comp}`);this.operator=m2[1]!==void 0?m2[1]:"",this.operator==="="&&(this.operator=""),m2[2]?this.semver=new SemVer(m2[2],this.options.loose):this.semver=ANY}toString(){return this.value}test(version2){if(debug("Comparator.test",version2,this.options.loose),this.semver===ANY||version2===ANY)return!0;if(typeof version2=="string")try{version2=new SemVer(version2,this.options)}catch{return!1}return cmp(version2,this.operator,this.semver,this.options)}intersects(comp,options){if(!(comp instanceof Comparator2))throw new TypeError("a Comparator is required");return this.operator===""?this.value===""?!0:new Range(comp.value,options).test(this.value):comp.operator===""?comp.value===""?!0:new Range(this.value,options).test(comp.semver):(options=parseOptions(options),options.includePrerelease&&(this.value==="<0.0.0-0"||comp.value==="<0.0.0-0")||!options.includePrerelease&&(this.value.startsWith("<0.0.0")||comp.value.startsWith("<0.0.0"))?!1:!!(this.operator.startsWith(">")&&comp.operator.startsWith(">")||this.operator.startsWith("<")&&comp.operator.startsWith("<")||this.semver.version===comp.semver.version&&this.operator.includes("=")&&comp.operator.includes("=")||cmp(this.semver,"<",comp.semver,options)&&this.operator.startsWith(">")&&comp.operator.startsWith("<")||cmp(this.semver,">",comp.semver,options)&&this.operator.startsWith("<")&&comp.operator.startsWith(">")))}};module.exports=Comparator;var parseOptions=require_parse_options(),{safeRe:re2,t:t2}=require_re(),cmp=require_cmp(),debug=require_debug(),SemVer=require_semver$1(),Range=require_range()})),require_satisfies=__commonJSMin(((exports,module)=>{var Range=require_range(),satisfies=__name((version2,range,options)=>{try{range=new Range(range,options)}catch{return!1}return range.test(version2)},"satisfies");module.exports=satisfies})),require_to_comparators=__commonJSMin(((exports,module)=>{var Range=require_range(),toComparators=__name((range,options)=>new Range(range,options).set.map(comp=>comp.map(c2=>c2.value).join(" ").trim().split(" ")),"toComparators");module.exports=toComparators})),require_max_satisfying=__commonJSMin(((exports,module)=>{var SemVer=require_semver$1(),Range=require_range(),maxSatisfying=__name((versions,range,options)=>{let max=null,maxSV=null,rangeObj=null;try{rangeObj=new Range(range,options)}catch{return null}return versions.forEach(v2=>{rangeObj.test(v2)&&(!max||maxSV.compare(v2)===-1)&&(max=v2,maxSV=new SemVer(max,options))}),max},"maxSatisfying");module.exports=maxSatisfying})),require_min_satisfying=__commonJSMin(((exports,module)=>{var SemVer=require_semver$1(),Range=require_range(),minSatisfying=__name((versions,range,options)=>{let min=null,minSV=null,rangeObj=null;try{rangeObj=new Range(range,options)}catch{return null}return versions.forEach(v2=>{rangeObj.test(v2)&&(!min||minSV.compare(v2)===1)&&(min=v2,minSV=new SemVer(min,options))}),min},"minSatisfying");module.exports=minSatisfying})),require_min_version=__commonJSMin(((exports,module)=>{var SemVer=require_semver$1(),Range=require_range(),gt=require_gt(),minVersion=__name((range,loose)=>{range=new Range(range,loose);let minver=new SemVer("0.0.0");if(range.test(minver)||(minver=new SemVer("0.0.0-0"),range.test(minver)))return minver;minver=null;for(let i2=0;i2<range.set.length;++i2){const comparators=range.set[i2];let setMin=null;comparators.forEach(comparator=>{const compver=new SemVer(comparator.semver.version);switch(comparator.operator){case">":compver.prerelease.length===0?compver.patch++:compver.prerelease.push(0),compver.raw=compver.format();case"":case">=":(!setMin||gt(compver,setMin))&&(setMin=compver);break;case"<":case"<=":break;default:throw new Error(`Unexpected operation: ${comparator.operator}`)}}),setMin&&(!minver||gt(minver,setMin))&&(minver=setMin)}return minver&&range.test(minver)?minver:null},"minVersion");module.exports=minVersion})),require_valid=__commonJSMin(((exports,module)=>{var Range=require_range(),validRange=__name((range,options)=>{try{return new Range(range,options).range||"*"}catch{return null}},"validRange");module.exports=validRange})),require_outside=__commonJSMin(((exports,module)=>{var SemVer=require_semver$1(),Comparator=require_comparator(),{ANY}=Comparator,Range=require_range(),satisfies=require_satisfies(),gt=require_gt(),lt2=require_lt(),lte=require_lte(),gte=require_gte(),outside=__name((version2,range,hilo,options)=>{version2=new SemVer(version2,options),range=new Range(range,options);let gtfn,ltefn,ltfn,comp,ecomp;switch(hilo){case">":gtfn=gt,ltefn=lte,ltfn=lt2,comp=">",ecomp=">=";break;case"<":gtfn=lt2,ltefn=gte,ltfn=gt,comp="<",ecomp="<=";break;default:throw new TypeError('Must provide a hilo val of "<" or ">"')}if(satisfies(version2,range,options))return!1;for(let i2=0;i2<range.set.length;++i2){const comparators=range.set[i2];let high=null,low=null;if(comparators.forEach(comparator=>{comparator.semver===ANY&&(comparator=new Comparator(">=0.0.0")),high=high||comparator,low=low||comparator,gtfn(comparator.semver,high.semver,options)?high=comparator:ltfn(comparator.semver,low.semver,options)&&(low=comparator)}),high.operator===comp||high.operator===ecomp||(!low.operator||low.operator===comp)&&ltefn(version2,low.semver))return!1;if(low.operator===ecomp&&ltfn(version2,low.semver))return!1}return!0},"outside");module.exports=outside})),require_gtr=__commonJSMin(((exports,module)=>{var outside=require_outside(),gtr=__name((version2,range,options)=>outside(version2,range,">",options),"gtr");module.exports=gtr})),require_ltr=__commonJSMin(((exports,module)=>{var outside=require_outside(),ltr=__name((version2,range,options)=>outside(version2,range,"<",options),"ltr");module.exports=ltr})),require_intersects=__commonJSMin(((exports,module)=>{var Range=require_range(),intersects=__name((r1,r2,options)=>(r1=new Range(r1,options),r2=new Range(r2,options),r1.intersects(r2,options)),"intersects");module.exports=intersects})),require_simplify=__commonJSMin(((exports,module)=>{var satisfies=require_satisfies(),compare=require_compare();module.exports=(versions,range,options)=>{const set=[];let first=null,prev=null;const v2=versions.sort((a2,b2)=>compare(a2,b2,options));for(const version2 of v2)satisfies(version2,range,options)?(prev=version2,first||(first=version2)):(prev&&set.push([first,prev]),prev=null,first=null);first&&set.push([first,null]);const ranges=[];for(const[min,max]of set)min===max?ranges.push(min):!max&&min===v2[0]?ranges.push("*"):max?min===v2[0]?ranges.push(`<=${max}`):ranges.push(`${min} - ${max}`):ranges.push(`>=${min}`);const simplified=ranges.join(" || "),original=typeof range.raw=="string"?range.raw:String(range);return simplified.length<original.length?simplified:range}})),require_subset=__commonJSMin(((exports,module)=>{var Range=require_range(),Comparator=require_comparator(),{ANY}=Comparator,satisfies=require_satisfies(),compare=require_compare(),subset=__name((sub,dom,options={})=>{if(sub===dom)return!0;sub=new Range(sub,options),dom=new Range(dom,options);let sawNonNull=!1;OUTER:for(const simpleSub of sub.set){for(const simpleDom of dom.set){const isSub=simpleSubset(simpleSub,simpleDom,options);if(sawNonNull=sawNonNull||isSub!==null,isSub)continue OUTER}if(sawNonNull)return!1}return!0},"subset"),minimumVersionWithPreRelease=[new Comparator(">=0.0.0-0")],minimumVersion=[new Comparator(">=0.0.0")],simpleSubset=__name((sub,dom,options)=>{if(sub===dom)return!0;if(sub.length===1&&sub[0].semver===ANY){if(dom.length===1&&dom[0].semver===ANY)return!0;options.includePrerelease?sub=minimumVersionWithPreRelease:sub=minimumVersion}if(dom.length===1&&dom[0].semver===ANY){if(options.includePrerelease)return!0;dom=minimumVersion}const eqSet=new Set;let gt,lt2;for(const c2 of sub)c2.operator===">"||c2.operator===">="?gt=higherGT(gt,c2,options):c2.operator==="<"||c2.operator==="<="?lt2=lowerLT(lt2,c2,options):eqSet.add(c2.semver);if(eqSet.size>1)return null;let gtltComp;if(gt&&lt2){if(gtltComp=compare(gt.semver,lt2.semver,options),gtltComp>0)return null;if(gtltComp===0&&(gt.operator!==">="||lt2.operator!=="<="))return null}for(const eq of eqSet){if(gt&&!satisfies(eq,String(gt),options)||lt2&&!satisfies(eq,String(lt2),options))return null;for(const c2 of dom)if(!satisfies(eq,String(c2),options))return!1;return!0}let higher,lower,hasDomLT,hasDomGT,needDomLTPre=lt2&&!options.includePrerelease&&lt2.semver.prerelease.length?lt2.semver:!1,needDomGTPre=gt&&!options.includePrerelease&&gt.semver.prerelease.length?gt.semver:!1;needDomLTPre&&needDomLTPre.prerelease.length===1&&lt2.operator==="<"&&needDomLTPre.prerelease[0]===0&&(needDomLTPre=!1);for(const c2 of dom){if(hasDomGT=hasDomGT||c2.operator===">"||c2.operator===">=",hasDomLT=hasDomLT||c2.operator==="<"||c2.operator==="<=",gt){if(needDomGTPre&&c2.semver.prerelease&&c2.semver.prerelease.length&&c2.semver.major===needDomGTPre.major&&c2.semver.minor===needDomGTPre.minor&&c2.semver.patch===needDomGTPre.patch&&(needDomGTPre=!1),c2.operator===">"||c2.operator===">="){if(higher=higherGT(gt,c2,options),higher===c2&&higher!==gt)return!1}else if(gt.operator===">="&&!satisfies(gt.semver,String(c2),options))return!1}if(lt2){if(needDomLTPre&&c2.semver.prerelease&&c2.semver.prerelease.length&&c2.semver.major===needDomLTPre.major&&c2.semver.minor===needDomLTPre.minor&&c2.semver.patch===needDomLTPre.patch&&(needDomLTPre=!1),c2.operator==="<"||c2.operator==="<="){if(lower=lowerLT(lt2,c2,options),lower===c2&&lower!==lt2)return!1}else if(lt2.operator==="<="&&!satisfies(lt2.semver,String(c2),options))return!1}if(!c2.operator&&(lt2||gt)&&gtltComp!==0)return!1}return!(gt&&hasDomLT&&!lt2&&gtltComp!==0||lt2&&hasDomGT&&!gt&&gtltComp!==0||needDomGTPre||needDomLTPre)},"simpleSubset"),higherGT=__name((a2,b2,options)=>{if(!a2)return b2;const comp=compare(a2.semver,b2.semver,options);return comp>0?a2:comp<0||b2.operator===">"&&a2.operator===">="?b2:a2},"higherGT"),lowerLT=__name((a2,b2,options)=>{if(!a2)return b2;const comp=compare(a2.semver,b2.semver,options);return comp<0?a2:comp>0||b2.operator==="<"&&a2.operator==="<="?b2:a2},"lowerLT");module.exports=subset})),require_semver=__commonJSMin(((exports,module)=>{var internalRe=require_re(),constants=require_constants(),SemVer=require_semver$1(),identifiers=require_identifiers(),parse=require_parse(),valid=require_valid$1(),clean=require_clean(),inc=require_inc(),diff=require_diff(),major=require_major(),minor=require_minor(),patch=require_patch(),prerelease=require_prerelease(),compare=require_compare(),rcompare=require_rcompare(),compareLoose=require_compare_loose(),compareBuild=require_compare_build(),sort=require_sort(),rsort=require_rsort(),gt=require_gt(),lt2=require_lt(),eq=require_eq(),neq=require_neq(),gte=require_gte(),lte=require_lte(),cmp=require_cmp(),coerce=require_coerce(),Comparator=require_comparator(),Range=require_range(),satisfies=require_satisfies(),toComparators=require_to_comparators(),maxSatisfying=require_max_satisfying(),minSatisfying=require_min_satisfying(),minVersion=require_min_version(),validRange=require_valid(),outside=require_outside(),gtr=require_gtr(),ltr=require_ltr(),intersects=require_intersects(),simplifyRange=require_simplify(),subset=require_subset();module.exports={parse,valid,clean,inc,diff,major,minor,patch,prerelease,compare,rcompare,compareLoose,compareBuild,sort,rsort,gt,lt:lt2,eq,neq,gte,lte,cmp,coerce,Comparator,Range,satisfies,toComparators,maxSatisfying,minSatisfying,minVersion,validRange,outside,gtr,ltr,intersects,simplifyRange,subset,SemVer,re:internalRe.re,src:internalRe.src,tokens:internalRe.t,SEMVER_SPEC_VERSION:constants.SEMVER_SPEC_VERSION,RELEASE_TYPES:constants.RELEASE_TYPES,compareIdentifiers:identifiers.compareIdentifiers,rcompareIdentifiers:identifiers.rcompareIdentifiers}})),import_semver=require_semver(),STORAGE_KEY="react-scan-options",EXTENSION_STORAGE_KEY="react-scan-extension",isIframe=window!==window.top,isPopup=window.opener!==null,canLoadReactScan=!isIframe&&!isPopup,IS_CLIENT=typeof window<"u",ReactDetection={limits:{MAX_DEPTH:10,MAX_ELEMENTS:30,ELEMENTS_PER_LEVEL:5},nonVisualTags:new Set(["HTML","HEAD","META","TITLE","BASE","SCRIPT","STYLE","LINK","NOSCRIPT","SOURCE","TRACK","EMBED","OBJECT","PARAM","TEMPLATE","PORTAL","SLOT","AREA","XML","DOCTYPE","COMMENT"]),reactMarkers:{root:"_reactRootContainer",fiber:"__reactFiber",instance:"__reactInternalInstance$",container:"__reactContainer$"}},childrenCache=new WeakMap,hasReactFiber=__name(()=>{const rootElement=document.body;let elementsChecked=0;const getChildren=__name(element=>{let children=childrenCache.get(element);if(!children){const childNodes=element.children;children=[];for(let i2=0;i2<childNodes.length;i2++){const child=childNodes[i2];ReactDetection.nonVisualTags.has(child.tagName)||children.push(child)}childrenCache.set(element,children)}return children},"getChildren"),checkElement=__name((element,depth)=>{if(elementsChecked>=ReactDetection.limits.MAX_ELEMENTS)return!1;elementsChecked++;const props=Object.getOwnPropertyNames(element);if(ReactDetection.reactMarkers.root in element){const elementWithRoot=element,hasLegacyRoot=elementWithRoot._reactRootContainer?._internalRoot?.current?.child!=null,hasContainerRoot=Object.keys(elementWithRoot).some(key=>key.startsWith(ReactDetection.reactMarkers.container));return hasLegacyRoot||hasContainerRoot}for(const key of props)if(key.startsWith(ReactDetection.reactMarkers.fiber)||key.startsWith(ReactDetection.reactMarkers.instance))return!0;if(depth<ReactDetection.limits.MAX_DEPTH){const children=getChildren(element),maxCheck=Math.min(children.length,ReactDetection.limits.ELEMENTS_PER_LEVEL);for(let i2=0;i2<maxCheck;i2++)if(checkElement(children[i2],depth+1))return!0}return!1},"checkElement");return checkElement(rootElement,0)},"hasReactFiber"),readLocalStorage=__name(storageKey=>{if(!IS_CLIENT)return null;try{const stored=localStorage.getItem(storageKey);return stored?JSON.parse(stored):null}catch{return null}},"readLocalStorage"),saveLocalStorage=__name((storageKey,state)=>{if(IS_CLIENT)try{window.localStorage.setItem(storageKey,JSON.stringify(state))}catch{}},"saveLocalStorage"),eventBus=new Map,busSubscribe=__name((event,callback)=>(eventBus.has(event)||eventBus.set(event,new Set),eventBus.get(event).add(callback),()=>{const callbacks=eventBus.get(event);callbacks&&(callbacks.delete(callback),callbacks.size===0&&eventBus.delete(event))}),"busSubscribe"),busDispatch=__name((event,data)=>{const callbacks=eventBus.get(event);callbacks&&callbacks.forEach(callback=>callback(data))},"busDispatch"),sleep=__name(ms=>new Promise(resolve=>setTimeout(resolve,ms)),"sleep"),isStorageRecord=__name(value=>typeof value=="object"&&value!==null,"isStorageRecord"),storageGetItem=__name(async(storageKey,key)=>{try{const data=(await chrome.storage.local.get(storageKey))[storageKey];if(!isStorageRecord(data))return null;const value=data[key];return value===void 0?null:value}catch{return null}},"storageGetItem"),storageSetItem=__name(async(storageKey,key,value)=>{try{const data=(await chrome.storage.local.get(storageKey))[storageKey],updatedData={...isStorageRecord(data)?data:{},[key]:value};await chrome.storage.local.set({[storageKey]:updatedData})}catch{}},"storageSetItem"),no_react_default="html.freeze>body{pointer-events:none}html.freeze{overscroll-behavior-x:contain;overflow:auto}html.freeze svg{pointer-events:none}html.freeze #react-scan-toast{pointer-events:auto}#react-scan-backdrop{-webkit-backdrop-filter:blur(94px)saturate(180%);backdrop-filter:blur(94px)saturate(180%);opacity:0;pointer-events:none;z-index:2147483647;background-color:#00000003;transition:opacity .5s;animation-duration:.3s;position:fixed;inset:0}#react-scan-toast{color:#fff;z-index:2147483647;background:#000000f2;border:1px solid #ffffff1a;border-radius:8px;flex-direction:column;min-width:320px;max-width:480px;padding:12px 40px 12px 16px;font-family:Menlo,Consolas,Monaco,Liberation Mono,Lucida Console,monospace;font-size:12px;line-height:1.5;transition:opacity .3s ease-in-out;display:flex;position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);box-shadow:0 4px 12px #0003}#react-scan-toast-title{margin:0 0 8px}#react-scan-toast-message{align-items:flex-start;display:flex}#react-scan-toast-message span{white-space:pre-line}#react-scan-toast .icon{margin-right:8px;font-size:.75rem}@media (width<=320px){#react-scan-toast{flex-direction:column;width:calc(100% - 36px);min-width:auto}}@media (width<=720px){#react-scan-toast br{display:none}}#react-scan-toast-close-button{color:#fff;cursor:pointer;background:#ffffff03;border:none;border-radius:4px;align-items:center;width:23px;height:23px;padding:4px;transition:background-color .3s;display:flex;position:absolute;top:10px;right:8px}#react-scan-toast-close-button:hover{background-color:#ffffff26}",backdrop=null,isAnimating=!1,defaultTitle="React Not Detected",defaultContent=`React is not detected on this page. 
Please ensure you're visiting a React application!`,createNotificationUI=__name(({title=defaultTitle,content=defaultContent})=>{if(busDispatch("react-scan:send-to-background",{topic:"react-scan:send-to-background",message:{type:"react-scan:is-enabled",data:{state:!1}}}),backdrop)return;backdrop=document.createElement("div"),backdrop.id="react-scan-backdrop",backdrop.style.opacity="0",backdrop.style.pointerEvents="none";const toast=document.createElement("div");toast.id="react-scan-toast",toast.onclick=e2=>{e2.stopPropagation()};const titleElement=document.createElement("div");titleElement.id="react-scan-toast-title";const icon=document.createElement("span");icon.className="icon",icon.textContent="⚛️",titleElement.appendChild(icon);const titleText=document.createElement("span");titleText.textContent=title,titleElement.appendChild(titleText),toast.appendChild(titleElement);const messageElement=document.createElement("div");messageElement.id="react-scan-toast-message";const text=document.createElement("span");text.textContent=content,text.style.whiteSpace="pre-line",messageElement.appendChild(text),toast.appendChild(messageElement);const button=document.createElement("button");button.id="react-scan-toast-close-button",button.type="button",button.onclick=toggleNotification;const svg=document.createElementNS("http://www.w3.org/2000/svg","svg");svg.setAttribute("width","15"),svg.setAttribute("height","15"),svg.setAttribute("viewBox","0 0 24 24"),svg.setAttribute("fill","none"),svg.setAttribute("stroke","currentColor"),svg.setAttribute("stroke-width","2"),svg.setAttribute("stroke-linecap","round"),svg.setAttribute("stroke-linejoin","round");const line1=document.createElementNS("http://www.w3.org/2000/svg","line");line1.setAttribute("x1","18"),line1.setAttribute("y1","6"),line1.setAttribute("x2","6"),line1.setAttribute("y2","18");const line2=document.createElementNS("http://www.w3.org/2000/svg","line");line2.setAttribute("x1","6"),line2.setAttribute("y1","6"),line2.setAttribute("x2","18"),line2.setAttribute("y2","18"),svg.appendChild(line1),svg.appendChild(line2),button.appendChild(svg),toast.appendChild(button),backdrop.appendChild(toast),backdrop.onclick=toggleNotification;const style=document.createElement("style");style.id="react-scan-no-react-styles",style.appendChild(document.createTextNode(no_react_default));const fragment=document.createDocumentFragment();fragment.appendChild(style),fragment.appendChild(backdrop),document.documentElement.appendChild(fragment)},"createNotificationUI"),toggleNotification=__name(()=>{if(!backdrop||isAnimating)return;isAnimating=!0;const handleTransitionEnd=__name(()=>{isAnimating=!1,backdrop?.removeEventListener("transitionend",handleTransitionEnd)},"handleTransitionEnd");backdrop.addEventListener("transitionend",handleTransitionEnd);const isVisible=backdrop.style.opacity==="1";backdrop.style.opacity=isVisible?"0":"1",backdrop.style.pointerEvents=isVisible?"none":"auto",document.documentElement.classList.toggle("freeze",!isVisible)},"toggleNotification"),reactScanExtensionVersion="version"in ReactScanInternals?ReactScanInternals.version:void 0,isTargetPageAlreadyUsedReactScan=__name(()=>{const currentReactScanVersion=window.__REACT_SCAN_VERSION__;return window.__REACT_SCAN__?.ReactScanInternals?.Store?.monitor?.value&&!currentReactScanVersion?!0:!reactScanExtensionVersion||!currentReactScanVersion?!1:(0,import_semver.gt)(currentReactScanVersion,reactScanExtensionVersion)},"isTargetPageAlreadyUsedReactScan"),getInitialOptions=__name(async()=>{const storedOptions=readLocalStorage(STORAGE_KEY);let isEnabled=!1;try{isEnabled=await storageGetItem("react-scan-extension","isEnabled")??!1}catch{}return{...storedOptions,enabled:isEnabled,showToolbar:isEnabled,dangerouslyForceRunInProduction:!0}},"getInitialOptions"),initializeReactScan=__name(async()=>{const options=await getInitialOptions();window.__REACT_SCAN_EXTENSION__=!0,options.enabled&&(window.hideIntro=!0,scan(options),window.reactScan=void 0)},"initializeReactScan"),timer,updateReactScanState=__name(async isEnabled=>{clearTimeout(timer);const toggledState=isEnabled===null?!0:!isEnabled;try{await storageSetItem(EXTENSION_STORAGE_KEY,"isEnabled",toggledState)}catch{}saveLocalStorage(STORAGE_KEY,{...readLocalStorage("react-scan-options")??{},enabled:toggledState,showToolbar:toggledState,dangerouslyForceRunInProduction:!0}),window.location.reload()},"updateReactScanState");initializeReactScan(),window.addEventListener("DOMContentLoaded",async()=>{if(!canLoadReactScan)return;let isReactAvailable=!1;if(await sleep(1e3),isReactAvailable=await hasReactFiber(),!isReactAvailable){createNotificationUI({title:"React Not Detected",content:`React is not detected on this page.
Please ensure you're visiting a React application.`}),busDispatch("react-scan:send-to-background",{topic:"react-scan:send-to-background",message:{type:"react-scan:is-enabled",data:{state:!1}}}),busSubscribe("react-scan:toggle-state",async()=>{toggleNotification()});return}if(isTargetPageAlreadyUsedReactScan()){createNotificationUI({title:"Already Initialized",content:"React Scan is already initialized on this page."}),busDispatch("react-scan:send-to-background",{topic:"react-scan:send-to-background",message:{type:"react-scan:is-enabled",data:{state:!1}}}),busSubscribe("react-scan:toggle-state",async()=>{toggleNotification()});return}const storedOptions=readLocalStorage(STORAGE_KEY);storedOptions!==null&&busDispatch("react-scan:send-to-background",{topic:"react-scan:send-to-background",message:{type:"react-scan:is-enabled",data:{state:storedOptions.showToolbar}}}),isTargetPageAlreadyUsedReactScan()||(window.reactScan=setOptions),busSubscribe("react-scan:toggle-state",async()=>{if(!isReactAvailable||isTargetPageAlreadyUsedReactScan()){toggleNotification();return}try{await updateReactScanState(!!await storageGetItem(EXTENSION_STORAGE_KEY,"isEnabled"))}catch{await updateReactScanState(null)}})})})();
